﻿using eIRTAdmin.Models;
using eIRTAdmin.Models.APIModels;
using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace eIRTAdmin.Services.Interface
{
    public interface IIncidentReportService
    {
        Task<APIListAndCountIncidentReport> GetIncidentReportsAsync(APISearchInfo searchInfo);
        Task<APIIncidentReport> AddIncidentReportAsync(APIIncidentReport incidentReport);
        Task<APIIncidentReport> GetIncidentReportAsync(APIId apiId);
        Task<APIIncidentReport> UpdateIncidentReportAsync(int Id, APIIncidentReport incidentReport);
        Task DeleteIncidentReportAsync(int Id);
        Task UploadIncidentReportPhoto(int Id, IFormFile img);
        Task<bool> IsExistAsync(APIIsExistInput apiIsExistInput);
        Task<List<APIIncidentReport>> GetIncidentReportsList(APISearchInfo searchInfo);
        Task<bool> IsIncidentCreatedAsync(APIIsIncidentCreated incidentCreated);
        Task<List<APIIncidentReport>> GetSingleIncidentReportsList(APIId id);
        Task<APIListAndCountIncidentReport> GetAllIncidentDetailsAsync(APISearchInfo searchInfo); 
        Task<APIListAndCountIncidentReport> GetIncidentReportsForManagersAsync(APISearchInfoForManagers searchInfo);
        Task<APIIncidentReportCount> GetCountOfAllStatus();
        Task<APIOpenClosedIncidentReport> GetOpenClosedIncidentsReport(APIOpenClosedIncidentSearch searchInfo);
        Task<Stream> ExportXlsxAsync(APIOpenClosedIncidentSearch incidentSearch);
        Task<APIListAndCountIncidentReport> GetReportedIncidentsAsync(APISearchIncident searchInfo);
        Task<APIFileBase64Model> GetImageBase64ContentAsync(int id);
    }
}
