﻿using eIRTAdmin.Models.APIModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace eIRTAdmin.Services.Interface
{
    public interface IIncidentAssignmentService
    {        
        Task<APIListAndCountIncidentAssignment> GetIncidentAssignmentsAsync(APISearchIncidentAssignment searchInfo);
        Task<APIIncidentAssignment> UpdateIncidentAssignmentAsync(int Id, APIIncidentAssignment incidentAssignment);
        Task DeleteIncidentAssignmentAsync(int Id);
        Task<APIIncidentAssignment> AddIncidentAssignmentAsync(APIIncidentAssignment incidentAssignment);
        Task<APIIncidentAssignment> GetIncidentAssignmentAsync(APIId apiId);
        Task<List<APIIncidentReport>> GetIncidentsForActionTaken(APISearchInfo searchInfo);
    }
}
