﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using eIRTAdmin.Models.APIModels;
using eIRTAdmin.Models;
using System.IO;
using Newtonsoft.Json.Linq;
using Microsoft.AspNetCore.Http;

namespace eIRTAdmin.Services
{
    public interface IUserMasterService
    {
        Task<APIUserDetails> GetUserAsync(int id);
        Task<List<APIUserSignUp>> GetUsersAsync();
        Task<APIListAndCountforUserMaster> GetUsersForPAAsync(APISearchInfo apiSearchInfo);
        Task<APIListAndCountforUserMaster> GetUsersForCAAsync(APISearchInfo apiSearchInfo);
        Task<int> GetUsersCountAsync(string filter = null, string search = null);
        Task<APIUserSignUp> SignUpUserAsync(APIUserSignUp User);        //register user
        //bool SendOTP(JObject OTPDetails);
        Task<APIUserSignUp> UpdateUserAsync(APIUserSignUp User);
        Task<IsSuccess> ResendOTPAsync(Guid guId);
        Task<string> GetUserOTPAsync(Guid guId);
        Task<bool> ValidateUserOtpAsync(UserOptValidate otpDetails);
        Task SetUserPassword(APIUserPassword userPassword);
        Task<IsSuccess> ChangeUserPassword(APIUserMasterPasswordChange userPassword);
        Task<Stream> ExportXlsxAsync(string filter = null, string search = null);
        Task DeleteUserAsync(Guid guId);
        Task<bool> IsExistAsync(string FieldName, string value);
        Task<bool> UserLogout();
        Task<APIUserInfo> GetUserInfoByMobileNumber(APIUserMobile userMobile);
        
        Task<APIUserDetails> AddUserDetailsForPAAsync(APIUserDetails apiUserDetails); 
        Task<ResponseError> UpdateUserProfilePic(int Id, Guid guid, IFormFile icon);
        Task<APIUserDetails> AddUserDetailsForCAAsync(APIUserDetails apiUserDetails);
        Task<APIUserDetails> UpdateUserDetailsForPAAsync(int id, APIUserDetails apiUserDetails);
        Task<APIUserDetails> UpdateUserDetailsForCAAsync(int id, APIUserDetails apiUserDetails); 
        Task DeleteUserDetailsForPAAsync(int id);
        Task DeleteUserDetailsForCAAsync(int id);
        Task<int> GetActiveUsersCountAsync();
        Task<bool> IsExistAsync(APIIsExistInput apiIsExistInput);        
        Task<APIUserProfile> GetUserProfileAsync();
        Task<APIUserProfile> AddUserProfileAsync(APIUserProfile userProfile);
        Task<APIUserProfile> UpdateUserProfileAsync(int Id, APIUserProfile userProfile);
        Task<APIUserProfile> GetUserProfileAsync(int Id);
        Task<APIFileBase64Model> GetUserProfilePic();
        Task<APIUserSecurityQuestion> GetUserSecurityQuestionAsync();
        Task<IsSuccess> ForgotPasswordAsync(APIForgotPassword userPassword);
    }
}
