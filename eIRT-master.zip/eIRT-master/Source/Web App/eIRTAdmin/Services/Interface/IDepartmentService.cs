﻿using eIRTAdmin.Models;
using eIRTAdmin.Models.APIModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace eIRTAdmin.Services.Interface
{
    public interface IDepartmentService
    {
        Task<APIListAndCountDepartment> GetDepartmentsAsync(APISearchInfo searchInfo);

        Task<List<APIDepartments>> GetDepartmentByOrganization(APIDepartmentsWithOrganization aPIDepartments);
        Task<APIDepartments> UpdateDepartmentAsync(int Id, APIDepartments departments);
        Task DeleteDepartmentAsync(int Id);
        Task<APIDepartments> AddDepartmentAsync(APIDepartments departments);
        Task<APIDepartments> GetDepartmentAsync(APIId apiId);
        Task<bool> IsExistAsync(APIIsExistInput apiIsExistInput);
    }
}
