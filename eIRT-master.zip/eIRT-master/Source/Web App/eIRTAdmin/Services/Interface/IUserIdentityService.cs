﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using eIRTAdmin.Models;

namespace eIRTAdmin.Services
{
    public interface IUserIdentityService
    {
        Task<IdentityResponseModel> GetTokenAsync(string UserId, string Password, string organizationCode);
    }
}
