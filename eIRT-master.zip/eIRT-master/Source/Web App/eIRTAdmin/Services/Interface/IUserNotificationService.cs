﻿using eIRTAdmin.Models.APIModels;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace eIRTAdmin.Services
{
    public interface IUserNotificationService
    {
        Task<List<APIUserNotifications>> GetUserNotifications();
        Task<bool> ReadNotification(int notificationId);
    }
}
