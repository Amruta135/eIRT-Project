﻿using eIRTAdmin.Models;
using eIRTAdmin.Models.APIModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace eIRTAdmin.Services.Interface
{
    public interface IRolesConfigurationService
    {        
        Task<APIListAndCountRoleConfig> GetRolesConfigurationsAsync(APISearchInfo searchInfo);
        Task<APIRolesConfigurations> GetRoleConfigurationAsync(APIId apiId);
        Task<APIRolesConfigurations> UpdateRolesConfigurationAsync(int Id, APIRolesConfigurations apiRolesConfigurations);
        Task DeleteRolesConfigurationAsync(int Id);
        Task<APIRolesConfigurations> AddRolesConfigurationAsync(APIRolesConfigurations apiRolesConfigurations);
        Task<bool> IsExistAsync(APIIsExistInput apiIsExistInput);
    }
}
