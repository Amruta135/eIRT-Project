﻿using eIRTAdmin.Models.APIModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace eIRTAdmin.Services.Interface
{
    public interface ISecurityQuestionService
    {
        Task<List<APISecurityQuestion>> GetAllQuestionsAsync();
    }
}
