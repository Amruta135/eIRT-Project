﻿using eIRTAdmin.Models.APIModels;
using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace eIRTAdmin.Services.Interface
{
    public interface IOrganizationInfoService
    {
        Task<APIListAndCount> GetOrganizationInfosAsync(APISearchInfo searchInfo);
        Task<APIOrganizationInfo> AddOrganizationInfoAsync(APIOrganizationInfo apiOrganizationInfo);
        Task<APIOrganizationInfo> GetOrganizationInfoAsync(APIId organizationInfoId);
        Task<APIOrganizationInfo> UpdateOrganizationInfoAsync(int Id, APIOrganizationInfo organizationInfo);
        Task DeleteOrganizationInfoAsync(int Id);
        Task UploadOrganizationLogo(int Id, IFormFile img);
        Task<bool> IsExistAsync(string FieldName, string value);
        Task<int> GetOrganizationMaxUsers();
        Task<APIOrganizationInfo> GetCurrentUserOrganizationAsync();
        Task<APIFileBase64Model> GetImageBase64ContentAsync(int id);
    }
}
