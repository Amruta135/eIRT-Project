﻿using eIRTAdmin.Models;
using eIRTAdmin.Models.APIModels;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace eIRTAdmin.Services.Interface
{
    public interface ICompetencyService
    {
        Task<APICompetency> GetCompetencyAsync(APIId apiId);
        Task<APIListAndCountCompetencies> GetCompetenciesAsync(APISearchInfo searchInfo);
        Task<List<APICompetency>> GetAllCompetenciesAsync();
        Task<IsSuccess> AddCompetencyAsync(APICompetency info);
        Task<IsSuccess> UpdateCompetencyAsync(APICompetency info);
        Task<IsSuccess> DeleteCompetencyAsync(APIId apiId);
        Task<bool> IsExistAsync(APIIsExistInput apiIsExistInput);
    }
}
