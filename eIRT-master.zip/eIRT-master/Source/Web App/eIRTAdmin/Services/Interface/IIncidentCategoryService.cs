﻿using eIRTAdmin.Models;
using eIRTAdmin.Models.APIModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace eIRTAdmin.Services.Interface
{
    public interface IIncidentCategoryService
    {
        Task<APIListAndCountIncident> GetIncidentCategorysAsync(APISearchInfo searchInfo);
        Task<APIIncidentCategory> UpdateIncidentCategoryAsync(int Id, APIIncidentCategory incidentCategory);
        Task<APIIncidentCategory> AddIncidentCategoryAsync(APIIncidentCategory incidentCategory);
        Task<APIIncidentCategory> GetIncidentCategoryAsync(APIId apiId);
        Task<bool> IsExistAsync(APIIsExistInput apiIsExistInput);
    }
}
