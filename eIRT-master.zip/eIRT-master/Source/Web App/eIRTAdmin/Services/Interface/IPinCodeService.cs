﻿using eIRTAdmin.Models.APIModels;
using System.Threading.Tasks;

namespace eIRTAdmin.Services
{
    public interface IPinCodeService
    {
        Task<APIPinCode> GetStateByPincode(string pincode);
    }
}
