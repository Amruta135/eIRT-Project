﻿using eIRTAdmin.Models.APIModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace eIRTAdmin.Services.Interface
{
    public interface IActionTakenReportService
    {
        Task<APIListAndCountActionTakenRpt> GetActionTakenReportsAsync(APISearchActionTeken searchInfo);
        Task<APIActionTakenReport> UpdateActionTakenReportAsync(int Id, APIActionTakenReport actionTakenReport);
        Task DeleteActionTakenReportAsync(int Id);
        Task<APIActionTakenReport> AddActionTakenReportAsync(APIActionTakenReport actionTakenReport);
        Task<APIActionTakenReport> GetActionTakenReportAsync(APIId apiId);
    }
}
