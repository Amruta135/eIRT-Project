﻿using eIRTAdmin.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace eIRTAdmin.Services
{
    public interface IUserDetailsService
    {
        Task<UserDetails> GetUserDetailsAsync(string token);
        Task<bool> UserLogout(string token);

        Task<string> GetUserProfilePic(string token);
    }
}
