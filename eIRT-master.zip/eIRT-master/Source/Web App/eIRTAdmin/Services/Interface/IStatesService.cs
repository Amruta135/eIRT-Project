﻿using eIRTAdmin.Models.APIModels;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace eIRTAdmin.Services
{
    public interface IStatesService
    {
        Task<List<APIStates>> GetStates();

        Task<List<APIStates>> GetStatesByLanguage(string language);
    }
}
