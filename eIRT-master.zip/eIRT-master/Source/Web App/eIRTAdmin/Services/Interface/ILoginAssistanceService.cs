﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using eIRTAdmin.Models;
using eIRTAdmin.Models.APIModels;

namespace eIRTAdmin.Services.Interface
{
    public interface ILoginAssistanceService
    {
        Task<IsSuccess> ForgotPasswordAsync(APIForgotPassword request);
        Task<IsSuccess> ForgotPasswordUpdateAsync(APIForgotPassword fPassword);
    }
}
