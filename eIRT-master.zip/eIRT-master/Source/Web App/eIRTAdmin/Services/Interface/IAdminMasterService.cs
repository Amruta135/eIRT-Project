﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using eIRTAdmin.Models.APIModels;
using eIRTAdmin.Models;
using System.Linq.Expressions;
using System.IO;

namespace eIRTAdmin.Services
{
    public interface IAdminMasterService
    {
        Task<APIAdminMaster> GetAdminUserAsync(Guid guId);
        Task<List<AdminMasterViewModel>> GetAdminUsersAsync();
        Task<List<AdminMasterViewModel>> GetAdminUsersAsync(int page = 1, string filter = null, string search = null);
        Task<int> GetAdminUsersCountAsync(string filter = null, string search = null);
        Task <AdminMasterViewModel> AddAdminUserAsync(APIAdminMaster adminUser);
        Task<APIAdminMaster> UpdateAdminUserAsync(Guid guId, APIAdminMaster adminUser);
        Task<bool> IsExistAsync(string FieldName, string value);
        Task<Stream> ExportXlsxAsync(string filter = null, string search = null);
        Task<Stream> ExportPDFAsync(string filter = null, string search = null);
         Task DeleteAdminUserAsync(Guid guId);
        Task<List<AdminMasterViewModel>> GetAllUsersByRole(string role);
    }
}
