﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using eIRTAdmin.Models.APIModels;
using Microsoft.AspNetCore.Http;

namespace eIRTAdmin.Services
{
    public interface IUserProfileService
    {
        Task<APIUserProfile> GetUserProfileAsync(int Id);
        Task<APIUserProfile> GetUserProfileByGuIdAsync(Guid GuId);
        Task<List<APIUserProfile>> GetUserProfileAsync();
        Task<APIUserProfile> AddUserProfileAsync(APIUserProfile userProfile);
        Task<APIUserProfile> UpdateUserProfileAsync(int Id, APIUserProfile userProfile);
        //Task<bool> IsExist(string FieldName, string value);
        Task DeleteUserProfileAsync(int Id);
        Task UploadProfilePicAsync(int Id, Guid guid, IFormFile icon);

        Task<string> GetUserProfilePic(Guid GuId);
    }
}
