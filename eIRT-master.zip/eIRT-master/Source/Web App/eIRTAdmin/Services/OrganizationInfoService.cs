﻿using eIRTAdmin.Infrastructure;
using eIRTAdmin.Models;
using eIRTAdmin.Models.APIModels;
using eIRTAdmin.Services.Interface;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;

namespace eIRTAdmin.Services
{
    public class OrganizationInfoService : IOrganizationInfoService
    {
        private readonly HttpClient _apiClient;
        private readonly string _ServiceBaseUrl;
        private readonly IOptions<AppSettings> _settings;
        public string AccessToken { get; set; }
        private readonly HttpContext _hcontext;

        public OrganizationInfoService(HttpClient httpClient, IOptions<AppSettings> settings, IHttpContextAccessor haccess)
        {
            _apiClient = httpClient;
            _settings = settings;
            _ServiceBaseUrl = $"{settings.Value.AppUserUrl}";
            _hcontext = haccess.HttpContext;
            AccessToken = _hcontext.User.Identity.IsAuthenticated != false ? _hcontext.User.FindFirst("AccessToken").Value : "";
            _apiClient.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", AccessToken);
        }

        public async Task<APIListAndCount> GetOrganizationInfosAsync(APISearchInfo searchInfo)
        {
            var uri = API.OrganizationInfo.GetOrganizationInfos(_ServiceBaseUrl);
            var UserContent = new StringContent(JsonConvert.SerializeObject(searchInfo), System.Text.Encoding.UTF8, "application/json");
            var responseString = await _apiClient.PostAsync(uri, UserContent);
            var response = JsonConvert.DeserializeObject<APIListAndCount>(await responseString.Content.ReadAsStringAsync());
            return response;
        }

        public async Task<APIOrganizationInfo> AddOrganizationInfoAsync(APIOrganizationInfo apiOrganizationInfo)
        {
            var uri = API.OrganizationInfo.AddOrganizationInfo(_ServiceBaseUrl);
            var UserContent = new StringContent(JsonConvert.SerializeObject(apiOrganizationInfo), System.Text.Encoding.UTF8, "application/json");
            var responseString = await _apiClient.PostAsync(uri, UserContent);
            var response = JsonConvert.DeserializeObject<APIOrganizationInfo>(await responseString.Content.ReadAsStringAsync());
            return response;
        }

        public async Task<APIOrganizationInfo> GetOrganizationInfoAsync(APIId organizationInfoId)
        {
            var uri = API.OrganizationInfo.GetOrganizationInfo(_ServiceBaseUrl);
            var UserContent = new StringContent(JsonConvert.SerializeObject(organizationInfoId), System.Text.Encoding.UTF8, "application/json");
            var responseString = await _apiClient.PostAsync(uri, UserContent);
            var response = JsonConvert.DeserializeObject<APIOrganizationInfo>(await responseString.Content.ReadAsStringAsync());
            return response;
        }

        public async Task<APIOrganizationInfo> UpdateOrganizationInfoAsync(int Id, APIOrganizationInfo organizationInfo)
        {
            var uri = API.OrganizationInfo.UpdateOrganizationInfo(_ServiceBaseUrl, Id);
            var UserContent = new StringContent(JsonConvert.SerializeObject(organizationInfo), System.Text.Encoding.UTF8, "application/json");
            var response = await _apiClient.PutAsync(uri, UserContent);

            if (response.StatusCode == System.Net.HttpStatusCode.InternalServerError)
            {
                throw new Exception("Error updating user, try later.");
            }
            response.EnsureSuccessStatusCode();
            return organizationInfo;
        }

        public async Task DeleteOrganizationInfoAsync(int Id)
        {
            var uri = API.OrganizationInfo.DeleteOrganizationInfo(_ServiceBaseUrl, Id);
            var response = await _apiClient.DeleteAsync(uri);

            if (response.StatusCode == System.Net.HttpStatusCode.InternalServerError)
            {
                throw new Exception("Error deleteting user, try later.");
            }
            response.EnsureSuccessStatusCode();
        }

        public async Task UploadOrganizationLogo(int Id, IFormFile Image)
        {
            var uri = API.OrganizationInfo.UpdateOrganizationLogo(_ServiceBaseUrl);
            byte[] data;
            HttpResponseMessage msg = new HttpResponseMessage();
            try
            {
                using (var br = new BinaryReader(Image.OpenReadStream()))
                {
                    data = br.ReadBytes((int)Image.OpenReadStream().Length);
                }
                ByteArrayContent bytes = new ByteArrayContent(data);
                MultipartFormDataContent multiContent = new MultipartFormDataContent();
                multiContent.Add(bytes, "LogoFile", Image.FileName);
                multiContent.Add(new StringContent(Id.ToString()), "Id");
                msg = await _apiClient.PutAsync(uri, multiContent);

                if (msg.StatusCode == System.Net.HttpStatusCode.InternalServerError)
                {
                    throw new Exception("Error Uploading file, try later.");
                }
            }
            catch (Exception e)
            {
                throw new Exception("Error Uploading file, try later.");
            }
            msg.EnsureSuccessStatusCode();
        }

        public async Task<bool> IsExistAsync(string FieldName, string value)
        {
            var uri = API.OrganizationInfo.IsExist(_ServiceBaseUrl, FieldName, value);

            var responseString = await _apiClient.GetStringAsync(uri);
            var response = JsonConvert.DeserializeObject<IsExistModel>(responseString);
            return response.exists;
        }

        public async Task<int> GetOrganizationMaxUsers()
        {
            var uri = API.OrganizationInfo.GetOrganizationMaxUsers(_ServiceBaseUrl);
            var responseString = await _apiClient.GetStringAsync(uri);
            var response = JsonConvert.DeserializeObject<APINoOfUsers>(responseString);
            return response.NoOfUsers;
        }

        public async Task<APIOrganizationInfo> GetCurrentUserOrganizationAsync()
        {
            var uri = API.OrganizationInfo.GetCurrentUserOrganization(_ServiceBaseUrl);
            var responseString = await _apiClient.GetStringAsync(uri);
            var response = JsonConvert.DeserializeObject<APIOrganizationInfo>(responseString);
            return response;
        }

        public async Task<APIFileBase64Model> GetImageBase64ContentAsync(int id)
        {
            var uri = API.OrganizationInfo.GetImageBase64Content(_ServiceBaseUrl, id);
            var responseString = await _apiClient.GetAsync(uri);
            var response = JsonConvert.DeserializeObject<APIFileBase64Model>(await responseString.Content.ReadAsStringAsync());
            return response;
        }
    }
}
