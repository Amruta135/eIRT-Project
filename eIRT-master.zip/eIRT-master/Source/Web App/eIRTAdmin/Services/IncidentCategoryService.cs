﻿using eIRTAdmin.Infrastructure;
using eIRTAdmin.Models;
using eIRTAdmin.Models.APIModels;
using eIRTAdmin.Services.Interface;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;

namespace eIRTAdmin.Services
{
    public class IncidentCategoryService : IIncidentCategoryService
    {
        private readonly HttpClient _apiClient;
        private readonly string _ServiceBaseUrl;
        private readonly IOptions<AppSettings> _settings;
        public string AccessToken { get; set; }
        private readonly HttpContext _hcontext;

        public IncidentCategoryService(HttpClient httpClient, IOptions<AppSettings> settings, IHttpContextAccessor haccess)
        {
            _apiClient = httpClient;
            _settings = settings;
            _ServiceBaseUrl = $"{settings.Value.AppUserUrl}";
            _hcontext = haccess.HttpContext;
            AccessToken = _hcontext.User.Identity.IsAuthenticated != false ? _hcontext.User.FindFirst("AccessToken").Value : "";
            _apiClient.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", AccessToken);
        }

        public async Task<APIListAndCountIncident> GetIncidentCategorysAsync(APISearchInfo searchInfo)
        {
            var uri = API.IncidentCategory.GetIncidentCategorys(_ServiceBaseUrl);
            var UserContent = new StringContent(JsonConvert.SerializeObject(searchInfo), System.Text.Encoding.UTF8, "application/json");
            var responseString = await _apiClient.PostAsync(uri, UserContent);
            var response = JsonConvert.DeserializeObject<APIListAndCountIncident>(await responseString.Content.ReadAsStringAsync());
            return response;
        }

        public async Task<APIIncidentCategory> UpdateIncidentCategoryAsync(int Id, APIIncidentCategory incidentCategory)
        {
            var uri = API.IncidentCategory.UpdateIncidentCategory(_ServiceBaseUrl, Id);
            var UserContent = new StringContent(JsonConvert.SerializeObject(incidentCategory), System.Text.Encoding.UTF8, "application/json");
            var response = await _apiClient.PutAsync(uri, UserContent);

            if (response.StatusCode == System.Net.HttpStatusCode.InternalServerError)
            {
                throw new Exception("Error updating user, try later.");
            }
            response.EnsureSuccessStatusCode();
            return incidentCategory;
        }

        public async Task<APIIncidentCategory> AddIncidentCategoryAsync(APIIncidentCategory incidentCategory)
        {
            var uri = API.IncidentCategory.AddIncidentCategory(_ServiceBaseUrl);
            var UserContent = new StringContent(JsonConvert.SerializeObject(incidentCategory), System.Text.Encoding.UTF8, "application/json");
            var responseString = await _apiClient.PostAsync(uri, UserContent);
            var response = JsonConvert.DeserializeObject<APIIncidentCategory>(await responseString.Content.ReadAsStringAsync());
            return response;
        }

        public async Task<APIIncidentCategory> GetIncidentCategoryAsync(APIId apiId)
        {
            var uri = API.IncidentCategory.GetIncidentCategory(_ServiceBaseUrl);
            var UserContent = new StringContent(JsonConvert.SerializeObject(apiId), System.Text.Encoding.UTF8, "application/json");
            var responseString = await _apiClient.PostAsync(uri, UserContent);
            var response = JsonConvert.DeserializeObject<APIIncidentCategory>(await responseString.Content.ReadAsStringAsync());
            return response;
        }

        public async Task<bool> IsExistAsync(APIIsExistInput apiIsExistInput)
        {
            var uri = API.IncidentCategory.IsExist(_ServiceBaseUrl);
            var UserContent = new StringContent(JsonConvert.SerializeObject(apiIsExistInput), System.Text.Encoding.UTF8, "application/json");
            var responseString = await _apiClient.PostAsync(uri, UserContent);
            var response = JsonConvert.DeserializeObject<IsExistModel>(await responseString.Content.ReadAsStringAsync());
            return response.exists;
        }
    }
}
