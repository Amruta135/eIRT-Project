﻿using eIRTAdmin.Infrastructure;
using eIRTAdmin.Models;
using eIRTAdmin.Models.APIModels;
using eIRTAdmin.Services.Interface;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;

namespace eIRTAdmin.Services
{
    public class CompetencyService: ICompetencyService
    {
        private readonly HttpClient _apiClient;
        private readonly string _ServiceBaseUrl;
        private readonly IOptions<AppSettings> _settings;
        public string AccessToken { get; set; }
        private readonly HttpContext _hcontext;

        public CompetencyService(HttpClient httpClient, IOptions<AppSettings> settings, IHttpContextAccessor haccess)
        {
            _apiClient = httpClient;
            _settings = settings;
            _ServiceBaseUrl = $"{settings.Value.AppUserUrl}";
            _hcontext = haccess.HttpContext;
            AccessToken = _hcontext.User.Identity.IsAuthenticated != false ? _hcontext.User.FindFirst("AccessToken").Value : "";
            _apiClient.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", AccessToken);
        }

        public async Task<APICompetency> GetCompetencyAsync(APIId apiId)
        {
            var uri = API.Competency.GetCompetency(_ServiceBaseUrl);
            var UserContent = new StringContent(JsonConvert.SerializeObject(apiId), System.Text.Encoding.UTF8, "application/json");
            var responseString = await _apiClient.PostAsync(uri, UserContent);
            var response = JsonConvert.DeserializeObject<APICompetency>(await responseString.Content.ReadAsStringAsync());
            return response;
        }

        public async Task<APIListAndCountCompetencies> GetCompetenciesAsync(APISearchInfo searchInfo)
        {
            var uri = API.Competency.GetCompetencies(_ServiceBaseUrl);
            var UserContent = new StringContent(JsonConvert.SerializeObject(searchInfo), System.Text.Encoding.UTF8, "application/json");
            var responseString = await _apiClient.PostAsync(uri, UserContent);
            var response = JsonConvert.DeserializeObject<APIListAndCountCompetencies>(await responseString.Content.ReadAsStringAsync());
            return response;
        }

        public async Task<List<APICompetency>> GetAllCompetenciesAsync()
        {
            var uri = API.Competency.GetAllCompetencies(_ServiceBaseUrl);
            var responseString = await _apiClient.GetAsync(uri);
            var response = JsonConvert.DeserializeObject<List<APICompetency>>(await responseString.Content.ReadAsStringAsync());
            return response;
        }

        public async Task<IsSuccess> AddCompetencyAsync(APICompetency info)
        {
            var uri = API.Competency.AddCompetency(_ServiceBaseUrl);
            var UserContent = new StringContent(JsonConvert.SerializeObject(info), System.Text.Encoding.UTF8, "application/json");
            var responseString = await _apiClient.PostAsync(uri, UserContent);
            var response = JsonConvert.DeserializeObject<IsSuccess>(await responseString.Content.ReadAsStringAsync());
            return response;
        }

        public async Task<IsSuccess> UpdateCompetencyAsync(APICompetency info)
        {
            var uri = API.Competency.UpdateCompetency(_ServiceBaseUrl);
            var UserContent = new StringContent(JsonConvert.SerializeObject(info), System.Text.Encoding.UTF8, "application/json");
            var responseString = await _apiClient.PutAsync(uri, UserContent);

            var response = JsonConvert.DeserializeObject<IsSuccess>(await responseString.Content.ReadAsStringAsync());
            return response;
        }

        public async Task<IsSuccess> DeleteCompetencyAsync(APIId apiId)
        {
            var uri = API.Competency.DeleteCompetency(_ServiceBaseUrl);
            var UserContent = new StringContent(JsonConvert.SerializeObject(apiId), System.Text.Encoding.UTF8, "application/json");
            var responseString = await _apiClient.PutAsync(uri, UserContent);
            var response = JsonConvert.DeserializeObject<IsSuccess>(await responseString.Content.ReadAsStringAsync());
            if (responseString.StatusCode == System.Net.HttpStatusCode.InternalServerError)
            {
                throw new Exception("Error updating record, try later.");
            }
            return response;
        }

        public async Task<bool> IsExistAsync(APIIsExistInput apiIsExistInput)
        {
            var uri = API.Competency.IsExist(_ServiceBaseUrl);
            var UserContent = new StringContent(JsonConvert.SerializeObject(apiIsExistInput), System.Text.Encoding.UTF8, "application/json");
            var responseString = await _apiClient.PostAsync(uri, UserContent);
            var response = JsonConvert.DeserializeObject<IsExistModel>(await responseString.Content.ReadAsStringAsync());
            return response.exists;
        }
    }
}
