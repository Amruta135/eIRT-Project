﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using eIRTAdmin.Models;
using eIRTAdmin.Models.APIModels;
using eIRTAdmin.Infrastructure;
using System.Net.Http;
using System.Linq.Expressions;
using System.IO;
using Microsoft.AspNetCore.Http;

namespace eIRTAdmin.Services
{
    public class AdminMasterService : IAdminMasterService
    {
        private HttpClient _apiClient;
        private readonly string _ServiceBaseUrl;
        private readonly IOptions<AppSettings> _settings;
        public string AccessToken { get; set; }
        private HttpContext hcontext;

        public AdminMasterService(HttpClient httpClient, IOptions<AppSettings> settings,
            IHttpContextAccessor haccess)
        {
            _apiClient = httpClient;
            _settings = settings;
            _ServiceBaseUrl = $"{settings.Value.AppUserUrl}";
            hcontext = haccess.HttpContext;
            AccessToken = hcontext.User.FindFirst("AccessToken").Value;
            _apiClient.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", AccessToken);
        }

        async public Task<List<AdminMasterViewModel>> GetAdminUsersAsync()
        {
            var uri = API.AdminMaster.GetAdminUsers(_ServiceBaseUrl);
            var responseString = await _apiClient.GetStringAsync(uri);
            var response = JsonConvert.DeserializeObject<List<AdminMasterViewModel>>(responseString);
            return response;
        }

        async public Task<List<AdminMasterViewModel>> GetAdminUsersAsync(int page = 1, string filter = null, string search = null)
        {
            var uri = API.AdminMaster.GetAdminUsers(_ServiceBaseUrl,page, 10, filter, search);
            var responseString = await _apiClient.GetStringAsync(uri);
            var response = JsonConvert.DeserializeObject<List<AdminMasterViewModel>>(responseString);
            return response;
        }

        async public Task<int> GetAdminUsersCountAsync(string filter = null, string search = null)
        {
            var uri = API.AdminMaster.GetAdminUsersCount(_ServiceBaseUrl, filter, search);
            var responseString = await _apiClient.GetStringAsync(uri);
            var response = JsonConvert.DeserializeObject<int>(responseString);
            return response;
        }

        async public Task<Stream> ExportXlsxAsync(string filter = null, string search = null)
        {
            var uri = API.AdminMaster.ExportXlsxAdminUsers(_ServiceBaseUrl, filter, search);
            var response = await _apiClient.GetStreamAsync(uri);
            //byte[] bindata = System.Text.Encoding.ASCII.GetBytes(response.ToString());
            //return File(bindata, "application/ms-excel", "ReportFile.xls");
            //var response = (File)(responseString);
            return response;
        }

        async public Task<APIAdminMaster> GetAdminUserAsync(Guid guId)
        {
            var uri = API.AdminMaster.GetAdminUser(_ServiceBaseUrl, guId);
            var responseString = await _apiClient.GetStringAsync(uri);
            var response = JsonConvert.DeserializeObject<APIAdminMaster>(responseString);
            return response;
        }

        public async Task<AdminMasterViewModel> AddAdminUserAsync(APIAdminMaster adminUser)
        {
            var uri = API.AdminMaster.AddAdminUsers(_ServiceBaseUrl);
            var AdminUserContent = new StringContent(JsonConvert.SerializeObject(adminUser), System.Text.Encoding.UTF8, "application/json");
            //_logger.LogInformation("Uri chechout {uri}", uri);
            var responseString = await _apiClient.PostAsync(uri, AdminUserContent);
            var response= JsonConvert.DeserializeObject<AdminMasterViewModel>(await responseString.Content.ReadAsStringAsync());
            return response;
        }

        async public Task<APIAdminMaster> UpdateAdminUserAsync(Guid guId, APIAdminMaster adminUser)
        {
            var uri = API.AdminMaster.UpdateAdminUsers(_ServiceBaseUrl, guId);
            var UserContent = new StringContent(JsonConvert.SerializeObject(adminUser), System.Text.Encoding.UTF8, "application/json");
            var response = await _apiClient.PutAsync(uri, UserContent);

            if (response.StatusCode == System.Net.HttpStatusCode.InternalServerError)
            {
                throw new Exception("Error updating user, try later.");
            }
            response.EnsureSuccessStatusCode();
            return adminUser;
        }

        async public Task DeleteAdminUserAsync(Guid guId)
        {
            var uri = API.AdminMaster.DeleteAdminUsers(_ServiceBaseUrl, guId);
            var response = await _apiClient.DeleteAsync(uri);

            if (response.StatusCode == System.Net.HttpStatusCode.InternalServerError)
            {
                throw new Exception("Error deleteting user, try later.");
            }
            response.EnsureSuccessStatusCode();
        }

        async public Task<bool> IsExistAsync(string FieldName, string value)
        {
            var uri = API.AdminMaster.IsExist(_ServiceBaseUrl, FieldName, value);

            var responseString = await _apiClient.GetStringAsync(uri);
            var response = JsonConvert.DeserializeObject<IsExistModel>(responseString);
            return response.exists;
        }

        async public Task<List<AdminMasterViewModel>> GetAllUsersByRole(string role)
        {
            var uri = API.AdminMaster.GetAllUsersByRole(_ServiceBaseUrl, role);
            var responseString = await _apiClient.GetStringAsync(uri);
            var response = JsonConvert.DeserializeObject<List<AdminMasterViewModel>>(responseString);
            return response;
        }

        public async Task<Stream> ExportPDFAsync(string filter = null, string search = null)
        {
            var uri = API.AdminMaster.ExportPDF(_ServiceBaseUrl, filter, search);
            var response = await _apiClient.GetStreamAsync(uri);
            return response;
        }
    }

    
}
