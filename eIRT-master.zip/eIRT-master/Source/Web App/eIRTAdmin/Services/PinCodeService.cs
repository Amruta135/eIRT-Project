﻿using eIRTAdmin.Infrastructure;
using eIRTAdmin.Models.APIModels;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using System.Net.Http;
using System.Threading.Tasks;

namespace eIRTAdmin.Services
{
    public class PinCodeService : IPinCodeService
    {
        private readonly HttpClient _apiClient;
        private readonly string _ServiceBaseUrl;
        private readonly IOptions<AppSettings> _settings;
        public string AccessToken { get; set; }
        private readonly HttpContext _hcontext;

        public PinCodeService(HttpClient httpClient, IOptions<AppSettings> settings, IHttpContextAccessor haccess)
        {
            _apiClient = httpClient;
            _settings = settings;
            _ServiceBaseUrl = $"{settings.Value.AppUserUrl}";
            _hcontext = haccess.HttpContext;
            AccessToken = _hcontext.User.Identity.IsAuthenticated != false ? _hcontext.User.FindFirst("AccessToken").Value : "";
            _apiClient.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", AccessToken);
        }

        public async Task<APIPinCode> GetStateByPincode(string pincode)
        {
            var uri = API.Pincode.GetStateByPincode(_ServiceBaseUrl, pincode);
            var responseString = await _apiClient.GetStringAsync(uri);
            var response = JsonConvert.DeserializeObject<APIPinCode>(responseString);
            return response;
        }
    }
}
