﻿using eIRTAdmin.Infrastructure;
using eIRTAdmin.Models;
using eIRTAdmin.Models.APIModels;
using eIRTAdmin.Services.Interface;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;

namespace eIRTAdmin.Services
{
    public class IncidentReportService : IIncidentReportService
    {
        private readonly HttpClient _apiClient;
        private readonly string _ServiceBaseUrl;
        private readonly IOptions<AppSettings> _settings;
        public string AccessToken { get; set; }
        private readonly HttpContext _hcontext;

        public IncidentReportService(HttpClient httpClient, IOptions<AppSettings> settings, IHttpContextAccessor haccess)
        {
            _apiClient = httpClient;
            _settings = settings;
            _ServiceBaseUrl = $"{settings.Value.AppUserUrl}";
            _hcontext = haccess.HttpContext;
            AccessToken = _hcontext.User.Identity.IsAuthenticated != false ? _hcontext.User.FindFirst("AccessToken").Value : "";
            _apiClient.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", AccessToken);
        }

        public async Task<APIListAndCountIncidentReport> GetIncidentReportsAsync(APISearchInfo searchInfo)
        {
            var uri = API.IncidentReport.GetIncidentReports(_ServiceBaseUrl);
            var UserContent = new StringContent(JsonConvert.SerializeObject(searchInfo), System.Text.Encoding.UTF8, "application/json");
            var responseString = await _apiClient.PostAsync(uri, UserContent);
            var response = JsonConvert.DeserializeObject<APIListAndCountIncidentReport>(await responseString.Content.ReadAsStringAsync());
            return response;
        }

        public async Task<APIIncidentReport> AddIncidentReportAsync(APIIncidentReport incidentReport)
        {
            var uri = API.IncidentReport.AddIncidentReport(_ServiceBaseUrl);
            var UserContent = new StringContent(JsonConvert.SerializeObject(incidentReport), System.Text.Encoding.UTF8, "application/json");
            var responseString = await _apiClient.PostAsync(uri, UserContent);
            var response = JsonConvert.DeserializeObject<APIIncidentReport>(await responseString.Content.ReadAsStringAsync());
            return response;
        }

        public async Task<APIIncidentReport> GetIncidentReportAsync(APIId apiId)
        {
            var uri = API.IncidentReport.GetIncidentReport(_ServiceBaseUrl);
            var UserContent = new StringContent(JsonConvert.SerializeObject(apiId), System.Text.Encoding.UTF8, "application/json");
            var responseString = await _apiClient.PostAsync(uri, UserContent);
            var response = JsonConvert.DeserializeObject<APIIncidentReport>(await responseString.Content.ReadAsStringAsync());
            return response;
        }

        public async Task<APIIncidentReport> UpdateIncidentReportAsync(int Id, APIIncidentReport incidentReport)
        {
            var uri = API.IncidentReport.UpdateIncidentReport(_ServiceBaseUrl, Id);
            var UserContent = new StringContent(JsonConvert.SerializeObject(incidentReport), System.Text.Encoding.UTF8, "application/json");
            var response = await _apiClient.PutAsync(uri, UserContent);

            if (response.StatusCode == System.Net.HttpStatusCode.InternalServerError)
            {
                throw new Exception("Error updating user, try later.");
            }
            response.EnsureSuccessStatusCode();
            return incidentReport;
        }

        public async Task DeleteIncidentReportAsync(int Id)
        {
            var uri = API.IncidentReport.DeleteIncidentReport(_ServiceBaseUrl, Id);
            var response = await _apiClient.DeleteAsync(uri);

            if (response.StatusCode == System.Net.HttpStatusCode.InternalServerError)
            {
                throw new Exception("Error deleteting user, try later.");
            }
            response.EnsureSuccessStatusCode();
        }

        public async Task UploadIncidentReportPhoto(int Id, IFormFile img)
        {
            var uri = API.IncidentReport.PutIncidentReportPhoto(_ServiceBaseUrl);
            byte[] data;
            HttpResponseMessage msg = new HttpResponseMessage();
            try
            {
                using (var br = new BinaryReader(img.OpenReadStream()))
                {
                    data = br.ReadBytes((int)img.OpenReadStream().Length);
                }
                ByteArrayContent bytes = new ByteArrayContent(data);
                MultipartFormDataContent multiContent = new MultipartFormDataContent();
                multiContent.Add(bytes, "PhotoFile", img.FileName);
                multiContent.Add(new StringContent(Id.ToString()), "Id");
                msg = await _apiClient.PutAsync(uri, multiContent);

                if (msg.StatusCode == System.Net.HttpStatusCode.InternalServerError)
                {
                    throw new Exception("Error Uploading file, try later.");
                }
            }
            catch (Exception e)
            {
                throw new Exception("Error Uploading file, try later.");
            }
            msg.EnsureSuccessStatusCode();
        }

        public async Task<bool> IsExistAsync(APIIsExistInput apiIsExistInput)
        {
            var uri = API.IncidentReport.IsExist(_ServiceBaseUrl);
            var UserContent = new StringContent(JsonConvert.SerializeObject(apiIsExistInput), System.Text.Encoding.UTF8, "application/json");
            var responseString = await _apiClient.PostAsync(uri, UserContent);
            var response = JsonConvert.DeserializeObject<IsExistModel>(await responseString.Content.ReadAsStringAsync());
            return response.exists;
        }

        public async Task<List<APIIncidentReport>> GetIncidentReportsList(APISearchInfo searchInfo)
        {
            var uri = API.IncidentReport.GetIncidentReportsList(_ServiceBaseUrl);
            var UserContent = new StringContent(JsonConvert.SerializeObject(searchInfo), System.Text.Encoding.UTF8, "application/json");
            var responseString = await _apiClient.PostAsync(uri, UserContent);
            var response = JsonConvert.DeserializeObject<List<APIIncidentReport>>(await responseString.Content.ReadAsStringAsync());
            return response;
        }

        public async Task<bool> IsIncidentCreatedAsync(APIIsIncidentCreated incidentCreated)
        {
            var uri = API.IncidentReport.IsIncidentCreated(_ServiceBaseUrl);
            var UserContent = new StringContent(JsonConvert.SerializeObject(incidentCreated), System.Text.Encoding.UTF8, "application/json");
            var responseString = await _apiClient.PostAsync(uri, UserContent);
            var response = JsonConvert.DeserializeObject<IsExistModel>(await responseString.Content.ReadAsStringAsync());
            return response.exists;
        }

        public async Task<List<APIIncidentReport>> GetSingleIncidentReportsList(APIId id)
        {
            var uri = API.IncidentReport.GetSingleIncidentReportsList(_ServiceBaseUrl);
            var UserContent = new StringContent(JsonConvert.SerializeObject(id), System.Text.Encoding.UTF8, "application/json");
            var responseString = await _apiClient.PostAsync(uri, UserContent);
            var response = JsonConvert.DeserializeObject<List<APIIncidentReport>>(await responseString.Content.ReadAsStringAsync());
            return response;
        }

        public async Task<APIListAndCountIncidentReport> GetAllIncidentDetailsAsync(APISearchInfo searchInfo)
        {
            var uri = API.IncidentReport.GetAllIncidentDetails(_ServiceBaseUrl);
            var UserContent = new StringContent(JsonConvert.SerializeObject(searchInfo), System.Text.Encoding.UTF8, "application/json");
            var responseString = await _apiClient.PostAsync(uri, UserContent);
            var response = JsonConvert.DeserializeObject<APIListAndCountIncidentReport>(await responseString.Content.ReadAsStringAsync());
            return response;
        }

        public async Task<APIListAndCountIncidentReport> GetIncidentReportsForManagersAsync(APISearchInfoForManagers searchInfo)
        {
            var uri = API.IncidentReport.GetIncidentReportsForManagers(_ServiceBaseUrl);
            var UserContent = new StringContent(JsonConvert.SerializeObject(searchInfo), System.Text.Encoding.UTF8, "application/json");
            var responseString = await _apiClient.PostAsync(uri, UserContent);
            var response = JsonConvert.DeserializeObject<APIListAndCountIncidentReport>(await responseString.Content.ReadAsStringAsync());
            return response;
        }

        public async Task<APIListAndCountIncidentReport> GetReportedIncidentsAsync(APISearchIncident searchInfo)
        {
            var uri = API.IncidentReport.GetReportedIncidents(_ServiceBaseUrl);
            var UserContent = new StringContent(JsonConvert.SerializeObject(searchInfo), System.Text.Encoding.UTF8, "application/json");
            var responseString = await _apiClient.PostAsync(uri, UserContent);
            var response = JsonConvert.DeserializeObject<APIListAndCountIncidentReport>(await responseString.Content.ReadAsStringAsync());
            return response;
        }

        public async Task<APIIncidentReportCount> GetCountOfAllStatus()
        {
            var uri = API.IncidentReport.GetCountOfAllStatus(_ServiceBaseUrl);
            var responseString = await _apiClient.GetStringAsync(uri);
            var response = JsonConvert.DeserializeObject<APIIncidentReportCount>(responseString);
            return response;
        }

        public async Task<APIOpenClosedIncidentReport> GetOpenClosedIncidentsReport(APIOpenClosedIncidentSearch searchInfo)
        {
            var uri = API.IncidentReport.GetOpenClosedIncidentsReport(_ServiceBaseUrl);
            var UserContent = new StringContent(JsonConvert.SerializeObject(searchInfo), System.Text.Encoding.UTF8, "application/json");
            var responseString = await _apiClient.PostAsync(uri, UserContent);
            var response = JsonConvert.DeserializeObject<APIOpenClosedIncidentReport>(await responseString.Content.ReadAsStringAsync());
            return response;
        }

        public async Task<APIFileBase64Model> GetImageBase64ContentAsync(int id)
        {
            var uri = API.IncidentReport.GetImageBase64Content(_ServiceBaseUrl, id);
            var responseString = await _apiClient.GetAsync(uri);
            var response = JsonConvert.DeserializeObject<APIFileBase64Model>(await responseString.Content.ReadAsStringAsync());
            return response;
        }

        public async Task<Stream> ExportXlsxAsync(APIOpenClosedIncidentSearch incidentSearch)
        {
            var uri = API.IncidentReport.ExportXlsx(_ServiceBaseUrl);
            var requestContent = new StringContent(JsonConvert.SerializeObject(incidentSearch), System.Text.Encoding.UTF8, "application/json");
            var responseString = await _apiClient.PostAsync(uri, requestContent);
            //var response = JsonConvert.DeserializeObject<Stream>(await responseString.Content.ReadAsStringAsync());
            //return response;
            var contentStream = await responseString.Content.ReadAsStreamAsync();
            return contentStream;
        }
    }
}
