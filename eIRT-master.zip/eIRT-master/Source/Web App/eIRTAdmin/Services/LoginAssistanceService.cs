﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using eIRTAdmin.Models;
using eIRTAdmin.Models.APIModels;
using eIRTAdmin.Infrastructure;
using System.Net.Http;
using System.Linq.Expressions;
using System.IO;
using Microsoft.AspNetCore.Http;
using eIRTAdmin.Services.Interface;

namespace eIRTAdmin.Services
{
    public class LoginAssistanceService : ILoginAssistanceService
    {
        private HttpClient _apiClient;
        private readonly string _ServiceBaseUrl;
        private readonly IOptions<AppSettings> _settings;
        public string AccessToken { get; set; }
        private HttpContext hcontext;

        public LoginAssistanceService(HttpClient httpClient, IOptions<AppSettings> settings,
            IHttpContextAccessor haccess)
        {
            _apiClient = httpClient;
            _settings = settings;
            _ServiceBaseUrl = $"{settings.Value.AppUserUrl}";
            hcontext = haccess.HttpContext;
            AccessToken = hcontext.User.FindFirst("AccessToken") != null ? hcontext.User.FindFirst("AccessToken").Value : "";
            //_apiClient.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", AccessToken);
            if (!string.IsNullOrEmpty(AccessToken))
                _apiClient.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", AccessToken);
        }

        async public Task<IsSuccess> ForgotPasswordAsync(APIForgotPassword request)
        {
            var uri = API.LoginAssistance.ForgotPassword(_ServiceBaseUrl);
            var Content = new StringContent(JsonConvert.SerializeObject(new { userId = request.UserId }), System.Text.Encoding.UTF8, "application/json");
            var responseString = await _apiClient.PutAsync(uri, Content);
            var response = JsonConvert.DeserializeObject<IsSuccess>(await responseString.Content.ReadAsStringAsync());

            if (responseString.StatusCode == System.Net.HttpStatusCode.InternalServerError)
            {
                throw new Exception("Error, try later.");
            }
            responseString.EnsureSuccessStatusCode();
            return response;
        }
        async public Task<IsSuccess> ForgotPasswordUpdateAsync(APIForgotPassword fPassword)
        {
            var uri = API.LoginAssistance.ForgotPasswordUpdate(_ServiceBaseUrl);
            var Content = new StringContent(JsonConvert.SerializeObject(fPassword), System.Text.Encoding.UTF8, "application/json");
            var responseString = await _apiClient.PutAsync(uri, Content);
            var response = JsonConvert.DeserializeObject<IsSuccess>(await responseString.Content.ReadAsStringAsync());

            if (responseString.StatusCode == System.Net.HttpStatusCode.InternalServerError)
            {
                throw new Exception("Error, try later.");
            }
            responseString.EnsureSuccessStatusCode();
            return response;
        }
    }
}
