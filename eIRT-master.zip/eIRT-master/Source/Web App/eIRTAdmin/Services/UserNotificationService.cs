﻿using eIRTAdmin.Infrastructure;
using eIRTAdmin.Models.APIModels;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;

namespace eIRTAdmin.Services
{
    public class UserNotificationService : IUserNotificationService
    {
        private HttpClient _apiClient;
        private readonly string _ServiceBaseUrl;
        private readonly IOptions<AppSettings> _settings;
        public string AccessToken { get; set; }
        private HttpContext hcontext;

        public UserNotificationService(HttpClient httpClient, IOptions<AppSettings> settings,
            IHttpContextAccessor haccess)
        {
            _apiClient = httpClient;
            _settings = settings;
            _ServiceBaseUrl = $"{settings.Value.NotificationUrl}";
            hcontext = haccess.HttpContext;
            AccessToken = hcontext.User.FindFirst("AccessToken").Value;
            _apiClient.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", AccessToken);
        }

        public async Task<List<APIUserNotifications>> GetUserNotifications()
        {
            var uri = API.UserNotification.GetUserNotifications(_ServiceBaseUrl);
            var responseString = await _apiClient.GetStringAsync(uri);
            var response = JsonConvert.DeserializeObject<List<APIUserNotifications>>(responseString);
            return response;
        }
        async public Task<bool> ReadNotification(int notificationId)
        {
            var uri = API.UserNotification.ReadNotification(_ServiceBaseUrl, notificationId);
            var responseString = await _apiClient.GetStringAsync(uri);
            var response = JsonConvert.DeserializeObject<bool>(responseString);
            return response;
        }
    }
}
