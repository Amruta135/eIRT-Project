﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using eIRTAdmin.Infrastructure;
using eIRTAdmin.Models.APIModels;
using eIRTAdmin.Services.Interface;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;

namespace eIRTAdmin.Services
{
    public class SecurityQuestionService : ISecurityQuestionService
    {
        private readonly HttpClient _apiClient;
        private readonly string _ServiceBaseUrl;
        private readonly IOptions<AppSettings> _settings;
        public string AccessToken { get; set; }
        private readonly HttpContext _hcontext;

        public SecurityQuestionService(HttpClient httpClient, IOptions<AppSettings> settings, IHttpContextAccessor haccess)
        {
            _apiClient = httpClient;
            _settings = settings;
            _ServiceBaseUrl = $"{settings.Value.AppUserUrl}";
            _hcontext = haccess.HttpContext;
            AccessToken = _hcontext.User.Identity.IsAuthenticated != false ? _hcontext.User.FindFirst("AccessToken").Value : "";
            _apiClient.DefaultRequestHeaders.Authorization = ! string.IsNullOrWhiteSpace(AccessToken)? new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", AccessToken) : null;
        }
        public async Task<List<APISecurityQuestion>> GetAllQuestionsAsync()
        {
            var uri = API.SecurityQuestion.GetAllSecurityQuestions(_ServiceBaseUrl);
            var responseString = await _apiClient.GetAsync(uri);
            var response = JsonConvert.DeserializeObject<List<APISecurityQuestion>>(await responseString.Content.ReadAsStringAsync());
            return response;
        }
    }
}
