﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using eIRTAdmin.Models;
using eIRTAdmin.Models.APIModels;
using eIRTAdmin.Infrastructure;
using System.Net.Http;
using System.Linq.Expressions;
using System.IO;
using Newtonsoft.Json.Linq;
using eIRTAdmin.Helper;
using System.Security.Claims;
using Microsoft.AspNetCore.Http;

namespace eIRTAdmin.Services
{
    public class UserMasterService : IUserMasterService
    {
        private HttpClient _apiClient;
        private readonly string _ServiceBaseUrl;
        private readonly IOptions<AppSettings> _settings;
        public string AccessToken { get; set; }
        private HttpContext hcontext;

        public UserMasterService(HttpClient httpClient, IOptions<AppSettings> settings,
            IHttpContextAccessor haccess)
        {
            _apiClient = httpClient;
            _settings = settings;
            _ServiceBaseUrl = $"{settings.Value.AppUserUrl}";
            hcontext = haccess.HttpContext;
            AccessToken = hcontext.User.FindFirst("AccessToken") != null ? hcontext.User.FindFirst("AccessToken").Value : "";
            if (!string.IsNullOrEmpty(AccessToken))
                _apiClient.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", AccessToken);
        }

        public string GetToken()
        {
            return AccessToken;
        }
        async public Task<List<APIUserSignUp>> GetUsersAsync()
        {
            var uri = API.UserMaster.GetUsers(_ServiceBaseUrl);
            var responseString = await _apiClient.GetStringAsync(uri);
            var response = JsonConvert.DeserializeObject<List<APIUserSignUp>>(responseString);
            return response;
        }

        async public Task<APIListAndCountforUserMaster> GetUsersForPAAsync(APISearchInfo apiSearchInfo)
        {
            var uri = API.UserMaster.GetUsersForPAAsync(_ServiceBaseUrl);
            var UserContent = new StringContent(JsonConvert.SerializeObject(apiSearchInfo), System.Text.Encoding.UTF8, "application/json");
            var responseString = await _apiClient.PostAsync(uri, UserContent);
            var response = JsonConvert.DeserializeObject<APIListAndCountforUserMaster>(await responseString.Content.ReadAsStringAsync());
            return response;
        }

        async public Task<APIListAndCountforUserMaster> GetUsersForCAAsync(APISearchInfo apiSearchInfo)
        {
            var uri = API.UserMaster.GetUsersForCAAsync(_ServiceBaseUrl);
            var UserContent = new StringContent(JsonConvert.SerializeObject(apiSearchInfo), System.Text.Encoding.UTF8, "application/json");
            var responseString = await _apiClient.PostAsync(uri, UserContent);
            var response = JsonConvert.DeserializeObject<APIListAndCountforUserMaster>(await responseString.Content.ReadAsStringAsync());
            return response;
        }

        async public Task<int> GetUsersCountAsync(string filter = null, string search = null)
        {
            var uri = API.UserMaster.GetUsersCount(_ServiceBaseUrl, filter, search);
            var responseString = await _apiClient.GetStringAsync(uri);
            var response = JsonConvert.DeserializeObject<int>(responseString);
            return response;
        }

        async public Task<APIUserDetails> GetUserAsync(int id)
        {
            var uri = API.UserMaster.GetUser(_ServiceBaseUrl, id);
            var responseString = await _apiClient.GetStringAsync(uri);
            var response = JsonConvert.DeserializeObject<APIUserDetails>(responseString);
            return response;
        }

        async public Task<Stream> ExportXlsxAsync(string filter = null, string search = null)
        {
            var uri = API.UserMaster.ExportXlsxUsers(_ServiceBaseUrl, filter, search);
            var response = await _apiClient.GetStreamAsync(uri);
            return response;
        }

        public async Task<APIUserSignUp> SignUpUserAsync(APIUserSignUp user)
        {
            var uri = API.UserMaster.UserSignUp(_ServiceBaseUrl);
            var UserContent = new StringContent(JsonConvert.SerializeObject(user), System.Text.Encoding.UTF8, "application/json");
            var responseString = await _apiClient.PostAsync(uri, UserContent);
            var response = JsonConvert.DeserializeObject<APIUserSignUp>(await responseString.Content.ReadAsStringAsync());
            return response;
        }

        async public Task<APIUserSignUp> UpdateUserAsync(APIUserSignUp user)
        {
            var uri = API.UserMaster.UpdateUsers(_ServiceBaseUrl, (Guid)user.GuId);
            var UserContent = new StringContent(JsonConvert.SerializeObject(user), System.Text.Encoding.UTF8, "application/json");
            var response = await _apiClient.PutAsync(uri, UserContent);

            if (response.StatusCode == System.Net.HttpStatusCode.InternalServerError)
            {
                throw new Exception("Error updating user, try later.");
            }
            response.EnsureSuccessStatusCode();
            return user;
        }

        async public Task<APIUserSecurityQuestion> GetUserSecurityQuestionAsync()
        {
            var uri = API.UserMaster.GetUserSecurityQuestion(_ServiceBaseUrl);
            var responseString = await _apiClient.GetStringAsync(uri);
            var response = JsonConvert.DeserializeObject<APIUserSecurityQuestion>(responseString);
            return response;
        }


        async public Task<APIUserInfo> GetUserInfoByMobileNumber(APIUserMobile userMobile)
        {
            var uri = API.UserMaster.GetUserInfoByMobileNumber(_ServiceBaseUrl);
            var UserContent = new StringContent(JsonConvert.SerializeObject(userMobile), System.Text.Encoding.UTF8, "application/json");
            var responseString = await _apiClient.PostAsync(uri, UserContent);
            var response = JsonConvert.DeserializeObject<APIUserInfo>(await responseString.Content.ReadAsStringAsync());
            return response;
        }

        async public Task<IsSuccess> ResendOTPAsync(Guid guId)
        {
            var uri = API.UserMaster.ResendUserOTP(_ServiceBaseUrl, guId);
            var responseString = await _apiClient.GetStringAsync(uri);
            var response = JsonConvert.DeserializeObject<IsSuccess>(responseString);
            return response;
        }

        async public Task<string> GetUserOTPAsync(Guid guId)
        {
            var uri = API.UserMaster.GetUsersOtp(_ServiceBaseUrl, guId);
            var responseString = await _apiClient.GetStringAsync(uri);
            var response = JsonConvert.DeserializeObject<string>(responseString);
            return response;
        }

        async public Task<bool> ValidateUserOtpAsync(UserOptValidate otpDetails)
        {
            var uri = API.UserMaster.ValidateUsersOtp(_ServiceBaseUrl);
            var ValidateOTPContent = new StringContent(JsonConvert.SerializeObject(otpDetails), System.Text.Encoding.UTF8, "application/json");
            var responseString = await _apiClient.PostAsync(uri, ValidateOTPContent);
            var response = JsonConvert.DeserializeObject<IsValid>(await responseString.Content.ReadAsStringAsync());
            return response.Valid;
        }

        async public Task SetUserPassword(APIUserPassword userPassword)
        {
            var uri = API.UserMaster.SetUserPassword(_ServiceBaseUrl, userPassword.GuId);
            var UserContent = new StringContent(JsonConvert.SerializeObject(userPassword), System.Text.Encoding.UTF8, "application/json");
            var response = await _apiClient.PutAsync(uri, UserContent);

            if (response.StatusCode == System.Net.HttpStatusCode.InternalServerError)
            {
                throw new Exception("Error updating user, try later.");
            }
            response.EnsureSuccessStatusCode();
            //return userPassword;
        }

        async public Task<IsSuccess> ChangeUserPassword(APIUserMasterPasswordChange userPassword)
        {
            var uri = API.UserMaster.ChangeUserPassword(_ServiceBaseUrl);
            var UserContent = new StringContent(JsonConvert.SerializeObject(userPassword), System.Text.Encoding.UTF8, "application/json");
            var responseString = await _apiClient.PutAsync(uri, UserContent);
            var response = JsonConvert.DeserializeObject<IsSuccess>(await responseString.Content.ReadAsStringAsync());

            if (responseString.StatusCode == System.Net.HttpStatusCode.InternalServerError)
            {
                throw new Exception("Error updating user, try later.");
            }
            responseString.EnsureSuccessStatusCode();
            return response ?? new IsSuccess() {success = false, message = "" };
        }
        async public Task DeleteUserAsync(Guid guId)
        {
            var uri = API.UserMaster.DeleteUser(_ServiceBaseUrl, guId);
            var response = await _apiClient.DeleteAsync(uri);

            if (response.StatusCode == System.Net.HttpStatusCode.InternalServerError)
            {
                throw new Exception("Error deleteting user, try later.");
            }
            response.EnsureSuccessStatusCode();
        }

        async public Task<bool> IsExistAsync(string FieldName, string value)
        {
            var uri = API.UserMaster.IsExist(_ServiceBaseUrl, FieldName, value);

            var responseString = await _apiClient.GetStringAsync(uri);
            var response = JsonConvert.DeserializeObject<IsExistModel>(responseString);
            return response.exists;
        }

        async public Task<bool> UserLogout()
        {
            var uri = API.UserMaster.UserLogOut(_ServiceBaseUrl);
            var responseString = await _apiClient.GetStringAsync(uri);
            var response = JsonConvert.DeserializeObject<IsSuccess>(responseString);
            return response.success;
        }

        async public Task<IsSuccess> ForgotPasswordAsync(APIForgotPassword userPassword)
        {
            var uri = API.UserMaster.ForgotPassword(_ServiceBaseUrl);
            var UserContent = new StringContent(JsonConvert.SerializeObject(userPassword), System.Text.Encoding.UTF8, "application/json");
            var responseString = await _apiClient.PutAsync(uri, UserContent);
            var response = JsonConvert.DeserializeObject<IsSuccess>(await responseString.Content.ReadAsStringAsync());

            if (responseString.StatusCode == System.Net.HttpStatusCode.InternalServerError)
            {
                throw new Exception("Error updating user, try later.");
            }
            responseString.EnsureSuccessStatusCode();
            return response ?? new IsSuccess() { success = false, message = "Internal server error!" };
        }

        
        public async Task<APIUserDetails> AddUserDetailsForPAAsync(APIUserDetails apiUserDetails)
        {
            var uri = API.UserMaster.AddUserDetailsForPA(_ServiceBaseUrl);
            var UserContent = new StringContent(JsonConvert.SerializeObject(apiUserDetails), System.Text.Encoding.UTF8, "application/json");
            var responseString = await _apiClient.PostAsync(uri, UserContent);
            var response = JsonConvert.DeserializeObject<APIUserDetails>(await responseString.Content.ReadAsStringAsync());
            return response;
        }

        public async Task<ResponseError> UpdateUserProfilePic(int Id, Guid guid, IFormFile Pic)
        {
            ResponseError eMsg = new ResponseError();
            APIUserProfilePic profilePic = new APIUserProfilePic()
            {
                Id = Id,
                UserMasterGuId = guid,
                ProfilePic = Pic
            };
            var uri = API.UserMaster.UpdateUserProfilePic(_ServiceBaseUrl);
            //var BankInfoIcon = new StringContent(JsonConvert.SerializeObject(bankIcon), System.Text.Encoding.UTF8, "application/json");
            byte[] data;
            HttpResponseMessage msg = new HttpResponseMessage();
            try
            {
                using (var br = new BinaryReader(Pic.OpenReadStream()))
                {
                    data = br.ReadBytes((int)Pic.OpenReadStream().Length);
                }
                ByteArrayContent bytes = new ByteArrayContent(data);
                MultipartFormDataContent multiContent = new MultipartFormDataContent();
                multiContent.Add(bytes, "ProfilePic", Pic.FileName);
                multiContent.Add(new StringContent(guid.ToString()), "UserMasterGuId");
                multiContent.Add(new StringContent(Id.ToString()), "Id");
                msg = await _apiClient.PutAsync(uri, multiContent);

                if (msg.StatusCode != System.Net.HttpStatusCode.OK)
                {
                    eMsg.StatusCode = Convert.ToInt32(msg.StatusCode);
                    eMsg.Message = "Image format not supported!";
                }
                else
                    eMsg.StatusCode = 200;
            }
            catch (Exception e)
            {
                throw new Exception("Error Uploading file, try later.");
            }
            return eMsg;
        }

        public async Task<APIUserDetails> AddUserDetailsForCAAsync(APIUserDetails apiUserDetails)
        {
            var uri = API.UserMaster.AddUserDetailsForCA(_ServiceBaseUrl);
            var UserContent = new StringContent(JsonConvert.SerializeObject(apiUserDetails), System.Text.Encoding.UTF8, "application/json");
            var responseString = await _apiClient.PostAsync(uri, UserContent);
            var response = JsonConvert.DeserializeObject<APIUserDetails>(await responseString.Content.ReadAsStringAsync());
            return response;
        }

        public async Task<APIUserDetails> UpdateUserDetailsForPAAsync(int id, APIUserDetails apiUserDetails)
        {
            var uri = API.UserMaster.UpdateUserDetailsForPA(_ServiceBaseUrl, id);
            var UserContent = new StringContent(JsonConvert.SerializeObject(apiUserDetails), System.Text.Encoding.UTF8, "application/json");
            var response = await _apiClient.PutAsync(uri, UserContent);

            if (response.StatusCode == System.Net.HttpStatusCode.InternalServerError)
            {
                throw new Exception("Error updating user, try later.");
            }
            response.EnsureSuccessStatusCode();
            return apiUserDetails;
        }

        public async Task<APIUserDetails> UpdateUserDetailsForCAAsync(int id, APIUserDetails apiUserDetails)
        {
            var uri = API.UserMaster.UpdateUserDetailsForCA(_ServiceBaseUrl, id);
            var UserContent = new StringContent(JsonConvert.SerializeObject(apiUserDetails), System.Text.Encoding.UTF8, "application/json");
            var response = await _apiClient.PutAsync(uri, UserContent);

            if (response.StatusCode == System.Net.HttpStatusCode.InternalServerError)
            {
                //throw new Exception("Error updating user, try later.");
                apiUserDetails = null;
            }
            response.EnsureSuccessStatusCode();
            return apiUserDetails;
        }

        public async Task DeleteUserDetailsForPAAsync(int id)
        {
            var uri = API.UserMaster.DeleteUserDetails(_ServiceBaseUrl, id);
            var response = await _apiClient.DeleteAsync(uri);

            if (response.StatusCode == System.Net.HttpStatusCode.InternalServerError)
            {
                throw new Exception("Error deleteting user, try later.");
            }
            response.EnsureSuccessStatusCode();
        }

        public async Task DeleteUserDetailsForCAAsync(int id)
        {
            var uri = API.UserMaster.DeleteUserDetails(_ServiceBaseUrl, id);
            var response = await _apiClient.DeleteAsync(uri);

            if (response.StatusCode == System.Net.HttpStatusCode.InternalServerError)
            {
                throw new Exception("Error deleteting user, try later.");
            }
            response.EnsureSuccessStatusCode();
        }

        public async Task<int> GetActiveUsersCountAsync()
        {
            var uri = API.UserMaster.GetActiveUsersCount(_ServiceBaseUrl);
            var responseString = await _apiClient.GetStringAsync(uri);
            var response = JsonConvert.DeserializeObject<int>(responseString);
            return response;
        }

        public async Task<bool> IsExistAsync(APIIsExistInput apiIsExistInput)
        {
            var uri = API.UserMaster.IsExist(_ServiceBaseUrl);
            var UserContent = new StringContent(JsonConvert.SerializeObject(apiIsExistInput), System.Text.Encoding.UTF8, "application/json");
            var responseString = await _apiClient.PostAsync(uri, UserContent);
            var response = JsonConvert.DeserializeObject<IsExistModel>(await responseString.Content.ReadAsStringAsync());
            return response.exists;
        }

        public async Task<APIUserProfile> GetUserProfileAsync()
        {
            var uri = API.UserMaster.GetUserProfile(_ServiceBaseUrl);
            var responseString = await _apiClient.GetStringAsync(uri);
            var response = JsonConvert.DeserializeObject<APIUserProfile>(responseString);
            return response;
        }

        public async Task<APIUserProfile> AddUserProfileAsync(APIUserProfile userProfile)
        {
            var uri = API.UserMaster.AddUserProfile(_ServiceBaseUrl);
            var UserProfileContent = new StringContent(JsonConvert.SerializeObject(userProfile), System.Text.Encoding.UTF8, "application/json");
            var response = await _apiClient.PostAsync(uri, UserProfileContent);
            var NewUserProfile = JsonConvert.DeserializeObject<APIUserProfile>(await response.Content.ReadAsStringAsync());
            if (response.StatusCode == System.Net.HttpStatusCode.InternalServerError)
            {
                throw new Exception("Error Adding user Profile, try later.");
            }
            response.EnsureSuccessStatusCode();
            return NewUserProfile;
        }

        public async Task<APIUserProfile> UpdateUserProfileAsync(int Id, APIUserProfile userProfile)
        {
            var uri = API.UserMaster.UpdateUserProfile(_ServiceBaseUrl, Id);
            var UserProfileContent = new StringContent(JsonConvert.SerializeObject(userProfile), System.Text.Encoding.UTF8, "application/json");
            var response = await _apiClient.PutAsync(uri, UserProfileContent);

           if (response.StatusCode == System.Net.HttpStatusCode.InternalServerError)
            {
                throw new Exception("Error updating user profile, try later.");
            }
            response.EnsureSuccessStatusCode();
            return userProfile;
        }

        public async Task<APIUserProfile> GetUserProfileAsync(int Id)
        {
            var uri = API.UserMaster.GetUserProfile(_ServiceBaseUrl, Id);
            var responseString = await _apiClient.GetStringAsync(uri);
            var response = JsonConvert.DeserializeObject<APIUserProfile>(responseString);
            return response;
        }

        public async Task<APIFileBase64Model> GetUserProfilePic()
        {
            var uri = API.UserMaster.GetUserProfilePic(_ServiceBaseUrl);
            //_apiClient.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", token);
            var responseString = await _apiClient.GetStringAsync(uri);
            var response = JsonConvert.DeserializeObject<APIFileBase64Model>(responseString);
            return response;
        }
    }    
}
