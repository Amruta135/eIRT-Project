﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using eIRTAdmin.Models;
using eIRTAdmin.Models.APIModels;
using eIRTAdmin.Infrastructure;
using System.Net.Http;
using Microsoft.AspNetCore.Http;
using System.IO;

namespace eIRTAdmin.Services
{
    public class UserProfileService : IUserProfileService
    {
        private HttpClient _apiClient;
        private readonly string _ServiceBaseUrl;
        private readonly IOptions<AppSettings> _settings;
        public string AccessToken { get; set; }
        private HttpContext hcontext;

        public UserProfileService(HttpClient httpClient, IOptions<AppSettings> settings,
            IHttpContextAccessor haccess)
        {
            _apiClient = httpClient;
            _settings = settings;
            _ServiceBaseUrl = $"{settings.Value.AppUserUrl}";
            hcontext = haccess.HttpContext;
            AccessToken = hcontext.User.FindFirst("AccessToken") != null ? hcontext.User.FindFirst("AccessToken").Value : "";
            _apiClient.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", AccessToken);
        }

        public async Task<APIUserProfile> GetUserProfileAsync(int Id)
        {
            var uri = API.UserProfile.GetUserProfile(_ServiceBaseUrl, Id);
            var responseString = await _apiClient.GetStringAsync(uri);
            var response = JsonConvert.DeserializeObject<APIUserProfile>(responseString);
            return response;
        }

        public async Task<APIUserProfile> GetUserProfileByGuIdAsync(Guid GuId)
        {
            var uri = API.UserProfile.GetUserProfileByGuId(_ServiceBaseUrl, GuId);
            var responseString = await _apiClient.GetStringAsync(uri);
            var response = JsonConvert.DeserializeObject<APIUserProfile>(responseString);
            return response;
        }

        public async Task<List<APIUserProfile>> GetUserProfileAsync()
        {
            var uri = API.UserProfile.GetUserProfile(_ServiceBaseUrl);
            var responseString = await _apiClient.GetStringAsync(uri);
            var response = JsonConvert.DeserializeObject<List<APIUserProfile>>(responseString);
            return response;
        }
        public async Task<APIUserProfile> AddUserProfileAsync(APIUserProfile userProfile)
        {
            var uri = API.UserProfile.AddUserProfile(_ServiceBaseUrl);
            var UserProfileContent = new StringContent(JsonConvert.SerializeObject(userProfile), System.Text.Encoding.UTF8, "application/json");
            var response = await _apiClient.PostAsync(uri, UserProfileContent);
            var NewUserProfile = JsonConvert.DeserializeObject<APIUserProfile>(await response.Content.ReadAsStringAsync());
            if (response.StatusCode == System.Net.HttpStatusCode.InternalServerError)
            {
                throw new Exception("Error Adding user Profile, try later.");
            }
            response.EnsureSuccessStatusCode();
            return NewUserProfile;
        }

        public async Task<APIUserProfile> UpdateUserProfileAsync(int Id, APIUserProfile userProfile)
        {
            var uri = API.UserProfile.UpdateUserProfile(_ServiceBaseUrl, Id);
            var UserProfileContent = new StringContent(JsonConvert.SerializeObject(userProfile), System.Text.Encoding.UTF8, "application/json");
            var response = await _apiClient.PutAsync(uri, UserProfileContent);

            if (response.StatusCode == System.Net.HttpStatusCode.InternalServerError)
            {
                throw new Exception("Error updating user profile, try later.");
            }
            response.EnsureSuccessStatusCode();
            return userProfile;
        }
        //public async Task<bool> IsExist(string FieldName, string value)
        //{
        //    var uri = API.UPIPSPBankInformation.IsExist(_ServiceBaseUrl, FieldName, value);

        //    var responseString = await _apiClient.GetStringAsync(uri);
        //    var response = JsonConvert.DeserializeObject<bool>(responseString);
        //    return response;
        //}
        public async Task DeleteUserProfileAsync(int Id)
        {
            var uri = API.UserProfile.DeleteUserProfile(_ServiceBaseUrl, Id);
            var response = await _apiClient.DeleteAsync(uri);

            if (response.StatusCode == System.Net.HttpStatusCode.InternalServerError)
            {
                throw new Exception("Error deleteting User Profile, try later.");
            }
            response.EnsureSuccessStatusCode();
        }

        public async Task UploadProfilePicAsync(int Id, Guid guid, IFormFile Pic)
        {
            APIUserProfilePic profilePic = new APIUserProfilePic()
            {
                Id = Id,
                UserMasterGuId = guid,
                ProfilePic = Pic
            };
            var uri = API.UserProfile.UpdateUserProfilePic(_ServiceBaseUrl);
            //var BankInfoIcon = new StringContent(JsonConvert.SerializeObject(bankIcon), System.Text.Encoding.UTF8, "application/json");
            byte[] data;
            HttpResponseMessage msg = new HttpResponseMessage();
            try
            {
                using (var br = new BinaryReader(Pic.OpenReadStream()))
                {
                    data = br.ReadBytes((int)Pic.OpenReadStream().Length);
                }
                ByteArrayContent bytes = new ByteArrayContent(data);
                MultipartFormDataContent multiContent = new MultipartFormDataContent();
                multiContent.Add(bytes, "ProfilePic", Pic.FileName);
                multiContent.Add(new StringContent(guid.ToString()), "UserMasterGuId");
                multiContent.Add(new StringContent(Id.ToString()), "Id");
                msg = await _apiClient.PutAsync(uri, multiContent);

                if (msg.StatusCode == System.Net.HttpStatusCode.InternalServerError)
                {
                    throw new Exception("Error Uploading file, try later.");
                }
            }
            catch (Exception e)
            {
                throw new Exception("Error Uploading file, try later.");
            }
            msg.EnsureSuccessStatusCode();
            //return bankInfo;
        }

        async public Task<string> GetUserProfilePic(Guid GuId)
        {
            var uri = API.UserDetails.GetUserProfilePic(_ServiceBaseUrl);
            //_apiClient.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", token);
            var responseString = await _apiClient.GetStringAsync(uri);
                //var response = JsonConvert.DeserializeObject<string>(responseString);
                return responseString;
        }        
    }
}
