﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using eIRTAdmin.Infrastructure;
using System.Net.Http;
using Microsoft.Extensions.Options;
using eIRTAdmin.Models;
using Newtonsoft.Json;

namespace eIRTAdmin.Services
{
    public class UserIdentityService : IUserIdentityService
    {
        private HttpClient _apiClient;
        private readonly string _ServiceBaseUrl;
        private readonly IOptions<AppSettings> _settings;

        public UserIdentityService(HttpClient httpClient, IOptions<AppSettings> settings)
        {
            _apiClient = httpClient;
            _settings = settings;
            _ServiceBaseUrl = $"{settings.Value.IdentityUrl}";
        }

        public async Task<IdentityResponseModel> GetTokenAsync(string UserId, string Password, string organizationCode)
        {
            var uri = API.UserIdentity.GetToken(_ServiceBaseUrl);
            IdentityModel reqObj = new IdentityModel()
            { UserName= UserId,
            Password = Password};

            var IdentiyContent = new StringContent(JsonConvert.SerializeObject(reqObj), System.Text.Encoding.UTF8, "application/json");
            HttpContent content = new FormUrlEncodedContent(new[] {
                    new KeyValuePair<string, string>("grant_type", "implicit"),
                    new KeyValuePair<string, string>("client_id", "client"),
                    new KeyValuePair<string, string>("username", UserId),
                    new KeyValuePair<string, string>("password", Password),
                    new KeyValuePair<string, string>("loggedinweb", "1"),
                    new KeyValuePair<string, string>("organizationcode", organizationCode)
            });
            var responseString = await _apiClient.PostAsync(uri, content);
            var response = JsonConvert.DeserializeObject<IdentityResponseModel>(await responseString.Content.ReadAsStringAsync());
            return response;
        }
    }
}
