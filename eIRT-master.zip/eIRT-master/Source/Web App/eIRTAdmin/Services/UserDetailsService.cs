﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using eIRTAdmin.Infrastructure;
using System.Net.Http;
using Microsoft.Extensions.Options;
using eIRTAdmin.Models;
using Newtonsoft.Json;
using eIRTAdmin.Models.APIModels;

namespace eIRTAdmin.Services
{
    public class UserDetailsService : IUserDetailsService
    {
        private HttpClient _apiClient;
        private readonly string _ServiceBaseUrl;
        private readonly IOptions<AppSettings> _settings;

        public UserDetailsService(HttpClient httpClient, IOptions<AppSettings> settings)
        {
            _apiClient = httpClient;
            _settings = settings;
            _ServiceBaseUrl = $"{settings.Value.AppUserUrl}";
        }

        public async Task<UserDetails> GetUserDetailsAsync(string token)
        {
            var uri = API.UserDetails.GetUserDetails(_ServiceBaseUrl);
            _apiClient.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", token);
            var responseString = await _apiClient.GetStringAsync(uri);
            var response = JsonConvert.DeserializeObject<UserDetails>(responseString);
            return response;
        }

        async public Task<string> GetUserProfilePic(string token)
        {
            var uri = API.UserDetails.GetUserProfilePic(_ServiceBaseUrl);
            _apiClient.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", token);
            var responseString = await _apiClient.GetStringAsync(uri);
            var response = JsonConvert.DeserializeObject<APIFileBase64Model>(responseString);
            return response.FileBase64 ?? "";
        }

        async public Task<bool> UserLogout(string token)
        {
            var uri = API.UserMaster.UserLogOut(_ServiceBaseUrl);
            _apiClient.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", token);
            var responseString = await _apiClient.GetStringAsync(uri);
            var response = JsonConvert.DeserializeObject<IsSuccess>(responseString);
            return response.success;
        }


    }
}
