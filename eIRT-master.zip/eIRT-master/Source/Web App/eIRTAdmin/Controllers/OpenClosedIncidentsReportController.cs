﻿using eIRTAdmin.Models.APIModels;
using eIRTAdmin.Services.Interface;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using Microsoft.Net.Http.Headers;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;

namespace eIRTAdmin.Controllers
{
    public class OpenClosedIncidentsReportController : Controller
    {
        private IIncidentReportService _incidentRptSvc;
        private HttpContext _hcontext;
        private IDepartmentService _deptSvc;
        private IIncidentCategoryService _incidentCategorySvc;
        private readonly ICompetencyService _competencySvc;
        private readonly IMapper _mapper;

        public OpenClosedIncidentsReportController(IIncidentReportService incidentRptSvc,
                                                   IHttpContextAccessor haccess,
                                                   IOptions<AppSettings> settings,
                                                   IDepartmentService deptSvc,
                                                   IIncidentCategoryService incidentCategorySvc,
                                                   ICompetencyService competencySvc,
                                                   IMapper mapper)
        {
            _incidentRptSvc = incidentRptSvc;
            _hcontext = haccess.HttpContext;
            _deptSvc = deptSvc;
            _incidentCategorySvc = incidentCategorySvc;
            _competencySvc = competencySvc;
            _mapper = mapper;
            if (_hcontext.User == null || _hcontext.User.FindFirst("AccessToken") == null)
            {
                Response.Redirect(Url.Action("Logout", "Account"));
            }
        }

        [HttpGet]
        public async Task<IActionResult> Index()
        {
            APISearchInfo apiSearchInfo = new APISearchInfo();
            apiSearchInfo.page = 1;
            apiSearchInfo.pageSize = 1000;
            APIListAndCountIncident listAndCount = await _incidentCategorySvc.GetIncidentCategorysAsync(apiSearchInfo);
            ViewBag.ListOfCategories = listAndCount.apiIncidentCategories;

            APIListAndCountDepartment listAndCounts = await _deptSvc.GetDepartmentsAsync(apiSearchInfo);
            ViewBag.ListOfDepartments = listAndCounts.apiDepartments;
            ViewBag.Competencies = await _competencySvc.GetAllCompetenciesAsync();

            APIOpenClosedIncidentReport incidentReport = new APIOpenClosedIncidentReport();
            ViewBag.FullMonth = "";
            ViewBag.SearchDataMonth = "";
            ViewBag.SearchDataYear = "";
            ViewBag.SearchDataStatus = "";
            ViewBag.SearchDataCategory = "";
            ViewBag.SearchDataDepartment = "";

            ViewBag.FullMonthJson = JsonConvert.SerializeObject("");
            ViewBag.SearchDataMonthJson = JsonConvert.SerializeObject("");
            ViewBag.SearchDataYearJson = JsonConvert.SerializeObject("");
            ViewBag.SearchDataStatusJson = JsonConvert.SerializeObject("");
            ViewBag.SearchDataCategoryJson = JsonConvert.SerializeObject("");
            ViewBag.SearchDataDepartmentJson = JsonConvert.SerializeObject("");

            ViewBag.MenuId = "menuOpenClosedIncidentsReport";
            return View("Index", incidentReport);
        }

        //[HttpPost]
        //public async Task<IActionResult> Index(APIOpenClosedIncidentSearch incidentSearch)
        //{
        //    ViewBag.MenuId = "menuOpenClosedIncidentsReport";
        //    APISearchInfo apiSearchInfo = new APISearchInfo();
        //    apiSearchInfo.page = 1;
        //    apiSearchInfo.pageSize = 1000;
        //    APIListAndCountIncident listAndCount = await _incidentCategorySvc.GetIncidentCategorysAsync(apiSearchInfo);
        //    ViewBag.ListOfCategories = listAndCount.apiIncidentCategories;

        //    APIListAndCountDepartment listAndCounts = await _deptSvc.GetDepartmentsAsync(apiSearchInfo);
        //    ViewBag.ListOfDepartments = listAndCounts.apiDepartments;

        //    if (incidentSearch.month > 0 && incidentSearch.year > 0)
        //    {
        //        DateTime firstDay = new DateTime(incidentSearch.year, incidentSearch.month, 1);
        //        DateTime lastDay = firstDay.AddMonths(1).AddDays(-1);
        //        incidentSearch.startDate = firstDay;
        //        incidentSearch.endDate = lastDay;
        //    }
        //    if (incidentSearch.month == 0 && incidentSearch.year > 0)
        //    {
        //        DateTime firstDay = new DateTime(incidentSearch.year, 1, 1);
        //        DateTime lastDay = firstDay.AddMonths(12).AddDays(-1);
        //        incidentSearch.startDate = firstDay;
        //        incidentSearch.endDate = lastDay;
        //    }
        //    if (incidentSearch.month == 0 && incidentSearch.year == 0)
        //    {
        //        incidentSearch.startDate = Convert.ToDateTime("01/01/2020");   //Default Start Date
        //        incidentSearch.endDate = DateTime.Now;
        //    }
        //    if(incidentSearch.status==null)
        //    {
        //        incidentSearch.status = "";
        //    }

        //    APIOpenClosedIncidentReport incidentReport = new APIOpenClosedIncidentReport();
        //    incidentReport = await this._incidentRptSvc.GetOpenClosedIncidentsReport(incidentSearch);
        //    if (incidentReport.reportDate == null)
        //    {
        //        return View(incidentReport);
        //    }

        //    var month = incidentSearch.month;
        //    var localizeValue = "";
        //    switch (month)
        //    {
        //        case 1: localizeValue = "Jan"; break;
        //        case 2: localizeValue = "Feb"; break;
        //        case 3: localizeValue = "Mar"; break;
        //        case 4: localizeValue = "Apr"; break;
        //        case 5: localizeValue = "May"; break;
        //        case 6: localizeValue = "Jun"; break;
        //        case 7: localizeValue = "Jul"; break;
        //        case 8: localizeValue = "Aug"; break;
        //        case 9: localizeValue = "Sep"; break;
        //        case 10: localizeValue = "Oct"; break;
        //        case 11: localizeValue = "Nov"; break;
        //        case 12: localizeValue = "Dec"; break;
        //    }

        //    ViewBag.FullMonth = localizeValue;
        //    ViewBag.SearchDataMonth = incidentSearch.month;
        //    ViewBag.SearchDataYear = incidentSearch.year;
        //    ViewBag.SearchDataStatus = incidentSearch.status;
        //    ViewBag.SearchDataCategory = incidentSearch.category;
        //    ViewBag.SearchDataDepartment = incidentSearch.departmentId;

        //    ViewBag.FullMonthJson = JsonConvert.SerializeObject(localizeValue);
        //    ViewBag.SearchDataMonthJson = JsonConvert.SerializeObject(incidentSearch.month);
        //    ViewBag.SearchDataYearJson = JsonConvert.SerializeObject(incidentSearch.year);
        //    ViewBag.SearchDataStatusJson = JsonConvert.SerializeObject(incidentSearch.status);
        //    ViewBag.SearchDataCategoryJson = JsonConvert.SerializeObject(incidentSearch.category);
        //    ViewBag.SearchDataDepartmentJson = JsonConvert.SerializeObject(incidentSearch.departmentId);

        //    return View("Index", incidentReport);
        //}

        [HttpPost]
        public async Task<IActionResult> IndexJson(APIOpenClosedIncidentSearch incidentSearch)
        {
            ViewBag.MenuId = "menuOpenClosedIncidentsReport";

            if (incidentSearch.month > 0 && incidentSearch.year > 0)
            {
                DateTime firstDay = new DateTime(incidentSearch.year, incidentSearch.month, 1);
                DateTime lastDay = firstDay.AddMonths(1).AddDays(-1);
                incidentSearch.startDate = firstDay;
                incidentSearch.endDate = lastDay;
            }
            if (incidentSearch.month == 0 && incidentSearch.year > 0)
            {
                DateTime firstDay = new DateTime(incidentSearch.year, 1, 1);
                DateTime lastDay = firstDay.AddMonths(12).AddDays(-1);
                incidentSearch.startDate = firstDay;
                incidentSearch.endDate = lastDay;
            }
            if (incidentSearch.month == 0 && incidentSearch.year == 0)
            {
                incidentSearch.startDate = Convert.ToDateTime("01/01/2020");   //Default Start Date
                incidentSearch.endDate = DateTime.Now;
            }
            if (incidentSearch.status == null)
            {
                incidentSearch.status = "";
            }

            APIOpenClosedIncidentReport incidentReport = new APIOpenClosedIncidentReport();
            incidentReport = await this._incidentRptSvc.GetOpenClosedIncidentsReport(incidentSearch);
            incidentReport.reportDate = incidentReport.reportDate == null ? new List<APIOpenClosedIncidentInfo>() : incidentReport.reportDate;
            
            return Json(new { isValid = true, html = Helper.RenderRezorView.RenderRazorViewToString(this, "_ViewAll", incidentReport) });
        }

        [HttpGet]
        public async Task<IActionResult> ExportXlsx(int month, int year, int category, int departmentId, string status = "")
        {
            APIOpenClosedIncidentSearch incidentSearch = new APIOpenClosedIncidentSearch();
            incidentSearch.month = month;
            incidentSearch.year = year;
            incidentSearch.status = status;
            incidentSearch.category = category;
            incidentSearch.departmentId = departmentId;

            if (incidentSearch.month > 0 && incidentSearch.year > 0)
            {
                DateTime firstDay = new DateTime(incidentSearch.year, incidentSearch.month, 1);
                DateTime lastDay = firstDay.AddMonths(1).AddDays(-1);
                incidentSearch.startDate = firstDay;
                incidentSearch.endDate = lastDay;
            }
            if (incidentSearch.month == 0 && incidentSearch.year > 0)
            {
                DateTime firstDay = new DateTime(incidentSearch.year, 1, 1);
                DateTime lastDay = firstDay.AddMonths(12).AddDays(-1);
                incidentSearch.startDate = firstDay;
                incidentSearch.endDate = lastDay;
            }
            if (incidentSearch.month == 0 && incidentSearch.year == 0)
            {
                incidentSearch.startDate = Convert.ToDateTime("01/01/2020");   //Default Start Date
                incidentSearch.endDate = DateTime.Now;
            }
            if (incidentSearch.status == null)
            {
                incidentSearch.status = "";
            }
            var stream = await _incidentRptSvc.ExportXlsxAsync(incidentSearch);
            return new FileStreamResult(stream, new MediaTypeHeaderValue("application/xlsx"))
            {
                FileDownloadName = "OpenClosedIncidentReport.xlsx",
                EnableRangeProcessing = true
            };
        }

        [HttpPost]
        public async Task<IActionResult> DataForExport(APIOpenClosedIncidentSearch incidentSearch)
        {
            if (incidentSearch.month > 0 && incidentSearch.year > 0)
            {
                DateTime firstDay = new DateTime(incidentSearch.year, incidentSearch.month, 1);
                DateTime lastDay = firstDay.AddMonths(1).AddDays(-1);
                incidentSearch.startDate = firstDay;
                incidentSearch.endDate = lastDay;
            }
            if (incidentSearch.month == 0 && incidentSearch.year > 0)
            {
                DateTime firstDay = new DateTime(incidentSearch.year, 1, 1);
                DateTime lastDay = firstDay.AddMonths(12).AddDays(-1);
                incidentSearch.startDate = firstDay;
                incidentSearch.endDate = lastDay;
            }
            if (incidentSearch.month == 0 && incidentSearch.year == 0)
            {
                incidentSearch.startDate = Convert.ToDateTime("01/01/2020");   //Default Start Date
                incidentSearch.endDate = DateTime.Now;
            }
            if (incidentSearch.status == null)
            {
                incidentSearch.status = "";
            }

            APIOpenClosedIncidentReport incidentReport = new APIOpenClosedIncidentReport();
            incidentReport = await this._incidentRptSvc.GetOpenClosedIncidentsReport(incidentSearch);
            try
            {
                List<APIOpenClosedIncidentInfoExport> incidents = incidentReport.reportDate.Select(x => new APIOpenClosedIncidentInfoExport
                {
                    Department = x.Department ?? "---",
                    DateReported = x.DateReported.ToString("dd-MMM-yyyy"),
                    ATRReportedBy = x.ReportedBy ?? "---",
                    LastActionTaken = x.LastActionTaken == null || x.LastActionTaken == DateTime.MinValue ? "---" : x.LastActionTaken.Value.ToString("dd-MMM-yyyy"),
                    ReportedBy = x.ReportedBy ?? "---",
                    BriefDescription = x.BriefDescription ?? "---",
                    CorrectiveActions = x.CorrectiveActions ?? "---",
                    IncidentCategory = x.IncidentCategory,
                    Competencies = x.Competencies != null && x.Competencies.Count() > 0 ? string.Join(", ", x.Competencies.Select(y => y.CompetencyDescription)) : "---",
                    Status = x.Status
                }).ToList();
                //List<APIOpenClosedIncidentInfoExport> incidents = _mapper.Map<List<APIOpenClosedIncidentInfoExport>>(incidentReport.reportDate);
                return Json(incidents);
            }
            catch (Exception e)
            {
                return Json(new List<APIOpenClosedIncidentInfoExport>());
            }
        }
    }
}
