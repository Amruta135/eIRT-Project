﻿using eIRTAdmin.Helper;
using eIRTAdmin.Models;
using eIRTAdmin.Models.APIModels;
using eIRTAdmin.Services.Interface;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace eIRTAdmin.Controllers
{
    [Authorize(Roles = RoleCode.IRT_Client_Admin)]
    public class CompetencyController : Controller
    {
        private ICompetencyService _competencySvc;
        private HttpContext _hcontext;

        public CompetencyController(ICompetencyService competencySvc,
                                            IHttpContextAccessor haccess)
        {
            _competencySvc = competencySvc;
            _hcontext = haccess.HttpContext;
            if (_hcontext.User == null || _hcontext.User.FindFirst("AccessToken") == null)
            {
                Response.Redirect(Url.Action("Logout", "Account"));
            }
        }

        public IActionResult Index(APISearchInfo searchInfo)
        {
            searchInfo.page = 1;
            searchInfo.pageSize = 10;
            APIListAndCountCompetencies listAndCount = new APIListAndCountCompetencies(); //await _roleConfigSvc.GetRolesConfigurationsAsync(searchInfo);
            ViewBag.RecordCount = 0;
            ViewBag.TotalPageCount = 1;
            ViewBag.Page = searchInfo.page;
            ViewBag.MenuId = "menuCompetency";
            return View(listAndCount.Competencies);
        }

        public async Task<IActionResult> IndexJson(APISearchInfo searchInfo)
        {
            searchInfo.page = searchInfo.page == 0 ? 1 : searchInfo.page;
            searchInfo.pageSize = searchInfo.pageSize == 0 ? 10 : searchInfo.pageSize;
            APIListAndCountCompetencies listAndCount = await _competencySvc.GetCompetenciesAsync(searchInfo);
            ViewBag.Page = searchInfo.page;
            ViewBag.RecordCount = listAndCount.Count;
            ViewBag.TotalPageCount = (int)Math.Ceiling((decimal)ViewBag.RecordCount / (decimal)searchInfo.pageSize);
            return Json(new { isValid = true, html = Helper.RenderRezorView.RenderRazorViewToString(this, "_ViewAll", listAndCount.Competencies)});
        }

        public IActionResult Create()
        {
            return PartialView("Create");
        }

        [HttpPost]
        public async Task<IActionResult> Create(APICompetency info)
        {
            IsSuccess result = new IsSuccess() { success = false};
            if (ModelState.IsValid)
            {
                result = await _competencySvc.AddCompetencyAsync(info);

                if (result.success)
                {
                    //APISearchInfo searchInfo = new APISearchInfo();
                    //searchInfo.page = 1;
                    //searchInfo.pageSize = 10;
                    //APIListAndCountCompetencies listAndCount = await _competencySvc.GetCompetenciesAsync(searchInfo);
                    //ViewBag.RecordCount = listAndCount.Count;
                    //ViewBag.TotalPageCount = (int)Math.Ceiling((decimal)ViewBag.RecordCount / (decimal)searchInfo.pageSize);
                    //return Json(new { isValid = true, html = Helper.RenderRezorView.RenderRazorViewToString(this, "_ViewAll", listAndCount.Competencies) });
                    return Json(new { isValid = true});
                }
                else
                    ModelState.AddModelError("CompetencyDescription", result.message);
            }
            return Json(new { isValid = false, html = Helper.RenderRezorView.RenderRazorViewToString(this, "Create", info) });
        }

        public async Task<IActionResult> Edit(APIId apiId)
        {
            APICompetency info = await this._competencySvc.GetCompetencyAsync(apiId);

            return PartialView("Edit", info);
        }

        [HttpPost]
        public async Task<IActionResult> Edit(APICompetency info)
        {
            IsSuccess result = new IsSuccess() { success = false, message = "" };
            if (ModelState.IsValid)
            {
                result = await this._competencySvc.UpdateCompetencyAsync(info);

                if (result.success)
                {
                    //APISearchInfo searchInfo = new APISearchInfo();
                    //searchInfo.page = 1;
                    //searchInfo.pageSize = 10;
                    //APIListAndCountCompetencies listAndCount = await _competencySvc.GetCompetenciesAsync(searchInfo);
                    //ViewBag.RecordCount = listAndCount.Count;
                    //ViewBag.TotalPageCount = (int)Math.Ceiling((decimal)ViewBag.RecordCount / (decimal)searchInfo.pageSize);
                    //return Json(new { isValid = true, html = Helper.RenderRezorView.RenderRazorViewToString(this, "_ViewAll", listAndCount.Competencies) });
                    return Json(new { isValid = true });
                }
                else
                {
                    ModelState.AddModelError("CompetencyDescription", result.message);
                }
            }

            return Json(new { isValid = false, html = Helper.RenderRezorView.RenderRazorViewToString(this, "Edit", info) });
        }

        public async Task<IActionResult> Delete(APIId apiId)
        {
            IsSuccess result = new IsSuccess() { success = false, message = "" };

            result = await this._competencySvc.DeleteCompetencyAsync(apiId);

            return Json(result);
        }

        [HttpGet]
        public async Task<bool> IsCompetencyExist(string CompetencyDescription, int? Id)
        {
            bool isExist = false;
            APIIsExistInput apiIsExistInput = new APIIsExistInput();
            apiIsExistInput.FieldName = "CompetencyDescription";
            apiIsExistInput.value = CompetencyDescription;
            apiIsExistInput.Id = Id;
            if (Id > 0)
            {
                APIId apiId = new APIId();
                apiId.Id = Id.GetValueOrDefault();
                APICompetency competency = await _competencySvc.GetCompetencyAsync(apiId);
                if (CompetencyDescription.Trim().ToLower() != competency.CompetencyDescription.ToLower())
                    isExist = await this._competencySvc.IsExistAsync(apiIsExistInput);
            }
            else
            {
                isExist = await this._competencySvc.IsExistAsync(apiIsExistInput);
            }
            return !isExist;
        }
    }
}
