﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using eIRTAdmin.Models;
using eIRTAdmin.Services;
using System.Security.Claims;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.DataProtection;
using Microsoft.AspNetCore.Localization;
using eIRTAdmin.Helper;
using Microsoft.AspNetCore.Identity;
using eIRTAdmin.Models.APIModels;
using System.Net.NetworkInformation;

namespace eIRTAdmin.Controllers
{
    public class AccountController : Controller
    {
        private IUserIdentityService _identitySvc;
        private IUserDetailsService _userSvc;
        private HttpContext _hcontext;
        private readonly IDataProtector _protector;
        private IUserMasterService _userMasterSvc;

        public AccountController(IUserIdentityService identitySvc,
            IUserDetailsService userSvc,
            IHttpContextAccessor haccess,
            IDataProtectionProvider provider,
            IUserMasterService userMasterSvc)
        {
            _identitySvc = identitySvc;
            _userSvc = userSvc;
            _hcontext = haccess.HttpContext;
            _protector = provider.CreateProtector("mydataprotectorkey");
            _userMasterSvc = userMasterSvc;
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public async Task<IActionResult> Login(string returnUrl)
        {
            UserDetails CurrentUser = new UserDetails();
            ViewBag.showQuestion = false;
            string loggedInUserDomainName = System.Net.NetworkInformation.IPGlobalProperties.GetIPGlobalProperties().DomainName;
            if (_hcontext.User.FindFirst("AccessToken") != null && !string.IsNullOrWhiteSpace(_hcontext.User.FindFirst("AccessToken").Value))
            {
                try
                {
                    CurrentUser = await _userSvc.GetUserDetailsAsync(_hcontext.User.FindFirst("AccessToken").Value);
                    if (CurrentUser != null)
                    {
                        ViewBag.showQuestion = false;
                        //ViewBag.IsFirstLogin = CurrentUser.IsFirstLogin;
                        string displayGuid = _protector.Protect(CurrentUser.GuId.ToString());
                        string[] roles = CurrentUser.Role.Split(",");
                        if (roles[0].ToString() != "PA" && CurrentUser.AllowToLogin == false)
                        {
                            return RedirectToAction("ValidityExpiredLogout", "Account", new { displayGuId = displayGuid });
                        }

                        if (roles[0].ToString() != "PA" && !CurrentUser.DeliveryModel.Equals("Cloud") && loggedInUserDomainName != CurrentUser.DomainName.ToString())
                        {
                            return RedirectToAction("ValidityExpiredLogout", "Account", new { displayGuId = displayGuid });
                        }
                        if (CurrentUser != null && CurrentUser.IsFirstLogin == true)
                        {
                            return RedirectToAction("ChangePasswordAtFirstLogin", "UserProfile");
                        }

                        if (roles[0].ToString() != Helper.RoleCode.Posiview_Admin)
                        {
                            return RedirectToAction("Index", "Dashboard");
                        }
                        return RedirectToAction("Index", "Home");
                    }
                    else if(CurrentUser == null)
                    {
                        await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
                        _hcontext.User = null;
                        _hcontext = null;
                        foreach (var cookie in Request.Cookies.Keys)
                        {
                            Response.Cookies.Delete(cookie);
                        }
                        HttpContext.Session.Clear();
                        HttpContext.Request.Headers["Authorization"] = "";
                        return View();
                    }
                }
                catch (Exception e)
                {
                    await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
                    _hcontext.User = null;
                    _hcontext = null;
                    foreach (var cookie in Request.Cookies.Keys)
                    {
                        Response.Cookies.Delete(cookie);
                    }
                    HttpContext.Session.Clear();
                    HttpContext.Request.Headers["Authorization"] = "";
                    return View();
                }
            }
            return View();
        }

        [HttpPost]
        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public async Task<IActionResult> Login(LoginViewModel userLogin)
        {
            if (ModelState.IsValid)
            {
                string loggedInUserDomainName =  System.Net.NetworkInformation.IPGlobalProperties.GetIPGlobalProperties().DomainName;

                var IdentityResponse = await this._identitySvc.GetTokenAsync(userLogin.UserId, userLogin.Password, userLogin.OrganizationCode);
                if (IdentityResponse != null && IdentityResponse.access_token != null)
                {
                    
                    UserDetails CurrentUser = await _userSvc.GetUserDetailsAsync(IdentityResponse.access_token);
                    if (CurrentUser != null && CurrentUser.GuId != Guid.Empty && CurrentUser.Status == Helper.Status.Active)
                    {
                        var claims = new List<Claim>();

                        string displayGuid = _protector.Protect(CurrentUser.GuId.ToString());

                        claims.Add(new Claim("User_Guid", CurrentUser.GuId.ToString()));
                        claims.Add(new Claim(ClaimTypes.NameIdentifier, CurrentUser.GuId.ToString()));
                        claims.Add(new Claim(ClaimTypes.Name, CurrentUser.Name));
                        claims.Add(new Claim(ClaimTypes.Expired, (IdentityResponse.expires_in / 60).ToString()));
                        claims.Add(new Claim("AccessToken", IdentityResponse.access_token.ToString()));
                        claims.Add(new Claim(ClaimTypes.MobilePhone, CurrentUser.MobileNumber));
                        claims.Add(new Claim("User_Satus", CurrentUser.Status));
                        //claims.Add(new Claim("FirstLoginDate", CurrentUser.FirstLoginDate != DateTime.MinValue ? CurrentUser.FirstLoginDate.GetValueOrDefault().ToString("dd-MMM-yyyy") : ""));
                        claims.Add(new Claim("LastLoggedInTime", CurrentUser.LastLoggedInTime ?? "--"));
                        claims.Add(new Claim("DisplayUser_Guid", displayGuid));
                        claims.Add(new Claim("AllowToLogin", CurrentUser.AllowToLogin == true ? "true" : "false"));
                        claims.Add(new Claim("Organization", CurrentUser.Organization));
                        claims.Add(new Claim("AppName", CurrentUser.AppName));
                        claims.Add(new Claim("RGBCode", CurrentUser.RGBCode));
                        claims.Add(new Claim("IsFirstLogin", CurrentUser.IsFirstLogin.ToString()));

                        string[] roles = CurrentUser.Role.Split(",");
                        foreach (string role in roles)
                        {
                            claims.Add(new Claim(ClaimTypes.Role, role));
                        }

                        var identity = new ClaimsIdentity(
                            claims, CookieAuthenticationDefaults.
                            AuthenticationScheme);

                        var principal = new ClaimsPrincipal(identity);

                        var props = new AuthenticationProperties();
                        props.IsPersistent = true;//model.RememberMe;
                        props.IssuedUtc = DateTimeOffset.UtcNow;
                        props.AllowRefresh = false;
                        props.ExpiresUtc = DateTimeOffset.UtcNow.AddMinutes(IdentityResponse.expires_in / 60);

                         await HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme,
                                                        new ClaimsPrincipal(principal),props);

                        if (roles[0].ToString() != "PA" && CurrentUser.AllowToLogin == false)
                        {
                            return RedirectToAction("ValidityExpiredLogout", "Account", new { displayGuId = displayGuid });
                        }

                        if (roles[0].ToString() != "PA" && !CurrentUser.DeliveryModel.Equals("Cloud") && loggedInUserDomainName != CurrentUser.DomainName.ToString())
                        {
                            return RedirectToAction("ValidityExpiredLogout", "Account", new { displayGuId = displayGuid });
                        }

                        ViewBag.showQuestion = false;
                        //.IsFirstLogin = CurrentUser.IsFirstLogin;
                        if (CurrentUser != null && CurrentUser.IsFirstLogin == true)
                        {
                            return RedirectToAction("ChangePasswordAtFirstLogin", "UserProfile");
                        }
                        
                        if (roles[0].ToString() != Helper.RoleCode.Posiview_Admin)
                        {
                            return RedirectToAction("Index", "Dashboard");
                        }
                        return RedirectToAction("Index", "Home");
                    }
                    else
                    {
                        ModelState.AddModelError("UserId", "Your user id expired or Not Active");
                        ViewBag.showQuestion = true;
                        return View("Login", userLogin);
                    }
                }
                else
                {
                    ModelState.AddModelError("UserId", "Invalid User Id / Mobile Or Password");
                    ViewBag.showQuestion = true;
                    return View("Login", userLogin);
                }
            }
            else
            {
                ViewBag.showQuestion = true;
                return View("Login", userLogin);
            }
        }


        //[HttpPost]
        [ResponseCache(Duration = -1, Location = ResponseCacheLocation.None, NoStore = true)]
        public async Task<IActionResult> Logout()
        
        {

            string AccessToken = _hcontext.User.FindFirst("AccessToken") != null ? _hcontext.User.FindFirst("AccessToken").Value : "";
            try
            {
                bool logout = await _userSvc.UserLogout(AccessToken);
            }
            catch (Exception e) {
                string a = e.Message;
            }
            await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
            _hcontext.User = null;
            _hcontext = null;
            //var usr = _hcontext.User;
            //HttpContext.Response.Cookies.Delete($".AspNetCore.{CookieAuthenticationDefaults.AuthenticationScheme}");
            HttpContext.Session.Clear();
            HttpContext.Request.Headers["Authorization"] = "";
            //Response.Headers.Clear();
            foreach (var cookie in Request.Cookies.Keys)
            {
                Response.Cookies.Delete(cookie);
            }
            return new SignOutResult(CookieAuthenticationDefaults.AuthenticationScheme,
                new Microsoft.AspNetCore.Authentication.AuthenticationProperties { RedirectUri = Url.Action("Login", "Account") });
            //return RedirectToAction("Login", "Account");
        }

        public async Task<IActionResult> ValidityExpiredLogout(string displayGuid)
        {
            string AccessToken = _hcontext.User.FindFirst("AccessToken") != null ? _hcontext.User.FindFirst("AccessToken").Value : "";
            try
            {
                bool logout = await _userSvc.UserLogout(AccessToken);
            }
            catch (Exception) { }
            return RedirectToAction("ExtendedValidityExpired", "Account", new { displayGuId = displayGuid });
        }

        [HttpGet]
        public async Task<IActionResult> ExtendedValidityExpired(string displayGuId)
        {
            Guid guid = Guid.Parse(_protector.Unprotect(displayGuId));

            await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
            _hcontext.User = null;
            var usr = _hcontext.User;
            return View();
        }

        //public async Task<IActionResult> MenuSwitch(string menu)
        //{
        //    try
        //    {
        //        var UserGuid = _hcontext.User.FindFirst("User_Guid") != null ? _hcontext.User.FindFirst("User_Guid").Value : "";
        //        APIUserAppMenu UserAppMenu = new APIUserAppMenu();
        //        UserAppMenu.GuId = Guid.Parse(UserGuid);
        //        UserAppMenu.AppMenu = menu;

        //        if (UserAppMenu.GuId != null && UserAppMenu.GuId != Guid.Empty)
        //        {
        //            Models.IsSuccess success = await _userMasterSvc.ChangeUserAppMenuAsync(UserAppMenu);
        //            if (success.success)
        //                HttpContext.Session.SetString("AppMenu", UserAppMenu.AppMenu);
        //        }
        //    }
        //    catch (Exception e)
        //    {
        //        return RedirectToAction("Index", "Home");
        //    }
        //    return RedirectToAction("Index", "Home");
        //    //HttpContext.Session.SetString("AppMenu", menu);

        //    //return RedirectToAction("Index", "Home");
        //}

        public async Task<IActionResult> MissingSystemStandardData(string displayGuid)
        {
            string AccessToken = _hcontext.User.FindFirst("AccessToken") != null ? _hcontext.User.FindFirst("AccessToken").Value : "";
            try
            {
                bool logout = await _userSvc.UserLogout(AccessToken);
            }
            catch (Exception) { }
            return RedirectToAction("MissingSystemStandardLogout", "Account", new { displayGuId = displayGuid });
        }

        [HttpGet]
        public async Task<IActionResult> MissingSystemStandardLogout(string displayGuId)
        {
            Guid guid = Guid.Parse(_protector.Unprotect(displayGuId));

            await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
            _hcontext.User = null;
            var usr = _hcontext.User;
            return View();
        }

        [HttpGet]
        public IActionResult BusinessNotCreatedOrNotConnectedToBiller()
        {
            return View();
        }
    }
}