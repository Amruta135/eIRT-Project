﻿using eIRTAdmin.Helper;
using eIRTAdmin.Models;
using eIRTAdmin.Models.APIModels;
using eIRTAdmin.Services;
using eIRTAdmin.Services.Interface;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using Newtonsoft.Json;

namespace eIRTAdmin.Controllers
{
    [Authorize(Roles = "CA, PA")]
    public class UserMasterController : Controller
    {
        private IUserMasterService _userMasterSvc;
        private HttpContext _hcontext;
        private IDepartmentService _deptSvc;
        private IOrganizationInfoService _orgInfoSvc;
        private IRolesConfigurationService _roleConfigSvc;
        private readonly ICompetencyService _competencySvc;
        private readonly IMapper _mapper;

        public UserMasterController(IUserMasterService userMasterSvc,
                                    IHttpContextAccessor haccess,
                                    IDepartmentService deptSvc,
                                    IOrganizationInfoService orgInfoSvc,
                                    IRolesConfigurationService roleConfigSvc,
                                    ICompetencyService competencySvc,
                                    IMapper mapper)
        {
            _userMasterSvc = userMasterSvc;
            _hcontext = haccess.HttpContext;
            _deptSvc = deptSvc;
            _orgInfoSvc = orgInfoSvc;
            _roleConfigSvc = roleConfigSvc;
            _competencySvc = competencySvc;
            _mapper = mapper;
            if (_hcontext.User == null || _hcontext.User.FindFirst("AccessToken") == null)
            {
                Response.Redirect(Url.Action("Logout", "Account"));
            }
        }

        public IActionResult IndexForPA(APISearchInfo searchInfo)
        {
            searchInfo.page = 1;
            searchInfo.pageSize = 10;
            APIListAndCountforUserMaster listAndCount = new APIListAndCountforUserMaster(); //await _userMasterSvc.GetUsersForPAAsync(searchInfo);
            ViewBag.RecordCount = 0;
            ViewBag.TotalPageCount = 1;
            ViewBag.Page = searchInfo.page;
            ViewBag.MenuId = "menuUserMaster";
            return View(listAndCount.apiUserDetails);
        }

        public async Task<IActionResult> IndexForPAJson(APISearchInfo searchInfo)
        {
            searchInfo.page = searchInfo.page == 0 ? 1 : searchInfo.page;
            searchInfo.pageSize = searchInfo.pageSize == 0 ? 10 : searchInfo.pageSize;
            APIListAndCountforUserMaster listAndCount = await _userMasterSvc.GetUsersForPAAsync(searchInfo);
            ViewBag.Page = searchInfo.page;
            ViewBag.RecordCount = listAndCount.count;
            ViewBag.TotalPageCount = (int)Math.Ceiling((decimal)ViewBag.RecordCount / (decimal)searchInfo.pageSize);
            return Json(new { isValid = true, html = Helper.RenderRezorView.RenderRazorViewToString(this, "_ViewAllPA", listAndCount.apiUserDetails) });
        }

        public async Task<IActionResult> CreateForPA()
        {
            APISearchInfo aPISearchInfo = new APISearchInfo();
            aPISearchInfo.page = 1;
            aPISearchInfo.pageSize = 1000;
            APIListAndCountDepartment list= await _deptSvc.GetDepartmentsAsync(aPISearchInfo);
            ViewBag.ListOfDepartments = list.apiDepartments;

            APIListAndCount listAndCount = await _orgInfoSvc.GetOrganizationInfosAsync(aPISearchInfo);
            ViewBag.ListOfOrganizations = listAndCount.apiOrganizationInfo.Where(x=>x.CreatedBy!=0 && !x.HasAdmin);

            return PartialView("CreateForPA");
        }

        [HttpPost]
        public async Task<IActionResult> CreateForPA(APIUserDetailsForPA info)
        {
            APISearchInfo aPISearchInfo = new APISearchInfo();
            try
            {
                if (ModelState.IsValid)
                {
                    APIUserDetails details = new APIUserDetails()
                    {
                        CreatedBy = info.CreatedBy,
                        DepartmentId=info.DepartmentId,
                        Designation=info.Designation,
                        Email=info.Email,
                        EmployeeCode=info.EmployeeCode,
                        GuId=info.GuId,
                        Id=info.Id,
                        LastLoggedInTime=info.LastLoggedInTime,
                        MobileNumber=info.MobileNumber,
                        Name=info.Name,
                        Organization=info.Organization,
                        OrganizationCode=info.OrganizationCode,
                        OTP=info.OTP,
                        ProfilePic=info.ProfilePic,
                        ProfilePicBase64=info.ProfilePicBase64,
                        Role=info.Role,
                        Status=info.Status,
                        UserProfilePic=info.UserProfilePic
                    };
                    APIUserDetails newUserDetails = await _userMasterSvc.AddUserDetailsForPAAsync(details);
                    if (newUserDetails.Id > 0 && newUserDetails.GuId != Guid.Empty && details.ProfilePic != null)
                    {
                        await this._userMasterSvc.UpdateUserProfilePic(newUserDetails.Id, newUserDetails.GuId, details.ProfilePic);
                    }
                    APISearchInfo searchInfo = new APISearchInfo();
                    searchInfo.page = 1;
                    searchInfo.pageSize = 10;
                    APIListAndCountforUserMaster apiListAndCount = await _userMasterSvc.GetUsersForPAAsync(searchInfo);
                    ViewBag.RecordCount = apiListAndCount.count;
                    ViewBag.TotalPageCount = (int)Math.Ceiling((decimal)ViewBag.RecordCount / (decimal)searchInfo.pageSize);

                    return Json(new { isValid = true, html = Helper.RenderRezorView.RenderRazorViewToString(this, "_ViewAllPA", apiListAndCount.apiUserDetails) });
                }
            }
            catch (Exception e)
            {
                ModelState.AddModelError("Error", $"It was not possible to add a new buyer, please try later on ({e.GetType().Name} - {e.Message})");
            }

            aPISearchInfo.page = 1;
            aPISearchInfo.pageSize = 1000;

            APIListAndCountDepartment list = await _deptSvc.GetDepartmentsAsync(aPISearchInfo);
            ViewBag.ListOfDepartments = list.apiDepartments;

            APIListAndCount listAndCount = await _orgInfoSvc.GetOrganizationInfosAsync(aPISearchInfo);
            ViewBag.ListOfOrganizations = listAndCount.apiOrganizationInfo.Where(x => x.CreatedBy != 0 && !x.HasAdmin);

            return Json(new { isValid = false, html = Helper.RenderRezorView.RenderRazorViewToString(this, "CreateForPA", info) });
        }        

        public async Task<IActionResult> EditForPA(int id)
        {
            APISearchInfo aPISearchInfo = new APISearchInfo();
            aPISearchInfo.page = 1;
            aPISearchInfo.pageSize = 1000;
            APIListAndCountDepartment list = await _deptSvc.GetDepartmentsAsync(aPISearchInfo);
            ViewBag.ListOfDepartments = list.apiDepartments;

            APIListAndCount listAndCount = await _orgInfoSvc.GetOrganizationInfosAsync(aPISearchInfo);
            ViewBag.ListOfOrganizations = listAndCount.apiOrganizationInfo.Where(x => x.CreatedBy != 0);

            APIUserDetails userDetails = await _userMasterSvc.GetUserAsync(id);

            APIUserDetailsForPA details = new APIUserDetailsForPA()
            {
                CreatedBy = userDetails.CreatedBy,
                DepartmentId = userDetails.DepartmentId,
                Designation = userDetails.Designation,
                Email = userDetails.Email,
                EmployeeCode = userDetails.EmployeeCode,
                GuId = userDetails.GuId,
                Id = userDetails.Id,
                LastLoggedInTime = userDetails.LastLoggedInTime,
                MobileNumber = userDetails.MobileNumber,
                Name = userDetails.Name,
                Organization = userDetails.Organization,
                OrganizationCode = userDetails.OrganizationCode,
                OTP = userDetails.OTP,
                ProfilePic = userDetails.ProfilePic,
                ProfilePicBase64 = userDetails.ProfilePicBase64,
                Role = userDetails.Role,
                Status = userDetails.Status,
                UserProfilePic = userDetails.UserProfilePic
            };

            return PartialView("EditForPA",details);
        }

        [HttpPost]
        public async Task<IActionResult> EditForPA(APIUserDetailsForPA info)
        {
            APISearchInfo searchInfo = new APISearchInfo();
            if (ModelState.IsValid)
            {
                APIUserDetails details = new APIUserDetails()
                {
                    CreatedBy = info.CreatedBy,
                    DepartmentId = info.DepartmentId,
                    Designation = info.Designation,
                    Email = info.Email,
                    EmployeeCode = info.EmployeeCode,
                    GuId = info.GuId,
                    Id = info.Id,
                    LastLoggedInTime = info.LastLoggedInTime,
                    MobileNumber = info.MobileNumber,
                    Name = info.Name,
                    Organization = info.Organization,
                    OrganizationCode = info.OrganizationCode,
                    OTP = info.OTP,
                    ProfilePic = info.ProfilePic,
                    ProfilePicBase64 = info.ProfilePicBase64,
                    Role = info.Role,
                    Status = info.Status,
                    UserProfilePic = info.UserProfilePic
                };
                APIUserDetails userDetails = await this._userMasterSvc.UpdateUserDetailsForPAAsync(info.Id, details);
                if (userDetails.Id > 0 && userDetails.GuId != Guid.Empty && details.ProfilePic != null)
                {
                    await this._userMasterSvc.UpdateUserProfilePic(userDetails.Id, userDetails.GuId, details.ProfilePic);
                }
                if (userDetails != null)
                {
                    searchInfo.page = 1;
                    searchInfo.pageSize = 10;
                    APIListAndCountforUserMaster apiListAndCount = await _userMasterSvc.GetUsersForPAAsync(searchInfo);
                    ViewBag.RecordCount = apiListAndCount.count;
                    ViewBag.TotalPageCount = (int)Math.Ceiling((decimal)ViewBag.RecordCount / (decimal)searchInfo.pageSize);

                    return Json(new { isValid = true, html = Helper.RenderRezorView.RenderRazorViewToString(this, "_ViewAllPA", apiListAndCount.apiUserDetails) });
                }
            }

            searchInfo.page = 1;
            searchInfo.pageSize = 1000;

            APIListAndCountDepartment list = await _deptSvc.GetDepartmentsAsync(searchInfo);
            ViewBag.ListOfDepartments = list.apiDepartments;

            APIListAndCount listAndCount = await _orgInfoSvc.GetOrganizationInfosAsync(searchInfo);
            ViewBag.ListOfOrganizations = listAndCount.apiOrganizationInfo.Where(x => x.CreatedBy != 0);

            return Json(new { isValid = false, html = Helper.RenderRezorView.RenderRazorViewToString(this, "EditForPA", info) });
        }

        public async Task<IActionResult> DeleteForPA(int id)
        {
            await this._userMasterSvc.DeleteUserDetailsForPAAsync(id);
            return RedirectToAction("IndexForPA");
        }

        public async Task<IActionResult> IndexForCA(APISearchInfo searchInfo)
        {
            searchInfo.page = 1;
            searchInfo.pageSize = 10;
            APIListAndCountforUserMaster listAndCount = new APIListAndCountforUserMaster(); //await _userMasterSvc.GetUsersForCAAsync(searchInfo);
            ViewBag.RecordCount = 0;
            ViewBag.TotalPageCount = 1;
            ViewBag.Page = searchInfo.page;
            ViewBag.MenuId = "menuUserMaster";
            ViewBag.OrganizationMaxUsers = await _orgInfoSvc.GetOrganizationMaxUsers();
            return View(listAndCount.apiUserDetails);
        }

        public async Task<IActionResult> IndexForCAJson(APISearchInfo searchInfo)
        {
            searchInfo.page = searchInfo.page == 0 ? 1 : searchInfo.page;
            searchInfo.pageSize = searchInfo.pageSize == 0 ? 10 : searchInfo.pageSize;
            APIListAndCountforUserMaster listAndCount = await _userMasterSvc.GetUsersForCAAsync(searchInfo);
            ViewBag.Page = searchInfo.page;
            ViewBag.RecordCount = listAndCount.count;
            ViewBag.TotalPageCount = (int)Math.Ceiling((decimal)ViewBag.RecordCount / (decimal)searchInfo.pageSize);
            return Json(new { isValid = true, html = Helper.RenderRezorView.RenderRazorViewToString(this, "_ViewAllCA", listAndCount.apiUserDetails) });
            //return View(listAndCount.apiUserDetails);
        }

        public async Task<IActionResult> CreateForCA()
        {
            APISearchInfo aPISearchInfo = new APISearchInfo();
            aPISearchInfo.page = 1;
            aPISearchInfo.pageSize = 1000;
            APIListAndCountDepartment list = await _deptSvc.GetDepartmentsAsync(aPISearchInfo);
            ViewBag.ListOfDepartments = list.apiDepartments.OrderBy(x=>x.Name);

            APIListAndCountRoleConfig roles = await _roleConfigSvc.GetRolesConfigurationsAsync(aPISearchInfo);
            ViewBag.ListOfRoles = roles.apiRolesConfigurations.Where(x=>x.OriginalRoleCode != Helper.RoleCode.IRT_Client_Admin).OrderBy(x=>x.ChangedRoleDescription);

            APIOrganizationInfo apiOrganization = await _orgInfoSvc.GetCurrentUserOrganizationAsync();
            ViewBag.Organization = apiOrganization.OrganizationName;
            ViewBag.OrganizationCode = apiOrganization.OrganizationCode;
            ViewBag.ActiveUsers = await _userMasterSvc.GetActiveUsersCountAsync();
            ViewBag.OrganizationMaxUsers = await _orgInfoSvc.GetOrganizationMaxUsers();
            ViewBag.Competencies = await _competencySvc.GetAllCompetenciesAsync();
            return PartialView("CreateForCA");
        }

        [HttpPost]
        public async Task<IActionResult> CreateForCA(APIUserDetails info)
        {
            APISearchInfo aPISearchInfo = new APISearchInfo();
            APIListAndCountDepartment list = new APIListAndCountDepartment();
            APIListAndCountRoleConfig roles = new APIListAndCountRoleConfig();
            APIOrganizationInfo apiOrganization = new APIOrganizationInfo();
            try
            {
                if (ModelState.IsValid)
                {
                    if(info.OTP!=null)
                    {
                        if (info.CompetencyArr != null && info.CompetencyArr.Length > 0)
                        {
                            info.CompetencyIds = string.Join(",", info.CompetencyArr);
                        }
                        else
                            info.CompetencyIds = null;
                        APIUserDetails newUserDetails = await _userMasterSvc.AddUserDetailsForCAAsync(info);
                        
                        if (newUserDetails.Id > 0 && newUserDetails.GuId != Guid.Empty)
                        {
                            if (info.ProfilePic != null)
                            {
                                await this._userMasterSvc.UpdateUserProfilePic(newUserDetails.Id, newUserDetails.GuId, info.ProfilePic);
                            }
                            APISearchInfo searchInfo = new APISearchInfo();
                            searchInfo.page = 1;
                            searchInfo.pageSize = 10;
                            APIListAndCountforUserMaster apiListAndCount = await _userMasterSvc.GetUsersForCAAsync(searchInfo);
                            ViewBag.RecordCount = apiListAndCount.count;
                            ViewBag.TotalPageCount = (int)Math.Ceiling((decimal)ViewBag.RecordCount / (decimal)searchInfo.pageSize);

                            return Json(new { isValid = true, html = Helper.RenderRezorView.RenderRazorViewToString(this, "_ViewAllCA", apiListAndCount.apiUserDetails) });
                        }
                    }
                    else
                    {
                        ModelState.AddModelError("OTP", "Onetime Password field is required.");

                        aPISearchInfo.page = 1;
                        aPISearchInfo.pageSize = 1000;

                        list = await _deptSvc.GetDepartmentsAsync(aPISearchInfo);
                        ViewBag.ListOfDepartments = list.apiDepartments;

                        roles = await _roleConfigSvc.GetRolesConfigurationsAsync(aPISearchInfo);
                        ViewBag.ListOfRoles = roles.apiRolesConfigurations.Where(x => x.OriginalRoleCode != Helper.RoleCode.IRT_Client_Admin).OrderBy(x=>x.ChangedRoleDescription);

                        apiOrganization = await _orgInfoSvc.GetCurrentUserOrganizationAsync();
                        ViewBag.Organization = apiOrganization.OrganizationName;
                        ViewBag.OrganizationCode = apiOrganization.OrganizationCode;
                        ViewBag.ActiveUsers = await _userMasterSvc.GetActiveUsersCountAsync();
                        ViewBag.OrganizationMaxUsers = await _orgInfoSvc.GetOrganizationMaxUsers();
                        ViewBag.Competencies = await _competencySvc.GetAllCompetenciesAsync();

                        return Json(new { isValid = false, html = Helper.RenderRezorView.RenderRazorViewToString(this, "CreateForCA", info) });
                    }
                }
            }
            catch (Exception e)
            {
                ModelState.AddModelError("Error", $"It was not possible to add a new buyer, please try later on ({e.GetType().Name} - {e.Message})");
            }

            aPISearchInfo.page = 1;
            aPISearchInfo.pageSize = 1000;

            list = await _deptSvc.GetDepartmentsAsync(aPISearchInfo);
            ViewBag.ListOfDepartments = list.apiDepartments;

            roles = await _roleConfigSvc.GetRolesConfigurationsAsync(aPISearchInfo);
            ViewBag.ListOfRoles = roles.apiRolesConfigurations;

            apiOrganization = await _orgInfoSvc.GetCurrentUserOrganizationAsync();
            ViewBag.Organization = apiOrganization.OrganizationName;
            ViewBag.OrganizationCode = apiOrganization.OrganizationCode;
            ViewBag.ActiveUsers = await _userMasterSvc.GetActiveUsersCountAsync();
            ViewBag.OrganizationMaxUsers = await _orgInfoSvc.GetOrganizationMaxUsers();

            return Json(new { isValid = false, message = "User already exist or incorrect data!", html = Helper.RenderRezorView.RenderRazorViewToString(this, "CreateForCA", info) });
        }

        public async Task<IActionResult> EditForCA(int id)
        {
            APISearchInfo aPISearchInfo = new APISearchInfo();
            aPISearchInfo.page = 1;
            aPISearchInfo.pageSize = 1000;
            APIListAndCountDepartment list = await _deptSvc.GetDepartmentsAsync(aPISearchInfo);
            ViewBag.ListOfDepartments = list.apiDepartments;

            APIUserDetails userDetails = await _userMasterSvc.GetUserAsync(id);
            if (!string.IsNullOrWhiteSpace(userDetails.CompetencyIds))
            {
                userDetails.CompetencyArr = userDetails.CompetencyIds.Split(",");
            }

            APIListAndCountRoleConfig roles = await _roleConfigSvc.GetRolesConfigurationsAsync(aPISearchInfo);
            ViewBag.ListOfRoles = userDetails.Role != Helper.RoleCode.IRT_Client_Admin ? roles.apiRolesConfigurations.Where(x=>x.OriginalRoleCode != Helper.RoleCode.IRT_Client_Admin).OrderBy(x=>x.ChangedRoleDescription)
                                  : roles.apiRolesConfigurations.OrderBy(x => x.ChangedRoleDescription);
            ViewBag.Competencies = await _competencySvc.GetAllCompetenciesAsync();

            APIOrganizationInfo apiOrganization = await _orgInfoSvc.GetCurrentUserOrganizationAsync();
            ViewBag.Organization = apiOrganization.OrganizationName;
            ViewBag.OrganizationCode = apiOrganization.OrganizationCode;
            userDetails.Organization = apiOrganization.OrganizationName;            

            return PartialView("EditForCA", userDetails);
        }

        [HttpPost]
        public async Task<IActionResult> EditForCA(APIUserDetails info)
        {
            APISearchInfo searchInfo = new APISearchInfo();
            if (ModelState.IsValid)
            {
                if (info.CompetencyArr != null && info.CompetencyArr.Length > 0)
                {
                    info.CompetencyIds = string.Join(",", info.CompetencyArr);
                }
                else
                    info.CompetencyIds = null;
                APIUserDetails userDetails = await this._userMasterSvc.UpdateUserDetailsForCAAsync(info.Id, info);
                if (userDetails != null && userDetails.Id > 0 && userDetails.GuId != Guid.Empty)
                {
                    if (info.ProfilePic != null)
                    {
                        await this._userMasterSvc.UpdateUserProfilePic(userDetails.Id, userDetails.GuId, info.ProfilePic);
                    }
                    searchInfo.page = 1;
                    searchInfo.pageSize = 10;
                    APIListAndCountforUserMaster apiListAndCount = await _userMasterSvc.GetUsersForCAAsync(searchInfo);
                    ViewBag.RecordCount = apiListAndCount.count;
                    ViewBag.TotalPageCount = (int)Math.Ceiling((decimal)ViewBag.RecordCount / (decimal)searchInfo.pageSize);

                    //return Json(new { isValid = true, html = Helper.RenderRezorView.RenderRazorViewToString(this, "_ViewAllCA", apiListAndCount.apiUserDetails) });
                    return Json(new { isValid = true });
                }
            }

            searchInfo.page = 1;
            searchInfo.pageSize = 1000;

            APIListAndCountDepartment list = await _deptSvc.GetDepartmentsAsync(searchInfo);
            ViewBag.ListOfDepartments = list.apiDepartments;

            APIListAndCountRoleConfig roles = await _roleConfigSvc.GetRolesConfigurationsAsync(searchInfo);
            ViewBag.ListOfRoles = info.Role != Helper.RoleCode.IRT_Client_Admin ? roles.apiRolesConfigurations.Where(x => x.OriginalRoleCode != Helper.RoleCode.IRT_Client_Admin).OrderBy(x => x.ChangedRoleDescription)
                                  : roles.apiRolesConfigurations.OrderBy(x => x.ChangedRoleDescription);
            ViewBag.Competencies = await _competencySvc.GetAllCompetenciesAsync();
            APIOrganizationInfo apiOrganization = await _orgInfoSvc.GetCurrentUserOrganizationAsync();
            ViewBag.Organization = apiOrganization.OrganizationName;
            ViewBag.OrganizationCode = apiOrganization.OrganizationCode;
            info.Organization = apiOrganization.OrganizationName;

            return Json(new { isValid = false, message="Duplicat Employee code or mobile, or Invalid data!", html = Helper.RenderRezorView.RenderRazorViewToString(this, "EditForCA", info) });
        }

        public async Task<IActionResult> DeleteForCA(int id)
        {
            await this._userMasterSvc.DeleteUserDetailsForCAAsync(id);
            return RedirectToAction("IndexForCA");
        }

        public async Task<IActionResult> GetDepartmentByOrganization(string organizationCode)
        {
            APIDepartmentsWithOrganization aPIDepartments = new APIDepartmentsWithOrganization();
            aPIDepartments.OrganizationCode = organizationCode;

            List<APIDepartments> departments = await _deptSvc.GetDepartmentByOrganization(aPIDepartments);
            departments = departments ?? new List<APIDepartments>();
            return Json(departments);
        }

        [HttpGet]
        public async Task<bool> IsEmployeeCodeExist(string EmployeeCode, string OrganizationCode, int? Id)
        {
            bool isExist = false;
            APIIsExistInput apiIsExistInput = new APIIsExistInput();
            apiIsExistInput.FieldName = "EmployeeCode";
            apiIsExistInput.value = EmployeeCode;
            apiIsExistInput.OrganizationCode = OrganizationCode;
            apiIsExistInput.Id = Id;
            if (Id > 0)
            {
                APIUserDetails userDetails = await _userMasterSvc.GetUserAsync(Id.GetValueOrDefault());
                if (EmployeeCode != userDetails.EmployeeCode)
                    isExist = await this._userMasterSvc.IsExistAsync(apiIsExistInput);
            }
            else
            {
                isExist = await this._userMasterSvc.IsExistAsync(apiIsExistInput);
            }
            return !isExist;
        }

        [HttpGet]
        public async Task<bool> IsMobileExist(string MobileNumber, string OrganizationCode, int? Id)
        {
            bool isExist = false;
            APIIsExistInput apiIsExistInput = new APIIsExistInput();
            apiIsExistInput.FieldName = "MobileNumber";
            apiIsExistInput.value = MobileNumber;
            apiIsExistInput.OrganizationCode = OrganizationCode;
            apiIsExistInput.Id = Id;
            if (Id > 0)
            {
                APIUserDetails userDetails = await _userMasterSvc.GetUserAsync(Id.GetValueOrDefault());
                if (MobileNumber != userDetails.MobileNumber)
                    isExist = await this._userMasterSvc.IsExistAsync(apiIsExistInput);
            }
            else
            {
                isExist = await this._userMasterSvc.IsExistAsync(apiIsExistInput);
            }
            return !isExist;
        }
        
        [HttpGet]
        public async Task<bool> IsEmailExist(string Email, string OrganizationCode, int? Id)
        {
            bool isExist = false;
            APIIsExistInput apiIsExistInput = new APIIsExistInput();
            apiIsExistInput.FieldName = "Email";
            apiIsExistInput.value = Email;
            apiIsExistInput.OrganizationCode = OrganizationCode;
            apiIsExistInput.Id = Id;
            if (Id > 0)
            {
                APIUserDetails userDetails = await _userMasterSvc.GetUserAsync(Id.GetValueOrDefault());
                if (Email != userDetails.Email)
                    isExist = await this._userMasterSvc.IsExistAsync(apiIsExistInput);
            }
            else
            {
                isExist = await this._userMasterSvc.IsExistAsync(apiIsExistInput);
            }
            return !isExist;
        }
        
        [HttpPost]
        public async Task<IActionResult> DataForPAExport(APISearchInfo searchInfo)
        {
            searchInfo.page = searchInfo.page == 0 ? 1 : searchInfo.page;
            searchInfo.pageSize = searchInfo.pageSize == 0 ? 10 : searchInfo.pageSize;
            APIListAndCountforUserMaster listAndCount = await _userMasterSvc.GetUsersForPAAsync(searchInfo);
            listAndCount.apiUserDetails.ForEach(x => x.LastLoggedInTime = (x.LastLoggedInTime == "01-Jan-0001" ? "---" : x.LastLoggedInTime ));
            listAndCount.apiUserDetails.ForEach(x => x.Department = x.Department ?? "---");
            List<APIUserDetailsForExport> users = _mapper.Map<List<APIUserDetailsForExport>>(listAndCount.apiUserDetails);
            return Json(users);
        }

        [HttpPost]
        public async Task<IActionResult> DataForCAExport(APISearchInfo searchInfo)
        {
            searchInfo.page = searchInfo.page == 0 ? 1 : searchInfo.page;
            searchInfo.pageSize = searchInfo.pageSize == 0 ? 10 : searchInfo.pageSize;
            APIListAndCountforUserMaster listAndCount = await _userMasterSvc.GetUsersForCAAsync(searchInfo);
            //listAndCount.apiUserDetails.ForEach(x => x.LastLoggedInTime = (x.LastLoggedInTime == "01-Jan-0001" ? "---" : x.LastLoggedInTime));
            List<APIUserDetailsForExport> users = listAndCount.apiUserDetails.Select(x => new APIUserDetailsForExport
            {
                Designation = string.IsNullOrWhiteSpace(x.Designation) ? "---" : x.Designation, 
                Email = x.Email,
                EmployeeCode = x.EmployeeCode,
                MobileNumber = x.MobileNumber,
                Name = x.Name,
                Organization = x.Organization,
                Role = x.Role,
                Status = x.Status,
                Competencies = x.Competencies != null && x.Competencies.Count()> 0 ? string.Join(", " , x.Competencies.Select(x=>x.CompetencyDescription)) : "---" ,
                Department = x.Department ?? "---",
                LastLoggedInTime = (x.LastLoggedInTime == "01-Jan-0001" ? "---" : x.LastLoggedInTime)
            } ).ToList();
            //List<APIUserDetailsForExport> users = _mapper.Map<List<APIUserDetailsForExport>>(listAndCount.apiUserDetails);
            return Json(users);
        }
    }
}
