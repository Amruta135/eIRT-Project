﻿using eIRTAdmin.Helper;
using eIRTAdmin.Models;
using eIRTAdmin.Models.APIModels;
using eIRTAdmin.Services.Interface;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace eIRTAdmin.Controllers
{
    [Authorize(Roles = RoleCode.IRT_Client_Admin)]
    public class RolesConfigurationController : Controller
    {
        private IRolesConfigurationService _roleConfigSvc;
        private HttpContext _hcontext;

        public RolesConfigurationController(IRolesConfigurationService roleConfigSvc,
                                            IHttpContextAccessor haccess)
        {
            _roleConfigSvc = roleConfigSvc;
            _hcontext = haccess.HttpContext;
            if (_hcontext.User == null || _hcontext.User.FindFirst("AccessToken") == null)
            {
                Response.Redirect(Url.Action("Logout", "Account"));
            }
        }

        public IActionResult Index(APISearchInfo searchInfo)
        {
            searchInfo.page = 1;
            searchInfo.pageSize = 10;
            APIListAndCountRoleConfig listAndCount = new APIListAndCountRoleConfig(); //await _roleConfigSvc.GetRolesConfigurationsAsync(searchInfo);
            ViewBag.RecordCount = 0;
            ViewBag.TotalPageCount = 1;
            ViewBag.Page = searchInfo.page;
            ViewBag.MenuId = "menuRolesConfiguration";
            return View(listAndCount.apiRolesConfigurations);
        }

        public async Task<IActionResult> IndexJson(APISearchInfo searchInfo)
        {
            searchInfo.page = searchInfo.page == 0 ? 1 : searchInfo.page;
            searchInfo.pageSize = searchInfo.pageSize == 0 ? 10 : searchInfo.pageSize;
            APIListAndCountRoleConfig listAndCount = await _roleConfigSvc.GetRolesConfigurationsAsync(searchInfo);
            ViewBag.Page = searchInfo.page;
            ViewBag.RecordCount = listAndCount.count;
            ViewBag.TotalPageCount = (int)Math.Ceiling((decimal)ViewBag.RecordCount / (decimal)searchInfo.pageSize);
            return Json(new { isValid = true, html = Helper.RenderRezorView.RenderRazorViewToString(this, "_ViewAll", listAndCount.apiRolesConfigurations) });
        }

        public IActionResult Create()
        {
            return PartialView("Create");
        }

        [HttpPost]
        public async Task<IActionResult> Create(APIRolesConfigurations info)
        {
            if (ModelState.IsValid)
            {
                await _roleConfigSvc.AddRolesConfigurationAsync(info);
                
                APISearchInfo searchInfo = new APISearchInfo();
                searchInfo.page = 1;
                searchInfo.pageSize = 10;
                APIListAndCountRoleConfig listAndCount = await _roleConfigSvc.GetRolesConfigurationsAsync(searchInfo);
                ViewBag.RecordCount = listAndCount.count;
                ViewBag.TotalPageCount = (int)Math.Ceiling((decimal)ViewBag.RecordCount / (decimal)searchInfo.pageSize);
                return Json(new { isValid = true, html = Helper.RenderRezorView.RenderRazorViewToString(this, "_ViewAll", listAndCount.apiRolesConfigurations) });
            }

            return Json(new { isValid = false, html = Helper.RenderRezorView.RenderRazorViewToString(this, "Create", info) });
        }

        public async Task<IActionResult> Edit(APIId apiId)
        {
            APIRolesConfigurations info = await this._roleConfigSvc.GetRoleConfigurationAsync(apiId);

            return PartialView("Edit", info);
        }

        [HttpPost]
        public async Task<IActionResult> Edit(APIRolesConfigurations info)
        {
            if (ModelState.IsValid)
            {
                APIRolesConfigurations rolesConfigurations = await this._roleConfigSvc.UpdateRolesConfigurationAsync(info.Id, info);
                
                if (rolesConfigurations != null)
                {
                    APISearchInfo searchInfo = new APISearchInfo();
                    searchInfo.page = 1;
                    searchInfo.pageSize = 10;
                    APIListAndCountRoleConfig listAndCount = await _roleConfigSvc.GetRolesConfigurationsAsync(searchInfo);
                    ViewBag.RecordCount = listAndCount.count;
                    ViewBag.TotalPageCount = (int)Math.Ceiling((decimal)ViewBag.RecordCount / (decimal)searchInfo.pageSize);
                    return Json(new { isValid = true, html = Helper.RenderRezorView.RenderRazorViewToString(this, "_ViewAll", listAndCount.apiRolesConfigurations) });
                }
            }

            return Json(new { isValid = false, html = Helper.RenderRezorView.RenderRazorViewToString(this, "Edit", info) });
        }

        public async Task<IActionResult> Delete(int id)
        {
            await this._roleConfigSvc.DeleteRolesConfigurationAsync(id);
            return RedirectToAction("Index");
        }

        [HttpGet]
        public async Task<bool> IsChangedRoleExist(string ChangedRoleDescription, int? Id)
        {
            bool isExist = false;
            APIIsExistInput apiIsExistInput = new APIIsExistInput();
            apiIsExistInput.FieldName = "ChangedRoleDescription";
            apiIsExistInput.value = ChangedRoleDescription;
            apiIsExistInput.Id = Id;
            if (Id > 0)
            {
                APIId apiId = new APIId();
                apiId.Id = Id.GetValueOrDefault();
                APIRolesConfigurations rolesConfigurations = await _roleConfigSvc.GetRoleConfigurationAsync(apiId);
                if (ChangedRoleDescription != rolesConfigurations.ChangedRoleDescription)
                    isExist = await this._roleConfigSvc.IsExistAsync(apiIsExistInput);
            }
            else
            {
                isExist = await this._roleConfigSvc.IsExistAsync(apiIsExistInput);
            }
            return !isExist;
        }
    }
}
