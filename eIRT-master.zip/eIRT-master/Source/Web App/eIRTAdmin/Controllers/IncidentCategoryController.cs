﻿using eIRTAdmin.Helper;
using eIRTAdmin.Models;
using eIRTAdmin.Models.APIModels;
using eIRTAdmin.Services.Interface;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace eIRTAdmin.Controllers
{
    [Authorize(Roles = RoleCode.IRT_Client_Admin)]
    public class IncidentCategoryController : Controller
    {
        private IIncidentCategoryService _incidentSvc;
        private HttpContext _hcontext;

        public IncidentCategoryController(IIncidentCategoryService incidentSvc,
                                          IHttpContextAccessor haccess)
        {
            _incidentSvc = incidentSvc;
            _hcontext = haccess.HttpContext;
            if (_hcontext.User == null || _hcontext.User.FindFirst("AccessToken") == null)
            {
                Response.Redirect(Url.Action("Logout", "Account"));
            }
        }

        public IActionResult Index(APISearchInfo searchInfo)
        {
            searchInfo.page = 1;
            searchInfo.pageSize = 10;
            APIListAndCountIncident listAndCount = new APIListAndCountIncident(); //await _incidentSvc.GetIncidentCategorysAsync(searchInfo);
            ViewBag.RecordCount = 0;
            ViewBag.TotalPageCount = 1;
            ViewBag.Page = searchInfo.page;
            ViewBag.MenuId = "menuIncidentCategory";
            return View(listAndCount.apiIncidentCategories);
        }

        public async Task<IActionResult> IndexJson(APISearchInfo searchInfo)
        {
            searchInfo.page = searchInfo.page == 0 ? 1 : searchInfo.page;
            searchInfo.pageSize = searchInfo.pageSize == 0 ? 10 : searchInfo.pageSize;
            APIListAndCountIncident listAndCount = await _incidentSvc.GetIncidentCategorysAsync(searchInfo);
            ViewBag.Page = searchInfo.page;
            ViewBag.RecordCount = listAndCount.count;
            ViewBag.TotalPageCount = (int)Math.Ceiling((decimal)ViewBag.RecordCount / (decimal)searchInfo.pageSize);
            return Json(new { isValid = true, html = Helper.RenderRezorView.RenderRazorViewToString(this, "_ViewAll", listAndCount.apiIncidentCategories) });
        }

        public IActionResult Create()
        {
            return PartialView("Create");
        }

        [HttpPost]
        public async Task<IActionResult> Create(APIIncidentCategory info)
        {
            if (ModelState.IsValid)
            {
                await _incidentSvc.AddIncidentCategoryAsync(info);

                APISearchInfo searchInfo = new APISearchInfo();
                searchInfo.page = 1;
                searchInfo.pageSize = 10;
                APIListAndCountIncident listAndCount = await _incidentSvc.GetIncidentCategorysAsync(searchInfo);
                ViewBag.RecordCount = listAndCount.count;
                ViewBag.TotalPageCount = (int)Math.Ceiling((decimal)ViewBag.RecordCount / (decimal)searchInfo.pageSize);
                return Json(new { isValid = true, html = Helper.RenderRezorView.RenderRazorViewToString(this, "_ViewAll", listAndCount.apiIncidentCategories) });
            }

            return Json(new { isValid = false, html = Helper.RenderRezorView.RenderRazorViewToString(this, "Create", info) });
        }
        
        public async Task<IActionResult> Edit(APIId apiId)
        {
            APIIncidentCategory info = await this._incidentSvc.GetIncidentCategoryAsync(apiId);

            return PartialView("Edit", info);
        }

        [HttpPost]
        public async Task<IActionResult> Edit(APIIncidentCategory info)
        {
            if (ModelState.IsValid)
            {
                APIIncidentCategory incidentCategory = await this._incidentSvc.UpdateIncidentCategoryAsync(info.Id, info);

                if (incidentCategory != null)
                {
                    APISearchInfo searchInfo = new APISearchInfo();
                    searchInfo.page = 1;
                    searchInfo.pageSize = 10;
                    APIListAndCountIncident listAndCount = await _incidentSvc.GetIncidentCategorysAsync(searchInfo);
                    ViewBag.RecordCount = listAndCount.count;
                    ViewBag.TotalPageCount = (int)Math.Ceiling((decimal)ViewBag.RecordCount / (decimal)searchInfo.pageSize);
                    return Json(new { isValid = true, html = Helper.RenderRezorView.RenderRazorViewToString(this, "_ViewAll", listAndCount.apiIncidentCategories) });
                }
            }

            return Json(new { isValid = false, html = Helper.RenderRezorView.RenderRazorViewToString(this, "Edit", info) });
        }

        [HttpGet]
        public async Task<bool> IsIncidentCategoryExist(string Category, int? Id)
        {
            bool isExist = false;
            APIIsExistInput apiIsExistInput = new APIIsExistInput();
            apiIsExistInput.FieldName = "Category";
            apiIsExistInput.value = Category;
            apiIsExistInput.Id = Id;
            if (Id > 0)
            {
                APIId apiId = new APIId();
                apiId.Id = Id.GetValueOrDefault();
                APIIncidentCategory incidentCategory = await _incidentSvc.GetIncidentCategoryAsync(apiId);
                if (Category != incidentCategory.Category)
                    isExist = await this._incidentSvc.IsExistAsync(apiIsExistInput);
            }
            else
            {
                isExist = await this._incidentSvc.IsExistAsync(apiIsExistInput);
            }
            return !isExist;
        }
    }
}
