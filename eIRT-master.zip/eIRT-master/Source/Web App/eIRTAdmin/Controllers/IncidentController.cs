﻿using eIRTAdmin.Models.APIModels;
using eIRTAdmin.Services;
using eIRTAdmin.Services.Interface;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace eIRTAdmin.Controllers
{
    public class IncidentController : Controller
    {
        private IIncidentReportService _incidentRptSvc;
        private IIncidentCategoryService _incidentCatSvc;
        private IActionTakenReportService _actTakenRptSvc;
        private IIncidentAssignmentService _incidentAssignSvc;
        private IDepartmentService _deptSvc;
        private IUserMasterService _userMasterSvc;
        private readonly ICompetencyService _competencySvc;
        private HttpContext _hcontext;
        private string IncidentReportPhotoPath;
        private string UserApiUrl;

        public IncidentController(IIncidentReportService incidentRptSvc,
                                            IHttpContextAccessor haccess,
                                            IOptions<AppSettings> settings,
                                            IIncidentCategoryService incidentCatSvc,
                                            IDepartmentService deptSvc,
                                            IActionTakenReportService actTakenRptSvc,
                                            IIncidentAssignmentService incidentAssignSvc,
                                            IUserMasterService userMasterSvc,
                                            ICompetencyService competencySvc)
        {
            _incidentRptSvc = incidentRptSvc;
            _incidentCatSvc = incidentCatSvc;
            _actTakenRptSvc = actTakenRptSvc;
            _incidentAssignSvc = incidentAssignSvc;
            _userMasterSvc = userMasterSvc;
            _competencySvc = competencySvc;
            _deptSvc = deptSvc;
            _hcontext = haccess.HttpContext;
            UserApiUrl = $"{settings.Value.AppUserUrl}";
            IncidentReportPhotoPath = $"{settings.Value.IncidentReportPhotoPath}";
            if (_hcontext.User == null || _hcontext.User.FindFirst("AccessToken") == null)
            {
                Response.Redirect(Url.Action("Logout", "Account"));
            }
        }

        
        public IActionResult Index(APISearchIncident searchInfo)
        {
            searchInfo.page = searchInfo.page == 0 ? 1 : searchInfo.page;
            searchInfo.pageSize = searchInfo.pageSize == 0 ? 10 : searchInfo.pageSize;
            searchInfo.status = string.IsNullOrWhiteSpace(searchInfo.status) ? "Open" : searchInfo.status;

            APIListAndCountIncidentReport incidentReports = new APIListAndCountIncidentReport(); //await _incidentRptSvc.GetIncidentReportsForManagersAsync(searchInfo) ?? new APIListAndCountIncidentReport();
            ViewBag.RecordCount = 0;
            ViewBag.TotalPageCount = 1;
            ViewBag.Page = searchInfo.page;
            ViewBag.MenuId = "menuOpenClosedIncident";
            return View(incidentReports.apiIncidentReports);
        }

        public async Task<IActionResult> IndexJson(APISearchIncident searchInfo)
        {
            searchInfo.page = searchInfo.page == 0 ? 1 : searchInfo.page;
            searchInfo.pageSize = searchInfo.pageSize == 0 ? 10 : searchInfo.pageSize;
            searchInfo.status = string.IsNullOrWhiteSpace(searchInfo.status) ? "Open" : searchInfo.status;

            APIListAndCountIncidentReport incidentReports = await _incidentRptSvc.GetReportedIncidentsAsync(searchInfo) ?? new APIListAndCountIncidentReport();
            ViewBag.RecordCount = incidentReports.count;
            ViewBag.TotalPageCount = (int)Math.Ceiling((decimal)incidentReports.count / (decimal)searchInfo.pageSize);
            ViewBag.Page = searchInfo.page;
            ViewBag.status = searchInfo.status;
            ViewBag.OpenBtnClass = string.IsNullOrWhiteSpace(searchInfo.status) || searchInfo.status == "Open" ? "btn-warning" : "btn-light";
            ViewBag.ClosedBtnClass = !string.IsNullOrWhiteSpace(searchInfo.status) && searchInfo.status == "Closed" ? "btn-primary" : "btn-light";
            ViewBag.MenuId = "menuOpenClosedIncident";
            return Json(new { isValid = true, html = Helper.RenderRezorView.RenderRazorViewToString(this, "_ViewAll", incidentReports.apiIncidentReports) });
            //return View(incidentReports.apiIncidentReports);
        }

        public async Task<IActionResult> Create()
        {
            APISearchInfo searchInfo = new APISearchInfo();
            searchInfo.page = 1;
            searchInfo.pageSize = 9999;
            APIListAndCountIncident listAndCount = await _incidentCatSvc.GetIncidentCategorysAsync(searchInfo);
            ViewBag.ListOfCategories = listAndCount.apiIncidentCategories;

            APIListAndCountDepartment list = await _deptSvc.GetDepartmentsAsync(searchInfo);
            ViewBag.ListOfDepartments = list.apiDepartments;
            return PartialView("Create");
        }

        [HttpPost]
        public async Task<IActionResult> Create(APIIncidentReport info)
        {
            APISearchInfo searchInfo = new APISearchInfo();
            try
            {
                if (ModelState.IsValid)
                {
                    APIIncidentReport newIncidentReport = await _incidentRptSvc.AddIncidentReportAsync(info);
                    if (info.PhotoFile != null && info.PhotoFile.Length > 0 && newIncidentReport.Id > 0)
                    {
                        await this._incidentRptSvc.UploadIncidentReportPhoto(newIncidentReport.Id, info.PhotoFile);
                    }

                    APISearchIncident incSearchInfo = new APISearchIncident();
                    incSearchInfo.page = 1;
                    incSearchInfo.pageSize = 10;
                    incSearchInfo.status = "Open";
                    APIListAndCountIncidentReport incidentReports = await _incidentRptSvc.GetReportedIncidentsAsync(incSearchInfo) ?? new APIListAndCountIncidentReport();
                    ViewBag.RecordCount = incidentReports.count;
                    ViewBag.TotalPageCount = (int)Math.Ceiling((decimal)incidentReports.count / (decimal)incSearchInfo.pageSize);
                    ViewBag.Page = incSearchInfo.page;
                    ViewBag.status = incSearchInfo.status;
                    ViewBag.OpenBtnClass = string.IsNullOrWhiteSpace(incSearchInfo.status) || incSearchInfo.status == "Open" ? "btn-primary" : "btn-light";
                    ViewBag.ClosedBtnClass = !string.IsNullOrWhiteSpace(incSearchInfo.status) && incSearchInfo.status == "Closed" ? "btn-primary" : "btn-light";
                    ViewBag.MenuId = "menuOpenClosedIncident";

                    return Json(new { isValid = true, html = Helper.RenderRezorView.RenderRazorViewToString(this, "_ViewAll", incidentReports.apiIncidentReports) });
                }
            }
            catch (Exception e)
            {
                ModelState.AddModelError("Error", $"It was not possible to add a new buyer, please try later on ({e.GetType().Name} - {e.Message})");
            }
            searchInfo.page = 1;
            searchInfo.pageSize = 9999;
            APIListAndCountIncident listAndCount = await _incidentCatSvc.GetIncidentCategorysAsync(searchInfo);
            ViewBag.ListOfCategories = listAndCount.apiIncidentCategories;

            APIListAndCountDepartment list = await _deptSvc.GetDepartmentsAsync(searchInfo);
            ViewBag.ListOfDepartments = list.apiDepartments;

            return Json(new { isValid = false, html = Helper.RenderRezorView.RenderRazorViewToString(this, "Create", info) });
        }

        public async Task<IActionResult> Edit(APIId apiId)
        {
            var uri = new Uri(UserApiUrl);
            APIIncidentReport info = await this._incidentRptSvc.GetIncidentReportAsync(apiId);
            ViewBag.LogoPath = uri.Scheme + "://" + uri.Authority + IncidentReportPhotoPath;
            APISearchInfo searchInfo = new APISearchInfo();
            searchInfo.page = 1;
            searchInfo.pageSize = 9999;
            APIListAndCountIncident listAndCount = await _incidentCatSvc.GetIncidentCategorysAsync(searchInfo);
            ViewBag.ListOfCategories = listAndCount.apiIncidentCategories;

            APIListAndCountDepartment list = await _deptSvc.GetDepartmentsAsync(searchInfo);
            ViewBag.ListOfDepartments = list.apiDepartments;

            return PartialView("Edit", info);
        }

        [HttpPost]
        public async Task<IActionResult> Edit(APIIncidentReport info)
        {
            APISearchInfo searchInfo = new APISearchInfo();
            if (ModelState.IsValid)
            {
                APIIncidentReport incidentReport = await this._incidentRptSvc.UpdateIncidentReportAsync(info.Id, info);
                if (incidentReport.PhotoFile != null && incidentReport.PhotoFile.Length > 0 && incidentReport.Id > 0)
                {
                    await this._incidentRptSvc.UploadIncidentReportPhoto(incidentReport.Id, incidentReport.PhotoFile);
                }
                if (incidentReport != null)
                {
                    APISearchIncident incSearchInfo = new APISearchIncident();
                    incSearchInfo.page = 1;
                    incSearchInfo.pageSize = 10;
                    incSearchInfo.status = "Open";
                    APIListAndCountIncidentReport incidentReports = await _incidentRptSvc.GetReportedIncidentsAsync(incSearchInfo) ?? new APIListAndCountIncidentReport();
                    ViewBag.RecordCount = incidentReports.count;
                    ViewBag.TotalPageCount = (int)Math.Ceiling((decimal)incidentReports.count / (decimal)incSearchInfo.pageSize);
                    ViewBag.Page = incSearchInfo.page;
                    ViewBag.status = incSearchInfo.status;
                    ViewBag.OpenBtnClass = string.IsNullOrWhiteSpace(incSearchInfo.status) || incSearchInfo.status == "Open" ? "btn-primary" : "btn-light";
                    ViewBag.ClosedBtnClass = !string.IsNullOrWhiteSpace(incSearchInfo.status) && incSearchInfo.status == "Closed" ? "btn-primary" : "btn-light";
                    ViewBag.MenuId = "menuOpenClosedIncident";
                    return Json(new { isValid = true, html = Helper.RenderRezorView.RenderRazorViewToString(this, "_ViewAll", incidentReports.apiIncidentReports) });
                }
            }

            var uri = new Uri(UserApiUrl);
            ViewBag.LogoPath = uri.Scheme + "://" + uri.Authority + IncidentReportPhotoPath;
            searchInfo.page = 1;
            searchInfo.pageSize = 9999;
            APIListAndCountIncident listAndCount = await _incidentCatSvc.GetIncidentCategorysAsync(searchInfo);
            ViewBag.ListOfCategories = listAndCount.apiIncidentCategories;

            APIListAndCountDepartment list = await _deptSvc.GetDepartmentsAsync(searchInfo);
            ViewBag.ListOfDepartments = list.apiDepartments;

            return Json(new { isValid = false, html = Helper.RenderRezorView.RenderRazorViewToString(this, "Edit", info) });
        }

        public async Task<IActionResult> AssignUser(APIId apiId)
        {
            APISearchIncidentAssignment searchInfo = new APISearchIncidentAssignment();
            searchInfo.page = 1;
            searchInfo.pageSize = 4999;
            searchInfo.IncidentId = apiId.Id;
            APIIncidentReport incident = await this._incidentRptSvc.GetIncidentReportAsync(apiId);
            APIListAndCountIncidentAssignment incidentAssignments = await this._incidentAssignSvc.GetIncidentAssignmentsAsync(searchInfo);
            APIIncidentAssignment info = incidentAssignments!= null ? incidentAssignments.apiIncidentAssignments.FirstOrDefault() : new APIIncidentAssignment() ;
            info = info ?? new APIIncidentAssignment();
            info.ReferenceIncidentId = apiId.Id;
            info.ReferenceIncident = incident.Description;
            if (!string.IsNullOrWhiteSpace(info.CompetencyIds))
            {
                info.CompetencyArr = info.CompetencyIds.Split(",");
            }
            APIListAndCountforUserMaster listAndCount = await _userMasterSvc.GetUsersForCAAsync(searchInfo);
            ViewBag.ListOfAssignToId = listAndCount.apiUserDetails.Where(x => x.RoleCode == Helper.RoleCode.EHS_Manager);
            ViewBag.ListOfAssignToIdJson = JsonConvert.SerializeObject(listAndCount.apiUserDetails.Where(x => x.RoleCode == Helper.RoleCode.EHS_Manager));

            ViewBag.SelectedSecondaryUser = JsonConvert.SerializeObject(info.SecondaryAssignToId);
            ViewBag.SelectedIncident = JsonConvert.SerializeObject(info.ReferenceIncidentId);
            ViewBag.Competencies = await _competencySvc.GetAllCompetenciesAsync();

            return PartialView("AssignUser", info);
        }

        [HttpPost]
        public async Task<IActionResult> AssignUser(APIIncidentAssignment info)
        {
            APISearchInfo searchInfo = new APISearchInfo();
            APIIncidentAssignment incidentAssignment = new APIIncidentAssignment();

            if (ModelState.IsValid)
            {
                if (info.CompetencyArr != null && info.CompetencyArr.Length > 0)
                {
                    info.CompetencyIds = string.Join(",", info.CompetencyArr);
                }
                else
                    info.CompetencyIds = null;

                if (info.Id == 0)
                {
                    incidentAssignment = await this._incidentAssignSvc.AddIncidentAssignmentAsync(info);
                }
                else
                {
                    incidentAssignment = await this._incidentAssignSvc.UpdateIncidentAssignmentAsync(info.Id, info);
                }
                if (incidentAssignment != null)
                {
                    APISearchIncident incSearchInfo = new APISearchIncident();
                    incSearchInfo.page = 1;
                    incSearchInfo.pageSize = 10;
                    incSearchInfo.status = "Open";
                    APIListAndCountIncidentReport incidentReports = await _incidentRptSvc.GetReportedIncidentsAsync(incSearchInfo) ?? new APIListAndCountIncidentReport();
                    ViewBag.RecordCount = incidentReports.count;
                    ViewBag.TotalPageCount = (int)Math.Ceiling((decimal)incidentReports.count / (decimal)incSearchInfo.pageSize);
                    ViewBag.Page = incSearchInfo.page;
                    ViewBag.status = incSearchInfo.status;
                    ViewBag.OpenBtnClass = string.IsNullOrWhiteSpace(incSearchInfo.status) || incSearchInfo.status == "Open" ? "btn-primary" : "btn-light";
                    ViewBag.ClosedBtnClass = !string.IsNullOrWhiteSpace(incSearchInfo.status) && incSearchInfo.status == "Closed" ? "btn-primary" : "btn-light";
                    ViewBag.MenuId = "menuOpenClosedIncident";
                    return Json(new { isValid = true, html = Helper.RenderRezorView.RenderRazorViewToString(this, "_ViewAll", incidentReports.apiIncidentReports) });
                }
            }

            searchInfo.page = 1;
            searchInfo.pageSize = 4999;

            APIListAndCountforUserMaster listAndCountUser = await _userMasterSvc.GetUsersForCAAsync(searchInfo);
            ViewBag.ListOfAssignToId = listAndCountUser.apiUserDetails.Where(x => x.RoleCode == Helper.RoleCode.EHS_Manager);
            ViewBag.ListOfAssignToIdJson = JsonConvert.SerializeObject(listAndCountUser.apiUserDetails.Where(x => x.RoleCode == Helper.Role.EHS_Manager));

            ViewBag.SelectedSecondaryUser = JsonConvert.SerializeObject(info.SecondaryAssignToId);
            ViewBag.SelectedIncident = JsonConvert.SerializeObject(info.ReferenceIncidentId);
            ViewBag.Competencies = await _competencySvc.GetAllCompetenciesAsync();

            return Json(new { isValid = false, html = Helper.RenderRezorView.RenderRazorViewToString(this, "AssignUser", info) });
        }

        [HttpGet]
        public async Task<IActionResult> Actions(int incidentId)
        {
            APISearchActionTeken searchInfo = new APISearchActionTeken();
            searchInfo.page = searchInfo.page == 0 ? 1 : searchInfo.page;
            searchInfo.pageSize = int.MaxValue;
            searchInfo.IncidentId = incidentId;
            APIListAndCountActionTakenRpt listAndCount = await _actTakenRptSvc.GetActionTakenReportsAsync(searchInfo) ?? new APIListAndCountActionTakenRpt();
            ViewBag.Page = searchInfo.page;
            ViewBag.RecordCount = listAndCount.count;
            ViewBag.IncidentId = incidentId;
            return PartialView(listAndCount.apiActionTakenReports); //Json(new { isValid = true, html = Helper.RenderRezorView.RenderRazorViewToString(this, "Actions", listAndCount.apiActionTakenReports) });
        }

        [HttpGet]
        public async Task<IActionResult> CreateAction(APIId apiId)
        {
            APIIncidentReport incidentInfo = await this._incidentRptSvc.GetIncidentReportAsync(apiId);
            APIActionTakenReport actionInfo = new APIActionTakenReport();
            actionInfo.ReferenceIncident = incidentInfo.Description;
            actionInfo.ReferenceIncidentId = incidentInfo.Id;
            actionInfo.ReportedUserName = incidentInfo.ReportedUserName;
            actionInfo.DateReported = incidentInfo.ReportedDate;
            actionInfo.Category = incidentInfo.IncidentCategory;

            return PartialView("CreateAction",actionInfo);
        }

        [HttpPost]
        public async Task<IActionResult> CreateAction(APIActionTakenReport info)
        {
            APISearchActionTeken searchInfo = new APISearchActionTeken();
            List<APIIncidentReport> apiIncidentReports = new List<APIIncidentReport>();
            if (ModelState.IsValid)
            {
                if (info.InvestigationFindings != null || info.RootCauseAnalysis != null || info.ImmediateActionTaken != null)
                {
                    info.Id = 0;
                    await _actTakenRptSvc.AddActionTakenReportAsync(info);

                    APISearchIncident incSearchInfo = new APISearchIncident();
                    incSearchInfo.page = 1;
                    incSearchInfo.pageSize = 10;
                    incSearchInfo.status = "Open";
                    APIListAndCountIncidentReport incidentReports = await _incidentRptSvc.GetReportedIncidentsAsync(incSearchInfo) ?? new APIListAndCountIncidentReport();
                    ViewBag.RecordCount = incidentReports.count;
                    ViewBag.TotalPageCount = (int)Math.Ceiling((decimal)incidentReports.count / (decimal)incSearchInfo.pageSize);
                    ViewBag.Page = incSearchInfo.page;
                    ViewBag.status = incSearchInfo.status;
                    ViewBag.OpenBtnClass = string.IsNullOrWhiteSpace(incSearchInfo.status) || incSearchInfo.status == "Open" ? "btn-primary" : "btn-light";
                    ViewBag.ClosedBtnClass = !string.IsNullOrWhiteSpace(incSearchInfo.status) && incSearchInfo.status == "Closed" ? "btn-primary" : "btn-light";
                    ViewBag.MenuId = "menuOpenClosedIncident";

                    return Json(new { isValid = true, html = Helper.RenderRezorView.RenderRazorViewToString(this, "_ViewAll", incidentReports.apiIncidentReports) });
                }
                else
                {
                    //searchInfo.page = 1;
                    //searchInfo.pageSize = 4999;
                    //apiIncidentReports = await _incidentAssignSvc.GetIncidentsForActionTaken(searchInfo);
                    //ViewBag.ListOfIncidentReport = apiIncidentReports;
                    //ViewBag.ListOfIncidentReportJson = JsonConvert.SerializeObject(apiIncidentReports);

                    ModelState.AddModelError("InvestigationFindings", "One of the field Investigation Findings, Root Cause Analysis or Immediate Action Taken should be required!");
                    return Json(new { isValid = false, html = Helper.RenderRezorView.RenderRazorViewToString(this, "CreateAction", info) });
                }
            }

            //searchInfo.page = 1;
            //searchInfo.pageSize = 4999;
            //apiIncidentReports = await _incidentAssignSvc.GetIncidentsForActionTaken(searchInfo);
            //ViewBag.ListOfIncidentReport = apiIncidentReports;
            //ViewBag.ListOfIncidentReportJson = JsonConvert.SerializeObject(apiIncidentReports);

            return Json(new { isValid = false, html = Helper.RenderRezorView.RenderRazorViewToString(this, "CreateAction", info) });
        }

        public async Task<IActionResult> EditAction(APIId apiId)
        {
            APIActionTakenReport info = await this._actTakenRptSvc.GetActionTakenReportAsync(apiId);
            apiId.Id = info.ReferenceIncidentId;
            APIIncidentReport incidentInfo = await this._incidentRptSvc.GetIncidentReportAsync(apiId);
            info.ReferenceIncident = incidentInfo.Description;

            return PartialView("EditAction", info);
        }

        [HttpPost]
        public async Task<IActionResult> EditAction(APIActionTakenReport info)
        {
            APISearchActionTeken searchInfo = new APISearchActionTeken();
            APIId apiId = new APIId();
            List<APIIncidentReport> apiIncidentReports = new List<APIIncidentReport>();
            if (ModelState.IsValid)
            {
                if (info.InvestigationFindings != null || info.RootCauseAnalysis != null || info.ImmediateActionTaken != null)
                {
                    APIActionTakenReport actionTakenReport = await this._actTakenRptSvc.UpdateActionTakenReportAsync(info.Id, info);

                    if (actionTakenReport != null)
                    {
                        APISearchIncident incSearchInfo = new APISearchIncident();
                        incSearchInfo.page = 1;
                        incSearchInfo.pageSize = 10;
                        incSearchInfo.status = "Open";
                        APIListAndCountIncidentReport incidentReports = await _incidentRptSvc.GetReportedIncidentsAsync(incSearchInfo) ?? new APIListAndCountIncidentReport();
                        ViewBag.RecordCount = incidentReports.count;
                        ViewBag.TotalPageCount = (int)Math.Ceiling((decimal)incidentReports.count / (decimal)incSearchInfo.pageSize);
                        ViewBag.Page = incSearchInfo.page;
                        ViewBag.status = incSearchInfo.status;
                        ViewBag.OpenBtnClass = string.IsNullOrWhiteSpace(incSearchInfo.status) || incSearchInfo.status == "Open" ? "btn-primary" : "btn-light";
                        ViewBag.ClosedBtnClass = !string.IsNullOrWhiteSpace(incSearchInfo.status) && incSearchInfo.status == "Closed" ? "btn-primary" : "btn-light";
                        ViewBag.MenuId = "menuOpenClosedIncident";

                        return Json(new { isValid = true, html = Helper.RenderRezorView.RenderRazorViewToString(this, "_ViewAll", incidentReports.apiIncidentReports) });
                    }
                }
                else
                {
                    searchInfo.page = 1;
                    searchInfo.pageSize = 4999;
                    apiId.Id = info.ReferenceIncidentId;
                    apiIncidentReports = await _incidentRptSvc.GetSingleIncidentReportsList(apiId);
                    ViewBag.ListOfIncidentReport = apiIncidentReports;
                    ViewBag.ListOfIncidentReportJson = JsonConvert.SerializeObject(apiIncidentReports);

                    ModelState.AddModelError("InvestigationFindings", "One of the field Investigation Findings, Root Cause Analysis or Immediate Action Taken should be required!");
                    return Json(new { isValid = false, html = Helper.RenderRezorView.RenderRazorViewToString(this, "EditAction", info) });
                }
            }

            searchInfo.page = 1;
            searchInfo.pageSize = 4999;
            apiId.Id = info.ReferenceIncidentId;
            apiIncidentReports = await _incidentRptSvc.GetSingleIncidentReportsList(apiId);
            ViewBag.ListOfIncidentReport = apiIncidentReports;
            ViewBag.ListOfIncidentReportJson = JsonConvert.SerializeObject(apiIncidentReports);

            ViewBag.SelectedIncident = JsonConvert.SerializeObject(info.ReferenceIncidentId);

            return Json(new { isValid = false, html = Helper.RenderRezorView.RenderRazorViewToString(this, "EditAction", info) });
        }

        public async Task<IActionResult> GetImageBase64Content(int Id)
        {
            APIFileBase64Model image = await _incidentRptSvc.GetImageBase64ContentAsync(Id);
            return Json(image);
        }
    }
}
