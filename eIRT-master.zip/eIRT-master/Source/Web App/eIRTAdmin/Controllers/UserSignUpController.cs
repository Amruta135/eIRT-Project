﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using eIRTAdmin.Services;
using eIRTAdmin.Models.APIModels;
using Microsoft.Extensions.Options;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.DataProtection;
using eIRTAdmin.Models;
using Microsoft.AspNetCore.Http;

namespace eIRTAdmin.Controllers
{
    public class UserSignUpController : Controller
    {
        private IUserMasterService _userSvc;
        //private IApplicationLanguageService _langSvc;
        //private IProductDocumentService _prodDocSvc;
        private readonly IOptions<AppSettings> _settings;
        private string AdminApiUrl;
        private string productDocumentUrl;
        private readonly IDataProtector _protector;
        private HttpContext _hcontext;

        public UserSignUpController(IUserMasterService userSvc, 
            //IApplicationLanguageService langSvc, 
            //IProductDocumentService prodDocSvc,
            IOptions<AppSettings> settings,
            IDataProtectionProvider provider,
            IHttpContextAccessor haccess)
        {
            _userSvc = userSvc;
            //_langSvc = langSvc;
            //_prodDocSvc = prodDocSvc;
            _settings = settings;
            AdminApiUrl = $"{settings.Value.AdminUrl}";
            productDocumentUrl = $"{settings.Value.ProductDocumentPath}";
            _protector = provider.CreateProtector("mydataprotectorkey");
            _hcontext = haccess.HttpContext;
        }
        [AllowAnonymous]
        public IActionResult SignUp()
        {
            var uri = new Uri(AdminApiUrl);
            //List<APIProductDocumentInformation> documents = await _prodDocSvc.GetProductDocumentInfoAsync();
            //APIProductDocumentInformation doc = documents.Where(d => d.DocumentType.ToLower() == "terms of service").FirstOrDefault();
            //if (doc != null)
            //    ViewBag.LicPath = uri.Scheme + "://" + uri.Authority + productDocumentUrl + "/" + doc.DocumentPath ?? "";
            //else
            //    ViewBag.LicPath = "";

            //APIProductDocumentInformation docPrivacyPolicy = documents.Where(d => d.DocumentType.ToLower() == "privacy policy").FirstOrDefault();
            //if (docPrivacyPolicy != null)
            //    ViewBag.privacyPolicyPath = uri.Scheme + "://" + uri.Authority + productDocumentUrl + "/" + docPrivacyPolicy.DocumentPath ?? "";
            //else
            //    ViewBag.privacyPolicyPath = "";

            //List <APIApplicationLanguage> LanguageList = await _langSvc.GetAppLanguagesAsync();
            //LanguageList.Insert(0, new APIApplicationLanguage { Id = 0, Code = "", Language = "Select" });
            //ViewBag.ListOfLanguage = LanguageList;
            return View("SignUp");
        }

        //[HttpPost]
        //[AllowAnonymous]
        //public async Task<IActionResult> SignUp(APIUserSignUp User)
        //{
        //    try
        //    {
        //        if (ModelState.IsValid)
        //        {
        //            User.Status =  Helper.Status.Inactive;
        //            User.IsFirstLogin = true;
        //            User.Role = Helper.Roles.User;
        //            APIUserSignUp newUser = await _userSvc.SignUpUserAsync(User);
        //            if (newUser != null && newUser.GuId != null && newUser.GuId != Guid.Empty)
        //            {
        //                newUser.OTP = "";
        //                return RedirectToAction("OtpVerification", newUser);
        //            }
        //            else
        //            {
        //                ModelState.AddModelError("Error", $"It was not possible to sign up a new  user, please try later.");
        //                View("SignUp", User);
        //            }
        //        }
        //    }
        //    catch (Exception e)
        //    {
        //        ModelState.AddModelError("Error", $"It was not possible to sign up a new  user, please try later on ({e.GetType().Name} - {e.Message})");
        //    }
        //    //List<APIApplicationLanguage> LanguageList = await _langSvc.GetAppLanguagesAsync();
        //    //LanguageList.Insert(0, new APIApplicationLanguage { Id = 0, Code = "", Language = "Select" });
        //    //ViewBag.ListOfLanguage = LanguageList;
        //    return View("SignUp", User);
        //}

        public IActionResult OtpVerification(APIUserSignUp User)
        {
            UserOptValidate optValidate = new UserOptValidate();
            if (User.GuId.HasValue)
            {
                optValidate.GuId = (Guid)User.GuId;
                //optValidate.OTP = "";
            }
            return View("OtpVerification", optValidate);
        }

        [HttpPost]
        public async Task<IActionResult> OtpVerification(UserOptValidate optValidate)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (await _userSvc.ValidateUserOtpAsync(optValidate))
                        return RedirectToAction("SetPassword", optValidate);
                }
                else
                {
                    ModelState.AddModelError("Error", $"Otp is Either Expired or Not matching!)");
                    return View("OtpVerification", optValidate);
                }
            }
            catch (Exception e)
            {
                ModelState.AddModelError("Error", $"not able to verify OTP, please try later on ({e.GetType().Name} - {e.Message})");
                return View("OtpVerification", optValidate);
            }
            ModelState.AddModelError("Error", $"Otp is Either Expired or Not matching!)");
            return View("OtpVerification", optValidate);
        }

        public async Task<IActionResult> ResendOTP(Guid GuId)
        {
            IsSuccess response = new IsSuccess() { success = false, message = "invalid request" };
            if (GuId == Guid.Empty)
            {
                response.success = false;
                response.message = "User Not Found!";
            }

            try
            {
                response = await _userSvc.ResendOTPAsync(GuId);
            }
            catch (Exception e)
            {
                return Json(new { Success = response.success, Message = response.message });
            }
            if (response.success)
            {
                return Json(new { Success = response.success, Message = response.message });
                //return View("ForgotPassword", UserId);
            }
            else
            {
                return Json(new { Success = response.success, Message = response.message });
            }
        }

        public IActionResult SetPassword(UserOptValidate optValidate)
        {
            APIUserPassword userPassword = new APIUserPassword();
            if (optValidate.GuId != null && optValidate.GuId.ToString().Trim().Length > 0)
            {
                userPassword.GuId = (Guid)optValidate.GuId;
                return View("SetPassword", userPassword);
            }
            return View("OtpVerification", optValidate);
        }

        [HttpPost]
        public async Task<IActionResult> SetPassword(APIUserPassword userPassword)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    await _userSvc.SetUserPassword(userPassword);
                    return View("SuccessfullSignUp");
                }
                else
                {
                    ModelState.AddModelError("Error", $"Something Went Wrong!)");
                    return View("SetPassword", userPassword);
                }
            }
            catch (Exception e)
            {
                ModelState.AddModelError("Error", $"Something Went Wrong! ({e.GetType().Name} - {e.Message})");
                return View("SetPassword", userPassword);
            }
            //return View("SetPassword", userPassword);
        }

        [HttpGet]
        public IActionResult ChangePassword(string displayGuId)
        {
            Guid guId = Guid.Parse(_protector.Unprotect(displayGuId));

            APIUserMasterPasswordChange userPassword = new APIUserMasterPasswordChange();
            if (guId != null && guId != Guid.Empty)
            {
                userPassword.GuId = guId;
                return View("ChangePassword", userPassword);
            }
            return View("ChangePassword", userPassword);
        }

        [HttpPost]
        public async Task<IActionResult> ChangePassword(APIUserMasterPasswordChange userPassword)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (userPassword.GuId != null && userPassword.GuId != Guid.Empty)
                    {
                        IsSuccess response = await _userSvc.ChangeUserPassword(userPassword);
                        if (!response.success)
                        {
                            if (response.message == "Wrong Password!")
                                ModelState.AddModelError("OldPassword", response.message);
                            else if(response.message == "Old Password and new password should not be same!")
                                ModelState.AddModelError("Password", response.message);
                            else
                                ModelState.AddModelError("Password", response.message);
                            return View("ChangePassword", userPassword);
                        }
                        return RedirectToAction("Logout", "Account");
                    }
                    else
                    {
                        ModelState.AddModelError("Error", $"Something Went Wrong!)");
                        return View("SetPassword", userPassword);
                    }
                }
                else
                {
                    ModelState.AddModelError("Error", $"Something Went Wrong!)");
                    return View("SetPassword", userPassword);
                }
            }
            catch (Exception e)
            {
                ModelState.AddModelError("Error", $"Something Went Wrong! ({e.GetType().Name} - {e.Message})");
                return View("SetPassword", userPassword);
            }
        }

        [HttpGet]
        public async Task<bool> IsUserExist(string UserId)
        {
            bool isExist = await this._userSvc.IsExistAsync("UserId", UserId);
            return !isExist;
        }

        [HttpGet]
        public async Task<bool> IsMobileNumberExist(string MobileNumber)
        {
            bool isExist = await this._userSvc.IsExistAsync("MobileNumber", MobileNumber);
            return !isExist;
        }

        //[HttpGet]
        //public async Task<IActionResult> GetTermsOfService()
        //{
        //    var uri = new Uri(AdminApiUrl);
        //    APIFileBase64Model fileBase64Model = await this._prodDocSvc.GetTermsOfServiceAsync();
        //    return PartialView("../Shared/_ViewDocument", fileBase64Model);
        //}

        //[HttpGet]
        //[AllowAnonymous]
        //public async Task<IActionResult> GetTermsOfServiceContent()
        //{
        //    var uri = new Uri(AdminApiUrl);
        //    ViewData["TermsOfService"] = await this._prodDocSvc.GetTermsOfServiceContentAsync();
        //    return View();
        //}

        //[HttpGet]
        //[AllowAnonymous]
        //public async Task<IActionResult> GetPrivacyPolicyContent()
        //{
        //    var uri = new Uri(AdminApiUrl);
        //    ViewData["PrivacyPolicy"]= await this._prodDocSvc.GetPrivacyPolicyContentAsync();
        //    return View();
        //}

        //[HttpGet]
        //public async Task<IActionResult> GetPrivacyPolicy()
        //{
        //    var uri = new Uri(AdminApiUrl);
        //    APIFileBase64Model fileBase64Model = await this._prodDocSvc.GetPrivacyPolicyAsync();
        //    return PartialView("../Shared/_ViewDocument", fileBase64Model);
        //}

        ////[HttpPost]
        //public async Task<IActionResult> ChangeUserAppMenu(string AppMenu)
        //{
        //    try
        //    {
        //        var UserGuid = _hcontext.User.FindFirst("User_Guid") != null ? _hcontext.User.FindFirst("User_Guid").Value : "";
        //        APIUserAppMenu UserAppMenu = new APIUserAppMenu();
        //        UserAppMenu.GuId = Guid.Parse(UserGuid);
        //        UserAppMenu.AppMenu = AppMenu;

        //        if (UserAppMenu.GuId != null && UserAppMenu.GuId != Guid.Empty)
        //        {
        //            Models.IsSuccess success = await _userSvc.ChangeUserAppMenuAsync(UserAppMenu);
        //            if (success.success)
        //                HttpContext.Session.SetString("AppMenu", UserAppMenu.AppMenu);
        //        }
        //    }
        //    catch (Exception e)
        //    {
        //        return RedirectToAction("Index", "Home");
        //    }
        //    return RedirectToAction("Index", "Home");
        //}
    }
}