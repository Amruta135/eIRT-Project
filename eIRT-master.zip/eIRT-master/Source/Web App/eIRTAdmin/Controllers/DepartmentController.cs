﻿using eIRTAdmin.Helper;
using eIRTAdmin.Models;
using eIRTAdmin.Models.APIModels;
using eIRTAdmin.Services;
using eIRTAdmin.Services.Interface;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Threading.Tasks;

namespace eIRTAdmin.Controllers
{
    [Authorize(Roles = RoleCode.IRT_Client_Admin)]
    public class DepartmentController : Controller
    {
        private IDepartmentService _deptSvc;
        private HttpContext _hcontext;
        private IUserMasterService _userMasterSvc;

        public DepartmentController(IDepartmentService deptSvc,
                                    IHttpContextAccessor haccess,
                                    IUserMasterService userMasterSvc)
        {
            _deptSvc = deptSvc;
            _hcontext = haccess.HttpContext;
            _userMasterSvc = userMasterSvc;
            if (_hcontext.User == null || _hcontext.User.FindFirst("AccessToken") == null)
            {
                Response.Redirect(Url.Action("Logout", "Account"));
            }
        }

        public IActionResult Index(APISearchInfo searchInfo)
        {
            searchInfo.page = 1;
            searchInfo.pageSize = 10;
            APIListAndCountDepartment listAndCount = new APIListAndCountDepartment(); //await _deptSvc.GetDepartmentsAsync(searchInfo);
            ViewBag.RecordCount = 0;
            ViewBag.TotalPageCount = 1;
            ViewBag.Page = searchInfo.page;
            ViewBag.MenuId = "menuDepartment";
            return View(listAndCount.apiDepartments);
            
        }

        public async Task<IActionResult> IndexJson(APISearchInfo searchInfo)
        {
            searchInfo.page = searchInfo.page == 0 ? 1 : searchInfo.page;
            searchInfo.pageSize = searchInfo.pageSize == 0 ? 10 : searchInfo.pageSize;
            APIListAndCountDepartment listAndCount = await _deptSvc.GetDepartmentsAsync(searchInfo);
            ViewBag.Page = searchInfo.page;
            ViewBag.RecordCount = listAndCount.count;
            ViewBag.TotalPageCount = (int)Math.Ceiling((decimal)ViewBag.RecordCount / (decimal)searchInfo.pageSize);
            return Json(new { isValid = true, html = Helper.RenderRezorView.RenderRazorViewToString(this, "_ViewAll", listAndCount.apiDepartments) });
        }

        public IActionResult Create()
        {
            return PartialView("Create");
        }

        [HttpPost]
        public async Task<IActionResult> Create(APIDepartments info)
        {
            if (ModelState.IsValid)
            {
                await _deptSvc.AddDepartmentAsync(info);

                APISearchInfo searchInfo = new APISearchInfo();
                searchInfo.page = 1;
                searchInfo.pageSize = 10;
                APIListAndCountDepartment listAndCount = await _deptSvc.GetDepartmentsAsync(searchInfo);
                ViewBag.RecordCount = listAndCount.count;
                ViewBag.TotalPageCount = (int)Math.Ceiling((decimal)ViewBag.RecordCount / (decimal)searchInfo.pageSize);
                return Json(new { isValid = true, html = Helper.RenderRezorView.RenderRazorViewToString(this, "_ViewAll", listAndCount.apiDepartments) });
            }

            return Json(new { isValid = false, html = Helper.RenderRezorView.RenderRazorViewToString(this, "Create", info) });
        }

        public async Task<IActionResult> Edit(APIId apiId)
        {
            APIDepartments info = await this._deptSvc.GetDepartmentAsync(apiId);

            return PartialView("Edit", info);
        }

        [HttpPost]
        public async Task<IActionResult> Edit(APIDepartments info)
        {
            if (ModelState.IsValid)
            {
                APIDepartments departments = await this._deptSvc.UpdateDepartmentAsync(info.Id, info);

                if (departments != null)
                {
                    APISearchInfo searchInfo = new APISearchInfo();
                    searchInfo.page = 1;
                    searchInfo.pageSize = 10;
                    APIListAndCountDepartment listAndCount = await _deptSvc.GetDepartmentsAsync(searchInfo);
                    ViewBag.RecordCount = listAndCount.count;
                    ViewBag.TotalPageCount = (int)Math.Ceiling((decimal)ViewBag.RecordCount / (decimal)searchInfo.pageSize);
                    return Json(new { isValid = true, html = Helper.RenderRezorView.RenderRazorViewToString(this, "_ViewAll", listAndCount.apiDepartments) });
                }
            }

            return Json(new { isValid = false, html = Helper.RenderRezorView.RenderRazorViewToString(this, "Edit", info) });
        }

        public async Task<IActionResult> Delete(int id)
        {
            await this._deptSvc.DeleteDepartmentAsync(id);
            return RedirectToAction("Index");
        }

        [HttpGet]
        public async Task<bool> IsDepartmentExist(string Name, int? Id)
        {
            bool isExist = false;
            APIIsExistInput apiIsExistInput = new APIIsExistInput();
            apiIsExistInput.FieldName = "Name";
            apiIsExistInput.value = Name;
            apiIsExistInput.Id = Id;
            if (Id > 0)
            {
                APIId apiId = new APIId();
                apiId.Id = Id.GetValueOrDefault();
                APIDepartments departments = await _deptSvc.GetDepartmentAsync(apiId);
                if (Name != departments.Name)
                    isExist = await this._deptSvc.IsExistAsync(apiIsExistInput);
            }
            else
            {
                isExist = await this._deptSvc.IsExistAsync(apiIsExistInput);
            }
            return !isExist;
        }

        [HttpGet]
        public async Task<bool> IsDepartmentCodeExist(string code, int? Id)
        {
            bool isExist = false;
            APIIsExistInput apiIsExistInput = new APIIsExistInput();
            apiIsExistInput.FieldName = "code";
            apiIsExistInput.value = code;
            apiIsExistInput.Id = Id;
            if (Id > 0)
            {
                APIId apiId = new APIId();
                apiId.Id = Id.GetValueOrDefault();
                APIDepartments departments = await _deptSvc.GetDepartmentAsync(apiId);
                if (code != departments.Code)
                    isExist = await this._deptSvc.IsExistAsync(apiIsExistInput);
            }
            else
            {
                isExist = await this._deptSvc.IsExistAsync(apiIsExistInput);
            }
            return !isExist;
        }

        [HttpGet]
        public async Task<bool> IsDepartmentExistForUser(int Id)
        {
            bool isExist = false;
            APIIsExistInput apiIsExistInput = new APIIsExistInput();
            apiIsExistInput.FieldName = "DepartmentName";
            apiIsExistInput.value = Id.ToString();
            isExist = await this._userMasterSvc.IsExistAsync(apiIsExistInput);

            return isExist;
        }
    }
}
