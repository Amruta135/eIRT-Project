﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using eIRTAdmin.Models;
using eIRTAdmin.Services;
using Microsoft.Net.Http.Headers;

namespace eIRTAdmin.Controllers
{
    public class LoginController : Controller
    {
        private IUserIdentityService _identitySvc;
        //private IApplicationLanguageService _langSvc;

        public LoginController(IUserIdentityService identitySvc)
        {
            _identitySvc = identitySvc;
        }

        public IActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Login( LoginViewModel userLogin)
        {
            if (ModelState.IsValid)
            {
                var IdentityResponse = await this._identitySvc.GetTokenAsync(userLogin.UserId, userLogin.Password, userLogin.OrganizationCode);
                if (IdentityResponse != null && IdentityResponse.access_token != null)
                    return RedirectToAction("Index", "Home");
                else
                {
                    ModelState.AddModelError("UserId", "Wrong User Id Or Password");
                    return View("Login", userLogin);
                }
                    
            }
            else
            {
                return View("Login", userLogin);
            }
        }

        
    }
}