﻿using eIRTAdmin.Helper;
using eIRTAdmin.Models.APIModels;
using eIRTAdmin.Services;
using eIRTAdmin.Services.Interface;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace eIRTAdmin.Controllers
{
    [Authorize(Roles = RoleCode.IRT_Client_Admin)]
    public class IncidentAssignmentController : Controller
    {
        private IIncidentAssignmentService _incidentAssignSvc;
        private HttpContext _hcontext;
        private IIncidentReportService _incidentRptSvc;
        private IUserMasterService _userMasterSvc;
        private readonly ICompetencyService _competencySvc;
        public IncidentAssignmentController(IIncidentAssignmentService incidentAssignSvc,
                                            IHttpContextAccessor haccess,
                                            IIncidentReportService incidentRptSvc,
                                            IUserMasterService userMasterSvc,
                                            ICompetencyService competencySvc)
        {
            _incidentAssignSvc = incidentAssignSvc;
            _hcontext = haccess.HttpContext;
            _incidentRptSvc = incidentRptSvc;
            _userMasterSvc = userMasterSvc;
            _competencySvc = competencySvc;
            if (_hcontext.User == null || _hcontext.User.FindFirst("AccessToken") == null)
            {
                Response.Redirect(Url.Action("Logout", "Account"));
            }
        }

        public IActionResult Index(APISearchIncident searchInfo)
        {
            searchInfo.page = searchInfo.page == 0 ? 1 : searchInfo.page;
            searchInfo.pageSize = searchInfo.pageSize == 0 ? 10 : searchInfo.pageSize;
            searchInfo.status = string.IsNullOrWhiteSpace(searchInfo.status) ? "NotAssigned" : searchInfo.status;

            APIListAndCountIncidentReport incidentReports = new APIListAndCountIncidentReport();
            ViewBag.RecordCount = 0;
            ViewBag.TotalPageCount = 1;
            ViewBag.Page = searchInfo.page;
            ViewBag.MenuId = "menuIncidentAssignment";
            return View(incidentReports.apiIncidentReports);
        }

        public async Task<IActionResult> IndexJson(APISearchIncident searchInfo)
        {
            searchInfo.page = searchInfo.page == 0 ? 1 : searchInfo.page;
            searchInfo.pageSize = searchInfo.pageSize == 0 ? 10 : searchInfo.pageSize;
            searchInfo.status = string.IsNullOrWhiteSpace(searchInfo.status) ? "NotAssigned" : searchInfo.status;

            APIListAndCountIncidentReport incidentReports = await _incidentRptSvc.GetReportedIncidentsAsync(searchInfo) ?? new APIListAndCountIncidentReport();
            ViewBag.RecordCount = incidentReports.count;
            ViewBag.TotalPageCount = (int)Math.Ceiling((decimal)incidentReports.count / (decimal)searchInfo.pageSize);
            ViewBag.Page = searchInfo.page;
            ViewBag.status = searchInfo.status;
            ViewBag.OpenBtnClass = string.IsNullOrWhiteSpace(searchInfo.status) || searchInfo.status == "NotAssigned" ? "btn-warning" : "btn-light";
            ViewBag.ClosedBtnClass = !string.IsNullOrWhiteSpace(searchInfo.status) && searchInfo.status == "Assigned" ? "btn-primary" : "btn-light";
            ViewBag.MenuId = "menuIncidentAssignment";
            return Json(new { isValid = true, html = Helper.RenderRezorView.RenderRazorViewToString(this, "_ViewAll", incidentReports.apiIncidentReports) });
            //return View(incidentReports.apiIncidentReports);
        }

        public async Task<IActionResult> AssignUser(APIIncidentAssignmentId apiId)
        {
            APISearchIncidentAssignment searchInfo = new APISearchIncidentAssignment();
            searchInfo.page = 1;
            searchInfo.pageSize = int.MaxValue;
            searchInfo.IncidentId = apiId.Id;
            APIIncidentReport incident = await this._incidentRptSvc.GetIncidentReportAsync(apiId);
            APIListAndCountIncidentAssignment incidentAssignments = await this._incidentAssignSvc.GetIncidentAssignmentsAsync(searchInfo);
            APIIncidentAssignment info = incidentAssignments != null ? incidentAssignments.apiIncidentAssignments.FirstOrDefault() : new APIIncidentAssignment();
            info = info ?? new APIIncidentAssignment();
            info.ReferenceIncidentId = apiId.Id;
            info.ReferenceIncident = incident.Description;
            if (!string.IsNullOrWhiteSpace(info.CompetencyIds))
            {
                info.CompetencyArr = info.CompetencyIds.Split(",");
            }
            APIListAndCountforUserMaster listAndCount = await _userMasterSvc.GetUsersForCAAsync(searchInfo);
            ViewBag.ListOfAssignToId = listAndCount.apiUserDetails.Where(x => x.RoleCode == Helper.RoleCode.EHS_Manager);
            ViewBag.ListOfAssignToIdJson = JsonConvert.SerializeObject(listAndCount.apiUserDetails.Where(x => x.RoleCode == Helper.RoleCode.EHS_Manager));
            ViewBag.Competencies = await _competencySvc.GetAllCompetenciesAsync();

            ViewBag.SelectedSecondaryUser = JsonConvert.SerializeObject(info.SecondaryAssignToId);
            ViewBag.SelectedIncident = JsonConvert.SerializeObject(info.ReferenceIncidentId);

            return PartialView("AssignUser", info);
        }

        [HttpPost]
        public async Task<IActionResult> AssignUser(APIIncidentAssignment info)
        {
            APISearchInfo searchInfo = new APISearchInfo();
            APIIncidentAssignment incidentAssignment = new APIIncidentAssignment();

            if (ModelState.IsValid)
            {
                if (info.CompetencyArr != null && info.CompetencyArr.Length > 0)
                {
                    info.CompetencyIds = string.Join(",", info.CompetencyArr);
                }
                else
                    info.CompetencyIds = null;

                if (info.Id == 0)
                {
                    incidentAssignment = await this._incidentAssignSvc.AddIncidentAssignmentAsync(info);
                }
                else
                {
                    incidentAssignment = await this._incidentAssignSvc.UpdateIncidentAssignmentAsync(info.Id, info);
                }
                if (incidentAssignment != null)
                {
                    APISearchIncident incSearchInfo = new APISearchIncident();
                    incSearchInfo.page = 1;
                    incSearchInfo.pageSize = 10;
                    incSearchInfo.status = info.Id > 0 ? "Assigned" : "NotAssigned";
                    APIListAndCountIncidentReport incidentReports = await _incidentRptSvc.GetReportedIncidentsAsync(incSearchInfo) ?? new APIListAndCountIncidentReport();
                    ViewBag.RecordCount = incidentReports.count;
                    ViewBag.TotalPageCount = (int)Math.Ceiling((decimal)incidentReports.count / (decimal)incSearchInfo.pageSize);
                    ViewBag.Page = incSearchInfo.page;
                    ViewBag.status = incSearchInfo.status;
                    ViewBag.ClosedBtnClass = string.IsNullOrWhiteSpace(incSearchInfo.status) || incSearchInfo.status == "Assigned" ? "btn-primary" : "btn-light";
                    ViewBag.OpenBtnClass = !string.IsNullOrWhiteSpace(incSearchInfo.status) && incSearchInfo.status == "NotAssigned" ? "btn-Warning" : "btn-light";
                    ViewBag.MenuId = "menuIncidentAssignment";
                    return Json(new { isValid = true, html = Helper.RenderRezorView.RenderRazorViewToString(this, "_ViewAll", incidentReports.apiIncidentReports) });
                }
            }

            searchInfo.page = 1;
            searchInfo.pageSize = 4999;

            APIListAndCountforUserMaster listAndCountUser = await _userMasterSvc.GetUsersForCAAsync(searchInfo);
            ViewBag.ListOfAssignToId = listAndCountUser.apiUserDetails.Where(x => x.RoleCode == Helper.RoleCode.EHS_Manager);
            ViewBag.ListOfAssignToIdJson = JsonConvert.SerializeObject(listAndCountUser.apiUserDetails.Where(x => x.RoleCode == Helper.Role.EHS_Manager));

            ViewBag.SelectedSecondaryUser = JsonConvert.SerializeObject(info.SecondaryAssignToId);
            ViewBag.SelectedIncident = JsonConvert.SerializeObject(info.ReferenceIncidentId);
            ViewBag.Competencies = await _competencySvc.GetAllCompetenciesAsync();

            return Json(new { isValid = false, html = Helper.RenderRezorView.RenderRazorViewToString(this, "AssignUser", info) });
        }

        //public async Task<IActionResult> Index(APISearchIncidentAssignment searchInfo)
        //{
        //    searchInfo.page = 1;
        //    searchInfo.pageSize = 10;
        //    APIListAndCountIncidentAssignment listAndCount = new APIListAndCountIncidentAssignment(); //await _incidentAssignSvc.GetIncidentAssignmentsAsync(searchInfo);
        //    ViewBag.RecordCount = 0;
        //    ViewBag.TotalPageCount = 1;
        //    ViewBag.Page = searchInfo.page;
        //    ViewBag.MenuId = "menuIncidentAssignment";
        //    return View(listAndCount.apiIncidentAssignments);
        //}

        //public async Task<IActionResult> IndexJson(APISearchIncidentAssignment searchInfo)
        //{
        //    searchInfo.page = searchInfo.page == 0 ? 1 : searchInfo.page;
        //    searchInfo.pageSize = searchInfo.pageSize == 0 ? 10 : searchInfo.pageSize;
        //    APIListAndCountIncidentAssignment listAndCount = await _incidentAssignSvc.GetIncidentAssignmentsAsync(searchInfo);
        //    ViewBag.Page = searchInfo.page;
        //    ViewBag.RecordCount = listAndCount.count;
        //    ViewBag.TotalPageCount = (int)Math.Ceiling((decimal)ViewBag.RecordCount / (decimal)searchInfo.pageSize);
        //    return Json(new { isValid = true, html = Helper.RenderRezorView.RenderRazorViewToString(this, "_ViewAll", listAndCount.apiIncidentAssignments) });
        //}

        public async Task<IActionResult> Create()
        {
            APISearchInfo searchInfo = new APISearchInfo();
            searchInfo.page = 1;
            searchInfo.pageSize = 4999;
            List<APIIncidentReport> apiIncidentReports = await _incidentRptSvc.GetIncidentReportsList(searchInfo);
            ViewBag.ListOfIncidentReport = apiIncidentReports;
            ViewBag.ListOfIncidentReportJson = JsonConvert.SerializeObject(apiIncidentReports);

            APIListAndCountforUserMaster listAndCount = await _userMasterSvc.GetUsersForCAAsync(searchInfo);
            ViewBag.ListOfAssignToId = listAndCount.apiUserDetails.Where(x => x.RoleCode == Helper.RoleCode.EHS_Manager);
            ViewBag.ListOfAssignToIdJson = JsonConvert.SerializeObject(listAndCount.apiUserDetails.Where(x => x.RoleCode == Helper.RoleCode.EHS_Manager));
            return PartialView("Create");
        }

        [HttpPost]
        public async Task<IActionResult> Create(APIIncidentAssignment info)
        {
            APISearchIncidentAssignment searchInfo = new APISearchIncidentAssignment();
            if (ModelState.IsValid)
            {
                await _incidentAssignSvc.AddIncidentAssignmentAsync(info);
                                
                searchInfo.page = 1;
                searchInfo.pageSize = 10;
                APIListAndCountIncidentAssignment listAndCount = await _incidentAssignSvc.GetIncidentAssignmentsAsync(searchInfo);
                ViewBag.RecordCount = listAndCount.count;
                ViewBag.TotalPageCount = (int)Math.Ceiling((decimal)ViewBag.RecordCount / (decimal)searchInfo.pageSize);
                return Json(new { isValid = true, html = Helper.RenderRezorView.RenderRazorViewToString(this, "_ViewAll", listAndCount.apiIncidentAssignments) });
            }

            searchInfo.page = 1;
            searchInfo.pageSize = 4999;
            List<APIIncidentReport> apiIncidentReports = await _incidentRptSvc.GetIncidentReportsList(searchInfo);
            ViewBag.ListOfIncidentReport = apiIncidentReports;
            ViewBag.ListOfIncidentReportJson = JsonConvert.SerializeObject(apiIncidentReports);

            APIListAndCountforUserMaster listAndCountUser = await _userMasterSvc.GetUsersForCAAsync(searchInfo);
            ViewBag.ListOfAssignToId = listAndCountUser.apiUserDetails.Where(x => x.RoleCode == Helper.RoleCode.EHS_Manager);
            ViewBag.ListOfAssignToIdJson = JsonConvert.SerializeObject(listAndCountUser.apiUserDetails.Where(x => x.RoleCode == Helper.RoleCode.EHS_Manager));

            return Json(new { isValid = false, html = Helper.RenderRezorView.RenderRazorViewToString(this, "Create", info) });
        }

        public async Task<IActionResult> Edit(APIId apiId)
        {
            APISearchInfo searchInfo = new APISearchInfo();
            searchInfo.page = 1;
            searchInfo.pageSize = 4999;
            APIIncidentAssignment info = await this._incidentAssignSvc.GetIncidentAssignmentAsync(apiId);
            apiId.Id = info.ReferenceIncidentId;
            List<APIIncidentReport> apiIncidentReports = await _incidentRptSvc.GetSingleIncidentReportsList(apiId);
            ViewBag.ListOfIncidentReport = apiIncidentReports;
            ViewBag.ListOfIncidentReportJson = JsonConvert.SerializeObject(apiIncidentReports);

            APIListAndCountforUserMaster listAndCount = await _userMasterSvc.GetUsersForCAAsync(searchInfo);
            ViewBag.ListOfAssignToId = listAndCount.apiUserDetails.Where(x => x.RoleCode == Helper.RoleCode.EHS_Manager);
            ViewBag.ListOfAssignToIdJson = JsonConvert.SerializeObject(listAndCount.apiUserDetails.Where(x => x.RoleCode == Helper.RoleCode.EHS_Manager));

            ViewBag.SelectedSecondaryUser = JsonConvert.SerializeObject(info.SecondaryAssignToId);
            ViewBag.SelectedIncident = JsonConvert.SerializeObject(info.ReferenceIncidentId);

            return PartialView("Edit", info);
        }

        [HttpPost]
        public async Task<IActionResult> Edit(APIIncidentAssignment info)
        {
            APISearchIncidentAssignment searchInfo = new APISearchIncidentAssignment();
            if (ModelState.IsValid)
            {
                APIIncidentAssignment incidentAssignment = await this._incidentAssignSvc.UpdateIncidentAssignmentAsync(info.Id, info);

                if (incidentAssignment != null)
                {                    
                    searchInfo.page = 1;
                    searchInfo.pageSize = 10;
                    APIListAndCountIncidentAssignment listAndCount = await _incidentAssignSvc.GetIncidentAssignmentsAsync(searchInfo);
                    ViewBag.RecordCount = listAndCount.count;
                    ViewBag.TotalPageCount = (int)Math.Ceiling((decimal)ViewBag.RecordCount / (decimal)searchInfo.pageSize);
                    return Json(new { isValid = true, html = Helper.RenderRezorView.RenderRazorViewToString(this, "_ViewAll", listAndCount.apiIncidentAssignments) });
                }
            }

            searchInfo.page = 1;
            searchInfo.pageSize = 4999;
            APIId apiId = new APIId();
            apiId.Id = info.ReferenceIncidentId;
            List<APIIncidentReport> apiIncidentReports = await _incidentRptSvc.GetSingleIncidentReportsList(apiId);
            ViewBag.ListOfIncidentReport = apiIncidentReports;
            ViewBag.ListOfIncidentReportJson = JsonConvert.SerializeObject(apiIncidentReports);

            APIListAndCountforUserMaster listAndCountUser = await _userMasterSvc.GetUsersForCAAsync(searchInfo);
            ViewBag.ListOfAssignToId = listAndCountUser.apiUserDetails.Where(x => x.RoleCode == Helper.RoleCode.EHS_Manager);
            ViewBag.ListOfAssignToIdJson = JsonConvert.SerializeObject(listAndCountUser.apiUserDetails.Where(x => x.RoleCode == Helper.RoleCode.EHS_Manager));

            ViewBag.SelectedSecondaryUser = JsonConvert.SerializeObject(info.SecondaryAssignToId);
            ViewBag.SelectedIncident = JsonConvert.SerializeObject(info.ReferenceIncidentId);

            return Json(new { isValid = false, html = Helper.RenderRezorView.RenderRazorViewToString(this, "Edit", info) });
        }

        public async Task<IActionResult> Delete(int id)
        {
            await this._incidentAssignSvc.DeleteIncidentAssignmentAsync(id);
            return RedirectToAction("Index");
        }

        [HttpGet]
        public async Task<bool> GetIncidentCreated(int userId, int incidentId)
        {
            bool isCreated = false;
            APIIsIncidentCreated apiIsIncidentCreated = new APIIsIncidentCreated();
            apiIsIncidentCreated.userId = userId;
            apiIsIncidentCreated.incidentId = incidentId;
            isCreated = await this._incidentRptSvc.IsIncidentCreatedAsync(apiIsIncidentCreated);

            return isCreated;
        }
    }
}
