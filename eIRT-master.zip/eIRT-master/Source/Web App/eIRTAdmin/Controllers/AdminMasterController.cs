﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using eIRTAdmin.Services;
using eIRTAdmin.Models;
using eIRTAdmin.Models.APIModels;
using Microsoft.Net.Http.Headers;
using Microsoft.AspNetCore.DataProtection;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authorization;
using Newtonsoft.Json;

namespace eIRTAdmin.Controllers
{
    //[Authorize(Roles = "Admin, Coordinator")]
    public class AdminMasterController : Controller
    {
        private IAdminMasterService _admSvc;
        //private IApplicationLanguageService _langSvc;
        private IUserMasterService _userSvc;
        private readonly IDataProtector _protector;
        //private ICoordinatorMappingService _coordinatorMappingSvc;
        private readonly IUserProfileService _userProfileSvc;

        public AdminMasterController(IAdminMasterService admSvc, 
            //IApplicationLanguageService langSvc,
            IUserMasterService userSvc,
            IDataProtectionProvider provider,
            //ICoordinatorMappingService coordinatorMappingSvc,
            IUserProfileService userProfileSvc)
        {
            _admSvc = admSvc;
            //_langSvc = langSvc;
            _userSvc = userSvc;
            _protector = provider.CreateProtector("mydataprotectorkey");
            //_coordinatorMappingSvc = coordinatorMappingSvc;
            _userProfileSvc = userProfileSvc;
        }
        public async Task<IActionResult> Index(int page = 1, string filter = null, string search = null)
        {
            int pageSize = 10;
            List<AdminMasterViewModel> adminUsers = await _admSvc.GetAdminUsersAsync(page, filter, search);
            ViewBag.RecordCount = await _admSvc.GetAdminUsersCountAsync(filter, search);
            ViewBag.TotalPageCount = (int)Math.Ceiling((decimal)ViewBag.RecordCount / (decimal)pageSize);
            return View(adminUsers);
        }

        public async Task<IActionResult> ExportXlsx(string filter = null, string search = null)
        {
            var stream = await _admSvc.ExportXlsxAsync(filter, search);
            return new FileStreamResult(stream, new MediaTypeHeaderValue("text/xls"))
            {
                FileDownloadName = "UserMaster.xlsx",
                EnableRangeProcessing = true
            };
        }

        public async Task<IActionResult> ExportPDF(string filter = null, string search = null)
        {
            var stream = await _admSvc.ExportPDFAsync(filter, search);
            return new FileStreamResult(stream, new MediaTypeHeaderValue("application/pdf"))
            {
                FileDownloadName = "UserMaster.pdf",
                EnableRangeProcessing = true
            };
        }

        public IActionResult Create()
        {
            //List<APIApplicationLanguage> LanguageList = await _langSvc.GetAppLanguagesAsync();
            //LanguageList.Insert(0, new APIApplicationLanguage { Id = 0, Code = "", Language = "Select" });
            //ViewBag.ListOfLanguage = LanguageList;
            return PartialView("Create");
        }

        [HttpPost]
        public async Task<IActionResult> Create(APIAdminMaster adminUser)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    await _admSvc.AddAdminUserAsync(adminUser);
                    int pageSize = 10;
                    List<AdminMasterViewModel> adminUsers = await _admSvc.GetAdminUsersAsync(1, null, null);
                    ViewBag.RecordCount = await _admSvc.GetAdminUsersCountAsync(null, null);
                    ViewBag.TotalPageCount = (int)Math.Ceiling((decimal)ViewBag.RecordCount / (decimal)pageSize);
                    return Json(new { isValid = true, html = Helper.RenderRezorView.RenderRazorViewToString(this, "_ViewAll", adminUsers) });
                }
            }
            catch (Exception e)
            {
                ModelState.AddModelError("Error", $"It was not possible to add a new admin user, please try later on ({e.GetType().Name} - {e.Message})");
            }
            //List<APIApplicationLanguage> LanguageList = await _langSvc.GetAppLanguagesAsync();
            //LanguageList.Insert(0, new APIApplicationLanguage { Id = 0, Code = "", Language = "Select" });
            //ViewBag.ListOfLanguage = LanguageList;
            return Json(new { isValid = false, html = Helper.RenderRezorView.RenderRazorViewToString(this, "Create", adminUser) });
        }

        public async Task<IActionResult> Edit(Guid GuId)
        {
            //List<APIApplicationLanguage> LanguageList = await _langSvc.GetAppLanguagesAsync();
            //LanguageList.Insert(0, new APIApplicationLanguage { Id = 0, Code = "", Language = "Select" });
            //ViewBag.ListOfLanguage = LanguageList;
            APIAdminMaster adminUser = await this._admSvc.GetAdminUserAsync(GuId);

            ViewBag.IsUserRole = false;
            bool addUserRole = false;
            if (adminUser != null && adminUser.Role == Helper.RoleCode.Posiview_Admin)
            {
                ViewBag.IsUserRole = true;
                addUserRole = true;
            }
            ViewBag.RoleTypes = GetRoleTypes(addUserRole);

            //bool isBillerAttached = await _coordinatorMappingSvc.IsBillerAttached("CoordinatorId", adminUser.Id.ToString());
            //ViewBag.BillerAttachedJson = JsonConvert.SerializeObject(isBillerAttached);

            return PartialView("Edit", adminUser);
        }

        private List<APIRoleTypes> GetRoleTypes(bool addUserRole)
        {
            List<APIRoleTypes> roleTypes = new List<APIRoleTypes>();
            roleTypes.Insert(0, new APIRoleTypes { Code = "Admin", Name = "Admin" });
            roleTypes.Insert(1, new APIRoleTypes { Code = "Coordinator", Name = "Coordinator" });

            if (addUserRole)
                roleTypes.Insert(2, new APIRoleTypes { Code = "User", Name = "User" });

            return roleTypes;
        }

        [HttpPost]
        public async Task<IActionResult> Edit(APIAdminMaster adminUser)
        {
            if (ModelState.IsValid)
            {
                if (await CheckMobileNumberExist(adminUser.MobileNumber, adminUser.GuId))
                {
                    ModelState.AddModelError("MobileNumber", "Mobile Number already exist!");
                    return Json(new { isValid = false, html = Helper.RenderRezorView.RenderRazorViewToString(this, "Edit", adminUser) });
                }
                APIAdminMaster user = await this._admSvc.UpdateAdminUserAsync((Guid)adminUser.GuId, adminUser);
                if (user != null)
                {
                    int pageSize = 10;
                    List<AdminMasterViewModel> adminUsers = await _admSvc.GetAdminUsersAsync(1, null, null);
                    ViewBag.RecordCount = await _admSvc.GetAdminUsersCountAsync(null, null);
                    ViewBag.TotalPageCount = (int)Math.Ceiling((decimal)ViewBag.RecordCount / (decimal)pageSize);
                    return Json(new { isValid = true, html = Helper.RenderRezorView.RenderRazorViewToString(this, "_ViewAll", adminUsers) });
                }
            }
            //List<APIApplicationLanguage> LanguageList = await _langSvc.GetAppLanguagesAsync();
            //LanguageList.Insert(0, new APIApplicationLanguage { Id = 0, Code = "", Language = "Select" });
            //ViewBag.ListOfLanguage = LanguageList;

            return Json(new { isValid = false, html = Helper.RenderRezorView.RenderRazorViewToString(this, "Edit", adminUser) });
        }

        public async Task<IActionResult> Delete(Guid id)
        {
            //APIAdminMaster adminUser = await this._admSvc.GetAdminUserAsync(id);
            await this._admSvc.DeleteAdminUserAsync(id);
            return RedirectToAction("Index");
        }

        [HttpGet]
        public async Task<bool> IsUserExist(string UserId, Guid? GuId)
        {
            bool isExist = false;
            if (GuId != null && Guid.Empty != GuId)
            {
                APIAdminMaster admin = await _admSvc.GetAdminUserAsync(GuId.GetValueOrDefault());
                if(admin.UserId != UserId)
                    isExist = await this._admSvc.IsExistAsync("UserId", UserId);
            }
            else
            {
                isExist = await this._admSvc.IsExistAsync("UserId", UserId);
            }
            return !isExist;
        }
        [HttpGet]
        public async Task<bool> IsMobileNumberExist(string MobileNumber, Guid? GuId)
        {
            bool exists = await CheckMobileNumberExist(MobileNumber, GuId);
            return !exists;
        }

        private async Task<bool> CheckMobileNumberExist(string MobileNumber, Guid? GuId)
        {
            bool exists = false;
            try
            {
                if (GuId != null && Guid.Empty != GuId)
                {
                    APIAdminMaster admin = await _admSvc.GetAdminUserAsync(GuId.GetValueOrDefault());
                    APIUserProfile UserProfile = await _userProfileSvc.GetUserProfileByGuIdAsync(GuId.GetValueOrDefault());

                    if (admin.MobileNumber != MobileNumber) // && UserProfile.MobileRegisteredWithBank != MobileNumber)
                        exists = await this._admSvc.IsExistAsync("MobileNumber", MobileNumber);
                }
                else
                {
                    exists = await this._admSvc.IsExistAsync("MobileNumber", MobileNumber);
                }
            }
            catch (Exception e)
            { }
            return exists;
        }

        [HttpGet]
        public IActionResult ChangePassword(Guid GuId)
        {
            APIUserMasterPasswordChange userPassword = new APIUserMasterPasswordChange();
            if (GuId != null && GuId != Guid.Empty)
            {
                userPassword.GuId = GuId;
                return View("ChangePassword", userPassword);
            }
            return View("ChangePassword", userPassword);
        }

        [HttpGet]
        public IActionResult ChangePasswordV2(string displayGuId)
        {
            Guid guid = Guid.Parse(_protector.Unprotect(displayGuId));
            APIUserMasterPasswordChange userPassword = new APIUserMasterPasswordChange();
            if (guid != null && guid != Guid.Empty)
            {
                userPassword.GuId = guid;
                return View("ChangePassword", userPassword);
            }
            return View("ChangePassword", userPassword);
        }

        [HttpPost]
        public async Task<IActionResult> ChangePassword(APIUserMasterPasswordChange userPassword)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    IsSuccess response= await _userSvc.ChangeUserPassword(userPassword);
                    if (userPassword.GuId != null && userPassword.GuId != Guid.Empty)
                    {
                        if (!response.success)
                        {
                            if (response.message == "Wrong Password!")
                                ModelState.AddModelError("OldPassword", response.message);
                            else if (response.message == "Old Password and new password should not be same!")
                                ModelState.AddModelError("Password", response.message);
                            else
                                ModelState.AddModelError("Password", response.message);
                            return View("ChangePassword", userPassword);
                        }
                        return RedirectToAction("Logout", "Account");
                    }
                    else
                    {
                        ModelState.AddModelError("Error", $"Something Went Wrong!)");
                        return View("ChangePassword", userPassword);
                    }
                }
                else
                {
                    ModelState.AddModelError("Error", $"Something Went Wrong!)");
                    return View("SetPassword", userPassword);
                }
            }
            catch (Exception e)
            {
                ModelState.AddModelError("Error", $"Something Went Wrong! ({e.GetType().Name} - {e.Message})");
                return View("SetPassword", userPassword);
            }
            //return View("SetPassword", userPassword);
        }
    }
}