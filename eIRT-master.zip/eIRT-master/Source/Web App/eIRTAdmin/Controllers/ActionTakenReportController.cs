﻿using eIRTAdmin.Helper;
using eIRTAdmin.Models.APIModels;
using eIRTAdmin.Services.Interface;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace eIRTAdmin.Controllers
{
    [Authorize(Roles = RoleCode.EHS_Manager)]
    public class ActionTakenReportController : Controller
    {
        private IActionTakenReportService _actTakenRptSvc;
        private HttpContext _hcontext;
        private IIncidentReportService _incidentRptSvc;
        private IIncidentAssignmentService _incidentAssignSvc;
        public ActionTakenReportController(IActionTakenReportService actTakenRptSvc,
                                           IHttpContextAccessor haccess,
                                           IIncidentReportService incidentRptSvc,
                                           IIncidentAssignmentService incidentAssignSvc)
        {
            _actTakenRptSvc = actTakenRptSvc;
            _hcontext = haccess.HttpContext;
            _incidentRptSvc = incidentRptSvc;
            _incidentAssignSvc = incidentAssignSvc;
            if (_hcontext.User == null || _hcontext.User.FindFirst("AccessToken") == null)
            {
                Response.Redirect(Url.Action("Logout", "Account"));
            }
        }

        public IActionResult Index(APISearchActionTeken searchInfo)
        {
            searchInfo.page = 1;
            searchInfo.pageSize = 10;
            APIListAndCountActionTakenRpt listAndCount = new APIListAndCountActionTakenRpt(); // await _actTakenRptSvc.GetActionTakenReportsAsync(searchInfo);
            ViewBag.RecordCount = 0;
            ViewBag.TotalPageCount = 1;
            ViewBag.Page = searchInfo.page;
            ViewBag.MenuId = "menuActionTakenReport";
            return View(listAndCount.apiActionTakenReports);
        }

        public async Task<IActionResult> IndexJson(APISearchActionTeken searchInfo)
        {
            searchInfo.page = searchInfo.page == 0 ? 1 : searchInfo.page;
            searchInfo.pageSize = searchInfo.pageSize == 0 ? 10 : searchInfo.pageSize;
            APIListAndCountActionTakenRpt listAndCount = await _actTakenRptSvc.GetActionTakenReportsAsync(searchInfo) ?? new APIListAndCountActionTakenRpt();
            ViewBag.Page = searchInfo.page;
            ViewBag.RecordCount = listAndCount.count;
            ViewBag.TotalPageCount = (int)Math.Ceiling((decimal)ViewBag.RecordCount / (decimal)searchInfo.pageSize);
            return Json(new { isValid = true, html = Helper.RenderRezorView.RenderRazorViewToString(this, "_ViewAll", listAndCount.apiActionTakenReports) });
        }

        [HttpGet]
        public async Task<IActionResult> Actions(int incidentId)
        {
            APISearchActionTeken searchInfo = new APISearchActionTeken();
            searchInfo.page = searchInfo.page == 0 ? 1 : searchInfo.page;
            searchInfo.pageSize = int.MaxValue;
            searchInfo.IncidentId = incidentId;
            APIListAndCountActionTakenRpt listAndCount = await _actTakenRptSvc.GetActionTakenReportsAsync(searchInfo) ?? new APIListAndCountActionTakenRpt();
            ViewBag.Page = searchInfo.page;
            ViewBag.RecordCount = listAndCount.count;
            //ViewBag.TotalPageCount = (int)Math.Ceiling((decimal)ViewBag.RecordCount / (decimal)searchInfo.pageSize);
            return PartialView(listAndCount.apiActionTakenReports); //Json(new { isValid = true, html = Helper.RenderRezorView.RenderRazorViewToString(this, "Actions", listAndCount.apiActionTakenReports) });
        }

        public async Task<IActionResult> Create()
        {
            APISearchInfo searchInfo = new APISearchInfo();
            searchInfo.page = 1;
            searchInfo.pageSize = 4999;
            List<APIIncidentReport> apiIncidentReports = await _incidentAssignSvc.GetIncidentsForActionTaken(searchInfo);
            ViewBag.ListOfIncidentReport = apiIncidentReports;
            ViewBag.ListOfIncidentReportJson = JsonConvert.SerializeObject(apiIncidentReports);
                        
            return PartialView("Create");
        }

        [HttpPost]
        public async Task<IActionResult> Create(APIActionTakenReport info)
        {
            APISearchActionTeken searchInfo = new APISearchActionTeken();
            List<APIIncidentReport> apiIncidentReports = new List<APIIncidentReport>();
            if (ModelState.IsValid)
            {
                if(info.InvestigationFindings!=null || info.RootCauseAnalysis!=null || info.ImmediateActionTaken!=null)
                {
                    await _actTakenRptSvc.AddActionTakenReportAsync(info);

                    searchInfo.page = 1;
                    searchInfo.pageSize = 10;
                    APIListAndCountActionTakenRpt listAndCount = await _actTakenRptSvc.GetActionTakenReportsAsync(searchInfo);
                    ViewBag.RecordCount = listAndCount.count;
                    ViewBag.TotalPageCount = (int)Math.Ceiling((decimal)ViewBag.RecordCount / (decimal)searchInfo.pageSize);
                    return Json(new { isValid = true, html = Helper.RenderRezorView.RenderRazorViewToString(this, "_ViewAll", listAndCount.apiActionTakenReports) });
                }
                else
                {
                    searchInfo.page = 1;
                    searchInfo.pageSize = 4999;
                    apiIncidentReports = await _incidentAssignSvc.GetIncidentsForActionTaken(searchInfo);
                    ViewBag.ListOfIncidentReport = apiIncidentReports;
                    ViewBag.ListOfIncidentReportJson = JsonConvert.SerializeObject(apiIncidentReports);

                    ModelState.AddModelError("InvestigationFindings", "One of the field Investigation Findings, Root Cause Analysis or Immediate Action Taken should be required!");
                    return Json(new { isValid = false, html = Helper.RenderRezorView.RenderRazorViewToString(this, "Create", info) });
                }                
            }

            searchInfo.page = 1;
            searchInfo.pageSize = 4999;
            apiIncidentReports = await _incidentAssignSvc.GetIncidentsForActionTaken(searchInfo);
            ViewBag.ListOfIncidentReport = apiIncidentReports;
            ViewBag.ListOfIncidentReportJson = JsonConvert.SerializeObject(apiIncidentReports);

            return Json(new { isValid = false, html = Helper.RenderRezorView.RenderRazorViewToString(this, "Create", info) });
        }

        public async Task<IActionResult> Edit(APIId apiId)
        {
            APISearchInfo searchInfo = new APISearchInfo();
            searchInfo.page = 1;
            searchInfo.pageSize = 4999;

            APIActionTakenReport info = await this._actTakenRptSvc.GetActionTakenReportAsync(apiId);
            apiId.Id = info.ReferenceIncidentId;

            List<APIIncidentReport> apiIncidentReports = await _incidentRptSvc.GetSingleIncidentReportsList(apiId);
            ViewBag.ListOfIncidentReport = apiIncidentReports;
            ViewBag.ListOfIncidentReportJson = JsonConvert.SerializeObject(apiIncidentReports);
            
            ViewBag.SelectedIncident = JsonConvert.SerializeObject(info.ReferenceIncidentId);

            return PartialView("Edit", info);
        }

        [HttpPost]
        public async Task<IActionResult> Edit(APIActionTakenReport info)
        {
            APISearchActionTeken searchInfo = new APISearchActionTeken();
            APIId apiId = new APIId();
            List<APIIncidentReport> apiIncidentReports = new List<APIIncidentReport>();
            if (ModelState.IsValid)
            {
                if (info.InvestigationFindings != null || info.RootCauseAnalysis != null || info.ImmediateActionTaken != null)
                {
                    info.Id = 0;
                    APIActionTakenReport actionTakenReport = await this._actTakenRptSvc.AddActionTakenReportAsync(info);

                    if (actionTakenReport != null)
                    {
                        searchInfo.page = 1;
                        searchInfo.pageSize = 10;
                        APIListAndCountActionTakenRpt listAndCount = await _actTakenRptSvc.GetActionTakenReportsAsync(searchInfo);
                        ViewBag.RecordCount = listAndCount.count;
                        ViewBag.TotalPageCount = (int)Math.Ceiling((decimal)ViewBag.RecordCount / (decimal)searchInfo.pageSize);
                        return Json(new { isValid = true, html = Helper.RenderRezorView.RenderRazorViewToString(this, "_ViewAll", listAndCount.apiActionTakenReports) });
                    }
                }
                else
                {
                    searchInfo.page = 1;
                    searchInfo.pageSize = 4999;
                    apiId.Id = info.ReferenceIncidentId;
                    apiIncidentReports = await _incidentRptSvc.GetSingleIncidentReportsList(apiId);
                    ViewBag.ListOfIncidentReport = apiIncidentReports;
                    ViewBag.ListOfIncidentReportJson = JsonConvert.SerializeObject(apiIncidentReports);

                    ModelState.AddModelError("InvestigationFindings", "One of the field Investigation Findings, Root Cause Analysis or Immediate Action Taken should be required!");
                    return Json(new { isValid = false, html = Helper.RenderRezorView.RenderRazorViewToString(this, "Create", info) });
                }
            }

            searchInfo.page = 1;
            searchInfo.pageSize = 4999;
            apiId.Id = info.ReferenceIncidentId;
            apiIncidentReports = await _incidentRptSvc.GetSingleIncidentReportsList(apiId);
            ViewBag.ListOfIncidentReport = apiIncidentReports;
            ViewBag.ListOfIncidentReportJson = JsonConvert.SerializeObject(apiIncidentReports);

            ViewBag.SelectedIncident = JsonConvert.SerializeObject(info.ReferenceIncidentId);

            return Json(new { isValid = false, html = Helper.RenderRezorView.RenderRazorViewToString(this, "Edit", info) });
        }

        public async Task<IActionResult> Delete(int id)
        {
            await this._actTakenRptSvc.DeleteActionTakenReportAsync(id);
            return RedirectToAction("Index");
        }
    }
}
