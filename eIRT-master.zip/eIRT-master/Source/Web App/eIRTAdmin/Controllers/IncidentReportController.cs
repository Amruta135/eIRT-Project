﻿using eIRTAdmin.Helper;
using eIRTAdmin.Models;
using eIRTAdmin.Models.APIModels;
using eIRTAdmin.Services.Interface;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace eIRTAdmin.Controllers
{
    [Authorize(Roles = "EM, EI")]
    public class IncidentReportController : Controller
    {
        private IIncidentReportService _incidentRptSvc;
        private HttpContext _hcontext;
        private string IncidentReportPhotoPath;
        private string UserApiUrl;
        private IIncidentCategoryService _incidentSvc;
        private IDepartmentService _deptSvc;

        public IncidentReportController(IIncidentReportService incidentRptSvc,
                                        IHttpContextAccessor haccess,
                                        IOptions<AppSettings> settings,
                                        IIncidentCategoryService incidentSvc,
                                        IDepartmentService deptSvc)
        {
            _incidentRptSvc = incidentRptSvc;
            _hcontext = haccess.HttpContext;
            _incidentSvc = incidentSvc;
            _deptSvc = deptSvc;
            UserApiUrl = $"{settings.Value.AppUserUrl}";
            IncidentReportPhotoPath = $"{settings.Value.IncidentReportPhotoPath}";
            if (_hcontext.User == null || _hcontext.User.FindFirst("AccessToken") == null)
            {
                Response.Redirect(Url.Action("Logout", "Account"));
            }
        }

        public IActionResult Index(APISearchInfo searchInfo)
        {
            searchInfo.page = 1;
            searchInfo.pageSize = 10;
            APIListAndCountIncidentReport listAndCount = new APIListAndCountIncidentReport(); // await _incidentRptSvc.GetIncidentReportsAsync(searchInfo);
            ViewBag.RecordCount = 0;
            ViewBag.TotalPageCount = 1;
            ViewBag.Page = searchInfo.page;
            ViewBag.MenuId = "menuIncidentReport";
            return View(listAndCount.apiIncidentReports);
        }

        public async Task<IActionResult> IndexJson(APISearchInfo searchInfo)
        {
            searchInfo.page = searchInfo.page == 0 ? 1 : searchInfo.page;
            searchInfo.pageSize = searchInfo.pageSize == 0 ? 10 : searchInfo.pageSize;
            APIListAndCountIncidentReport listAndCount = await _incidentRptSvc.GetIncidentReportsAsync(searchInfo);
            ViewBag.Page = searchInfo.page;
            ViewBag.RecordCount = listAndCount.count;
            ViewBag.TotalPageCount = (int)Math.Ceiling((decimal)ViewBag.RecordCount / (decimal)searchInfo.pageSize);
            return Json(new { isValid = true, html = Helper.RenderRezorView.RenderRazorViewToString(this, "_ViewAll", listAndCount.apiIncidentReports) });
        }

        public async Task<IActionResult> Create()
        {
            APISearchInfo searchInfo = new APISearchInfo();
            searchInfo.page = 1;
            searchInfo.pageSize = 9999;
            APIListAndCountIncident listAndCount = await _incidentSvc.GetIncidentCategorysAsync(searchInfo);
            ViewBag.ListOfCategories = listAndCount.apiIncidentCategories;

            APIListAndCountDepartment list = await _deptSvc.GetDepartmentsAsync(searchInfo);
            ViewBag.ListOfDepartments = list.apiDepartments;
            return PartialView("Create");
        }

        [HttpPost]
        public async Task<IActionResult> Create(APIIncidentReport info)
        {
            APISearchInfo searchInfo = new APISearchInfo();
            try
            {
                if (ModelState.IsValid)
                {
                    APIIncidentReport newIncidentReport = await _incidentRptSvc.AddIncidentReportAsync(info);
                    if (info.PhotoFile != null && info.PhotoFile.Length > 0 && newIncidentReport.Id > 0)
                    {
                        await this._incidentRptSvc.UploadIncidentReportPhoto(newIncidentReport.Id, info.PhotoFile);
                    }
                    
                    searchInfo.page = 1;
                    searchInfo.pageSize = 10;
                    APIListAndCountIncidentReport listAndCountIncident = await _incidentRptSvc.GetIncidentReportsAsync(searchInfo);
                    ViewBag.RecordCount = listAndCountIncident.count;
                    ViewBag.TotalPageCount = (int)Math.Ceiling((decimal)ViewBag.RecordCount / (decimal)searchInfo.pageSize);

                    return Json(new { isValid = true, html = Helper.RenderRezorView.RenderRazorViewToString(this, "_ViewAll", listAndCountIncident.apiIncidentReports) });
                }
            }
            catch (Exception e)
            {
                ModelState.AddModelError("Error", $"It was not possible to add a new buyer, please try later on ({e.GetType().Name} - {e.Message})");
            }
            searchInfo.page = 1;
            searchInfo.pageSize = 9999;
            APIListAndCountIncident listAndCount = await _incidentSvc.GetIncidentCategorysAsync(searchInfo);
            ViewBag.ListOfCategories = listAndCount.apiIncidentCategories;

            APIListAndCountDepartment list = await _deptSvc.GetDepartmentsAsync(searchInfo);
            ViewBag.ListOfDepartments = list.apiDepartments;

            return Json(new { isValid = false, html = Helper.RenderRezorView.RenderRazorViewToString(this, "Create", info) });
        }

        public async Task<IActionResult> Edit(APIId apiId)
        {
            var uri = new Uri(UserApiUrl);
            APIIncidentReport info = await this._incidentRptSvc.GetIncidentReportAsync(apiId);
            ViewBag.LogoPath = uri.Scheme + "://" + uri.Authority + IncidentReportPhotoPath;
            APISearchInfo searchInfo = new APISearchInfo();
            searchInfo.page = 1;
            searchInfo.pageSize = 9999;
            APIListAndCountIncident listAndCount = await _incidentSvc.GetIncidentCategorysAsync(searchInfo);
            ViewBag.ListOfCategories = listAndCount.apiIncidentCategories;

            APIListAndCountDepartment list = await _deptSvc.GetDepartmentsAsync(searchInfo);
            ViewBag.ListOfDepartments = list.apiDepartments;

            return PartialView("Edit", info);
        }

        [HttpPost]
        public async Task<IActionResult> Edit(APIIncidentReport info)
        {
            APISearchInfo searchInfo = new APISearchInfo();
            if (ModelState.IsValid)
            {
                APIIncidentReport incidentReport = await this._incidentRptSvc.UpdateIncidentReportAsync(info.Id, info);
                if (incidentReport.PhotoFile != null && incidentReport.PhotoFile.Length > 0 && incidentReport.Id > 0)
                {
                    await this._incidentRptSvc.UploadIncidentReportPhoto(incidentReport.Id, incidentReport.PhotoFile);
                }
                if (incidentReport != null)
                {
                    searchInfo.page = 1;
                    searchInfo.pageSize = 10;
                    APIListAndCountIncidentReport listAndCountIncident = await _incidentRptSvc.GetIncidentReportsAsync(searchInfo);
                    ViewBag.RecordCount = listAndCountIncident.count;
                    ViewBag.TotalPageCount = (int)Math.Ceiling((decimal)ViewBag.RecordCount / (decimal)searchInfo.pageSize);
                    return Json(new { isValid = true, html = Helper.RenderRezorView.RenderRazorViewToString(this, "_ViewAll", listAndCountIncident.apiIncidentReports) });
                }
            }

            var uri = new Uri(UserApiUrl);
            ViewBag.LogoPath = uri.Scheme + "://" + uri.Authority + IncidentReportPhotoPath;
            searchInfo.page = 1;
            searchInfo.pageSize = 9999;
            APIListAndCountIncident listAndCount = await _incidentSvc.GetIncidentCategorysAsync(searchInfo);
            ViewBag.ListOfCategories = listAndCount.apiIncidentCategories;

            APIListAndCountDepartment list = await _deptSvc.GetDepartmentsAsync(searchInfo);
            ViewBag.ListOfDepartments = list.apiDepartments;

            return Json(new { isValid = false, html = Helper.RenderRezorView.RenderRazorViewToString(this, "Edit", info) });
        }

        public async Task<IActionResult> Delete(int id)
        {
            await this._incidentRptSvc.DeleteIncidentReportAsync(id);
            return RedirectToAction("Index");
        }

        [HttpGet]
        public async Task<bool> IsDescriptionExist(string Description, int? Id)
        {
            bool isExist = false;
            APIIsExistInput apiIsExistInput = new APIIsExistInput();
            apiIsExistInput.FieldName = "Description";
            apiIsExistInput.value = Description;
            apiIsExistInput.Id = Id;
            if (Id > 0)
            {
                APIId apiId = new APIId();
                apiId.Id = Id.GetValueOrDefault();
                APIIncidentReport incidentReport = await _incidentRptSvc.GetIncidentReportAsync(apiId);
                if (Description != incidentReport.Description)
                    isExist = await this._incidentRptSvc.IsExistAsync(apiIsExistInput);
            }
            else
            {
                isExist = await this._incidentRptSvc.IsExistAsync(apiIsExistInput);
            }
            return !isExist;
        }
    }
}
