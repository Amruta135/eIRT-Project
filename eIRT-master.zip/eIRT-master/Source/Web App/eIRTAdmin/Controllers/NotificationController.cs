﻿using System.Collections.Generic;
using System.Threading.Tasks;
using eIRTAdmin.Models.APIModels;
using eIRTAdmin.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;

namespace eIRTAdmin.Controllers
{
    public class NotificationController : Controller
    {
        private readonly IUserNotificationService _userNotificationSvc;
        private readonly IOptions<AppSettings> _settings;
        private string notificationApiUrl;

        public NotificationController(IUserNotificationService userNotificationSvc,
                                      IOptions<AppSettings> settings)
        {
            _userNotificationSvc = userNotificationSvc;
            _settings = settings;
            notificationApiUrl = $"{settings.Value.NotificationUrl}";
        }
        public async Task<IActionResult> GetUserNotifications()
        {
            List<APIUserNotifications> notification = await _userNotificationSvc.GetUserNotifications();
            return Ok(new { UserNotification = notification, Count = notification.Count });
        }

        public async Task<IActionResult> ReadNotification(int notificationId)
        {
            await _userNotificationSvc.ReadNotification(notificationId);
            return Ok();
        }
    }
}