﻿using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using eIRTAdmin.Models;
using Microsoft.AspNetCore.Authorization;

namespace eIRTAdmin.Controllers
{
    [Authorize(Roles = "PA, CA, EM, EI, EO")]
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            ViewBag.MenuId = "menuHome";
            ViewBag.PwdChanged = TempData["pwdChanged"] == null ? false : (bool)TempData["pwdChanged"];
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        [AllowAnonymous]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult ResponseErrorMessage(int responseCode, string message)
        {
            return View(new ResponseErrorModel { ResponseCode = responseCode, Message = message });
        }

        [AllowAnonymous]
        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult UnauthorizedError()
        {
            ResponseErrorModel error = new ResponseErrorModel
            {
                ResponseCode = 401,
                Message = "Access Denied!"
            };
            return View(error);
        }
    }
}
