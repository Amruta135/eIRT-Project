﻿using eIRTAdmin.Models.APIModels;
using eIRTAdmin.Services;
using eIRTAdmin.Services.Interface;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace eIRTAdmin.Controllers
{
    public class OpenClosedIncidentController : Controller
    {
        private IIncidentReportService _incidentRptSvc;
        private HttpContext _hcontext;
        private string IncidentReportPhotoPath;
        private string UserApiUrl;

        public OpenClosedIncidentController(IIncidentReportService incidentRptSvc,
                                            IHttpContextAccessor haccess,
                                            IOptions<AppSettings> settings)
        {
            _incidentRptSvc = incidentRptSvc;
            _hcontext = haccess.HttpContext;
            UserApiUrl = $"{settings.Value.AppUserUrl}";
            IncidentReportPhotoPath = $"{settings.Value.IncidentReportPhotoPath}";
            if (_hcontext.User == null || _hcontext.User.FindFirst("AccessToken") == null)
            {
                Response.Redirect(Url.Action("Logout", "Account"));
            }
        }

        public async Task<IActionResult> IndexForCA(APISearchInfo searchInfo)
        {
            searchInfo.page = 1;
            searchInfo.pageSize = 10;
            APIListAndCountIncidentReport incidentReports = await this._incidentRptSvc.GetAllIncidentDetailsAsync(searchInfo);
            ViewBag.RecordCount = incidentReports.count;
            ViewBag.TotalPageCount = (int)Math.Ceiling((decimal)ViewBag.RecordCount / (decimal)searchInfo.pageSize);
            ViewBag.MenuId = "menuOpenClosedIncident";
            return View(incidentReports.apiIncidentReports);
        }

        public IActionResult IndexForManager(APISearchInfoForManagers searchInfo)
        {
            searchInfo.page = searchInfo.page == 0 ? 1 : searchInfo.page;
            searchInfo.pageSize = searchInfo.pageSize == 0 ? 10 : searchInfo.pageSize;
            searchInfo.status = string.IsNullOrWhiteSpace(searchInfo.status) ? "Open" : searchInfo.status;

            APIListAndCountIncidentReport incidentReports = new APIListAndCountIncidentReport(); //await _incidentRptSvc.GetIncidentReportsForManagersAsync(searchInfo) ?? new APIListAndCountIncidentReport();
            ViewBag.RecordCount = 0;
            ViewBag.TotalPageCount = 1;
            ViewBag.Page = searchInfo.page;
            ViewBag.MenuId = "menuOpenClosedIncident";
            return View(incidentReports.apiIncidentReports);
        }

        public async Task<IActionResult> IndexForManagerJson(APISearchInfoForManagers searchInfo)
        {
            searchInfo.page = searchInfo.page == 0 ? 1 : searchInfo.page;
            searchInfo.pageSize = searchInfo.pageSize == 0 ? 10 : searchInfo.pageSize;
            searchInfo.status = string.IsNullOrWhiteSpace(searchInfo.status) ? "Open" : searchInfo.status;

            APIListAndCountIncidentReport incidentReports = await _incidentRptSvc.GetIncidentReportsForManagersAsync(searchInfo) ?? new APIListAndCountIncidentReport();
            ViewBag.RecordCount = incidentReports.count;
            ViewBag.TotalPageCount = (int)Math.Ceiling((decimal)incidentReports.count / (decimal)searchInfo.pageSize);
            ViewBag.Page = searchInfo.page;
            ViewBag.status = searchInfo.status;
            ViewBag.OpenBtnClass = string.IsNullOrWhiteSpace(searchInfo.status) || searchInfo.status == "Open" ? "btn-success" : "btn-secondary";
            ViewBag.ClosedBtnClass = !string.IsNullOrWhiteSpace(searchInfo.status) && searchInfo.status == "Closed" ? "btn-success" : "btn-secondary";
            ViewBag.MenuId = "menuOpenClosedIncident";
            return Json(new { isValid = true, html = Helper.RenderRezorView.RenderRazorViewToString(this, "_ViewAllForManager", incidentReports.apiIncidentReports) });
            //return View(incidentReports.apiIncidentReports);
        }

        public async Task<IActionResult> IndexForInspector(APISearchInfo searchInfo)
        {
            searchInfo.page = 1;
            searchInfo.pageSize = 10;
            APIListAndCountIncidentReport incidentReports = await this._incidentRptSvc.GetIncidentReportsAsync(searchInfo);
            ViewBag.RecordCount = incidentReports.count;
            ViewBag.TotalPageCount = (int)Math.Ceiling((decimal)ViewBag.RecordCount / (decimal)searchInfo.pageSize);
            ViewBag.MenuId = "menuOpenClosedIncident";
            return View(incidentReports.apiIncidentReports);
        }

        public async Task<IActionResult> IndexForMonitor(APISearchInfo searchInfo)
        {
            searchInfo.page = 1;
            searchInfo.pageSize = 10;
            APIListAndCountIncidentReport incidentReports = await this._incidentRptSvc.GetAllIncidentDetailsAsync(searchInfo);
            ViewBag.RecordCount = incidentReports.count;
            ViewBag.TotalPageCount = (int)Math.Ceiling((decimal)ViewBag.RecordCount / (decimal)searchInfo.pageSize);
            ViewBag.MenuId = "menuOpenClosedIncident";
            return View(incidentReports.apiIncidentReports);
        }
    }
}
