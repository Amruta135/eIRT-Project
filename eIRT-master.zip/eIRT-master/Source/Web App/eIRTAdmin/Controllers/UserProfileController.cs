﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using eIRTAdmin.Services;
using eIRTAdmin.Models.APIModels;
using Microsoft.Extensions.Options;
using Microsoft.AspNetCore.DataProtection;
using System.Linq;
using eIRTAdmin.Services.Interface;
using eIRTAdmin.Models;

namespace eIRTAdmin.Controllers
{
    public class UserProfileController : Controller
    {
        private IUserProfileService _userProfSvc;
        private readonly IStatesService _statesSvc;
        private readonly IPinCodeService _pincodeSvc;
        private readonly IOptions<AppSettings> _settings;
        private string profilePicUrl;
        private string UserApiUrl;
        private readonly IDataProtector _protector;
        private IUserMasterService _userSvc;
        private IDepartmentService _deptSvc;
        private IRolesConfigurationService _roleConfigSvc;
        private readonly ISecurityQuestionService _secQuestionSvc;

        public UserProfileController(IUserProfileService userProfSvc,
            IOptions<AppSettings> settings,
            //IUPIPSPBankInformationService bankSvc,
            IStatesService statesSvc,
            IPinCodeService pincodeSvc,
            IDataProtectionProvider provider,
            IUserMasterService userSvc,
            IDepartmentService deptSvc,
            IRolesConfigurationService roleConfigSvc,
            ISecurityQuestionService secQuestionSvc)
        {
            _userProfSvc = userProfSvc;
            _settings = settings;
            //_bankSvc = bankSvc;
            UserApiUrl = $"{settings.Value.AppUserUrl}";
            profilePicUrl = $"{settings.Value.UserProfilePicPath}";
            _statesSvc = statesSvc;
            _pincodeSvc = pincodeSvc;
            _protector = provider.CreateProtector("mydataprotectorkey");
            _userSvc = userSvc;
            _deptSvc = deptSvc;
            _roleConfigSvc = roleConfigSvc;
            _secQuestionSvc = secQuestionSvc;
        }

        [HttpGet]
        public async Task<IActionResult> MyProfile()
        {
            //Guid? guid = Guid.Parse(_protector.Unprotect(displayGuId));  

            var uri = new Uri(UserApiUrl);

            APISearchInfo aPISearchInfo = new APISearchInfo();
            aPISearchInfo.page = 1;
            aPISearchInfo.pageSize = 1000;
            APIListAndCountDepartment list = await _deptSvc.GetDepartmentsAsync(aPISearchInfo);
            ViewBag.ListOfDepartments = list.apiDepartments.OrderBy(x => x.Name);

            APIUserProfile userProf = await _userSvc.GetUserProfileAsync() ?? new APIUserProfile();
            //userProf.GuId = guid.GetValueOrDefault();

            return View("MyProfile", userProf);
        }

        [HttpPost]
        public async Task<IActionResult> MyProfile([FromForm]APIUserProfile userProfile)
        {
            APIUserProfile UserProf = new APIUserProfile();
            APISearchInfo aPISearchInfo = new APISearchInfo();
            APIListAndCountDepartment list = new APIListAndCountDepartment();
            var uri = new Uri(UserApiUrl);

            try
            {
                if (ModelState.IsValid)
                {
                    if (await CheckMobileNumberExist(userProfile.MobileNumber, userProfile.GuId))
                    {
                        ModelState.AddModelError("Mobile", "Mobile Number already exist!");
                        return Json(new { isValid = false, html = Helper.RenderRezorView.RenderRazorViewToString(this, "_ProfileView", userProfile) });
                    }

                    if (userProfile.Id > 0 && userProfile.GuId != null && userProfile.GuId.ToString().Length > 0)
                    {
                        UserProf = await this._userSvc.UpdateUserProfileAsync(userProfile.Id, userProfile);

                    }
                    else if (userProfile.Id == 0 && userProfile.GuId != null && userProfile.GuId.ToString().Length > 0)
                    {
                        UserProf = await _userSvc.AddUserProfileAsync(userProfile);
                        UserProf = await _userSvc.GetUserProfileAsync(UserProf.Id);
                    }
                    if (UserProf.Id > 0 && UserProf.GuId != Guid.Empty && userProfile.ProfilePic != null)
                    {
                        await this._userSvc.UpdateUserProfilePic(UserProf.Id, UserProf.GuId, userProfile.ProfilePic);
                    }
                    APIUserProfile userProf = await _userSvc.GetUserProfileAsync() ?? new APIUserProfile();
                    if (UserProf.GuId != Guid.Empty)
                    {
                        userProf.GuId = UserProf.GuId;
                    }

                    aPISearchInfo.page = 1;
                    aPISearchInfo.pageSize = 1000;
                    list = await _deptSvc.GetDepartmentsAsync(aPISearchInfo);
                    ViewBag.ListOfDepartments = list.apiDepartments.OrderBy(x => x.Name);

                    return Json(new { isValid = true, html = Helper.RenderRezorView.RenderRazorViewToString(this, "_ProfileView", userProf) });
                }
            }
            catch (Exception e)
            {
                ModelState.AddModelError("Error", $"Unable to Update! ({e.GetType().Name} - {e.Message})");
            }

            
            aPISearchInfo.page = 1;
            aPISearchInfo.pageSize = 1000;
            list = await _deptSvc.GetDepartmentsAsync(aPISearchInfo);
            ViewBag.ListOfDepartments = list.apiDepartments.OrderBy(x => x.Name);
            return Json(new { isValid = false, html = Helper.RenderRezorView.RenderRazorViewToString(this, "_ProfileView", userProfile) });
        }

        public async Task<IActionResult> GetUserProfilePic()
        {
            APIFileBase64Model file = await _userSvc.GetUserProfilePic(); ;
            //file.FileBase64 = 

            return PartialView(file);
        }

        public async Task<IActionResult> ProfilePic()
        {
            var result = await _userSvc.GetUserProfilePic();
            ViewBag.MyProfilePic = result.FileBase64;
            APIUserProfilePic profilePic = new APIUserProfilePic();
            profilePic.UserMasterGuId = result.GuId;
            return PartialView(profilePic);
        }

        [HttpPost]
        public async Task<IActionResult> ProfilePic([FromForm] APIUserProfilePic pic)
        {
            ResponseError msg = new ResponseError();
            APIFileBase64Model result = new APIFileBase64Model();
            APIUserProfilePic profilePic = new APIUserProfilePic();
            if ((pic.Id > 0 || pic.UserMasterGuId != Guid.Empty) && pic.ProfilePic != null && pic.ProfilePic.Length > 0)
            {
                 msg = await this._userSvc.UpdateUserProfilePic(pic.Id, pic.UserMasterGuId, pic.ProfilePic);
            }
            if (msg.StatusCode != 200)
            {
                result = await _userSvc.GetUserProfilePic();
                ViewBag.MyProfilePic = result.FileBase64;
                ModelState.AddModelError("ProfilePic", msg.Message);
                return Json(new { isValid = false, html = Helper.RenderRezorView.RenderRazorViewToString(this, "ProfilePic", pic) });
                //return PartialView(profilePic);
            }
            //result = await _userSvc.GetUserProfilePic();
            //ViewBag.MyProfilePic = result.FileBase64;
            return Json(new { isValid = true});
            //return PartialView(pic);
        }

        private async Task<bool> CheckMobileNumberExist(string Mobile, Guid? GuId)
        {
            bool exists = false;
            try
            {
                if (GuId != null && Guid.Empty != GuId)
                {
                    APIUserProfile UserProfile = await _userSvc.GetUserProfileAsync();
                }
                else
                {
                    exists = await this._userSvc.IsExistAsync("MobileNumber", Mobile);
                }
            }
            catch (Exception e)
            { string a = e.Message; }
            return exists;
        }

        [HttpGet]
        public async Task<bool> IsMobileExist(string MobileNumber, string OrganizationCode, int? Id)
        {
            bool isExist = false;
            APIIsExistInput apiIsExistInput = new APIIsExistInput();
            apiIsExistInput.FieldName = "MobileNumber";
            apiIsExistInput.value = MobileNumber;
            apiIsExistInput.OrganizationCode = OrganizationCode;
            apiIsExistInput.Id = Id;
            if (Id > 0)
            {
                APIUserDetails userDetails = await _userSvc.GetUserAsync(Id.GetValueOrDefault());
                if (MobileNumber != userDetails.MobileNumber)
                    isExist = await this._userSvc.IsExistAsync(apiIsExistInput);
            }
            else
            {
                isExist = await this._userSvc.IsExistAsync(apiIsExistInput);
            }
            return !isExist;
        }

        [HttpGet]
        public async Task<bool> IsEmailExist(string Email, string OrganizationCode, int? Id)
        {
            bool isExist = false;
            APIIsExistInput apiIsExistInput = new APIIsExistInput();
            apiIsExistInput.FieldName = "Email";
            apiIsExistInput.value = Email;
            apiIsExistInput.OrganizationCode = OrganizationCode;
            apiIsExistInput.Id = Id;
            if (Id > 0)
            {
                APIUserDetails userDetails = await _userSvc.GetUserAsync(Id.GetValueOrDefault());
                if (Email != userDetails.Email)
                    isExist = await this._userSvc.IsExistAsync(apiIsExistInput);
            }
            else
            {
                isExist = await this._userSvc.IsExistAsync(apiIsExistInput);
            }
            return !isExist;
        }

        [HttpGet]
        public async Task< IActionResult> ChangePassword()
        {
            //Guid guId = Guid.Parse(_protector.Unprotect(displayGuId));
            List<APISecurityQuestion> questions = await _secQuestionSvc.GetAllQuestionsAsync();
            ViewBag.SecurityQuestions = questions.OrderBy(x => x.Question);
            APIUserSecurityQuestion userSecurityQuestion = await _userSvc.GetUserSecurityQuestionAsync();
            APIUserMasterPasswordChange userPassword = new APIUserMasterPasswordChange();
            userPassword.SecurityQuestionID = userSecurityQuestion.SecurityQuestionId;
            userPassword.SecurityQuestion = userSecurityQuestion.SecurityQuestion;
            userPassword.Answer = userSecurityQuestion.SecurityAnswer;
            //if (guId != null && guId != Guid.Empty)
            //{
            //    userPassword.GuId = guId;
            //    return View("ChangePassword", userPassword);
            //}
            return View("ChangePassword", userPassword);
        }

        [HttpPost]
        public async Task<IActionResult> ChangePassword(APIUserMasterPasswordChange userPassword)
        {
            List<APISecurityQuestion> questions = await _secQuestionSvc.GetAllQuestionsAsync();
            ViewBag.SecurityQuestions = questions.OrderBy(x => x.Question);
            try
            {
                if (ModelState.IsValid)
                {

                    IsSuccess response = await _userSvc.ChangeUserPassword(userPassword);
                    if (!response.success)
                    {
                        if (response.message == "Wrong Password!")
                            ModelState.AddModelError("OldPassword", response.message);
                        else if (response.message == "Old Password and new password should not be same!")
                            ModelState.AddModelError("Password", response.message);
                        else
                            ModelState.AddModelError("Password", response.message);
                        return View("ChangePassword", userPassword);

                    }
                    TempData["pwdChanged"] = response.success;
                    if (User.IsInRole(Helper.RoleCode.Posiview_Admin))
                    {
                        return RedirectToAction("Index", "Home");
                    }
                    else
                    {
                        return RedirectToAction("Index", "Dashboard");
                    }
                }
            }
            catch (Exception e)
            {
                ModelState.AddModelError("Error", $"Something Went Wrong! ({e.GetType().Name} - {e.Message})");
            }
            return View("ChangePassword", userPassword);
        }
        
        [HttpGet]
        public async Task<IActionResult> ChangePasswordAtFirstLogin()
        {
            //Guid guId = Guid.Parse(_protector.Unprotect(displayGuId));
            List<APISecurityQuestion> questions = await _secQuestionSvc.GetAllQuestionsAsync();
            ViewBag.SecurityQuestions = questions.OrderBy(x => x.Question);

            APIUserMasterPasswordChange userPassword = new APIUserMasterPasswordChange();
            //if (guId != null && guId != Guid.Empty)
            //{
            //    userPassword.GuId = guId;
            //    return View("ChangePasswordAtFirstLogin", userPassword);
            // }
            return View("ChangePasswordAtFirstLogin", userPassword);
        }

        [HttpPost]
        public async Task<IActionResult> ChangePasswordAtFirstLogin(APIUserMasterPasswordChange userPassword)
        {
            List<APISecurityQuestion> questions = new List<APISecurityQuestion>();
            try
            {
                if (ModelState.IsValid)
                {
                    IsSuccess response = await _userSvc.ChangeUserPassword(userPassword);
                    if (!response.success)
                    {
                        if (response.message == "Wrong Password!")
                            ModelState.AddModelError("OldPassword", response.message);
                        else if (response.message == "Old Password and new password should not be same!")
                            ModelState.AddModelError("Password", response.message);
                        else
                            ModelState.AddModelError("Password", response.message);
                        questions = await _secQuestionSvc.GetAllQuestionsAsync();
                        ViewBag.SecurityQuestions = questions.OrderBy(x => x.Question);
                        return View("ChangePasswordAtFirstLogin", userPassword);
                    }
                    ViewBag.pwdChanged = true;
                    return View("ChangePasswordAtFirstLogin", new APIUserMasterPasswordChange());
                    //return RedirectToAction("Logout", "Account");
                }
            }
            catch (Exception e)
            {
                ModelState.AddModelError("Error", $"Something Went Wrong! ({e.GetType().Name} - {e.Message})");
                //return View("SetPassword", userPassword);
            }
            questions = await _secQuestionSvc.GetAllQuestionsAsync();
            ViewBag.SecurityQuestions = questions.OrderBy(x => x.Question);
            return View("ChangePasswordAtFirstLogin", userPassword);
        }

        [HttpGet]
        public async Task<IActionResult> ForgotPassword()
        {
            List<APISecurityQuestion> questions = await _secQuestionSvc.GetAllQuestionsAsync();
            ViewBag.SecurityQuestions = questions.OrderBy(x => x.Question);

            APIForgotPassword userPassword = new APIForgotPassword();
            return View(userPassword);
        }

        [HttpPost]
        public async Task<IActionResult> ForgotPassword(APIForgotPassword userPassword)
        {
            List<APISecurityQuestion> questions = new List<APISecurityQuestion>();
            try
            {
                if (ModelState.IsValid)
                {
                    IsSuccess response = await _userSvc.ForgotPasswordAsync(userPassword);
                    if (!response.success)
                    {
                        ModelState.AddModelError("UserId", response.message);
                        questions = await _secQuestionSvc.GetAllQuestionsAsync();
                        ViewBag.SecurityQuestions = questions.OrderBy(x => x.Question);
                        return View(userPassword);
                    }
                    ViewBag.pwdChanged = response.success;
                    return View(new APIForgotPassword());
                    //return RedirectToAction("Logout", "Account");
                }
            }
            catch (Exception e)
            {
                ModelState.AddModelError("UserId", $"Internal Error! ({e.GetType().Name} - {e.Message})");
                return View(userPassword);
            }
            questions = await _secQuestionSvc.GetAllQuestionsAsync();
            ViewBag.SecurityQuestions = questions.OrderBy(x => x.Question);
            return View(userPassword);
        }
    }
}