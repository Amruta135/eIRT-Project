﻿using eIRTAdmin.Models.APIModels;
using eIRTAdmin.Services.Interface;
using eIRTAdmin.Helper;
using eIRTAdmin.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;

namespace eIRTAdmin.Controllers
{
    [Authorize(Roles = RoleCode.Posiview_Admin)]
    public class OrganizationInfoController : Controller
    {
        private IOrganizationInfoService _orgInfoSvc;
        private readonly IStatesService _statesSvc;
        private readonly IPinCodeService _pincodeSvc;
        private HttpContext _hcontext;
        private string OrganizationLogoPath;
        private string UserApiUrl;

        public OrganizationInfoController(IOrganizationInfoService orgInfoSvc,
                                          IStatesService statesSvc,
                                          IPinCodeService pincodeSvc,
                                          IHttpContextAccessor haccess,
                                          IOptions<AppSettings> settings)
        {
            _orgInfoSvc = orgInfoSvc;
            _statesSvc = statesSvc;
            _pincodeSvc = pincodeSvc;
            _hcontext = haccess.HttpContext;
            UserApiUrl = $"{settings.Value.AppUserUrl}";
            OrganizationLogoPath = $"{settings.Value.OrganizationLogoPath}";
            if (_hcontext.User == null || _hcontext.User.FindFirst("AccessToken") == null)
            {
                Response.Redirect(Url.Action("Logout", "Account"));
            }
        }

        public IActionResult Index(APISearchInfo searchInfo)
        {
            searchInfo.page = 1;
            searchInfo.pageSize = 10;
            APIListAndCount listAndCount = new APIListAndCount(); //await _orgInfoSvc.GetOrganizationInfosAsync(searchInfo);
            ViewBag.Page = searchInfo.page;
            ViewBag.RecordCount = 0;
            ViewBag.TotalPageCount = 1;
            ViewBag.MenuId = "menuOrganizationInfo";
            return View(listAndCount.apiOrganizationInfo);
        }

        public async Task<IActionResult> IndexJson(APISearchInfo searchInfo)
        {
            searchInfo.page = searchInfo.page == 0 ?1 : searchInfo.page;
            searchInfo.pageSize = searchInfo.pageSize == 0 ? 10 : searchInfo.pageSize;
            APIListAndCount listAndCount = await _orgInfoSvc.GetOrganizationInfosAsync(searchInfo);
            ViewBag.Page = searchInfo.page;
            ViewBag.RecordCount = listAndCount.count;
            ViewBag.TotalPageCount = (int)Math.Ceiling((decimal)ViewBag.RecordCount / (decimal)searchInfo.pageSize);
            return Json(new { isValid = true, html = Helper.RenderRezorView.RenderRazorViewToString(this, "_ViewAll", listAndCount.apiOrganizationInfo) });
            //return View(listAndCount.apiOrganizationInfo);
        }

        public async Task<IActionResult> Create()
        {            
            ViewBag.ListOfstates = await _statesSvc.GetStates();
            APIOrganizationInfo info = new APIOrganizationInfo() { RGBCode = "#213958", AppName = "Incident Reporting Tool" };
            return PartialView("Create", info);
        }

        [HttpPost]
        public async Task<IActionResult> Create(APIOrganizationInfo info)
        {
            try
            {
                if (ModelState.IsValid)
                {                    
                    APIOrganizationInfo newOrganizationInfo = await _orgInfoSvc.AddOrganizationInfoAsync(info);
                    if (info.LogoFile != null && info.LogoFile.Length > 0 && newOrganizationInfo.Id > 0)
                    {
                        await this._orgInfoSvc.UploadOrganizationLogo(newOrganizationInfo.Id, info.LogoFile);
                    }
                    APISearchInfo searchInfo = new APISearchInfo();
                    searchInfo.page = 1;
                    searchInfo.pageSize = 10;
                    APIListAndCount listAndCount = await _orgInfoSvc.GetOrganizationInfosAsync(searchInfo);
                    ViewBag.RecordCount = listAndCount.count;
                    ViewBag.TotalPageCount = (int)Math.Ceiling((decimal)ViewBag.RecordCount / (decimal)searchInfo.pageSize);

                    return Json(new { isValid = true, html = Helper.RenderRezorView.RenderRazorViewToString(this, "_ViewAll", listAndCount.apiOrganizationInfo) });
                }
            }
            catch (Exception e)
            {
                ModelState.AddModelError("Error", $"It was not possible to add a new buyer, please try later on ({e.GetType().Name} - {e.Message})");
            }

            ViewBag.ListOfstates = await _statesSvc.GetStates();

            return Json(new { isValid = false, html = Helper.RenderRezorView.RenderRazorViewToString(this, "Create", info) });
        }

        [HttpGet]
        public async Task<IActionResult> GetStateByPincode(string pincode)
        {
            int pin;
            APIPinCode apiPinCode = null;
            if (Int32.TryParse(pincode, out pin))
            {
                apiPinCode = await _pincodeSvc.GetStateByPincode(pin.ToString());
            }
            apiPinCode = apiPinCode ?? new APIPinCode();
            return Json(apiPinCode);
        }

        public async Task<IActionResult> Edit(APIId organizationInfoId)
        {
            var uri = new Uri(UserApiUrl);
            APIOrganizationInfo info = await this._orgInfoSvc.GetOrganizationInfoAsync(organizationInfoId);
            ViewBag.ListOfstates = await _statesSvc.GetStates();
            ViewBag.LogoPath = uri.Scheme + "://" + uri.Authority + OrganizationLogoPath;

            ViewBag.DeliveryModelJson = JsonConvert.SerializeObject(info.DeliveryModel);
            ViewBag.DomainNameJson = JsonConvert.SerializeObject(info.DomainName);
            return PartialView("Edit", info);
        }

        [HttpPost]
        public async Task<IActionResult> Edit(APIOrganizationInfo info)
        {
            if (ModelState.IsValid)
            {
                APIOrganizationInfo organizationInfo = await this._orgInfoSvc.UpdateOrganizationInfoAsync(info.Id, info);
                if (organizationInfo.LogoFile != null && organizationInfo.LogoFile.Length > 0 && organizationInfo.Id > 0)
                {
                    await this._orgInfoSvc.UploadOrganizationLogo(organizationInfo.Id, organizationInfo.LogoFile);
                }
                if (organizationInfo != null)
                {
                    APISearchInfo searchInfo = new APISearchInfo();
                    searchInfo.page = 1;
                    searchInfo.pageSize = 10;
                    APIListAndCount listAndCount = await _orgInfoSvc.GetOrganizationInfosAsync(searchInfo);
                    ViewBag.RecordCount = listAndCount.count;
                    ViewBag.TotalPageCount = (int)Math.Ceiling((decimal)ViewBag.RecordCount / (decimal)searchInfo.pageSize);
                    return Json(new { isValid = true, html = Helper.RenderRezorView.RenderRazorViewToString(this, "_ViewAll", listAndCount.apiOrganizationInfo) });
                }
            }

            var uri = new Uri(UserApiUrl);
            ViewBag.LogoPath = uri.Scheme + "://" + uri.Authority + OrganizationLogoPath;
            ViewBag.ListOfstates = await _statesSvc.GetStates();

            return Json(new { isValid = false, html = Helper.RenderRezorView.RenderRazorViewToString(this, "Edit", info) });
        }

        public async Task<IActionResult> Delete(int id)
        {
            await this._orgInfoSvc.DeleteOrganizationInfoAsync(id);
            return RedirectToAction("Index");
        }

        [HttpGet]
        public async Task<bool> IsOrganizationExist(string OrganizationName, int? Id)
        {
            bool isExist = false;
            if (Id > 0)
            {
                APIId apiOrganizationInfoId = new APIId();
                apiOrganizationInfoId.Id = Id.GetValueOrDefault();
                APIOrganizationInfo organizationInfo = await _orgInfoSvc.GetOrganizationInfoAsync(apiOrganizationInfoId);
                if (OrganizationName != organizationInfo.OrganizationName)
                    isExist = await this._orgInfoSvc.IsExistAsync("OrganizationName", OrganizationName);
            }
            else
            {
                isExist = await this._orgInfoSvc.IsExistAsync("OrganizationName", OrganizationName);
            }
            return !isExist;
        }

        [HttpGet]
        public async Task<bool> IsDomainNameExist(string DomainName, int? Id)
        {
            bool isExist = false;
            if (Id > 0)
            {
                APIId apiOrganizationInfoId = new APIId();
                apiOrganizationInfoId.Id = Id.GetValueOrDefault();
                APIOrganizationInfo organizationInfo = await _orgInfoSvc.GetOrganizationInfoAsync(apiOrganizationInfoId);
                if (DomainName != organizationInfo.DomainName)
                    isExist = await this._orgInfoSvc.IsExistAsync("DomainName", DomainName);
            }
            else
            {
                isExist = await this._orgInfoSvc.IsExistAsync("DomainName", DomainName);
            }
            return !isExist;
        }
        
        [HttpGet]
        public async Task<bool> IsOrganizationCodeExist(string OrganizationCode, int? Id)
        {
            bool isExist = false;
            if (Id > 0)
            {
                APIId apiOrganizationInfoId = new APIId();
                apiOrganizationInfoId.Id = Id.GetValueOrDefault();
                APIOrganizationInfo organizationInfo = await _orgInfoSvc.GetOrganizationInfoAsync(apiOrganizationInfoId);
                if (OrganizationCode != organizationInfo.OrganizationCode)
                    isExist = await this._orgInfoSvc.IsExistAsync("OrganizationCode", OrganizationCode);
            }
            else
            {
                isExist = await this._orgInfoSvc.IsExistAsync("OrganizationCode", OrganizationCode);
            }
            return !isExist;
        }

        public async Task<IActionResult> GetImageBase64Content(int Id)
        {
            APIFileBase64Model image = await _orgInfoSvc.GetImageBase64ContentAsync(Id);
            return Json(image);
        }
    }
}
