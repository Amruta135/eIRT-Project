﻿using eIRTAdmin.Models;
using eIRTAdmin.Models.APIModels;
using eIRTAdmin.Services.Interface;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace eIRTAdmin.Controllers
{
    public class DashboardController : Controller
    {
        private IIncidentReportService _incidentRptSvc;
        private HttpContext _hcontext;
        public DashboardController(IIncidentReportService incidentRptSvc,
                                        IHttpContextAccessor haccess,
                                        IOptions<AppSettings> settings)
        {
            _incidentRptSvc = incidentRptSvc;
            _hcontext = haccess.HttpContext;
            if (_hcontext.User == null || _hcontext.User.FindFirst("AccessToken") == null)
            {
                Response.Redirect(Url.Action("Logout", "Account"));
            }
        }
        public async Task<IActionResult> Index()
        {
            APIIncidentReportCount incidentReportCount = await this._incidentRptSvc.GetCountOfAllStatus();
            ViewBag.MenuId = "menuDashboard";
            ViewBag.PwdChanged = TempData["pwdChanged"] == null ? false : (bool)TempData["pwdChanged"];

            var lstModel = new List<SimpleReportViewModel>();
            lstModel.Add(new SimpleReportViewModel
            {
                Name = "Reported Incident",
                Quantity = incidentReportCount.OpenIncidentCount
            });
            lstModel.Add(new SimpleReportViewModel
            {
                Name = "Work In Progress Incident",
                Quantity = incidentReportCount.WorkInProgressIncidentCount
            });
            lstModel.Add(new SimpleReportViewModel
            {
                Name = "Closed Incident",
                Quantity = incidentReportCount.ClosedIncidentCount
            });

            ViewBag.AverageClosuerPeriod = incidentReportCount.AverageClosuerPeriod;
            ViewBag.DaysSinceLastIncident = incidentReportCount.DaysSinceLastIncident;
            return  View(lstModel);
        }
    }
}
