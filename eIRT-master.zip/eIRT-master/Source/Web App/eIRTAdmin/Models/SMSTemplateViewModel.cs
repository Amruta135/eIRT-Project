﻿using System;
using System.ComponentModel.DataAnnotations;

namespace eIRTAdmin.Models
{
    public class SMSTemplateViewModel
    {
        public int Id { get; set; }

        [Required]
        [MaxLength(200)]
        public string Title { get; set; }

        [Required]
        [MaxLength(500)]
        public string Content { get; set; }
        [Required]
        public string Status { get; set; }

        [RegularExpression(@"^[a-zA-Z0-9]+$", ErrorMessage = "Use only letters and numbers.")]
        public string search { get; set; }

        [Display(Name = "Created By")]
        public int CreatedBy { get; set; }

        [Display(Name = "Created By")]
        public string CreatedByName { get; set; }

        [Display(Name = "Created Date")]
        public DateTime CreatedDate { get; set; }

        [Display(Name = "Modified By")]
        public int ModifiedBy { get; set; }

        [Display(Name = "Modified By")]
        public string ModifiedByName { get; set; }

        [Display(Name = "Modified Date")]
        public DateTime ModifiedDate { get; set; }

        [Required]
        [Display(Name = "Language")]
        public string Language { get; set; }
    }
}
