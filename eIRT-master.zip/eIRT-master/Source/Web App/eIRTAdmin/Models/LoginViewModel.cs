﻿using System.ComponentModel.DataAnnotations;

namespace eIRTAdmin.Models
{
    public class LoginViewModel
    {
        [Required(AllowEmptyStrings = false)]
        [StringLength(100, ErrorMessage = "Must be between 8 and 16 characters", MinimumLength = 8)]
        [Display(Name ="User Id")]
        public string UserId { get; set; }

        [Required(AllowEmptyStrings = false)]
        [StringLength(100, ErrorMessage = "Must be between 8 and 16 characters", MinimumLength = 8)]
        [DataType(DataType.Password)]
        public string Password { get; set; }

        [Required(AllowEmptyStrings =false)]
        [StringLength(100, ErrorMessage = "Must be between 3 and 7 characters", MinimumLength = 3)]
        [Display(Name = "Organization Code")]
        public string OrganizationCode { get; set; }
    }
}
