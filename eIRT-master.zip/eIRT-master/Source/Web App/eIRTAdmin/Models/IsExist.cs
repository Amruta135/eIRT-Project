﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace eIRTAdmin.Models
{
    public class IsExistModel
    {
        public bool exists { get; set; }
        
    }

    public class APIIsExistInput
    {
        public string FieldName { get; set; }
        public string value { get; set; }
        public int? Id { get; set; }
        public string OrganizationCode { get; set; }
    }
}
