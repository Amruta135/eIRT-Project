﻿using System;
using System.ComponentModel.DataAnnotations;

namespace eIRTAdmin.Models
{
    public class AdminMasterViewModel
    {
        public Guid? GuId { get; set; }

        [Required]
        [StringLength(100, ErrorMessage = "The {0} must be at least {2} and maximum {1} characters long.", MinimumLength = 1)]
        public string Name { get; set; }

        [Required]
        [StringLength(50, ErrorMessage = "The {0} must be at least {2} and maximum {1} characters long.", MinimumLength = 8)]
        [RegularExpression(@"^[a-zA-Z0-9_-]+$", ErrorMessage = "Use letters, numbers and special charecters like '_' and '-' only ")]
        [Display(Name ="User ID")]
        public string UserId { get; set; }

        [Required]
        [StringLength(10, ErrorMessage = "The {0} must be {2} characters long.", MinimumLength = 10)]
        
        [Display(Name = "Mobile Number")]
        [RegularExpression(@"^[0-9]{10}$", ErrorMessage = "Invalid Mobile Number.")]
        public string MobileNumber { get; set; }

        [Required]
        [StringLength(10, ErrorMessage = "The {0} must be {2} characters long.", MinimumLength = 1)]
        [RegularExpression("Coordinator|Admin|User", ErrorMessage = "The {0} should be Admin or Coordinator")]
        [Display(Name = "Role")]
        public string Role { get; set; } = "Coordinator";       // Values for this field are coordinator / admin 

        [Required]
        //[StringLength(3, ErrorMessage = "The {0} must be {2} characters long.", MinimumLength = 2)]
        public string Language { get; set; }

        [Display(Name = "Language")]
        public string LanguageName { get; set; }

        [Required]
        [StringLength(10, ErrorMessage = "The {0} should be active or inactive", MinimumLength = 1)]
        [RegularExpression("active|inactive", ErrorMessage = "The {0} should be active or inactive")]
        public string Status { get; set; } = "inactive";  // Values for this field are Active / Inactive 

        //[Required]
        //[RegularExpression(@"^([a-zA-Z0-9@*#]{8,16})$", ErrorMessage = "Password length should be min 8 characters long which contains alfanumeric and special character!")]
        //[DataType(DataType.Password)]
        //public string OTP { get; set; }

        //public bool IsFirstLogin { get; set; } = true;  //  if it is first time login then value will be true else false 

        //public DateTime FirstLoginDate { get; set; }

        [Display(Name = "Created By")]
        public int CreatedBy { get; set; }

        [Display(Name = "Created By")]
        public string CreatedByName { get; set; }

        [Display(Name = "Created Date")]
        public DateTime CreatedDate { get; set; }

        [Display(Name = "Modified By")]
        public int ModifiedBy { get; set; }

        [Display(Name = "Modified By")]
        public string ModifiedByName { get; set; }


        [Display(Name = "Modified Date")]
        public DateTime ModifiedDate { get; set; }
    }

    public class APIRoleTypes
    {
        public string Code { get; set; }
        public string Name { get; set; }
    }
}
