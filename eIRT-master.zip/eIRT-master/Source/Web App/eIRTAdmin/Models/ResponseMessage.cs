﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;

namespace eIRTAdmin.Models
{
    [DataContract]
    public class ResponseMessage <T>
    {
        [DataMember]
        public bool IsSuccess { get; set; }
        [DataMember]
        public string ReturnMessage { get; set; }
        [DataMember]
        public T data {get;set;}
    }
}
