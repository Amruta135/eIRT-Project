﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace eIRTAdmin.Models.APIModels
{
    public class APIUserPassword
    {
        [Required]
        public Guid GuId { get; set; }

        [Required]
        [StringLength(16, ErrorMessage = "The {0} must be at least {2} and maximum {1} characters long.", MinimumLength = 8)]
        [RegularExpression(@"^[a-zA-Z0-9_-]+$", ErrorMessage = "Use letters, numbers and special charecters like '_' and '-' only ")]
        [Display(Name ="User ID")]
        public string UserId { get; set; }

        //[Required]
        //[MaxLength(10)]
        //public string OTP { get; set; }

        [Required(AllowEmptyStrings =false)]
        [RegularExpression(@"^(?=.*[0-9]+.*)(?=.*[a-zA-Z]+.*)[0-9a-zA-Z*@_-]{8,12}$", ErrorMessage = "Password length should be minimum 8 and it should have minimum 1 character and 1 number!")]
        [DataType(DataType.Password)]
        public string Password { get; set; }

        [Required(AllowEmptyStrings =false, ErrorMessage = "Confirm Password required")]
        [CompareAttribute("Password", ErrorMessage = "Password doesn't match.")]
        [Display(Name = "Confirm Passowrd")]
        [DataType(DataType.Password)]
        public string ConfirmPassowrd { get; set; }

        //[Required]
        //public string MPin { get; set; }
    }
}
