﻿using eIRTAdmin.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace eIRTAdmin.Models.APIModels
{
    public class APIIncidentReport
    {
        public int Id { get; set; }

        [Display(Name = "Incident Category")]
        public int IncidentCategoryId { get; set; }

        [MaxLength(100, ErrorMessage = "Length should be less than 100 characters!")]
        [Display(Name = "Incident Category")]
        public string IncidentCategory { get; set; }

        [MaxLength(100, ErrorMessage = "Length should be less than 100 characters!")]
        [Display(Name = "Incident Location")]
        public string IncidentLocation { get; set; }

        [Display(Name = "Linked To Department")]
        public int LinkedToDepartmentId { get; set; }

        [Display(Name = "Linked To Department")]
        public string LinkedToDepartment { get; set; }

        [Required(AllowEmptyStrings =false)]
        [MaxLength(90, ErrorMessage = "Length should be less than 90 characters!")]
        [Display(Name = "Description")]
        [Remote("IsDescriptionExist", "IncidentReport", ErrorMessage = "Description is already exists!", AdditionalFields = "Id")]
        public string Description { get; set; }

        [MaxLength(100)]
        [Display(Name = "Photo")]
        public string Photo { get; set; }
        [Display(Name = "Photo")]
        [DataType(DataType.Upload)]
        [MaxFileSize(2 * 1024 * 1024)]
        [AllowedExtensions(new string[] { ".jpg", ".jpeg", ".png" })]
        public IFormFile PhotoFile { get; set; }

        public string PhotoBase64 { get; set; }

        [MaxLength(500, ErrorMessage = "Length should be less than 500 characters!")]
        [Display(Name = "Additional Description")]
        public string AdditionalDescription { get; set; }

        [Display(Name = "Status")]
        public string Status { get; set; }

        [Display(Name = "Reported Date")]
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:dd-MMM-yyyy}", ApplyFormatInEditMode = true)]
        public DateTime ReportedDate { get; set; }

        [Display(Name = "Reported User Name")]
        public string ReportedUserName { get; set; }
        [Display(Name = "Report Status")]
        public string ReportStatus { get; set; }
        public bool IsAssigned { get; set; } = false;
        public int PrimaryAssignedToId { get; set; }
        public string PrimaryAssignedTo { get; set; }
        public int SecondaryAssignedToId { get; set; }
        public string SecondaryAssignedTo { get; set; }
        public DateTime AssignmentDate { get; set; }

        [Display(Name = "Remark By Admin")]
        public string RemarkByAdmin { get; set; }

        public DateTime ModifiedDate { get; set; }

        [Display(Name = "Required Competencies")]
        public string CompetencyIds { get; set; }

        [Display(Name = "Required Competencies")]
        public List<APICompetency> Competencies { get; set; }

        [Required]
        [Display(Name = "Expected Closure Date")]
        public DateTime ClosureDate { get; set; }
    }

    public class APIListAndCountIncidentReport
    {
        public List<APIIncidentReport> apiIncidentReports { get; set; } = new List<APIIncidentReport>();
        public int count { get; set; }
    }
}
