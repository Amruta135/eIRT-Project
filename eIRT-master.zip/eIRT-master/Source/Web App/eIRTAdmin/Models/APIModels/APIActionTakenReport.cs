﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace eIRTAdmin.Models.APIModels
{
    public class APIActionTakenReport
    {
        public int Id { get; set; }

        [Required]
        [Display(Name= "Incident")]
        [Range(1, int.MaxValue, ErrorMessage = "Please select!")]
        public int ReferenceIncidentId { get; set; }

        [Display(Name = "Reference Incident")]
        public string ReferenceIncident { get; set; }

        [Display(Name = "Category")]
        public string Category { get; set; }

        [Required(AllowEmptyStrings =false, ErrorMessage ="Please enter!")]
        [Display(Name = "Findings")]
        [MaxLength(100, ErrorMessage = "should be less than 100 characters long!")]
        public string InvestigationFindings { get; set; }

        [Display(Name = "Root Cause")]
        [MaxLength(100)]
        public string RootCauseAnalysis { get; set; }

        
        [Display(Name = "Immediate Actions")]
        [MaxLength(100)]
        public string ImmediateActionTaken { get; set; }

        [Display(Name = "Status")]
        [Required(AllowEmptyStrings = false, ErrorMessage = "Please select!")]
        public string IncidentStatus { get; set; }

        [Display(Name = "Target Closure")]
        [Required(AllowEmptyStrings = false, ErrorMessage = "The Target Closure Date field is required.")]
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:dd-MMM-yyyy}", ApplyFormatInEditMode = true)]
        public DateTime? TargetClosureDate { get; set; }

        [Display(Name = "Corrective Actions")]
        [Required(AllowEmptyStrings =false, ErrorMessage = "The Corrective Action field is required.")]
        [MaxLength(100, ErrorMessage = "should be less than 100 characters long!")]
        public string CorrectiveActionsImplemented { get; set; }

        [Display(Name = "Reported on")]
        public DateTime DateReported { get; set; }

        [Display(Name = "Reported By")]
        public string ReportedUserName { get; set; }

        [Display(Name = "Action By")]
        public string ActionTekenBy { get; set; }

        [Display(Name = "Action On")]
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:dd-MMM-yyyy}", ApplyFormatInEditMode = true)]
        public DateTime ActionTekenOn { get; set; }
    }

    public class APIListAndCountActionTakenRpt
    {
        public List<APIActionTakenReport> apiActionTakenReports { get; set; } = new List<APIActionTakenReport>();
        public int count { get; set; }
    }
}
