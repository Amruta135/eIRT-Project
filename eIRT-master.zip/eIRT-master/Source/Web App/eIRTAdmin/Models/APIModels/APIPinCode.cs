﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace eIRTAdmin.Models.APIModels
{
    public class APIPinCode
    {
        public int Pincode { get; set; }
        public string PostOfficeName { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public string StateCode { get; set; }
    }
}
