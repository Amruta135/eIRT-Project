﻿using System;
using System.ComponentModel.DataAnnotations;

namespace eSMBAdmin.Models.APIModels
{
    public class APISMSTemplateModel
    {
        public int Id { get; set; }

        [Required]
        [MaxLength(200)]
        public string Title { get; set; }

        [Required]
        [MaxLength(500)]
        public string Content { get; set; }
        [Required]
        public string Status { get; set; }
        public string Language { get; set; }
    }
}
