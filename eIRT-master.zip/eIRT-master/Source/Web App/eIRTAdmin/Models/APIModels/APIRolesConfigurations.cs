﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace eIRTAdmin.Models.APIModels
{
    public class APIRolesConfigurations
    {
        public int Id { get; set; }
        [Display(Name = "Original Role")]
        [Remote("IsOriginalRoleExist", "RolesConfiguration", ErrorMessage = "Role is already used!", AdditionalFields = "Id")]
        public string OriginalRoleDescription { get; set; }
        [Display(Name = "Changed Role")]
        [Required]
        [MaxLength(50)]
        [Remote("IsChangedRoleExist", "RolesConfiguration", ErrorMessage = "Role is already Exists!", AdditionalFields = "Id")]
        public string ChangedRoleDescription { get; set; }
        public string OriginalRoleCode { get; set; }
    }

    public class APIListAndCountRoleConfig
    {
        public List<APIRolesConfigurations> apiRolesConfigurations { get; set; } = new List<APIRolesConfigurations>();
        public int count { get; set; }
    }
}
