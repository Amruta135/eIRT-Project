﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace eIRTAdmin.Models.APIModels
{
    public class UserOptValidate
    {
        [Required]
        public Guid GuId { get; set; }

        [Required]
        [MaxLength(6)]
        [Display(Name ="One Time Password (OTP)")]
        public String OTP { get; set; }
    }
}
