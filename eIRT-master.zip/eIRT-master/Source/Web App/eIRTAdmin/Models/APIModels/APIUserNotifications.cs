﻿namespace eIRTAdmin.Models.APIModels
{
    public class APIUserNotifications
    {
        public int Id { get; set; }
        public string Text { get; set; }

    }
}
