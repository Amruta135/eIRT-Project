﻿using eIRTAdmin.Services;
using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace eIRTAdmin.Models.APIModels
{
    public class APIUploadDocument
    {
        [Required]
        [DataType(DataType.Upload)]
        [MaxFileSize(1 * 1024 * 1024)]
        [AllowedExtensions(new string[] { ".xls", ".xlsx" })]
        public IFormFile Document { get; set; }
    }

    public class APIFilePath
    {
        public string FilePath { get; set; }

        public string TotalRecord { get; set; }
    }
}
