﻿using System.ComponentModel.DataAnnotations;

namespace eIRTAdmin.Models.APIModels
{
    public class APIStates
    {
        [MaxLength(10)]
        public string Code { get; set; }
        [MaxLength(100)]
        public string Name { get; set; }
    }
}