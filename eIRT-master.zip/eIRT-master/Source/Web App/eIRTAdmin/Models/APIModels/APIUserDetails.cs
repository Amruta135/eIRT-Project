﻿using eIRTAdmin.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace eIRTAdmin.Models.APIModels
{
    public class APIUserDetails
    {
        public int Id { get; set; }
        public Guid GuId { get; set; }

        [RegularExpression("^[a-zA-Z\\s]+$", ErrorMessage = "Accepts only Alphabets.")]
        [Required]
        [MaxLength(100)]
        public string Name { get; set; }

        [Display(Name = "Mobile")]
        [MaxLength(10)]
        [Required]
        [Remote("IsMobileExist", "UserMaster", ErrorMessage = "Mobile number is already Exist!", AdditionalFields = "Id, OrganizationCode")]
        public string MobileNumber { get; set; }

        [Display(Name = "Organization")]
        [Required]
        public string OrganizationCode { get; set; }

        public string Organization { get; set; }

        [Display(Name = "Employee Code")]
        [MaxLength(20)]
        [Required]
        [Remote("IsEmployeeCodeExist", "UserMaster", ErrorMessage = "Employee Code is already Exist!", AdditionalFields = "Id, OrganizationCode")]
        public string EmployeeCode { get; set; }

        [Display(Name = "Department")]
        [Range(1, int.MaxValue, ErrorMessage = "Please select!")]
        public int DepartmentId { get; set; }

        public string Department { get; set; }

        public string Designation { get; set; }

        [EmailAddress]
        [Required]
        [Remote("IsEmailExist", "UserMaster", ErrorMessage = "Email is already Exist!", AdditionalFields = "Id, OrganizationCode")]
        [MaxLength(100)]
        public string Email { get; set; }

        public string RoleCode { get; set; }

        [Required]
        public string Role { get; set; }

        [Required(AllowEmptyStrings = false)]
        public string Status { get; set; }

        public string LastLoggedInTime { get; set; }

        [MaxLength(500)]
        [Display(Name = "Profile Picture")]
        public string UserProfilePic { get; set; }

        public string ProfilePicBase64 { get; set; }

        [Display(Name = "Profile Picture")]
        [DataType(DataType.Upload)]
        [MaxFileSize(2 * 1024 * 1024)]
        [AllowedExtensions(new string[] { ".jpg", ".jpeg", ".png" })]
        public IFormFile ProfilePic { get; set; }

        //[Required(AllowEmptyStrings = false)]
        [RegularExpression(@"^(?=.*[0-9]+.*)(?=.*[a-zA-Z]+.*)[0-9a-zA-Z*@_-]{8,12}$", ErrorMessage = "Password length should be minimum 8 and it should have minimum 1 character and 1 number!")]
        //[DataType(DataType.Password)]
        [Display(Name = "Onetime Password")]
        public string OTP { get; set; }

        public int CreatedBy { get; set; }

        [Display(Name = "Competencies")]
        public string CompetencyIds { get; set; }
        [Display(Name = "Competencies")]
        public string[] CompetencyArr { get; set; }
        [Display(Name = "Competencies")]
        public List<APICompetency> Competencies { get; set; }
    }

    public class APIListAndCountforUserMaster
    {
        public List<APIUserDetails> apiUserDetails { get; set; } = new List<APIUserDetails>();
        public int count { get; set; }
    }

    public class APIUserDetailsForPA
    {
        public int Id { get; set; }
        public Guid GuId { get; set; }
        [RegularExpression("^[a-zA-Z\\s]+$", ErrorMessage = "Accepts only Alphabets.")]
        [Required]
        public string Name { get; set; }
        [Display(Name = "Mobile")]
        [MaxLength(10)]
        [Required]
        [Remote("IsMobileExist", "UserMaster", ErrorMessage = "Mobile number is already Exist!", AdditionalFields = "Id, OrganizationCode")]
        public string MobileNumber { get; set; }
        [Display(Name = "Organization")]
        [Required]
        public string OrganizationCode { get; set; }
        public string Organization { get; set; }
        [Display(Name = "Employee Code")]
        [Required]
        [Remote("IsEmployeeCodeExist", "UserMaster", ErrorMessage = "Employee Code is already Exist!", AdditionalFields = "Id, OrganizationCode")]
        public string EmployeeCode { get; set; }
        [Display(Name = "Department")]
        [Range(0, int.MaxValue, ErrorMessage = "Please select!")]
        public int DepartmentId { get; set; }
        public string Designation { get; set; }
        [EmailAddress]
        [Required]
        public string Email { get; set; }
        [Required]
        public string Role { get; set; }
        [Required(AllowEmptyStrings =false)]
        public string Status { get; set; }
        public string LastLoggedInTime { get; set; }
        [MaxLength(500)]
        [Display(Name = "Profile Picture")]
        public string UserProfilePic { get; set; }

        public string ProfilePicBase64 { get; set; }

        [Display(Name = "Profile Picture")]
        [DataType(DataType.Upload)]
        [MaxFileSize(10 * 1024 * 1024)]
        [AllowedExtensions(new string[] { ".jpg", ".jpeg", ".png" })]
        public IFormFile ProfilePic { get; set; }

        //[Required(AllowEmptyStrings = false)]
        [RegularExpression(@"^(?=.*[0-9]+.*)(?=.*[a-zA-Z]+.*)[0-9a-zA-Z*@_-]{8,12}$", ErrorMessage = "Password length should be minimum 8 and it should have minimum 1 character and 1 number!")]
        //[DataType(DataType.Password)]
        [Display(Name = "Onetime Password")]
        public string OTP { get; set; }
        public int CreatedBy { get; set; }
    }

    public class APIUserDetailsForExport
    {

        public string Name { get; set; }

        public string MobileNumber { get; set; }

        public string Organization { get; set; }

        public string EmployeeCode { get; set; }

        public string Department { get; set; }

        public string Designation { get; set; }

        public string Email { get; set; }

        public string Role { get; set; }
        public string Competencies { get; set; }

        public string Status { get; set; }

        public string LastLoggedInTime { get; set; }
    }
}
