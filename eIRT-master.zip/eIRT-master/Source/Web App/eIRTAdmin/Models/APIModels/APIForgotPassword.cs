﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace eIRTAdmin.Models.APIModels
{
    public class APIForgotPassword
    {
        [Required(AllowEmptyStrings = false)]
        public string UserId { get; set; }

        [Required]
        [RegularExpression(@"^(?=.*[0-9]+.*)(?=.*[a-zA-Z]+.*)[0-9a-zA-Z*@_-]{8,12}$", ErrorMessage = "Password length should be 8 to 12 and it should have minimum 1 character and 1 number!")]
        [DataType(DataType.Password)]
        [Display(Name = "New Password")]
        public string Password { get; set; }

        [Required(ErrorMessage = "Confirm Password required")]
        [CompareAttribute("Password", ErrorMessage = "Password doesn't match.")]
        [Display(Name = "Confirm Password")]
        [DataType(DataType.Password)]
        public string ConfirmPassowrd { get; set; }

        [Required]
        [Range(1, int.MaxValue, ErrorMessage = "Please Select!")]
        [Display(Name = "Security Question")]
        public int SecurityQuestionID { get; set; }

        public string SecurityQuestion { get; set; }

        [Required(AllowEmptyStrings = false, ErrorMessage = "Please Enter!")]
        [StringLength(100, MinimumLength = 3, ErrorMessage = "Answer should be minimum 3 & maximum 100 chars long!")]
        public string Answer { get; set; }

        [Required(AllowEmptyStrings =false)]
        [Display(Name ="Organization Code")]
        public string OrgCode { get; set; }
    }
}
