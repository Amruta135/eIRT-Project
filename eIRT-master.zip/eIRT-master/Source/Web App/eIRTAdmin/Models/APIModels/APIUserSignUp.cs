﻿using eIRTAdmin.Infrastructure;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace eIRTAdmin.Models.APIModels
{
    public class APIUserSignUp
    {
        public Guid? GuId { get; set; }

        [Required]
        [StringLength(100, ErrorMessage = "The {0} must be at least {2} and maximum {1} characters long.", MinimumLength = 1)]
        [RegularExpression(@"^[a-zA-Z\\s\u0900-\u097F .-]+$", ErrorMessage = "Invalid Name, numbers and special charecters are not allowed!")]
        public string Name { get; set; }

        [Required]
        //[StringLength(3, ErrorMessage = "The {0} must be {2} characters long.", MinimumLength = 2)]
        public string Language { get; set; }

        [Required]
        [StringLength(10, ErrorMessage = "Must have 10 digit long Number!", MinimumLength = 10)]
        [RegularExpression(@"^[0-9]{10}$", ErrorMessage = "Must have 10 digit long Number!")]
        [Display(Name ="Mobile No.")]
        [Remote("IsMobileNumberExist", "UserSignUp", ErrorMessage = "Another user is already registered with this Mobile Number! Please enter correct Mobile Number!")]
        public string MobileNumber { get; set; }

        [Required]
        [MustBeTrue(ErrorMessage = "Please tick on I Accept the License agreement!")]
        [Display(Name = "I have read and accept the ")]
        public bool IsLicAccepted { get; set; } = false;

        public string OTP { get; set; }

        public string Role { get; set; } = "User";

        //[Required]
        [StringLength(10, ErrorMessage = "The {0} should be active or inactive", MinimumLength = 1)]
        [RegularExpression("active|inactive", ErrorMessage = "The {0} should be active or inactive")]
        public string Status { get; set; } = "inactive";  // Values for this field are Active / Inactive 

        [Display(Name = "Is First Login")]
        public bool IsFirstLogin { get; set; } = true;  //  if it is first time login then value will be true else false 

        [Display(Name = "First Login Date")]
        public DateTime FirstLoginDate { get; set; }
    }
}
