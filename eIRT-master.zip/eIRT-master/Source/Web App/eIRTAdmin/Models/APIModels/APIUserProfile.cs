﻿using eIRTAdmin.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.ComponentModel.DataAnnotations;

namespace eIRTAdmin.Models.APIModels
{
    public class APIUserProfile
    {
        public int Id { get; set; }

        public Guid GuId { get; set; }

        public string OrganizationCode { get; set; }

        [Display(Name = "Employee Code")]
        [Required]
        [Remote("IsEmployeeCodeExist", "UserMaster", ErrorMessage = "Employee Code is already Exist!", AdditionalFields = "Id, OrganizationCode")]
        public string EmployeeCode { get; set; }

        [RegularExpression("^[a-zA-Z\\s]+$", ErrorMessage = "Accepts only Alphabets.")]
        [Required]
        public string Name { get; set; }

        [Display(Name = "Department")]
        [Range(0, int.MaxValue, ErrorMessage = "Please select!")]
        public int DepartmentId { get; set; }

        public string Department { get; set; }

        public string Designation { get; set; }

        [Display(Name = "Mobile Number")]
        [StringLength(10, ErrorMessage = "Must have 10 digit long Number!", MinimumLength = 10)]
        [RegularExpression(@"^[0-9]{10}$", ErrorMessage = "Must have 10 digit long Number!")]
        [Remote("IsMobileExist", "UserProfile", ErrorMessage = "Mobile Number is already exist!", AdditionalFields = "Id, OrganizationCode")]
        public string MobileNumber { get; set; }

        [EmailAddress]
        [Required]
        [Remote("IsEmailExist", "UserProfile", ErrorMessage = "Email is already exist!", AdditionalFields = "Id, OrganizationCode")]
        public string Email { get; set; }

        [Required]
        public string Role { get; set; }

        [MaxLength(500)]
        [Display(Name = "Profile Picture")]
        public string ProfilePicUrl { get; set; }

        public string ProfilePicBase64 { get; set; }

        [Display(Name = "Profile Picture")]
        [DataType(DataType.Upload)]
        [MaxFileSize(1 * 1024 * 1024)]
        [AllowedExtensions(new string[] { ".jpg", ".jpeg", ".png" })]
        public IFormFile ProfilePic { get; set; }        
    }
    public class APIUserProfilePic
    {
        [Required]
        public int Id { get; set; }

        [Required]
        [Display(Name = "GuId")]
        public Guid UserMasterGuId { get; set; }

        [Required]
        [Display(Name = "Profile Picture")]
        [DataType(DataType.Upload)]
        [MaxFileSize(1 * 1024 * 1024)]
        [AllowedExtensions(new string[] { ".jpg", ".jpeg", ".png" })]
        public IFormFile ProfilePic { get; set; }
    }

}
