﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace eIRTAdmin.Models.APIModels
{
    public class APISearchInfo
    {
        public int page { get; set; }
        public int pageSize { get; set; }
        public string filter { get; set; } = null;
        public string search { get; set; } = null;
    }
    public class APISearchInfoForManagers : APISearchInfo
    {
        public string status { get; set; }
    }

    public class APISearchIncident : APISearchInfo
    {
        public string status { get; set; }
        public int DepartmentId { get; set; }
        public int AssignedTo { get; set; }
    }

    public class APISearchActionTeken : APISearchInfo
    {
        public int IncidentId { get; set; }
        public string status { get; set; }
    }

    public class APISearchIncidentAssignment : APISearchInfo
    {
        public int IncidentId { get; set; }
    }
}
