﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace eIRTAdmin.Models.APIModels
{
    public class APIOpenClosedIncidentSearch
    {
        public DateTime startDate { get; set; }
        public DateTime endDate { get; set; }
        public string status { get; set; } = "";
        public int category { get; set; }
        public int departmentId { get; set; }
        public int month { get; set; }
        public int year { get; set; }
        public string CompetencyIds { get; set; }
    }

    public class APIOpenClosedIncidentInfo
    {
        public int IncidentId { get; set; }
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:dd-MMM-yyyy}", ApplyFormatInEditMode = true)]
        public DateTime DateReported { get; set; }
        public string ReportedBy { get; set; }
        public string Designation { get; set; }
        public string BriefDescription { get; set; }
        public string IncidentCategory { get; set; }
        public string Status { get; set; }
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:dd-MMM-yyyy}", ApplyFormatInEditMode = true)]
        public DateTime? LastActionTaken { get; set; }
        public string CorrectiveActions { get; set; }
        public string ATRReportedBy { get; set; }
        public string Department { get; set; }
        public string CompetencyIds { get; set; }
        public List<APICompetency> Competencies { get; set; }
        [Required]
        public DateTime ClosureDate { get; set; }
    }

    public class APIOpenClosedIncidentReport
    {
        public string organizationName { get; set; }
        public string address { get; set; }
        public string city { get; set; }
        public string pinCode { get; set; }
        public List<APIOpenClosedIncidentInfo> reportDate { get; set; } = new List<APIOpenClosedIncidentInfo>();
    }

    public class APIOpenClosedIncidentInfoExport
    {
        public string DateReported { get; set; }
        public string Department { get; set; }
        public string BriefDescription { get; set; }
        public string IncidentCategory { get; set; }
        public string Competencies { get; set; }
        public string Status { get; set; }
        public string CorrectiveActions { get; set; }
        public string ReportedBy { get; set; }
        public string LastActionTaken { get; set; }
        public string ATRReportedBy { get; set; }
        
    }
}
