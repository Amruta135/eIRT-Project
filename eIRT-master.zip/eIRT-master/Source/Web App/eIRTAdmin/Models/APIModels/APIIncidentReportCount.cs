﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace eIRTAdmin.Models.APIModels
{
    public class APIIncidentReportCount
    {
        public int OpenIncidentCount { get; set; }
        public int AssignedIncidentCount { get; set; }
        public int WorkInProgressIncidentCount { get; set; }
        public int ClosedIncidentCount { get; set; }
        public decimal AverageClosuerPeriod { get; set; }
        public int DaysSinceLastIncident { get; set; }
    }
}
