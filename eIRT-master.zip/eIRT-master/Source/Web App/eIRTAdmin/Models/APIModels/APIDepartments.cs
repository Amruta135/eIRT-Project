﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace eIRTAdmin.Models.APIModels
{
    public class APIDepartments
    {
        public int Id { get; set; }
        [Required]
        [Display(Name = "Department")]
        [Remote("IsDepartmentExist", "Department", ErrorMessage = "Department is already exists!", AdditionalFields = "Id")]
        [MaxLength(50)]
        public string Name { get; set; }

        [Required(AllowEmptyStrings =false)]
        [MaxLength(5)]
        [Display(Name= "Department Code")]
        [Remote("IsDepartmentCodeExist", "Department", ErrorMessage = "Department is already exists!", AdditionalFields = "Id")]
        public string Code { get; set; }
    }

    public class APIListAndCountDepartment
    {
        public List<APIDepartments> apiDepartments { get; set; } = new List<APIDepartments>();
        public int count { get; set; }
    }
    public class APIDepartmentsWithOrganization
    {
        public string OrganizationCode { get; set; }
    }
}
