﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace eIRTAdmin.Models.APIModels
{
    public class APIIncidentAssignment
    {
        public int Id { get; set; }

        [Required]
        [Display(Name = "Reference Incident")]
        [Range(1, int.MaxValue, ErrorMessage = "Please select!")]
        public int ReferenceIncidentId { get; set; }

        [Display(Name = "Reference Incident")]
        public string ReferenceIncident { get; set; }

        [Display(Name = "Category")]
        public string Category { get; set; }

        [Required]
        [Display(Name = "Primary Assign To")]
        [Range(1, int.MaxValue, ErrorMessage = "Please select!")]
        public int PrimaryAssignToId { get; set; }

        [Display(Name = "Primary Assign To")]
        public string PrimaryAssignToName { get; set; }

        [Display(Name = "Secondary Assign To")]
        public int SecondaryAssignToId { get; set; }

        [Display(Name = "Secondary Assign To")]
        public string SecondaryAssignToName { get; set; }

        [Display(Name = "Assigned Date")]
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:dd-MMM-yyyy}", ApplyFormatInEditMode = true)]
        public DateTime AssignedDate { get; set; }

        [MaxLength(100, ErrorMessage = "Length should be less than 200 characters!")]
        [Display(Name = "Remarks")]
        public string Remarks { get; set; }
        [Display(Name = "Date Reported")]
        public DateTime DateReported { get; set; }

        [Display(Name = "Reported By")]
        public string ReportedUserName { get; set; }
        [Display(Name = "Required Competencies")]
        public string CompetencyIds { get; set; }

        [Display(Name = "Required Competencies")]
        public List<APICompetency> Competencies { get; set; }

        [Display(Name = "Required Competencies")]
        public string[] CompetencyArr { get; set; }

        [Required]
        [Display(Name = "Expected Closure Date")]
        public DateTime ClosureDate { get; set; }
    }

    public class APIListAndCountIncidentAssignment
    {
        public List<APIIncidentAssignment> apiIncidentAssignments { get; set; } = new List<APIIncidentAssignment>();
        public int count { get; set; }
    }

    public class APIIsIncidentCreated
    {
        public int userId { get; set; }
        public int incidentId { get; set; }
    }
}
