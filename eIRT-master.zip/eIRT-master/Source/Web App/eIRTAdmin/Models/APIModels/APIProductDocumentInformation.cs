﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Http;
using eIRTAdmin.Services;

namespace eIRTAdmin.Models.APIModels
{
    public class APIProductDocumentInformation
    {
        public int Id { get; set; }

        [Required]
        [MaxLength(100)]
        [Display(Name = "Document Type")]
        public string DocumentType { get; set; }

        [DataType(DataType.Date)]
        public DateTime Date { get; set; }

        //[Required]
        [MaxLength(200)]
        [Display(Name = "View Document")]
        public string DocumentPath { get; set; } = "";

        [Required]
        [DataType(DataType.Date)]
        [Display(Name = "Release Date")]
        [DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:dd-MMM-yyyy}")]
        public DateTime ReleaseDate { get; set; }

        [MaxLength(int.MaxValue)]
        [Display(Name = "Document Content")]
        public string DocumentContent { get; set; }
    }

    public class APIProductDocumentInfoCreate : APIProductDocumentInformation
    {
        //[Required]
        [DataType(DataType.Upload)]
        [MaxFileSize(1 * 1024 * 1024)]
        [AllowedExtensions(new string[] { ".pdf" })]
        public IFormFile Document { get; set; }
    }
    public class APIProductDocumentInfoEdit: APIProductDocumentInformation
    {
        [DataType(DataType.Upload)]
        [MaxFileSize(1 * 1024 * 1024)]
        [AllowedExtensions(new string[] { ".pdf" })]
        public IFormFile Document { get; set; }
    }
    public class APIProductDocument
    {
        [Required]
        public int Id { get; set; }

        [Required]
        public IFormFile Document { get; set; }
    }

    public class DocumentContentModel
    {
        public string DocumentContent { get; set; }

    }
}
