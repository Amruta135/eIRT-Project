﻿using eIRTAdmin.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace eIRTAdmin.Models.APIModels
{
    public class APIOrganizationInfo
    {
        public int Id { get; set; }
        [MaxLength(7)]
        [Display(Name = "Code")]
        [Remote("IsOrganizationCodeExist", "OrganizationInfo", ErrorMessage = "Organization Code is already used!", AdditionalFields = "Id")]
        public string OrganizationCode { get; set; }
        [Required]
        [Display(Name = "Name")]
        [Remote("IsOrganizationExist", "OrganizationInfo", ErrorMessage = "Organization is already used!", AdditionalFields = "Id")]
        public string OrganizationName { get; set; }
        [Required]
        [MaxLength(200)]
        [Display(Name = "Address")]
        public string Address { get; set; }
        [Required]
        [MaxLength(6)]
        [Display(Name = "Pin Code")]
        public string Pincode { get; set; }
        [MaxLength(100)]
        [Display(Name = "City")]
        public string City { get; set; }
        [MaxLength(100)]
        [Display(Name = "State")]
        public string State { get; set; }
        [Required]
        [MaxLength(10)]
        [Display(Name = "Mobile Number")]        
        public string MobileNumber { get; set; }
        //[Url]
        [MaxLength(100)]
        [Display(Name = "Website")]
        [RegularExpression(@"(http://)?(www\.)?\w+\.(com|net|edu|org)",ErrorMessage = "Please add correct Website!")]
        public string Website { get; set; }
        [MaxLength(100)]
        [Display(Name = "Delivery Model")]
        public string DeliveryModel { get; set; }
        //[Required]
        [MaxLength(100)]
        [Display(Name = "Domain Name")]
        [Remote("IsDomainNameExist", "OrganizationInfo", ErrorMessage = "Domain Name is already used!", AdditionalFields = "Id")]
        public string DomainName { get; set; }
        [Required]
        [MaxLength(100)]
        [Display(Name = "Workflow Option")]
        public string WorkflowOption { get; set; }
        [Required]
        [Display(Name = "No. of Users")]
        [Range(5,9999)]
        public int NoofUsers { get; set; }
        [Required]
        [Display(Name = "Account Validity Date")]
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:dd-MMM-yyyy}", ApplyFormatInEditMode = true)]
        public DateTime AccountValidityDate { get; set; }
        [MaxLength(200)]
        [Display(Name = "Logo")]
        public string Logo { get; set; }

        [Display(Name = "Logo")]
        [DataType(DataType.Upload)]
        [MaxFileSize(2 * 1024 * 1024)]
        [AllowedExtensions(new string[] { ".jpg", ".jpeg", ".png" })]
        public IFormFile LogoFile { get; set; }

        public string LogoBase64 { get; set; }

        [MaxLength(50)]
        [Display(Name = "RGB Code")]
        public string RGBCode { get; set; }
        public int CreatedBy { get; set; }
        
        [MaxLength(100)]
        public string AppName { get; set; }
        public bool HasAdmin { get; set; }

        [Display(Name = "Base Location")]
        public string BaseLocation { get; set; }

        [Display(Name = "Geo Fencing Distance")]
        [Range(0, 4000)]
        public int GeoFencingDistance { get; set; }
    }

    public class APIId
    {
        public int Id { get; set; }
    }

    public class APIIncidentAssignmentId : APIId
    {
        public string status { get; set; }
    }

    public class APIListAndCount
    {
        public List<APIOrganizationInfo> apiOrganizationInfo { get; set; } = new List<APIOrganizationInfo>();
        public int count { get; set; }
    }

    public class APINoOfUsers
    {
        public int NoOfUsers { get; set; }
    }
}
