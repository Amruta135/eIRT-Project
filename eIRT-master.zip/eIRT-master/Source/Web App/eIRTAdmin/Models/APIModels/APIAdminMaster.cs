﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Mvc;

namespace eIRTAdmin.Models.APIModels
{
    public class APIAdminMaster
    {
        public Guid? GuId { get; set; }
        public int Id { get; set; }

        [Required(AllowEmptyStrings =false)]
        [StringLength(100, ErrorMessage = "The {0} must be at least {2} and maximum {1} characters long.", MinimumLength = 1)]
        [RegularExpression(@"^[a-zA-Z .-]+$", ErrorMessage = "Invalid Name, numbers and special charecters are not allowed!")]
        public string Name { get; set; }

        [Required(AllowEmptyStrings = false)]
        [StringLength(50, ErrorMessage = "The {0} must be at least {2} and maximum {1} characters long.", MinimumLength = 8)]
        [RegularExpression(@"^[a-zA-Z0-9_-]+$", ErrorMessage = "Use letters, numbers and special charecters like '_' and '-' only ")]
        [Remote("IsUserExist", "AdminMaster", ErrorMessage = "User id is already exist!", AdditionalFields ="GuId")]
        [Display(Name ="User ID")]
        public string UserId { get; set; }

        [Required(AllowEmptyStrings = false)]
        [RegularExpression(@"^[0-9]{10}$", ErrorMessage = "Invalid Mobile Number.")]
        [Display(Name = "Mobile Number")]
        [Remote("IsMobileNumberExist", "AdminMaster", ErrorMessage = "Mobile Number is already exist!", AdditionalFields = "GuId")]
        public string MobileNumber { get; set; }

        [Required(AllowEmptyStrings = false)]
        //[StringLength(10, ErrorMessage = "The {0} must be {2} characters long.", MinimumLength = 1)]
        [RegularExpression("Coordinator|Admin", ErrorMessage = "The {0} should be Admin or Coordinator")]
        public string Role { get; set; } = "Coordinator";      

        [Required]
        public string Language { get; set; }

        [Required(AllowEmptyStrings = false)]
        [StringLength(10, ErrorMessage = "The {0} should be active or inactive", MinimumLength = 1)]
        [RegularExpression("active|inactive", ErrorMessage = "The {0} should be active or inactive")]
        public string Status { get; set; } = "active";  // Values for this field are Active / Inactive 

        [Required(AllowEmptyStrings = false)]
        [RegularExpression(@"^(?=.*[0-9]+.*)(?=.*[a-zA-Z]+.*)[0-9a-zA-Z*@_-]{8,12}$", ErrorMessage = "Password length should be minimum 8 and it should have minimum 1 character and 1 number!")]
        //[DataType(DataType.Password)]
        [Display(Name = "Onetime Password")]
        public string OTP { get; set; }

        [Display(Name = "Is First Login")]
        public bool IsFirstLogin { get; set; } = true;  //  if it is first time login then value will be true else false 

        [Display(Name = "First Login Date")]
        public DateTime FirstLoginDate { get; set; }

        [Display(Name = "Created By")]
        public int CreatedBy { get; set; }

        [Display(Name = "Created By")]
        public string CreatedByName { get; set; }

        [Display(Name = "Created Date")]
        [DataType(DataType.Date)]
        [DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:dd MMM yyyy}")]
        public DateTime CreatedDate { get; set; }

        [Display(Name = "Modified By")]
        public int ModifiedBy { get; set; }

        [Display(Name = "Modified By")]
        public string ModifiedByName { get; set; }

        [Display(Name = "Modified Date")]
        [DataType(DataType.Date)]
        [DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:dd MMM yyyy}")]
        public DateTime ModifiedDate { get; set; }

        [Display(Name = "Is Deleted")]
        public bool IsDeleted { get; set; } = false;
    }
}
