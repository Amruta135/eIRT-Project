﻿using Microsoft.AspNetCore.Mvc;
using System.ComponentModel.DataAnnotations;

namespace eIRTAdmin.Models.APIModels
{
    public class APIUserMobile
    {
        [Required]
        [StringLength(10, ErrorMessage = "The {0} must be {2} characters long.", MinimumLength = 10)]
        public string MobileNumber { get; set; }

        [Required]
        [Remote("IsBusinessLineExist", "BillerInformation", HttpMethod = "Post", ErrorMessage = "Business Line is already used!", AdditionalFields = "Id")]
        public int BusinessLineId { get; set; }
    }
}
