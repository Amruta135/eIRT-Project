﻿using Microsoft.CodeAnalysis.CSharp.Syntax;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace eIRTAdmin.Models
{
    public class LoggedInUser
    {
        public Guid GuId { get; set; }

        public string Name { get; set; }

        public string Language { get; set; }

        public string MobileNumber { get; set; }

        public string UserId { get; set; }

        public string Role { get; set; }

        public string Status { get; set; }

        public bool IsFirstLogin { get; set; }
        public DateTime FirstLoginDate { get; set; }

        public string Token { get; set; }

        public string ProfilePicUrl { get; set; }
    }
}
