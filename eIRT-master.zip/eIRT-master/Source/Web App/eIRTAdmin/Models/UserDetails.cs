﻿using System;

namespace eIRTAdmin.Models
{
    public class UserDetails
    {
        public Guid DisplayGuId { get; set; }
        public Guid GuId { get; set; }
        public string Name { get; set; }
        public string MobileNumber { get; set; }
        public string UserId { get; set; }
        public string Role { get; set; }
        public string Status { get; set; }
        public string LastLoggedInTime { get; set; }
        public string UserProfilePic { get; set; }
        public string UserProfileBase64 { get; set; }
        public bool IsUserProfileExists { get; set; }
        public bool IsSystemStandardDataExists { get; set; }
        public bool AllowToLogin { get; set; }
        public bool IsFirstLogin { get; set; }
        public string DomainName { get; set; }
        public string DeliveryModel { get; set; }
        public string Organization { get; set; }
        public string AppName { get; set; }
        public string RGBCode { get; set; }
    }
}
