﻿namespace eIRTAdmin.Helper
{
    public static class CacheKeys
    {
        public static string ConfigurableValues { get { return "_ConfigurableValues"; } }
        public static string LocalizationOfFunction { get { return "_LocalizationOfFunction"; } }
        public static string BusinessTerminology { get { return "_BusinessTerminology"; } }
        public static string ConfigurableParameters { get { return "_ConfigurableParameters"; } }
    }
}
