﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Threading.Tasks;

namespace eIRTAdmin.Helper
{
    public class Enums
    {
        public enum UserRoles
        {
            [Description("Admin")]
            Admin,
            [Description("Coordinator")]
            Coordinator,
            [Description("User")]
            User,
            [Description("All Users")]
            ALL
        }

        public enum FunctionGroups
        {
            [Description("Admin Functions")]
            AdminFunctions,
            [Description("Common Functions")]
            CommonFunctions,
            [Description("Biller Functions")]
            BillerFunctions,
            [Description("Buyer Functions")]
            BuyerFunctions
        }

        public enum Accessibility
        {
            [Description("Admin")]
            Admin,
            [Description("Coordinator")]
            Coordinator,
            [Description("User")]
            User
        }

        public enum DaysInEN
        {
            [Description("Monday")]
            Mon = 1,
            [Description("Tuesday")]
            Tue = 2,
            [Description("Wednesday")]
            Wed = 3,
            [Description("Thursday")]
            Thu = 4,
            [Description("Friday")]
            Fri = 5,
            [Description("Saturday")]
            Sat = 6,
            [Description("Sunday")]
            Sun = 7
        }

        public enum DaysInENNew
        {
            [Description("Monday")]
            Mon = 1,
            [Description("Tuesday")]
            Tue = 2,
            [Description("Wednesday")]
            Wed = 3,
            [Description("Thursday")]
            Thu = 4,
            [Description("Friday")]
            Fri = 5,
            [Description("Saturday")]
            Sat = 6,
            [Description("Sunday")]
            Sun = 7
        }

        public enum States
        {
            [Description("Andaman & Nicobar Islands")]
            AndamanAndNicobarIslands,
            [Description("Andhra Pradesh")]
            AndhraPradesh,
            [Description("Arunachal Pradesh")]
            ArunachalPradesh,
            [Description("Assam")]
            Assam,
            [Description("Bihar")]
            Bihar,
            [Description("Chandigarh")]
            Chandigarh,
            [Description("Chhattisgarh")]
            Chhattisgarh,
            [Description("Dadra & Nagar Haveli & Daman & Diu")]
            DadraAndNagarHaveliAndDamanAndDiu,
            [Description("Delhi")]
            Delhi,
            [Description("Goa")]
            Goa,
            [Description("Gujarat")]
            Gujarat,
            [Description("Haryana")]
            Haryana,
            [Description("Himachal Pradesh")]
            HimachalPradesh,
            [Description("Jammu & Kashmir")]
            JammuAndKashmir,
            [Description("Jharkhand")]
            Jharkhand,
            [Description("Karnataka")]
            Karnataka,
            [Description("Kerala")]
            Kerala,
            [Description("Ladakh")]
            Ladakh,
            [Description("Lakshadweep")]
            Lakshadweep,
            [Description("Madhya Pradesh")]
            MadhyaPradesh,
            [Description("Maharashtra")]
            Maharashtra,
            [Description("Manipur")]
            Manipur,
            [Description("Meghalaya")]
            Meghalaya,
            [Description("Mizoram")]
            Mizoram,
            [Description("Nagaland")]
            Nagaland,
            [Description("Odisha")]
            Odisha,
            [Description("Puducherry")]
            Puducherry,
            [Description("Punjab")]
            Punjab,
            [Description("Rajasthan")]
            Rajasthan,
            [Description("Sikkim")]
            Sikkim,
            [Description("Tamil Nadu")]
            TamilNadu,
            [Description("Telangana")]
            Telangana,
            [Description("Tripura")]
            Tripura,
            [Description("Uttar Pradesh")]
            UttarPradesh,
            [Description("Uttarakhand")]
            Uttarakhand,
            [Description("West Bengal")]
            WestBengal
        }

    }
}
