﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace eIRTAdmin.Helper
{
    public static class APIHelper
    {
        public static async Task<HttpResponseMessage> CallAPI(string url, JObject oJsonObject, string token = null)
        {
            using (HttpClient client = new HttpClient())
            {
                //if (token != null)
                //{
                //    token = token.Replace("Bearer ", "");
                //    client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
                //}
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                string apiUrl = url;
                HttpResponseMessage response = await client.PostAsync(url, new StringContent(oJsonObject.ToString(), Encoding.UTF8, "application/json"));
                return response;
            }

        }
    }
}
