﻿using System.Collections.Generic;
using System.ComponentModel;

namespace eIRTAdmin.Helper
{
    public class Role
    {
        public const string Posiview_Admin = "Posiview Admin";
        public const string IRT_Client_Admin = "IRT Client Admin";
        public const string EHS_Monitor = "EHS Monitor";
        public const string EHS_Manager = "EHS Manager";
        public const string EHS_Inspector = "EHS Inspector";
    }

    public class RoleCode
    {
        public const string Posiview_Admin = "PA";
        public const string IRT_Client_Admin = "CA";
        public const string EHS_Monitor = "EO";
        public const string EHS_Manager = "EM";
        public const string EHS_Inspector = "EI";
    }

    public class IncidentReportingStatus
    {
        public const string Draft = "Draft";
        public const string Reported = "Reported";
        public const string Cancelled = "Cancelled";
        public const string WorkInProgress = "Work In Progress";
        public const string Closed = "Closed";
        public const string Assigned = "Assigned";
    }

    public class IncidentCategoryCode
    {
        public const string High = "High";
        public const string Medium = "Medium";
        public const string Low = "Low";
    }

    public class Status
    {
        public const string Active = "active";
        public const string Inactive = "inactive";
    }

    public class LanguageCodes
    {
        public const string English = "en";
        public const string Hindi = "hi";
        public const string Marathi = "mr";
        public const string Kannada = "kn";
        public const string Gujarati = "gu";
        public const string Telugu = "te";
    }

    public class VersionReleaseType
    {
        public const string Minor = "Minor";
        public const string Major = "Major";
    }


    //public class Role
    //{
    //    public const string PA = "PA";
    //    public const string CA = "CA";
    //    public const string EM = "EM";
    //    public const string EI = "EI";
    //    public const string EO = "EO";
    //}

    public class ErrorMessage
    {
        public const string saved = "Record saved.";
        public const string Fail = "Failed to save.";
        public const string Deleted = "Deleted!";
        public const string NotFound = "Record not found!";
        public const string Duplicate = "Already exist!";
        public const string InvalidData = "Invalid data!";
        public const string InvalidFile = "Invalid file formate!";
        public const string ServerError = "Server Error!";
        public const string Unauthorized = "Access Restricted!";
        public const string MaxLimitReached = "Max limit reach!";
        public const string StartDateCheck = "Start Date should not less than End Date";
    }
}
