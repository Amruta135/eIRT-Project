﻿using eIRTAdmin.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;

namespace eIRTAdmin.Infrastructure
{
    public class SMBUserClaimsPrincipalFactory : UserClaimsPrincipalFactory<LoggedInUser>
    {
        public SMBUserClaimsPrincipalFactory(
        UserManager<LoggedInUser> userManager,
        IOptions<IdentityOptions> optionsAccessor)
            : base(userManager, optionsAccessor)
        {
        }
            protected override async Task<ClaimsIdentity> GenerateClaimsAsync(LoggedInUser user)
        {
            var identity = await base.GenerateClaimsAsync(user);
            identity.AddClaim(new Claim("User_Guid", user.GuId.ToString()));
            identity.AddClaim(new Claim("User_Satus", user.Status ?? ""));
            identity.AddClaim(new Claim("UserId", user.UserId ?? ""));
            identity.AddClaim(new Claim("IsFirstLogin", user.IsFirstLogin == true ? "true" : "false"));
            identity.AddClaim(new Claim("FirstLoginDate", user.FirstLoginDate != DateTime.MinValue ? user.FirstLoginDate.ToString("dd-MMM-yyyy") : ""));
            identity.AddClaim(new Claim("UserPicUrl", user.ProfilePicUrl));
            identity.AddClaim(new Claim("Access_Token", user.Token));
            return identity;
        }
    }
}
    

