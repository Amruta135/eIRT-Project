﻿using eSMBAdmin.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;

namespace eSMBAdmin.Infrastructure
{
    public class AppUserClaimsIdentityFactory : UserClaimsPrincipalFactory<LoggedInUser>
    {
        //UserManager<LoggedInUser> _userManager;
        public AppUserClaimsIdentityFactory(UserManager<LoggedInUser> userManager,
            IOptions<IdentityOptions> optionsAccessor) : base(userManager, optionsAccessor)
        { }

        public async override Task<ClaimsPrincipal> CreateAsync(LoggedInUser user)
        {
            var principal = await base.CreateAsync(user);
            
                ((ClaimsIdentity)principal.Identity).AddClaims(new[] {
                new Claim("IsDeveloper", "true"),
                new Claim("User_Guid", user.GuId.ToString()),
                new Claim("User_Satus", user.Status ?? ""),
                new Claim("UserId", user.UserId ?? ""),
                new Claim("IsFirstLogin", user.IsFirstLogin == true ? "true" : "false"),
                new Claim("FirstLoginDate", user.FirstLoginDate != DateTime.MinValue ? user.FirstLoginDate.ToString("dd-MMM-yyyy") : ""),
                new Claim("UserPicUrl", user.ProfilePicUrl),
                new Claim("Access_Token", user.Token)
        });
            
            return principal;
        }
    }
}
