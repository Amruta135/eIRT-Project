﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Threading.Tasks;

namespace eIRTAdmin.Infrastructure
{
    public class API
    {
        public static class UserIdentity
        {
            public static string GetToken(string baseUrl) => $"{baseUrl}/connect/token";
        }

        public static class UserDetails
        {
            public static string GetUserDetails(string baseUrl) => $"{baseUrl}/UserMaster/GetUserDetails";
            public static string GetUserProfilePic(string baseUrl) => $"{baseUrl}/UserMaster/GetUserProfileBase64";
        }

        #region Admin

        public static class State
        {
            public static string GetStates(string baseUri) => $"{baseUri}/State";
            public static string GetStatesByLanguage(string baseUri, string language) => $"{baseUri}/State/GetStatesByLanguage/{language}";
        }

        public static class Status
        {
            public static string GetStatus(string baseUri) => $"{baseUri}/Status";
            public static string GetStatusByLanguage(string baseUri, string language) => $"{baseUri}/Status/GetStatusByLanguage/{language}";
        }

        public static class ConfigurableValues
        {
            public static string GetConfigurableValues(string baseUri) => $"{baseUri}/ConfigurableValues"; 
            public static string GetTypeName(string baseUri)=> $"{baseUri}/ConfigurableValues/GetTypeName";            
            public static string GetConfigurableValuesList(string baseUri, int page = 1, int pageSize = 10, string filter = null, string search = null)
            {
                if (filter == null || filter == "")
                    return $"{baseUri}/ConfigurableValues/GetConfigurableValuesList/{page}/{pageSize}/";
                return $"{baseUri}/ConfigurableValues/GetConfigurableValuesList/{page}/{pageSize}/{filter}/{search}";
            }
            public static string GetConfigurableValuesCount(string baseUri, string filter = null, string search = null)
            {
                if (filter == null || filter == "")
                    return $"{baseUri}/ConfigurableValues/GetConfigurableValuesListCount/";
                return $"{baseUri}/ConfigurableValues/GetConfigurableValuesListCount/{filter}/{search}";
            }            
            public static string GetConfigurableValue(string baseUri, int Id) => $"{baseUri}/ConfigurableValues/{Id}"; 
            public static string UpdateConfigurableValue(string baseUri, int Id) => $"{baseUri}/ConfigurableValues/{Id}";
        }

        public static class Pincode1
        {
            public static string GetStateByPincode(string baseUri, string pincode) => $"{baseUri}/PinCodes/{pincode}";
        }
        public static class AppLanguage
        {
            public static string GetAppLanguage(string baseUri, int languageId) => $"{baseUri}/applicationlanguage/{languageId}";
            public static string GetAppLanguages(string baseUri) => $"{baseUri}/applicationlanguage/GetActiveApplicationLanguages";
            public static string UpdateLanguage(string baseUri, int languageId) => $"{baseUri}/applicationlanguage/{languageId}";
            public static string AddAppLanguage(string baseUri) => $"{baseUri}/applicationlanguage";
            public static string GetAllAppLanguages(string baseUri) => $"{baseUri}/applicationlanguage/GetAllApplicationLanguages";
            public static string GetRegionalAppLanguages(string baseUri) => $"{baseUri}/applicationlanguage/GetActiveRegionalApplicationLanguages";

        }

        public static class AdminMaster
        {
            public static string GetAdminUser(string baseUri, Guid guId) => $"{baseUri}/AdminMaster/{guId}";
            public static string GetAdminUsers(string baseUri) => $"{baseUri}/AdminMaster";
            public static string GetAdminUsers(string baseUri, int page = 1, int pageSize = 10, string filter = null, string search = null)
            {
                if (filter == null || filter == "")
                    return $"{baseUri}/AdminMaster/GetAdminUsers/{page}/{pageSize}/";
                return $"{baseUri}/AdminMaster/GetAdminUsers/{page}/{pageSize}/{filter}/{search}";
            }

            public static string GetAdminUsersCount(string baseUri, string filter = null, string search = null)
            {
                if (filter == null || filter == "")
                    return $"{baseUri}/AdminMaster/GetUsersCount/";
                return $"{baseUri}/AdminMaster/GetUsersCount/{filter}/{search}";
            }
            public static string ExportXlsxAdminUsers(string baseUri, string filter = null, string search = null)
            {
                if (filter == null || filter == "")
                    return $"{baseUri}/AdminMaster/ExportXlsx/";
                return $"{baseUri}/AdminMaster/ExportXlsx?filter={filter}&search={search}";
            }

            public static string GetActiveAdminUsers(string baseUri) => $"{baseUri}/AdminMaster/GetActiveAdminMasters";
            public static string UpdateAdminUsers(string baseUri, Guid guId) => $"{baseUri}/AdminMaster/UpdateAdminMaster/{guId}";
            public static string AddAdminUsers(string baseUri) => $"{baseUri}/AdminMaster";
            public static string DeleteAdminUsers(string baseUri, Guid guId) => $"{baseUri}/AdminMaster/{guId}";
            public static string IsExist(string baseUri, string FieldName, string value) => $"{baseUri}/AdminMaster/IsExistAsync?FieldName={FieldName}&Value={value}";
            public static string GetAllUsersByRole(string baseUri, string role) => $"{baseUri}/AdminMaster/GetAllUsersByRole/{role}";
            public static string ExportPDF(string baseUri, string filter = null, string search = null)
            {
                if (filter == null || filter == "")
                    return $"{baseUri}/AdminMaster/ExportPDF/";
                return $"{baseUri}/AdminMaster/ExportPDF?filter={filter}&search={search}";
            }
        }

        public static class UserMaster
        {
            public static string GetUser(string baseUri, int id) => $"{baseUri}/UserMaster/{id}";
            public static string GetUsersForPAAsync(string baseUri) => $"{baseUri}/UserMaster/GetUsersForPA";
            public static string GetUsersForCAAsync(string baseUri) => $"{baseUri}/UserMaster/GetUsersForCA";
            public static string GetUsers(string baseUri, int page = 1, int pageSize = 10, string filter = null, string search = null)
            {
                if (filter == null || filter == "")
                    return $"{baseUri}/UserMaster/GetUsers/{page}/{pageSize}/";
                return $"{baseUri}/UserMaster/GetUsers/{page}/{pageSize}/{filter}/{search}";
            }

            public static string GetUsersCount(string baseUri, string filter = null, string search = null)
            {
                if (filter == null || filter == "")
                    return $"{baseUri}/UserMaster/GetUsersCount/";
                return $"{baseUri}/UserMaster/GetUsersCount/{filter}/{search}";
            }
            public static string ExportXlsxUsers(string baseUri, string filter = null, string search = null)
            {
                if (filter == null || filter == "")
                    return $"{baseUri}/UserMaster/ExportXlsx/";
                return $"{baseUri}/UserMaster/ExportXlsx?filter={filter}&search={search}";
            }

            //public static string GetActiveUsers(string baseUri) => $"{baseUri}/UserMaster/GetActiveAdminMasters";

            public static string GetUsersOtp(string baseUri, Guid guId) => $"{baseUri}/UserMaster/GetUserOTP/{guId}";
            public static string ValidateUsersOtp(string baseUri) => $"{baseUri}/UserMaster/ValidateUserOtp";
            public static string UpdateUsers(string baseUri, Guid guId) => $"{baseUri}/UserMaster/{guId}";
            public static string UserSignUp(string baseUri) => $"{baseUri}/UserMaster";
            public static string ResendUserOTP(string baseUri, Guid guId) => $"{baseUri}/UserMaster/ResendUserOTP/{guId}";
            public static string SetUserPassword(string baseUri, Guid guId) => $"{baseUri}/UserMaster/SetUserPassword/{guId}";
            public static string ChangeUserPassword(string baseUri) => $"{baseUri}/UserMaster/ChangeUserPassword";
            public static string DeleteUser(string baseUri, Guid guId) => $"{baseUri}/UserMaster/{guId}";
            public static string IsExist(string baseUri, string FieldName, string value) => $"{baseUri}/UserMaster/IsExistAsync?FieldName={FieldName}&Value={value}";
            public static string UserLogOut(string baseUri) => $"{baseUri}/UserMaster/UserLogout";
            public static string GetUserInfoByMobileNumber(string baseUri) => $"{baseUri}/UserMaster/GetUserInfoByMobileNumber";
            public static string GetBillerInfoByBillerId(string baseUri) => $"{baseUri}/UserMaster/GetBillerInfoByBillerId";
            public static string ChangeUserAppMenu(string baseUri, Guid guId) => $"{baseUri}/UserMaster/ChangeUserAppMenu/{guId}";
            public static string GetUserInfoForMyBusiness(string baseUri) => $"{baseUri}/UserMaster/GetUserInfoForMyBusiness";
            
            public static string AddUserDetailsForPA(string baseUri) => $"{baseUri}/UserMaster/PostUserProfileDetails";
            public static string UpdateUserProfilePic(string baseUri) => $"{baseUri}/UserMaster/PutProfilePicture";
            public static string AddUserDetailsForCA(string baseUri) => $"{baseUri}/UserMaster/PostUserProfileDetails";
            public static string UpdateUserDetailsForPA(string baseUri, int id) => $"{baseUri}/UserMaster/{id}";
            public static string UpdateUserDetailsForCA(string baseUri, int id) => $"{baseUri}/UserMaster/{id}";
            public static string DeleteUserDetails(string baseUri, int  id) => $"{baseUri}/UserMaster/{id}";
            public static string GetActiveUsersCount(string baseUri) => $"{baseUri}/UserMaster/GetActiveUsersCount"; 
            public static string IsExist(string baseUri) => $"{baseUri}/UserMaster/IsExist";
            public static string GetUserProfile(string baseUri, int Id) => $"{baseUri}/UserMaster/GetUserProfileDetails/{Id}";
            public static string GetUserProfile(string baseUri) => $"{baseUri}/UserMaster/GetUserProfileDetails";
            public static string UpdateUserProfile(string baseUri, int Id) => $"{baseUri}/UserMaster/PutUserProfileDetails/{Id}";
            public static string AddUserProfile(string baseUri) => $"{baseUri}/UserMaster";
            public static string GetUserProfilePic(string baseUrl) => $"{baseUrl}/UserMaster/GetUserProfileBase64";
            public static string GetUserSecurityQuestion(string baseUri) => $"{baseUri}/UserMaster/GetUserSecurityQuestion";
            public static string ForgotPassword(string baseUri) => $"{baseUri}/UserMaster/ForgotPassword";
        }

        public static class LoginAssistance
        {
            public static string ForgotPassword(string baseUri) => $"{baseUri}/UserMaster/ForgotPassword";
            public static string ForgotPasswordUpdate(string baseUri) => $"{baseUri}/UserMaster/ForgotPasswordUpdate";
        }

        public static class UserProfile
        {
            public static string GetUserProfile(string baseUri, int Id) => $"{baseUri}/UserProfile/{Id}";
            public static string GetUserProfileByGuId(string baseUri, Guid GuId) => $"{baseUri}/UserProfile/GetUserProfileDetailsByGuId/{GuId}";
            public static string GetUserProfile(string baseUri) => $"{baseUri}/UserProfile";
            public static string UpdateUserProfile(string baseUri, int Id) => $"{baseUri}/UserProfile/{Id}";
            public static string UpdateUserProfilePic(string baseUri) => $"{baseUri}/UserProfile/PutProfilePicture";
            public static string AddUserProfile(string baseUri) => $"{baseUri}/UserProfile";
            public static string DeleteUserProfile(string baseUri, int Id) => $"{baseUri}/UserProfile/{Id}";
            //public static string IsExist(string baseUri, string FieldName, string value) => $"{baseUri}/UserProfile/IsExistAsync?FieldName={FieldName}&Value={value}";
        }

        public static class UPIPSPBankInformation
        {
            public static string GetBankInfo(string baseUri, int Id) => $"{baseUri}/UPIPSPBankInformation/{Id}";
            public static string GetBankInfoByName(string baseUri, string Name) => $"{baseUri}/UPIPSPBankInformation?name={Name}";
            public static string GetBanksInfo(string baseUri) => $"{baseUri}/UPIPSPBankInformation/GetAll";
            public static string UpdateBanksInfo(string baseUri, int Id) => $"{baseUri}/UPIPSPBankInformation/{Id}";
            public static string UpdateBanksIcon(string baseUri) => $"{baseUri}/UPIPSPBankInformation/PutBankIcon";
            public static string AddBankInfo(string baseUri) => $"{baseUri}/UPIPSPBankInformation";
            public static string DeleteBankInfo(string baseUri, int Id) => $"{baseUri}/UPIPSPBankInformation/{Id}";
            public static string IsExist(string baseUri, string FieldName, string value) => $"{baseUri}/UPIPSPBankInformation/IsExistAsync?FieldName={FieldName}&Value={value}";

            public static string GetBankInfoCount(string baseUri, string filter = null, string search = null)
            {
                if (filter == null || filter == "")
                    return $"{baseUri}/UPIPSPBankInformation/GetUPIPSPBankInformationsCount/";
                return $"{baseUri}/UPIPSPBankInformation/GetUPIPSPBankInformationsCount/{filter}/{search}";
            }

            public static string GetBanksInfo(string baseUri, int page = 1, int pageSize = 10, string filter = null, string search = null)
            {
                if (filter == null || filter == "")
                    return $"{baseUri}/UPIPSPBankInformation/GetUPIPSPBankInformations/{page}/{pageSize}/";
                return $"{baseUri}/UPIPSPBankInformation/GetUPIPSPBankInformations/{page}/{pageSize}/{filter}/{search}";
            }
        }

        public static class LocalizationofBankNameInfo
        {
            public static string GetLocalizationofBankNameInfo(string baseUri, int Id) => $"{baseUri}/LocalizationofBankNameInformation/{Id}";
            //public static string GetLocalizationofBankNameInfoByName(string baseUri, string Name) => $"{baseUri}/LocalizationofBankNameInformation?name={Name}";
            public static string GetLocalizationofBanksNameInfo(string baseUri) => $"{baseUri}/LocalizationofBankNameInformation/GetAll";
            public static string GetLanguageForUPIPSPBank(string baseUri, int BankId) => $"{baseUri}/LocalizationofBankNameInformation/GetLanguageForUPIPSPBank/{BankId}";
            public static string UpdateLocalizationofBankNameInfo(string baseUri, int Id) => $"{baseUri}/LocalizationofBankNameInformation/{Id}";
            public static string AddLocalizationofBankNameInfo(string baseUri) => $"{baseUri}/LocalizationofBankNameInformation";
            public static string DeleteLocalizationofBankNameInfo(string baseUri, int Id) => $"{baseUri}/LocalizationofBankNameInformation/{Id}";
            public static string IsExist(string baseUri, string FieldName, string value, int BankId) => $"{baseUri}/LocalizationofBankNameInformation/IsExistAsync?FieldName={FieldName}&Value={value}&BankId={BankId}";
            public static string SearchLocalizationofBankNameInfo(string baseUri) => $"{baseUri}/LocalizationofBankNameInformation/GetLocalizationofBankNameInformations";
            public static string CountLocalizationofBankNameInfo(string baseUri) => $"{baseUri}/LocalizationofBankNameInformation/GetLocalizationofBankNameInformationsCount";
        }

        public static class CompanyInformation
        {
            public static string GetCompanyInfo(string baseUri, int Id) => $"{baseUri}/CompanyInformation/{Id}";
            public static string GetCompanyInfo(string baseUri, String code) => $"{baseUri}/CompanyInformation?code={code}";
            public static string GetCompanyInfo(string baseUri) => $"{baseUri}/CompanyInformation/GetAll";
            public static string UpdateCompanyInfo(string baseUri, int Id) => $"{baseUri}/CompanyInformation/{Id}";
            public static string AddCompanyInfo(string baseUri) => $"{baseUri}/CompanyInformation";
            public static string DeleteCompanyInfo(string baseUri, int Id) => $"{baseUri}/CompanyInformation/{Id}";
            public static string IsExist(string baseUri, string FieldName, string value) => $"{baseUri}/CompanyInformation/IsExistAsync?FieldName={FieldName}&Value={value}";
        }

        public static class AccountAndTaxInformation
        {
            public static string GetAccountAndTaxInfo(string baseUri, int Id) => $"{baseUri}/AccountAndTaxInformation/{Id}";
            public static string GetAccountsAndTaxInfo(string baseUri) => $"{baseUri}/AccountAndTaxInformation/GetAll";
            public static string UpdateAccountAndTaxInfo(string baseUri, int Id) => $"{baseUri}/AccountAndTaxInformation/{Id}";
            public static string AddAccountAndTaxInfo(string baseUri) => $"{baseUri}/AccountAndTaxInformation";
            //public static string DeleteAccountAndTaxInfo(string baseUri, int Id) => $"{baseUri}/AccountAndTaxInformation/{Id}";
            //public static string IsExist(string baseUri, string FieldName, string value) => $"{baseUri}/AccountAndTaxInformation/IsExistAsync?FieldName={FieldName}&Value={value}";
        }

        public static class VersionManagementInformation
        {
            public static string GetVersionManagementInformation(string baseUri, int Id) => $"{baseUri}/VersionManagementInformation/{Id}";
            public static string GetVersionManagementInformation(string baseUri) => $"{baseUri}/VersionManagementInformation/GetAll";
            public static string UpdateVersionManagementInformation(string baseUri, int Id) => $"{baseUri}/VersionManagementInformation/{Id}";
            public static string UpdateVersionReleaseNoteDoc(string baseUri) => $"{baseUri}/VersionManagementInformation/PutVersionReleaseNote";
            public static string AddVersionManagementInformation(string baseUri) => $"{baseUri}/VersionManagementInformation";
            public static string DeleteVersionManagementInformation(string baseUri, int Id) => $"{baseUri}/VersionManagementInformation/{Id}";
            public static string IsExist(string baseUri, string FieldName, string value) => $"{baseUri}/VersionManagementInformation/IsExistAsync?FieldName={FieldName}&Value={value}";

            public static string GetVersionManagementInfoCount(string baseUri, string releaseType = null, string filter = null, string search = null)
            {
                if (filter == null || filter == "" || search == null || search == "")
                    return $"{baseUri}/VersionManagementInformation/GetVersionManagementInformationsCount/";
                return $"{baseUri}/VersionManagementInformation/GetVersionManagementInformationsCount/{releaseType}/{filter}/{search}";
            }

            public static string GetVersionManagementInformations(string baseUri, int page = 1, int pageSize = 10, string releaseType = null, string filter = null, string search = null)
            {
                if (filter == null || filter == "" || search == null || search == "")
                    return $"{baseUri}/VersionManagementInformation/GetVersionManagementInformations/{page}/{pageSize}/{releaseType}";
                return $"{baseUri}/VersionManagementInformation/GetVersionManagementInformations/{page}/{pageSize}/{releaseType}/{filter}/{search}";
            }
            public static string GetReleaseNoteDocument(string baseUri, int Id) => $"{baseUri}/VersionManagementInformation/GetReleaseNoteDocument/{Id}";
        }

        public static class ProductInformation
        {
            public static string GetProductInfo(string baseUri, int Id) => $"{baseUri}/ProductInformation/{Id}";
            public static string GetProductInfo(string baseUri, String code) => $"{baseUri}/ProductInformation?code={code}";
            public static string GetProductInfo(string baseUri) => $"{baseUri}/ProductInformation/GetAll";
            public static string UpdateProductInfo(string baseUri, int Id) => $"{baseUri}/ProductInformation/{Id}";
            public static string UpdateProductImage(string baseUri) => $"{baseUri}/ProductInformation/PutProductImage";
            public static string AddProductInfo(string baseUri) => $"{baseUri}/ProductInformation";
            public static string DeleteProductInfo(string baseUri, int Id) => $"{baseUri}/ProductInformation/{Id}";
            public static string IsExist(string baseUri, string FieldName, string value) => $"{baseUri}/ProductInformation/IsExistAsync?FieldName={FieldName}&Value={value}";
            public static string GetProductName(string baseUri, string language)
            {
                if (language == null)
                    return $"{baseUri}/ProductInformation/GetProductName/";
                else
                    return $"{baseUri}/ProductInformation/GetProductName?language={language}";
            }
            
        }

        public static class ProductDocumentInformation
        {
            public static string GetProductDocumentInfo(string baseUri, int Id) => $"{baseUri}/ProductDocumentInformation/{Id}";
            public static string GetProductDocumentInfo(string baseUri, String code) => $"{baseUri}/ProductDocumentInformation?code={code}";
            public static string GetProductDocumentInfo(string baseUri) => $"{baseUri}/ProductDocumentInformation/GetAll";
            public static string UpdateProductDocumentInfo(string baseUri, int Id) => $"{baseUri}/ProductDocumentInformation/{Id}";
            public static string UpdateProductDocument(string baseUri) => $"{baseUri}/ProductDocumentInformation/PutProductDocument";
            public static string AddProductDocumentInfo(string baseUri) => $"{baseUri}/ProductDocumentInformation";
            public static string DeleteProductDocumentInfo(string baseUri, int Id) => $"{baseUri}/ProductDocumentInformation/{Id}";
            public static string IsExist(string baseUri, string FieldName, string value) => $"{baseUri}/ProductDocumentInformation/IsExistAsync?FieldName={FieldName}&Value={value}";
            public static string SearchProductDocumentInfo(string baseUri) => $"{baseUri}/ProductDocumentInformation/GetProductDocumentInformations";
            public static string CountProductDocumentInfo(string baseUri) => $"{baseUri}/ProductDocumentInformation/GetProductDocumentInformationsCount";
            public static string GetProductDocument(string baseUri, int Id) => $"{baseUri}/ProductDocumentInformation/GetProductDocument/{Id}"; 
            public static string GetTermsOfService(string baseUri) => $"{baseUri}/ProductDocumentInformation/GetTermsOfService"; 
            public static string GetAboutSMB(string baseUri) => $"{baseUri}/ProductDocumentInformation/GetAboutSMB";

            public static string GetPrivacyPolicy(string baseUri) => $"{baseUri}/ProductDocumentInformation/GetPrivacyPolicy"; 
            public static string GetAboutSMBContent(string baseUri) => $"{baseUri}/ProductDocumentInformation/GetAboutSMBContent"; 
            public static string GetTermsOfServiceContent(string baseUri) => $"{baseUri}/ProductDocumentInformation/GetTermsofServiceContent"; 
            public static string GetPrivacyPolicyContent(string baseUri) => $"{baseUri}/ProductDocumentInformation/GetPrivacyPolicyContent";
        }

        public static class BusinessLine
        {
            public static string GetBusinessLine(string baseUri, int Id) => $"{baseUri}/BusinessLineMaster/{Id}";
            public static string GetBusinessLines(string baseUri) => $"{baseUri}/BusinessLineMaster/GetAll";
            public static string GetBusinessLines(string baseUri, int page = 1, int pageSize = 10, string filter = null, string search = null)
            {
                if (filter == null || filter == "")
                    return $"{baseUri}/BusinessLineMaster/GetBusinessLines/{page}/{pageSize}/";
                return $"{baseUri}/BusinessLineMaster/GetBusinessLines/{page}/{pageSize}/{filter}/{search}";
            }

            public static string GetBusinessLinesCount(string baseUri, string filter = null, string search = null)
            {
                if (filter == null || filter == "")
                    return $"{baseUri}/BusinessLineMaster/GetBusinessLinesCount/";
                return $"{baseUri}/BusinessLineMaster/GetBusinessLinesCount/{filter}/{search}";
            }
            public static string ExportXlsxBusinessLines(string baseUri, string filter = null, string search = null)
            {
                if (filter == null || filter == "")
                    return $"{baseUri}/BusinessLineMaster/ExportXlsx/";
                return $"{baseUri}/BusinessLineMaster/ExportXlsx?filter={filter}&search={search}";
            }
            public static string UpdateBusinessLine(string baseUri, int Id) => $"{baseUri}/BusinessLineMaster/{Id}";
            public static string UpdateBusinessIcon(string baseUri) => $"{baseUri}/BusinessLineMaster/PutBussubessIcon";
            public static string AddBusinessLine(string baseUri) => $"{baseUri}/BusinessLineMaster";
            public static string DeleteBusinessLine(string baseUri, int Id) => $"{baseUri}/BusinessLineMaster/{Id}";
            public static string IsExist(string baseUri, string FieldName, string value) => $"{baseUri}/BusinessLineMaster/IsExistAsync?FieldName={FieldName}&Value={value}";
            public static string GetBusinessLinesByLanguage(string baseUri) => $"{baseUri}/BusinessLineMaster/GetAllByLanguage";
        }

        public static class BusinessTerminologies
        {
            public static string GetBusinessTerminology(string baseUri, int Id) => $"{baseUri}/BusinessTerminologies/{Id}";
            public static string GetBusinessTerminologiesByBizLine(string baseUri, int BusinessLineId) => $"{baseUri}/BusinessTerminologies/GetBusinessTerminologiesByBizLine?BusinessLineId={BusinessLineId}";
            public static string GetBusinessTerminologies(string baseUri) => $"{baseUri}/BusinessTerminologies/GetAll";
            public static string UpdateBusinessTerminology(string baseUri, int Id) => $"{baseUri}/BusinessTerminologies/{Id}";
            public static string AddBusinessTerminology(string baseUri) => $"{baseUri}/BusinessTerminologies";
            public static string DeleteBusinessTerminology(string baseUri, int Id) => $"{baseUri}/BusinessTerminologies/{Id}";
            public static string IsExist(string baseUri, string FieldName, string value, int BusinessLineId) => $"{baseUri}/BusinessTerminologies/IsExistAsync?FieldName={FieldName}&Value={value}&BusinessLineId={BusinessLineId}";
            public static string GetBusinessTerminologies(string baseUri, int page = 1, int pageSize = 10, string filter = null, string search = null)
            {
                if (filter == null || filter == "")
                    return $"{baseUri}/BusinessTerminologies/GetBusinessTerminologies/{page}/{pageSize}/";
                return $"{baseUri}/BusinessTerminologies/GetBusinessTerminologies/{page}/{pageSize}/{filter}/{search}";
            }
            public static string GetBusinessTerminologiesCount(string baseUri, string filter = null, string search = null)
            {
                if (filter == null || filter == "")
                    return $"{baseUri}/BusinessTerminologies/GetBusinessTerminologiesCount/";
                return $"{baseUri}/BusinessTerminologies/GetBusinessTerminologiesCount/{filter}/{search}";
            }

            public static string GetBusinessTerminologiesSearch(string baseUri) => $"{baseUri}/BusinessTerminologies/GetBusinessTerminologiesSearch";
            public static string GetBusinessTerminologiesCount(string baseUri) => $"{baseUri}/BusinessTerminologies/GetBusinessTerminologiesCount/";
            public static string GetLanguagesForBusinessTerminology(string baseUri, int BusinessLineId) => $"{baseUri}/BusinessTerminologies/GetLanguagesForBusinessTerminology/{BusinessLineId}";
            public static string IsBusinessTerminologyExists(string baseUri, int businessLineId) => $"{baseUri}/BusinessTerminologies/IsBusinessTerminologyExists/{businessLineId}";
        }

        public static class LocalizationofBizLine
        {
            public static string GetLocalizationofBizLine(string baseUri, int Id) => $"{baseUri}/LocalizationofBizLines/{Id}";
            public static string GetLocalizationofBizLine(string baseUri, string BusinessLineId) => $"{baseUri}/LocalizationofBizLines?BusinessLineId={BusinessLineId}";
            public static string GetLocalizationofBizLine(string baseUri) => $"{baseUri}/LocalizationofBizLines/GetAll";
            public static string UpdateLocalizationofBizLine(string baseUri, int Id) => $"{baseUri}/LocalizationofBizLines/{Id}";
            public static string AddLocalizationofBizLine(string baseUri) => $"{baseUri}/LocalizationofBizLines";
            public static string DeleteLocalizationofBizLine(string baseUri, int Id) => $"{baseUri}/LocalizationofBizLines/{Id}";
            public static string IsExist(string baseUri, string FieldName, string value, int BusinessLineId) => $"{baseUri}/LocalizationofBizLines/IsExistAsync?FieldName={FieldName}&Value={value}&BusinessLineId={BusinessLineId}";
            public static string GetLocalizationofBizLines(string baseUri, int page = 1, int pageSize = 10, string filter = null, string search = null)
            {
                if (filter == null || filter == "")
                    return $"{baseUri}/LocalizationofBizLines/GetLocalizationofBusinessLines/{page}/{pageSize}/";
                return $"{baseUri}/LocalizationofBizLines/GetLocalizationofBusinessLines/{page}/{pageSize}/{filter}/{search}";
            }

            public static string GetLocalizationofBizLinesCount(string baseUri, string filter = null, string search = null)
            {
                if (filter == null || filter == "")
                    return $"{baseUri}/LocalizationofBizLines/GetLocalizationofBusinessLinesCount/";
                return $"{baseUri}/LocalizationofBizLines/GetLocalizationofBusinessLinesCount/{filter}/{search}";
            }
            public static string GetLanguagesForLocalizationofBizLine(string baseUri, int BusinessLineId) => $"{baseUri}/LocalizationofBizLines/GetLanguagesForLocalizationofBusinessLines/{BusinessLineId}";
            public static string IsLocalizationofBizLineExists(string baseUri, int businessLineId) => $"{baseUri}/LocalizationofBizLines/IsLocalizationofBizLineExists/{businessLineId}";
        }

        public static class BusinessLineSetting
        {
            public static string GetBusinessLineSetting(string baseUri, int Id) => $"{baseUri}/BusinessLineSettings/{Id}";
            public static string GetBusinessLineSettings(string baseUri) => $"{baseUri}/BusinessLineSettings/GetAll";
            public static string GetBusinessLineSettings(string baseUri, int page = 1, int pageSize = 10, string filter = null, string search = null)
            {
                if (filter == null || filter == "")
                    return $"{baseUri}/BusinessLineSettings/GetBusinessLineSettings/{page}/{pageSize}/";
                return $"{baseUri}/BusinessLineSettings/GetBusinessLineSettings/{page}/{pageSize}/{filter}/{search}";
            }

            public static string GetBusinessLineSettingCount(string baseUri, string filter = null, string search = null)
            {
                if (filter == null || filter == "")
                    return $"{baseUri}/BusinessLineSettings/GetBusinessLineSettingsCount/";
                return $"{baseUri}/BusinessLineSettings/GetBusinessLineSettingsCount/{filter}/{search}";
            }
            public static string ExportXlsxBusinessLineSettings(string baseUri, string filter = null, string search = null)
            {
                if (filter == null || filter == "")
                    return $"{baseUri}/BusinessLineSettings/ExportXlsx/";
                return $"{baseUri}/BusinessLineSettings/ExportXlsx?filter={filter}&search={search}";
            }
            public static string UpdateBusinessLineSetting(string baseUri, int Id) => $"{baseUri}/BusinessLineSettings/{Id}";
            public static string AddBusinessLineSetting(string baseUri) => $"{baseUri}/BusinessLineSettings";
            public static string DeleteBusinessLineSetting(string baseUri, int Id) => $"{baseUri}/BusinessLineSettings/{Id}";
            public static string IsExist(string baseUri, string FieldName, string value) => $"{baseUri}/BusinessLineSettings/IsExistAsync?FieldName={FieldName}&Value={value}";
            public static string IsBusinessLineSettingsExists(string baseUri, int businessLineId) => $"{baseUri}/BusinessLineSettings/IsBusinessLineSettingsExists/{businessLineId}";
        }

        public static class ConfigurableParameters
        {
            public static string GetConfigurableParameter(string baseUri, int Id) => $"{baseUri}/ConfigurableParameters/{Id}";
            public static string GetConfigurableParameter(string baseUri) => $"{baseUri}/ConfigurableParameters/GetAll";
            public static string UpdateConfigurableParameter(string baseUri, int Id) => $"{baseUri}/ConfigurableParameters/{Id}";
            public static string UpdateConfigurableParameter(string baseUri, int Id, string Value) => $"{baseUri}/ConfigurableParameters/UpdateByValue/{Id}/{Value}";

            public static string AddConfigurableParameters(string baseUri) => $"{baseUri}/ConfigurableParameters";
            public static string DeleteConfigurableParameters(string baseUri, int Id) => $"{baseUri}/ConfigurableParameters/{Id}";
        }

        public static class SystemFunctionRule
        {
            public static string GetSystemFunction(string baseUri, int Id) => $"{baseUri}/SystemFunctionsListInformation/{Id}";
            public static string GetSystemFunctions(string baseUri) => $"{baseUri}/SystemFunctionsListInformation/GetAll";
            public static string UpdateSystemFunction(string baseUri, int Id) => $"{baseUri}/SystemFunctionsListInformation/{Id}";
            public static string AddSystemFunction(string baseUri) => $"{baseUri}/SystemFunctionsListInformation";
            public static string DeleteSystemFunction(string baseUri, int Id) => $"{baseUri}/SystemFunctionsListInformation/{Id}";
            public static string IsExist(string baseUri, string FieldName, string value) => $"{baseUri}/SystemFunctionsListInformation/IsExistAsync?FieldName={FieldName}&Value={value}";
            public static string GetSystemFunctionRules(string baseUri, int page = 1, int pageSize = 10, string filter = null, string search = null)
            {
                if (filter == null || filter == "")
                    return $"{baseUri}/SystemFunctionsListInformation/GetSystemFunctionRules/{page}/{pageSize}/";
                return $"{baseUri}/SystemFunctionsListInformation/GetSystemFunctionRules/{page}/{pageSize}/{filter}/{search}";
            }
            public static string GetSystemFunctionRulesCount(string baseUri, string filter = null, string search = null)
            {
                if (filter == null || filter == "")
                    return $"{baseUri}/SystemFunctionsListInformation/GetSystemFunctionRulesCount/";
                return $"{baseUri}/SystemFunctionsListInformation/GetSystemFunctionRulesCount/{filter}/{search}";
            }
        }

        public static class LocalizationOfFunction
        {
            public static string GetLocalizationOfFunction(string baseUri, int Id) => $"{baseUri}/LocalizationOfFunctions/{Id}";
            public static string GetLocalizationOfFunctions(string baseUri, int page = 1, int pageSize = 10, string filter = null, string search = null)
            {
                if (filter == null || filter == "")
                    return $"{baseUri}/LocalizationOfFunctions/GetLocalizationOfFunctions/{page}/{pageSize}/";
                return $"{baseUri}/LocalizationOfFunctions/GetLocalizationOfFunctions/{page}/{pageSize}/{filter}/{search}";
            }
            public static string GetLocalizationOfFunctionsCount(string baseUri, string filter = null, string search = null)
            {
                if (filter == null || filter == "")
                    return $"{baseUri}/LocalizationOfFunctions/GetLocalizationOfFunctionsCount/";
                return $"{baseUri}/LocalizationOfFunctions/GetLocalizationOfFunctionsCount/{filter}/{search}";
            }
            public static string UpdateLocalizationOfFunction(string baseUri, int Id) => $"{baseUri}/LocalizationOfFunctions/{Id}";
            public static string AddLocalizationOfFunction(string baseUri) => $"{baseUri}/LocalizationOfFunctions";
            public static string DeleteLocalizationOfFunction(string baseUri, int Id) => $"{baseUri}/LocalizationOfFunctions/{Id}";
            public static string IsExist(string baseUri, string FieldName, string value, int BusinessLineId, int SystemFuctionId) => $"{baseUri}/LocalizationOfFunctions/IsExistAsync?FieldName={FieldName}&Value={value}&BusinessLineId={BusinessLineId}&SystemFuctionId={SystemFuctionId}";
            public static string GetLanguageForSystemFuction(string baseUri, int systemFunctionId, int BusinessLineId) => $"{baseUri}/LocalizationOfFunctions/GetLanguageForSystemFuction/{systemFunctionId}/{BusinessLineId}";
            public static string GetLocalizationOfFunctionsSearch(string baseUri) => $"{baseUri}/LocalizationOfFunctions/GetLocalizationOfFunctionsSearch";
            public static string GetCountsOfLocalizationOfFunctions(string baseUri) => $"{baseUri}/LocalizationOfFunctions/GetCountsOfLocalizationOfFunctions";
        }

        public static class BusinessFunctionMatrix
        {
            public static string GetBusinessFunctionMatrix(string baseUri, int Id) => $"{baseUri}/BusinessFunctionsMatrix/{Id}";
            public static string GetBusinessFunctionsMatrix(string baseUri) => $"{baseUri}/BusinessFunctionsMatrix/GetBusinessFunctionsMatrices";
            public static string GetBusinessFunctionsMatrixCount(string baseUri) => $"{baseUri}/BusinessFunctionsMatrix/GetBusinessFunctionsMatricesCount";
            public static string UpdateBusinessFunctionMatrix(string baseUri, int Id) => $"{baseUri}/BusinessFunctionsMatrix/{Id}";
            public static string AddBusinessFunctionMatrix(string baseUri) => $"{baseUri}/BusinessFunctionsMatrix";
            public static string DeleteBusinessFunctionMatrix(string baseUri, int Id) => $"{baseUri}/BusinessFunctionsMatrix/{Id}";
            public static string IsExist(string baseUri, string FieldName, string value, int? businessLineId) => $"{baseUri}/BusinessFunctionsMatrix/IsExistAsync?FieldName={FieldName}&Value={value}&BusinessLineId={businessLineId}";
            public static string IsBusinessFuctionMatixExists(string baseUri, int businessLineId) => $"{baseUri}/BusinessFunctionsMatrix/IsBusinessFuctionMatixExists/{businessLineId}";
            public static string GetBusinessFunctionsMatricesSettings(string baseUri, int businessLineId) => $"{baseUri}/BusinessFunctionsMatrix/GetBusinessFunctionsMatricesSettings/{businessLineId}";
        }

        public static class BrandingManagementInformation
        {
            public static string GetBrandingManagementInfo(string baseUri) => $"{baseUri}/BrandingManagementInformation/GetAll";
            public static string UpdateBrandingCompanyLogo(string baseUri) => $"{baseUri}/BrandingManagementInformation/PutCompanyLogo";
            public static string UpdateBrandingProductLogo(string baseUri) => $"{baseUri}/BrandingManagementInformation/PutProductLogo";
        }

        public static class CoordinatorMapping
        {
            public static string GetCoordinatorMapping(string baseUri, int Id) => $"{baseUri}/CoordinatorMapping/{Id}";
            public static string GetCoordinatorMapping(string baseUri, int page = 1, int pageSize = 10, string filter = null, string search = null)
            {
                if (filter == null || filter == "")
                    return $"{baseUri}/CoordinatorMapping/GetCoordinatorMappings/{page}/{pageSize}/";
                return $"{baseUri}/CoordinatorMapping/GetCoordinatorMappings/{page}/{pageSize}/{filter}/{search}";
            }
            public static string GetCoordinatorMappingCount(string baseUri, string filter = null, string search = null)
            {
                if (filter == null || filter == "")
                    return $"{baseUri}/CoordinatorMapping/GetCoordinatorMappingsCount/";
                return $"{baseUri}/CoordinatorMapping/GetCoordinatorMappingsCount/{filter}/{search}";
            }
            public static string UpdateCoordinatorMapping(string baseUri, int Id) => $"{baseUri}/CoordinatorMapping/{Id}";
            public static string AddCoordinatorMapping(string baseUri) => $"{baseUri}/CoordinatorMapping";
            public static string DeleteCoordinatorMapping(string baseUri, int Id) => $"{baseUri}/CoordinatorMapping/{Id}";
            public static string IsExist(string baseUri, string FieldName, int BusinessLineId, Guid BillerId) => $"{baseUri}/CoordinatorMapping/IsExistAsync?FieldName={FieldName}&BusinessLineId={BusinessLineId}&BillerId={BillerId}";
            public static string GetAverageBillersPerCoordinator(string baseUri, Guid GuId) => $"{baseUri}/CoordinatorMapping/GetAverageBillersPerCoordinator/{GuId}";
            public static string GetBillersByBusinessLine(string baseUri, int businessLineId, int coordinatorMappingId, string langCode) => $"{baseUri}/CoordinatorMapping/GetBillersByBusinessLine/{businessLineId}/{coordinatorMappingId}/{langCode}"; 
            public static string IsBillerAttached(string baseUri, string FieldName, string value) => $"{baseUri}/CoordinatorMapping/IsBillerAttached?FieldName={FieldName}&Value={value}";

        }

        public static class BillerIncentiveRules
        {
            public static string GetBillerIncentiveRules(string baseUri, int Id) => $"{baseUri}/BillerIncentiveRules/{Id}";
            public static string GetBillerIncentiveRules(string baseUri, int page = 1, int pageSize = 10, string filter = null, string search = null)
            {
                if (filter == null || filter == "")
                    return $"{baseUri}/BillerIncentiveRules/GetBillerIncentiveRules/{page}/{pageSize}/";
                return $"{baseUri}/BillerIncentiveRules/GetBillerIncentiveRules/{page}/{pageSize}/{filter}/{search}";
            }
            public static string GetBillerIncentiveRulesCount(string baseUri, string filter = null, string search = null)
            {
                if (filter == null || filter == "")
                    return $"{baseUri}/BillerIncentiveRules/GetBillerIncentiveRulesCount/";
                return $"{baseUri}/BillerIncentiveRules/GetBillerIncentiveRulesCount/{filter}/{search}";
            }
            public static string GetBillerIncentiveRulesByBizLine(string baseUri, int BusinessLineId) => $"{baseUri}/BillerIncentiveRules/GetBillerIncentiveRulesByBizLine?BusinessLineId={BusinessLineId}";
            public static string GetBillerIncentiveRules(string baseUri) => $"{baseUri}/BillerIncentiveRules/GetAll";
            public static string UpdateBillerIncentiveRules(string baseUri, int Id) => $"{baseUri}/BillerIncentiveRules/{Id}";
            public static string AddBillerIncentiveRules(string baseUri) => $"{baseUri}/BillerIncentiveRules";
            public static string DeleteBillerIncentiveRules(string baseUri, int Id) => $"{baseUri}/BillerIncentiveRules/{Id}";
            public static string IsExist(string baseUri, string FieldName, string value) => $"{baseUri}/BillerIncentiveRules/IsExistAsync?FieldName={FieldName}&Value={value}";
            public static string GetBillersByBusinessLine(string baseUri, int businessLineId, string langCode) => $"{baseUri}/BillerIncentiveRules/GetBillersByBusinessLine/{businessLineId}/{langCode}";
        }

        #endregion

        #region Biller

        public static class MyBusiness
        {
            public static string GetMyBusiness(string baseUri, int Id) => $"{baseUri}/MyBusinesses/{Id}";
            public static string GetMyBusinesses(string baseUri) => $"{baseUri}/MyBusinesses/GetAll"; 
            public static string GetAllMyBusinesses(string baseUri) => $"{baseUri}/MyBusinesses/GetAllBusinesses"; 
            public static string GetMyBusinesses(string baseUri, int page = 1, int pageSize = 10, string filter = null, string search = null)
            {
                if (filter == null || filter == "")
                    return $"{baseUri}/MyBusinesses/GetMyBusinesses/{page}/{pageSize}/";
                return $"{baseUri}/MyBusinesses/GetMyBusinesses/{page}/{pageSize}/{filter}/{search}";
            }
            public static string GetMyBusinessesCount(string baseUri, string filter = null, string search = null)
            {
                if (filter == null || filter == "")
                    return $"{baseUri}/MyBusinesses/GetMyBusinessesCount/";
                return $"{baseUri}/MyBusinesses/GetMyBusinessesCount/{filter}/{search}";
            }
            public static string UpdateMyBusiness(string baseUri, int Id) => $"{baseUri}/MyBusinesses/{Id}";
            public static string UpdateMyBusinessLogo(string baseUri) => $"{baseUri}/MyBusinesses/PutMyBussinessLogo";
            public static string AddMyBusiness(string baseUri) => $"{baseUri}/MyBusinesses";
            public static string DeleteMyBusiness(string baseUri, int Id) => $"{baseUri}/MyBusinesses/{Id}";
            public static string IsExist(string baseUri, string FieldName, int value) => $"{baseUri}/MyBusinesses/IsExistAsync?FieldName={FieldName}&Value={value}"; 
            public static string GetActiveMyBusinessesCount(string baseUri) => $"{baseUri}/MyBusinesses/GetActiveMyBusinessesCount";
            public static string GetActiveMyBusinessesAsync(string baseUri) => $"{baseUri}/MyBusinesses/GetActiveMyBusinessesAsync";
        }

        public static class BillingInformation
        {
            public static string GetBillingInfo(string baseUri, int Id) => $"{baseUri}/BillingInformation/{Id}";
            public static string GetBillingInfoByMyBusiness(string baseUri, int Id) => $"{baseUri}/BillingInformation/GetBillingInfoByMyBusiness/{Id}";
            public static string GetBillingInfo(string baseUri, int page = 1, int pageSize = 10, string filter = null, string search = null)
            {
                if (filter == null || filter == "")
                    return $"{baseUri}/BillingInformation/GetBillingInformations/{page}/{pageSize}/";
                return $"{baseUri}/BillingInformation/GetBillingInformations/{page}/{pageSize}/{filter}/{search}";
            }
            public static string GetBillingInfoCount(string baseUri, string filter = null, string search = null)
            {
                if (filter == null || filter == "")
                    return $"{baseUri}/BillingInformation/GetBillingInformationsCount/";
                return $"{baseUri}/BillingInformation/GetBillingInformationsCount/{filter}/{search}";
            }
            public static string UpdateBillingWithGSTInfo(string baseUri, int Id) => $"{baseUri}/BillingInformation/UpdateBillingInfoWithGST/{Id}";
            public static string UpdateBillingWithoutGSTInfo(string baseUri, int Id) => $"{baseUri}/BillingInformation/{Id}";
            public static string AddBillingWithGSTInfo(string baseUri) => $"{baseUri}/BillingInformation/AddBillingInfoWithGST";
            public static string AddBillingWithoutGSTInfo(string baseUri) => $"{baseUri}/BillingInformation";
            public static string DeleteBillingInfo(string baseUri, int Id) => $"{baseUri}/BillingInformation/{Id}";
            public static string IsExist(string baseUri, string FieldName, string value) => $"{baseUri}/BillingInformation/IsExistAsync?FieldName={FieldName}&Value={value}";
            public static string IsBillingInfoByMyBusinessExists(string baseUri, string FieldName, string value) => $"{baseUri}/BillingInformation/IsBillingInfoByMyBusinessExists?FieldName={FieldName}&Value={value}";

        }

        public static class ItemMaster
        {
            public static string GetItemsMasterByMyBusinessId(string baseUri, int myBusunessId) => $"{baseUri}/ItemsMaster/GetAllByMyBusiness/{myBusunessId}";
            public static string GetItemMaster(string baseUri, int Id) => $"{baseUri}/ItemsMaster/{Id}";
            public static string GetItemMaster(string baseUri) => $"{baseUri}/ItemsMaster/GetAll";
            public static string GetItemMasters(string baseUri, int page = 1, int pageSize = 10, string filter = null, string search = null)
            {
                if (filter == null || filter == "")
                    return $"{baseUri}/ItemsMaster/GetItemsMasters/{page}/{pageSize}/";
                return $"{baseUri}/ItemsMaster/GetItemsMasters/{page}/{pageSize}/{filter}/{search}";
            }
            public static string GetItemMastersCount(string baseUri, string filter = null, string search = null)
            {
                if (filter == null || filter == "")
                    return $"{baseUri}/ItemsMaster/GetItemsMastersCount/";
                return $"{baseUri}/ItemsMaster/GetItemsMastersCount/{filter}/{search}";
            }
            public static string ExportPDF(string baseUri, string filter = null, string search = null)
            {
                if (filter == null || filter == "")
                    return $"{baseUri}/ItemsMaster/ExportPDF/";
                return $"{baseUri}/ItemsMaster/ExportPDF?filter={filter}&search={search}";
            }
            public static string ExportXlsx(string baseUri, string filter = null, string search = null)
            {
                if (filter == null || filter == "")
                    return $"{baseUri}/ItemsMaster/ExportXlsx/";
                return $"{baseUri}/ItemsMaster/ExportXlsx?filter={filter}&search={search}";
            }
            public static string UpdateItemMaster(string baseUri, int Id) => $"{baseUri}/ItemsMaster/{Id}";
            public static string AddItemMaster(string baseUri) => $"{baseUri}/ItemsMaster";
            public static string DeleteItemMaster(string baseUri, int Id) => $"{baseUri}/ItemsMaster/{Id}";
            public static string IsExist(string baseUri, string FieldName, string value) => $"{baseUri}/ItemsMaster/IsExistAsync?FieldName={FieldName}&Value={value}"; 
            public static string GetItemsMasterHistory(string baseUri, int Id) => $"{baseUri}/ItemsMaster/GetItemsMasterHistory/{Id}"; 
            public static string AddItemsHistory(string baseUri) => $"{baseUri}/ItemsMaster/AddItemsHistory"; 
            public static string GetItemMasterHistory(string baseUri, int Id) => $"{baseUri}/ItemsMaster/GetItemMasterHistory/{Id}"; 
            public static string UpdateItemsMasterHistory(string baseUri, int Id) => $"{baseUri}/ItemsMaster/UpdateItemsMasterHistory/{Id}"; 
            public static string GetItemsByMyBusinessIdWithoutFrequency(string baseUri, int myBusunessId) => $"{baseUri}/ItemsMaster/GetItemsByMyBusinessIdWithoutFrequency/{myBusunessId}";
            public static string GetItemsByMyBusinessIdAndBuyerId(string baseUri, int myBusunessId, int BuyerId) => $"{baseUri}/ItemsMaster/GetItemsByMyBusinessIdAndBuyerId/{myBusunessId}/{BuyerId}";
        }
        
        public static class FrequencySetting
        {
            public static string GetFrequencySetting(string baseUri, int Id) => $"{baseUri}/FrequencySettings/{Id}";
           
            public static string IsFreqencySettingForItemMasterExists(string baseUri, string FieldName, string value) => $"{baseUri}/FrequencySettings/IsFreqencySettingForItemMasterExists?FieldName={FieldName}&Value={value}";

            public static string GetFrequencySettings(string baseUri, int page = 1, int pageSize = 10, string filter = null, string search = null)
            {
                if (filter == null || filter == "")
                    return $"{baseUri}/FrequencySettings/GetFrequencySettings/{page}/{pageSize}/";
                return $"{baseUri}/FrequencySettings/GetFrequencySettings/{page}/{pageSize}/{filter}/{search}";
            }
            public static string GetFrequencySettingsCount(string baseUri, string filter = null, string search = null)
            {
                if (filter == null || filter == "")
                    return $"{baseUri}/FrequencySettings/GetFrequencySettingsCount/";
                return $"{baseUri}/FrequencySettings/GetFrequencySettingsCount/{filter}/{search}";
            }
            public static string GetPeriodicMyBusinesses(string baseUri) => $"{baseUri}/FrequencySettings/GetPeriodicMyBusinesses";
            public static string UpdateFrequencySetting(string baseUri, int Id) => $"{baseUri}/FrequencySettings/{Id}";
            public static string AddFrequencySetting(string baseUri) => $"{baseUri}/FrequencySettings";
            public static string DeleteFrequencySetting(string baseUri, int Id) => $"{baseUri}/FrequencySettings/{Id}";
            public static string IsExist(string baseUri, string FieldName, string value) => $"{baseUri}/FrequencySettings/IsExistAsync?FieldName={FieldName}&Value={value}";
        }

        public static class BuyerGroups
        {
            public static string GetBuyerGroups(string baseUri, int Id) => $"{baseUri}/BuyerGroups/{Id}";
            public static string GetBuyerGroups(string baseUri, int page = 1, int pageSize = 10, string filter = null, string search = null)
            {
                if (filter == null || filter == "")
                    return $"{baseUri}/BuyerGroups/GetBuyerGroups/{page}/{pageSize}/";
                return $"{baseUri}/BuyerGroups/GetBuyerGroups/{page}/{pageSize}/{filter}/{search}";
            }
            public static string GetBuyerGroupsCount(string baseUri, string filter = null, string search = null)
            {
                if (filter == null || filter == "")
                    return $"{baseUri}/BuyerGroups/GetBuyerGroupsCount/";
                return $"{baseUri}/BuyerGroups/GetBuyerGroupsCount/{filter}/{search}";
            }
            public static string UpdateBuyerGroups(string baseUri, int Id) => $"{baseUri}/BuyerGroups/{Id}";
            public static string AddBuyerGroups(string baseUri) => $"{baseUri}/BuyerGroups";
            public static string DeleteBuyerGroups(string baseUri, int Id) => $"{baseUri}/BuyerGroups/{Id}";
            public static string IsExist(string baseUri, string FieldName, string value, int? MyBusinessesId) => $"{baseUri}/BuyerGroups/IsExistAsync?FieldName={FieldName}&Value={value}&MyBusinessesId={MyBusinessesId}";
        }

        public static class BuyerInfo
        {
            public static string GetBuyerInfosByMyBusinessId(string baseUri, int myBusunessId) => $"{baseUri}/BuyersInfo/GetAllByMyBusiness/{myBusunessId}";
            public static string GetBuyerInfosByBuyersGroupId(string baseUri, int buyerGroupsId) => $"{baseUri}/BuyersInfo/GetAllByBuyersGroup/{buyerGroupsId}";
            public static string GetBuyerInfo(string baseUri, int Id) => $"{baseUri}/BuyersInfo/{Id}";
            public static string GetBuyerInfos(string baseUri) => $"{baseUri}/BuyersInfo/GetAll";
            public static string GetBuyerInfos(string baseUri, int page = 1, int pageSize = 10, string filter = null, string search = null)
            {
                if (filter == null || filter == "")
                    return $"{baseUri}/BuyersInfo/GetBuyerInfos/{page}/{pageSize}/";
                return $"{baseUri}/BuyersInfo/GetBuyerInfos/{page}/{pageSize}/{filter}/{search}";
            }
            public static string GetBuyersInfoCount(string baseUri, string filter = null, string search = null)
            {
                if (filter == null || filter == "")
                    return $"{baseUri}/BuyersInfo/GetBuyerInfosCount/";
                return $"{baseUri}/BuyersInfo/GetBuyerInfosCount/{filter}/{search}";
            }
            public static string UpdateBuyerInfo(string baseUri, int Id) => $"{baseUri}/BuyersInfo/{Id}";
            public static string AddBuyerInfo(string baseUri) => $"{baseUri}/BuyersInfo";
            public static string DeleteBuyerInfo(string baseUri, int Id) => $"{baseUri}/BuyersInfo/{Id}";
            public static string IsExist(string baseUri, string FieldName, string value, int MyBusinessId) => $"{baseUri}/BuyersInfo/IsExistAsync?FieldName={FieldName}&Value={value}&MyBusinessId={MyBusinessId}"; 
            public static string IsBuyerInfoForBuyerGroupExists(string baseUri, string FieldName, string value) => $"{baseUri}/BuyersInfo/IsBuyerInfoForBuyerGroupExists?FieldName={FieldName}&Value={value}";
            public static string GetBuyerDetails(string baseUri) => $"{baseUri}/BuyersInfo/GetBuyerDetails";
            public static string GetBuyerDetailsAndBillNumber(string baseUri) => $"{baseUri}/BuyersInfo/GetBuyerDetailsAndBillNumber"; 
            public static string IsBuyersInfoByMyBusinessExist(string baseUri, string FieldName, string value) => $"{baseUri}/BuyersInfo/IsBuyersInfoByMyBusinessExist?FieldName={FieldName}&Value={value}";
            public static string UploadDocumentForImport(string baseUri) => $"{baseUri}/BuyersInfo/UploadDocumentForImport";
            public static string GenerateImportFile(string baseUri) => $"{baseUri}/BuyersInfo/GenerateImportFile";
            public static string IsMobileExistsWithOtherBusinessLine(string baseUri, string mobile, int MyBusinessId) => $"{baseUri}/BuyersInfo/IsMobileExistsWithOtherBusinessLine?mobile={mobile}&MyBusinessId={MyBusinessId}";
            public static string ProcessBuyersInfoFile(string baseUri) => $"{baseUri}/BuyersInfo/ProcessBuyersInfoFile";
            public static string GetRejectedBuyers(string baseUri, int page = 1, int pageSize = 10, string filter = null, string search = null)
            {
                if (filter == null || filter == "")
                    return $"{baseUri}/BuyersInfo/GetRejectedBuyers/{page}/{pageSize}/";
                return $"{baseUri}/BuyersInfo/GetRejectedBuyers/{page}/{pageSize}/{filter}/{search}";
            }
            public static string ExportXlsx(string baseUri, string filter = null, string search = null)
            {
                if (filter == null || filter == "")
                    return $"{baseUri}/BuyersInfo/ExportXlsx/";
                return $"{baseUri}/BuyersInfo/ExportXlsx?filter={filter}&search={search}";
            }
        }

        public static class BusinessSetting
        {
            public static string GetBusinessSetting(string baseUri, int Id) => $"{baseUri}/BusinessSettings/{Id}";
            public static string GetBusinessSettings(string baseUri) => $"{baseUri}/BusinessSettings/GetAll";
            public static string GetBusinessSettings(string baseUri, int page = 1, int pageSize = 10, string filter = null, string search = null)
            {
                if (filter == null || filter == "")
                    return $"{baseUri}/BusinessSettings/GetBusinessSettings/{page}/{pageSize}/";
                return $"{baseUri}/BusinessSettings/GetBusinessSettings/{page}/{pageSize}/{filter}/{search}";
            }

            public static string GetBusinessSettingCount(string baseUri, string filter = null, string search = null)
            {
                if (filter == null || filter == "")
                    return $"{baseUri}/BusinessSettings/GetBusinessSettingsCount/";
                return $"{baseUri}/BusinessSettings/GetBusinessSettingsCount/{filter}/{search}";
            }
            public static string UpdateBusinessSetting(string baseUri, int Id) => $"{baseUri}/BusinessSettings/{Id}";
            public static string AddBusinessSetting(string baseUri) => $"{baseUri}/BusinessSettings";
            public static string DeleteBusinessSetting(string baseUri, int Id) => $"{baseUri}/BusinessSettings/{Id}";
            public static string IsExist(string baseUri, string FieldName, int? MyBusinessesId) => $"{baseUri}/BusinessSettings/IsExistAsync?FieldName={FieldName}&MyBusinessesId={MyBusinessesId}"; 
            public static string GetBusinessSettingByMyBusiness(string baseUri, int Id) => $"{baseUri}/BusinessSettings/GetBusinessSettingByMyBusiness/{Id}";
        }
        
        public static class ContractsInfo
        {
            //public static string GetContractsInfosByMyBusinessId(string baseUri, int myBusunessId) => $"{baseUri}/ContractsInfo/GetAllByMyBusiness/{myBusunessId}";
            //public static string GetContractsInfosByBuyersGroupId(string baseUri, int buyerGroupsId) => $"{baseUri}/ContractsInfo/GetAllByBuyersGroup/{buyerGroupsId}";
            public static string GetContractsInfosByBuyersInfoId(string baseUri, int buyerId) => $"{baseUri}/ContractsInfo/GetAllByBuyerInfo/{buyerId}";
            public static string GetContractsInfo(string baseUri, int Id) => $"{baseUri}/ContractsInfo/{Id}";
            public static string GetContractsInfos(string baseUri) => $"{baseUri}/ContractsInfo/GetAll";
            public static string GetContractsInfos(string baseUri, int page = 1, int pageSize = 10, string filter = null, string search = null)
            {
                if (filter == null || filter == "")
                    return $"{baseUri}/ContractsInfo/GetContractsInfos/{page}/{pageSize}/";
                return $"{baseUri}/ContractsInfo/GetContractsInfos/{page}/{pageSize}/{filter}/{search}";
            }
            public static string GetContractsInfosCount(string baseUri, string filter = null, string search = null)
            {
                if (filter == null || filter == "")
                    return $"{baseUri}/ContractsInfo/GetContractsInfosCount/";
                return $"{baseUri}/ContractsInfo/GetContractsInfosCount/{filter}/{search}";
            }
            public static string UpdateContractsInfo(string baseUri, int Id) => $"{baseUri}/ContractsInfo/{Id}";
            public static string AddContractsInfo(string baseUri) => $"{baseUri}/ContractsInfo";
            public static string DeleteContractsInfo(string baseUri, int Id) => $"{baseUri}/ContractsInfo/{Id}";
            public static string IsExist(string baseUri, string FieldName, string value) => $"{baseUri}/ContractsInfo/IsExistAsync?FieldName={FieldName}&Value={value}";
            public static string IsContractInfoForBuyerInfoExists(string baseUri, string FieldName, string value) => $"{baseUri}/ContractsInfo/IsContractInfoForBuyerInfoExists?FieldName={FieldName}&Value={value}"; 
            public static string IsContractInfoForItemMasterExists(string baseUri, string FieldName, string value) => $"{baseUri}/ContractsInfo/IsContractInfoForItemMasterExists?FieldName={FieldName}&Value={value}";
            public static string UploadDocumentForImport(string baseUri) => $"{baseUri}/ContractsInfo/UploadDocumentForImport";
            public static string GenerateImportFile(string baseUri) => $"{baseUri}/ContractsInfo/GenerateImportFile";
            public static string ProcessContractInfoFile(string baseUri) => $"{baseUri}/ContractsInfo/ProcessContractInfoFile";
            public static string GetRejectedContracts(string baseUri, int page = 1, int pageSize = 10, string filter = null, string search = null)
            {
                if (filter == null || filter == "")
                    return $"{baseUri}/ContractsInfo/GetRejectedContracts/{page}/{pageSize}/";
                return $"{baseUri}/ContractsInfo/GetRejectedContracts/{page}/{pageSize}/{filter}/{search}";
            }
            public static string ExportXlsx(string baseUri, string filter = null, string search = null)
            {
                if (filter == null || filter == "")
                    return $"{baseUri}/ContractsInfo/ExportXlsx/";
                return $"{baseUri}/ContractsInfo/ExportXlsx?filter={filter}&search={search}";
            }
        }

        public static class BillerConnect
        {
            public static string GetBillerConnectSearch(string baseUri) => $"{baseUri}/BuyerFunctions/GetBillerConnectsByLocation";
            public static string GetBillerConnectCount(string baseUri) => $"{baseUri}/BuyerFunctions/GetBillerConnectsByLocationCount";
            public static string AddBuyerConnectInfo(string baseUri) => $"{baseUri}/BuyerFunctions/AddBuyerConnectInfo";
            public static string GetBillerInfo(string baseUri, int myBusinessId) => $"{baseUri}/BuyerFunctions/GetBillerInfo/{myBusinessId}";
            public static string GetBillerConnectsForBuyersSearchAsync(string baseUri, int page = 1, int pageSize = 10, string filter = null, string search = null)
            {
                if (filter == null || filter == "")
                    return $"{baseUri}/BuyerFunctions/GetBillerConnectsForBuyers/{page}/{pageSize}/";
                return $"{baseUri}/BuyerFunctions/GetBillerConnectsForBuyers/{page}/{pageSize}/{filter}/{search}";
            }
            public static string GetBillerConnectsForBuyersCountAsync(string baseUri, string filter = null, string search = null)
            {
                if (filter == null || filter == "")
                    return $"{baseUri}/BuyerFunctions/GetBillerConnectsForBuyersCount/";
                return $"{baseUri}/BuyerFunctions/GetBillerConnectsForBuyersCount/{filter}/{search}";
            }            
        }

        public static class BillerDisconnect
        {
            public static string GetBillerDisconnectsSearchAsync(string baseUri, int page = 1, int pageSize = 10, string filter = null, string search = null)
            {
                if (filter == null || filter == "")
                    return $"{baseUri}/BuyerFunctions/GetBillerDisconnects/{page}/{pageSize}/";
                return $"{baseUri}/BuyerFunctions/GetBillerDisconnects/{page}/{pageSize}/{filter}/{search}";
            }
            public static string GetBillerDisconnectsCountAsync(string baseUri, string filter = null, string search = null)
            {
                if (filter == null || filter == "")
                    return $"{baseUri}/BuyerFunctions/GetBillerDisconnectsCount/";
                return $"{baseUri}/BuyerFunctions/GetBillerDisconnectsCount/{filter}/{search}";
            }
            public static string DeleteBillerConnectInfo(string baseUri) => $"{baseUri}/BuyerFunctions/DeleteBuyerConnectInfo";            
        }

        public static class BillerInformation
        {
            public static string GetBillerInfo(string baseUri, int Id) => $"{baseUri}/BillerInformation/{Id}";

            public static string IsExist(string baseUri, string FieldName, string value, int BusinessLineId) => $"{baseUri}/BillerInformation/IsExistAsync?FieldName={FieldName}&Value={value}&BusinessLineId={BusinessLineId}";            
            public static string GetUserInfoAndMyBusinessByMobileNumber(string baseUri) => $"{baseUri}/BillerInformation/GetUserInfoAndMyBusinessByMobileNumber";
            public static string GetBillerInfos(string baseUri, int page = 1, int pageSize = 10, string filter = null, string search = null)
            {
                if (filter == null || filter == "")
                    return $"{baseUri}/BillerInformation/GetBillerInformation/{page}/{pageSize}/";
                return $"{baseUri}/BillerInformation/GetBillerInformation/{page}/{pageSize}/{filter}/{search}";
            }            
            public static string GetNonExistingBillerInfos(string baseUri, int page = 1, int pageSize = 10, string filter = null, string search = null)
            {
                if (filter == null || filter == "")
                    return $"{baseUri}/BillerInformation/GetBillerInformationNonExisting/{page}/{pageSize}/";
                return $"{baseUri}/BillerInformation/GetBillerInformationNonExisting/{page}/{pageSize}/{filter}/{search}";
            }
            public static string GetBillerInfoCount(string baseUri, string filter = null, string search = null)
            {
                if (filter == null || filter == "")
                    return $"{baseUri}/BillerInformation/GetBillerInformationCount/";
                return $"{baseUri}/BillerInformation/GetBillerInformationCount/{filter}/{search}";
            }            
            public static string AddBillerInfo(string baseUri) => $"{baseUri}/BillerInformation"; 
            public static string DeleteBillerInfo(string baseUri, int Id) => $"{baseUri}/BillerInformation/{Id}";
            public static string AddBuyerInfo(string baseUri) => $"{baseUri}/BillerInformation/AddBuyerInfo"; 
            public static string UpdateBillerInformation(string baseUri, int Id) => $"{baseUri}/BillerInformation/{Id}";
        }

        public static class ItemsInformationForBuyer
        {
            public static string GetItemInfos(string baseUri) => $"{baseUri}/ItemsInformationForBuyer/GetItemsInfosSearch";
            public static string GetItemsByBiller(string baseUri, int billerId, bool? isActualBiller) => $"{baseUri}/ItemsInformationForBuyer/GetItemsByBiller?billerId={billerId}&isActualBiller={isActualBiller}";
            public static string GetItemsByMyBusiness(string baseUri, int myBusinessId, bool? isActualBusiness) => $"{baseUri}/ItemsInformationForBuyer/GetItemsByMyBusiness?myBusinessId={myBusinessId}&isActualBusiness={isActualBusiness}";
            public static string GetItemInfosCount(string baseUri) => $"{baseUri}/ItemsInformationForBuyer/GetItemsInfosCount";
            public static string AddItemInfo(string baseUri) => $"{baseUri}/ItemsInformationForBuyer";
            public static string GetItemInfo(string baseUri, int Id) => $"{baseUri}/ItemsInformationForBuyer/{Id}";
            public static string UpdateItemsInfo(string baseUri, int Id) => $"{baseUri}/ItemsInformationForBuyer/{Id}";
            public static string DeleteItemsInfo(string baseUri, int Id) => $"{baseUri}/ItemsInformationForBuyer/{Id}";
            public static string GetMyBusinessByBillerId(string baseUri) => $"{baseUri}/ItemsInformationForBuyer/GetMyBusinessByBillerId";
            public static string GetBillerIdByFilter(string baseUri) => $"{baseUri}/ItemsInformationForBuyer/GetBillerIdByFilter";
            public static string GetItemsInfoByBillerId(string baseUri) => $"{baseUri}/ItemsInformationForBuyer/GetItemsInfoByBillerId"; 
            public static string GetBillers(string baseUri, bool? isActualBiller) => $"{baseUri}/ItemsInformationForBuyer/GetBillersForItemsInfo?isActualBiller={isActualBiller}";
        }

        public static class BillerValidityExtension
        {
            public static string GetBillerValidity(string baseUri) => $"{baseUri}/BillerValidityExtension/GetBillerValidityExtensions";
            public static string GetBillerValidityCount(string baseUri) => $"{baseUri}/BillerValidityExtension/GetBillerValidityExtensionsCount";
            public static string AddBillerValidityExtension(string baseUri) => $"{baseUri}/BillerValidityExtension";
            public static string GetBillerNameByBusinessLine(string baseUri) => $"{baseUri}/BillerValidityExtension/GetBillerNameByBusinessLine";
            public static string GetBillerValidityExtension(string baseUri, int Id) => $"{baseUri}/BillerValidityExtension/GetBillerValidityExtension/{Id}";
            public static string UpdateBillerValidityExtension(string baseUri, int Id) => $"{baseUri}/BillerValidityExtension/{Id}";
            public static string IsExist(string baseUri, string FieldName, int value, int BusinessLineId) => $"{baseUri}/BillerValidityExtension/IsExistAsync?FieldName={FieldName}&Value={value}&BusinessLineId={BusinessLineId}";
        }

        public static class CreditDebitNote
        {
            public static string GetCreditDebitNote(string baseUri, int Id) => $"{baseUri}/CreditDebitNote/{Id}";
            public static string GetLastCreditDebitNote(string baseUri, int BuyerInfoId) => $"{baseUri}/CreditDebitNote/GetLastCreditDebitNote/{BuyerInfoId}";
            public static string GetCreditDebitNotes(string baseUri, int page = 1, int pageSize = 10, string filter = null, string search = null)
            {
                if (filter == null || filter == "")
                    return $"{baseUri}/CreditDebitNote/GetCreditDebitNotes/{page}/{pageSize}/";
                return $"{baseUri}/CreditDebitNote/GetCreditDebitNotes/{page}/{pageSize}/{filter}/{search}";
            }
            public static string GetCreditDebitNotesCount(string baseUri, string filter = null, string search = null)
            {
                if (filter == null || filter == "")
                    return $"{baseUri}/CreditDebitNote/GetCreditDebitNotesCount/";
                return $"{baseUri}/CreditDebitNote/GetCreditDebitNotesCount/{filter}/{search}";
            }
            public static string UpdateCreditDebitNote(string baseUri, int Id) => $"{baseUri}/CreditDebitNote/{Id}";
            public static string AddCreditDebitNote(string baseUri) => $"{baseUri}/CreditDebitNote";
            public static string IsExist(string baseUri, string FieldName, string value, int? BuyerInfoId, int? MyBusinessesId) => $"{baseUri}/CreditDebitNote/IsExistAsync?FieldName={FieldName}&Value={value}&BuyerInfoId={BuyerInfoId}&MyBusinessesId={MyBusinessesId}";
            public static string ReportCreditDebitNotes(string baseUri)
            {
                return $"{baseUri}/CreditDebitNote/ReportCreditDebitNotes";
            }
            public static string ExportPDF(string baseUri) => $"{baseUri}/CreditDebitNote/ExportPDF/";
            public static string ExportXlsx(string baseUri) => $"{baseUri}/CreditDebitNote/ExportXlsx/";
        }
        
        public static class CashReceipt
        {
            public static string GetCashReceipt(string baseUri, int Id) => $"{baseUri}/CashReceipt/{Id}";
            public static string GetCashReceipts(string baseUri, int page = 1, int pageSize = 10, string filter = null, string search = null)
            {
                if (filter == null || filter == "")
                    return $"{baseUri}/CashReceipt/GetCashReceipts/{page}/{pageSize}/";
                return $"{baseUri}/CashReceipt/GetCashReceipts/{page}/{pageSize}/{filter}/{search}";
            }
            public static string GetCashReceiptsCount(string baseUri, string filter = null, string search = null)
            {
                if (filter == null || filter == "")
                    return $"{baseUri}/CashReceipt/GetCashReceiptsCount/";
                return $"{baseUri}/CashReceipt/GetCashReceiptsCount/{filter}/{search}";
            }
            public static string UpdateCashReceipt(string baseUri, int Id) => $"{baseUri}/CashReceipt/{Id}";
            public static string AddCashReceipt(string baseUri) => $"{baseUri}/CashReceipt";
        }

        public static class BuyerRecordKeeping
        {
            public static string GetBuyerRecord(string baseUri, int Id) => $"{baseUri}/BuyerRecordKeeping/{Id}";

            public static string GetBuyerRecordsByDate(string baseUri) => $"{baseUri}/BuyerRecordKeeping/GetBuyerRecordsByDate";

            public static string GetBillers(string baseUri, bool? isActualBiller) => $"{baseUri}/BuyerRecordKeeping/GetBillers?isActualBiller={isActualBiller}";

            public static string GetItems(string baseUri, int MyBusinessId, bool IsActualBusiness) => $"{baseUri}/BuyerRecordKeeping/GetItems?myBusinessId={MyBusinessId}&isActualBusiness={IsActualBusiness}";

            public static string AddBuyerRecord(string baseUri) => $"{baseUri}/BuyerRecordKeeping";

            public static string UpdateBuyerRecord(string baseUri, int Id) => $"{baseUri}/BuyerRecordKeeping/{Id}";

            public static string DeleteBuyerRecord(string baseUri, int Id) => $"{baseUri}/BuyerRecordKeeping/{Id}";

            public static string IsExist(string baseUri, string FieldName, string value) => $"{baseUri}/BuyerRecordKeeping/IsExistAsync?FieldName={FieldName}&Value={value}";
            
            public static string GetCurrentBillAmount(string baseUri, int myBusinessId, int itemId, bool isActualBiller) => $"{baseUri}/BuyerRecordKeeping/GetCurrentBillAmount?myBusinessId={myBusinessId}&itemId={itemId}&isActualBiller={isActualBiller}";
        }

        public static class BillerRecordKeeping
        {
            public static string GetBillerRecord(string baseUri, int Id) => $"{baseUri}/BillerRecordKeeping/{Id}";

            public static string GetBillerRecordsByDate(string baseUri) => $"{baseUri}/BillerRecordKeeping/GetBillerRecordsByDate";

            public static string GetBuyerByMyBusiness(string baseUri, int MyBusinessId) => $"{baseUri}/BillerRecordKeeping/GetBuyerByMyBusiness?myBusinessId={MyBusinessId}";
            
            public static string GetItems(string baseUri, int MyBusinessId, int BuyerId) => $"{baseUri}/BillerRecordKeeping/GetItems?myBusinessId={MyBusinessId}&buyerId={BuyerId}";

            public static string GetMyBusinesses(string baseUri) => $"{baseUri}/BillerRecordKeeping/GetMyBusinesses";

            public static string AddBillerRecord(string baseUri) => $"{baseUri}/BillerRecordKeeping";

            public static string UpdateBillerRecord(string baseUri, int Id) => $"{baseUri}/BillerRecordKeeping/{Id}";

            public static string DeleteBillerRecord(string baseUri, int Id) => $"{baseUri}/BillerRecordKeeping/{Id}";

            public static string IsExist(string baseUri, string FieldName, string value) => $"{baseUri}/BillerRecordKeeping/IsExistAsync?FieldName={FieldName}&Value={value}";

            public static string GetCurrentBillAmount(string baseUri, int myBusinessId, int buyerId, int itemId) => $"{baseUri}/BillerRecordKeeping/GetCurrentBillAmount?myBusinessId={myBusinessId}&buyerId={buyerId}&itemId={itemId}";
        }

        public static class ShowMyBills
        {
            public static string GetBillsForBuyer(string baseUri)=>$"{baseUri}/ShowMyBills/GetBillsForBuyer";
            
            public static string GetBillsForBuyerCount(string baseUri) => $"{baseUri}/ShowMyBills/GetBillsForBuyerCount"; 

            public static string GetBillForBuyer(string baseUri, int Id) => $"{baseUri}/ShowMyBills/{Id}";

            public static string GetBillForBuyerById(string baseUri, int Id) => $"{baseUri}/ShowMyBills/GetBillForBuyerById/{Id}";

            public static string AddShowMyBills(string baseUri) => $"{baseUri}/ShowMyBills";

            public static string ProcessNonSMBMonthlyBills(string baseUri) => $"{baseUri}/ShowMyBills/ProcessNonSMBMonthlyBills";

            public static string DeleteNonSMBMonthlyBills(string baseUri) => $"{baseUri}/ShowMyBills/DeleteNonSMBMonthlyBills";

            public static string GetHeaderDetails(string baseUri, int headerRecordId, bool isNonSMBBiller) => $"{baseUri}/ShowMyBills/GetHeaderDetails/{headerRecordId}/{isNonSMBBiller}";

            public static string ExportPDF(string baseUri, int headerRecordId, bool isNonSMBBiller) => $"{baseUri}/ShowMyBills/ExportPDF/{headerRecordId}/{isNonSMBBiller}";

            public static string ExportXlsx(string baseUri,int headerRecordId, bool isNonSMBBiller) => $"{baseUri}/ShowMyBills/ExportXlsx/{headerRecordId}/{isNonSMBBiller}";

            public static string GetHeaders(string baseUri, int headerRecordId, bool isNonSMBBiller) => $"{baseUri}/ShowMyBills/GetHeader/{headerRecordId}/{isNonSMBBiller}"; 
            public static string ProcessSMBMonthlyBills(string baseUri) => $"{baseUri}/ShowMyBills/ProcessSMBMonthlyBills";
            public static string DeleteSMBMonthlyBills(string baseUri) => $"{baseUri}/ShowMyBills/DeleteSMBMonthlyBills";
            public static string ProcessSMBCharges(string baseUri) => $"{baseUri}/ShowMyBills/ProcessSMBCharges";

            public static string GetBillNumber(string baseUri) => $"{baseUri}/ShowMyBills/GetAll"; 
            public static string GetBillAmountByBillNumber(string baseUri) => $"{baseUri}/ShowMyBills/GetBillAmountByBillNumber"; 
            public static string GetBillDetailsByBuyerId(string baseUri) => $"{baseUri}/ShowMyBills/GetBillDetailsByBuyerId";
        }

        public static class PaymentReceipt
        {
            public static string GetPaymentReceipt(string baseUri, int Id) => $"{baseUri}/PaymentReceipt/{Id}";
            public static string GetPaymentReceipts(string baseUri, int page = 1, int pageSize = 10, string filter = null, string search = null)
            {
                if (filter == null || filter == "")
                    return $"{baseUri}/PaymentReceipt/GetPaymentReceipts/{page}/{pageSize}/";
                return $"{baseUri}/PaymentReceipt/GetPaymentReceipts/{page}/{pageSize}/{filter}/{search}";
            }
            public static string GetPaymentReceiptsCount(string baseUri, string filter = null, string search = null)
            {
                if (filter == null || filter == "")
                    return $"{baseUri}/PaymentReceipt/GetPaymentReceiptsCount/";
                return $"{baseUri}/PaymentReceipt/GetPaymentReceiptsCount/{filter}/{search}";
            }

            public static string UpdatePaymentReceipt(string baseUri, int Id) => $"{baseUri}/PaymentReceipt/{Id}";
            public static string AddPaymentReceipt(string baseUri) => $"{baseUri}/PaymentReceipt/BillerCashReceipt";

            public static string ReportPaymentReceipts(string baseUri)
            {
                return $"{baseUri}/PaymentReceipt/ReportPaymentReceipts";
            }
            public static string ExportPDF(string baseUri) => $"{baseUri}/PaymentReceipt/ExportPDF/";
            public static string ExportXlsx(string baseUri) => $"{baseUri}/PaymentReceipt/ExportXlsx/";

            public static string GetPaymentHistory(string baseUri, int page = 1, int pageSize = 10, string filter = null, string search = null)
            {
                if (filter == null || filter == "")
                    return $"{baseUri}/PaymentReceipt/GetPaymentHistory/{page}/{pageSize}/";
                return $"{baseUri}/PaymentReceipt/GetPaymentHistory/{page}/{pageSize}/{filter}/{search}";
            }
            public static string GetPaymentHistoryCount(string baseUri, string filter = null, string search = null)
            {
                if (filter == null || filter == "")
                    return $"{baseUri}/PaymentReceipt/GetPaymentHistoryCount/";
                return $"{baseUri}/PaymentReceipt/GetPaymentHistoryCount/{filter}/{search}";
            }
        }

        public static class SMBInvoices
        {
            public static string GetSMBInvoices(string baseUri, int page = 1, int pageSize = 10, string filter = null, string search = null)
            {
                if (filter == null || filter == "")
                    return $"{baseUri}/SMBInvoice/GetSMBInvoices/{page}/{pageSize}/";
                return $"{baseUri}/SMBInvoice/GetSMBInvoices/{page}/{pageSize}/{filter}/{search}";
            }
            public static string GetSMBInvoicesCount(string baseUri, string filter = null, string search = null)
            {
                if (filter == null || filter == "")
                    return $"{baseUri}/SMBInvoice/GetSMBInvoicesCount/";
                return $"{baseUri}/SMBInvoice/GetSMBInvoicesCount/{filter}/{search}";
            }
            public static string GetInvoicesDetails(string baseUri, string InvoiceNumber) => $"{baseUri}/SMBInvoice/GetSMBInvoicesDetails/{InvoiceNumber}";
            public static string GetInvoicesDetails(string baseUri, string InvoiceNumber, int page = 1, int pageSize = 10, string filter = null, string search = null)
            {
                if (filter == null || filter == "")
                    return $"{baseUri}/SMBInvoice/GetSMBInvoicesDetails/{InvoiceNumber}/{page}/{pageSize}/";
                return $"{baseUri}/SMBInvoice/GetSMBInvoicesDetails/{InvoiceNumber}/{page}/{pageSize}/{filter}/{search}";
            }
            public static string GetInvoicesDetailsCount(string baseUri, string InvoiceNumber, string filter = null, string search = null)
            {
                if (filter == null || filter == "")
                    return $"{baseUri}/SMBInvoice/GetSMBInvoicesDetailsCount/{InvoiceNumber}/";
                return $"{baseUri}/SMBInvoice/GetSMBInvoicesDetailsCount/{InvoiceNumber}/{filter}/{search}";
            }
            public static string GetSMBInvoicesHeader(string baseUri, string InvoiceNumber) => $"{baseUri}/SMBInvoice/GetSMBInvoicesHeader/{InvoiceNumber}";
        }
        
        public static class AccountStatement
        {
            public static string GetAccountStatements(string baseUri) => $"{baseUri}/SMBInvoice/GetAccountStatements";
            public static string GetAccountStatementsCount(string baseUri) => $"{baseUri}/SMBInvoice/GetAccountStatementsCount";
            public static string GetAccountBalance(string baseUri) => $"{baseUri}/SMBInvoice/GetAccountBalance";
            public static string IsNegativeAccountBalance(string baseUri) => $"{baseUri}/SMBInvoice/IsNegativeAccountBalance";
            public static string GetAccountDetails(string baseUri) => $"{baseUri}/SMBInvoice/GetAccountDetails";
            public static string GetAccountDetailsCount(string baseUri) => $"{baseUri}/SMBInvoice/GetAccountDetailsCount";
        }

        public static class Reports
        {
            public static string ReportConsolidatedRequirements(string baseUri)
            {
                return $"{baseUri}/Reports/ReportConsolidatedRequirement";
            }

            public static string ReportOutstandingStatement(string baseUri)
            {
                return $"{baseUri}/Reports/ReportOutstandingStatement";
            }

            public static string ReportDiscountSummary(string baseUri)
            {
                return $"{baseUri}/Reports/ReportDiscountSummary";
            }
            public static string ExportConsolidatedRequirementsReportPDF(string baseUri) => $"{baseUri}/Reports/ExportConsolidatedRequirementsReportPDF/";
            public static string ExportConsolidatedRequirementsReportXlsx(string baseUri) => $"{baseUri}/Reports/ExportConsolidatedRequirementsReportXlsx/";
            public static string ExportOutstandingStatementReportPDF(string baseUri) => $"{baseUri}/Reports/ExportOutstandingStatementReportPDF/";
            public static string ExportOutstandingStatementReportXlsx(string baseUri) => $"{baseUri}/Reports/ExportOutstandingStatementReportXlsx/";
            public static string ExportDiscountSummaryReportPDF(string baseUri) => $"{baseUri}/Reports/ExportDiscountSummaryReportPDF/";
            public static string ExportDiscountSummaryReportXlsx(string baseUri) => $"{baseUri}/Reports/ExportDiscountSummaryReportXlsx/";
        }

        public static class AdHocBillingDetails
        {
            public static string GetAdHocBillingDetails(string baseUri, int page = 1, int pageSize = 10, string filter = null, string search = null)
            {
                if (filter == null || filter == "")
                    return $"{baseUri}/ShowMyBills/GetAdHocBillingDetails/{page}/{pageSize}/";
                return $"{baseUri}/ShowMyBills/GetAdHocBillingDetails/{page}/{pageSize}/{filter}/{search}";
            }
            public static string GetAdHocBillingDetailsCount(string baseUri, string filter = null, string search = null)
            {
                if (filter == null || filter == "")
                    return $"{baseUri}/ShowMyBills/GetAdHocBillingDetailsCount/";
                return $"{baseUri}/ShowMyBills/GetAdHocBillingDetailsCount/{filter}/{search}";
            }

            public static string AddAdHocBillingDetails(string baseUri) => $"{baseUri}/ShowMyBills/ProcessAdHocBillingDetails";

            public static string GetCurrentBillingDetails(string baseUri, int buyerInfoId, DateTime? contractEndedDate, string refund) => $"{baseUri}/ShowMyBills/GetCurrentBillingDetails/{buyerInfoId}/{Convert.ToDateTime(contractEndedDate, CultureInfo.CurrentCulture).ToString("dd-MMM-yyyy")}/{refund}";
        }

        public static class ServiceRequest
        {
            public static string GetServiceRequests(string baseUri, int page = 1, int pageSize = 10, string filter = null, string search = null)
            {
                if (filter == null || filter == "")
                    return $"{baseUri}/ServiceRequest/GetServiceRequests/{page}/{pageSize}/";
                return $"{baseUri}/ServiceRequest/GetServiceRequests/{page}/{pageSize}/{filter}/{search}";
            }
            public static string GetServiceRequestsCount(string baseUri, string filter = null, string search = null)
            {
                if (filter == null || filter == "")
                    return $"{baseUri}/ServiceRequest/GetServiceRequestsCount/";
                return $"{baseUri}/ServiceRequest/GetServiceRequestsCount/{filter}/{search}";
            }

            public static string AddServiceRequest(string baseUri) => $"{baseUri}/ServiceRequest/AddBillerServiceRequest";
        }

        public static class BuyerServiceRequest
        {
            public static string GetBuyerServiceRequests(string baseUri, int page = 1, int pageSize = 10, string filter = null, string search = null)
            {
                if (filter == null || filter == "")
                    return $"{baseUri}/ServiceRequest/GetBuyerServiceRequests/{page}/{pageSize}/";
                return $"{baseUri}/ServiceRequest/GetBuyerServiceRequests/{page}/{pageSize}/{filter}/{search}";
            }
            public static string GetBuyerServiceRequestsCount(string baseUri, string filter = null, string search = null)
            {
                if (filter == null || filter == "")
                    return $"{baseUri}/ServiceRequest/GetBuyerServiceRequestsCount/";
                return $"{baseUri}/ServiceRequest/GetBuyerServiceRequestsCount/{filter}/{search}";
            }

            public static string AddBuyerServiceRequest(string baseUri) => $"{baseUri}/ServiceRequest/AddBuyerServiceRequest";
        }

        public static class FAQ
        {
            public static string GetFaq(string baseUri, int Id) => $"{baseUri}/FAQs/{Id}";
            public static string GetFaqs(string baseUri, bool isForMobile) => $"{baseUri}/FAQs/GetAll/{isForMobile}";
            //public static string GetAllFAQByRole(string baseUri, bool isForMobile, string role) => $"{baseUri}/FAQs/GetAllFAQByRole/{isForMobile}/{role}";
            public static string GetFaqs(string baseUri, int page, int pageSize, bool isForMobile, string filter = null, string search = null)
            {
                if (filter == null || filter == "")
                    return $"{baseUri}/FAQs/GetFAQs/{page}/{pageSize}/{isForMobile}";
                return $"{baseUri}/FAQs/GetFAQs/{page}/{pageSize}/{isForMobile}/{filter}/{search}";
            }
            public static string GetFaqsCount(string baseUri, bool isForMobile, string filter = null, string search = null)
            {
                if (filter == null || filter == "")
                    return $"{baseUri}/FAQs/GetFAQsCount/{isForMobile}";
                return $"{baseUri}/FAQs/GetFAQsCount/{isForMobile}/{filter}/{search}";
            }
            public static string GetFaqsByRole(string baseUri, int page, int pageSize, bool isForMobile, string role, string filter = null, string search = null)
            {
                if (filter == null || filter == "")
                    return $"{baseUri}/FAQs/GetFAQsByRole/{page}/{pageSize}/{isForMobile}/{role}";
                return $"{baseUri}/FAQs/GetFAQsByRole/{page}/{pageSize}/{isForMobile}/{role}/{filter}/{search}";
            }
            public static string GetFaqsByRoleCount(string baseUri, bool isForMobile, string role, string filter = null, string search = null)
            {
                if (filter == null || filter == "")
                    return $"{baseUri}/FAQs/GetFAQsByRoleCount/{isForMobile}/{role}";
                return $"{baseUri}/FAQs/GetFAQsByRoleCount/{isForMobile}/{role}/{filter}/{search}";
            }

            public static string AddFaqInfo(string baseUri) => $"{baseUri}/FAQs";
            public static string UpdateFaqInfo(string baseUri, int Id) => $"{baseUri}/FAQs/{Id}";
            public static string DeleteFaqInfo(string baseUri, int Id) => $"{baseUri}/FAQs/{Id}";
        }

        public static class ServiceHoliday
        {            
            public static string GetServiceHoliday(string baseUri, int Id) => $"{baseUri}/ServiceHoliday/{Id}";
            public static string GetServiceHolidays(string baseUri, int page = 1, int pageSize = 10, string filter = null, string search = null)
            {
                if (filter == null || filter == "")
                    return $"{baseUri}/ServiceHoliday/GetServiceHolidays/{page}/{pageSize}/";
                return $"{baseUri}/ServiceHoliday/GetServiceHolidays/{page}/{pageSize}/{filter}/{search}";
            }
            public static string GetServiceHolidaysCount(string baseUri, string filter = null, string search = null)
            {
                if (filter == null || filter == "")
                    return $"{baseUri}/ServiceHoliday/GetServiceHolidaysCount/";
                return $"{baseUri}/ServiceHoliday/GetServiceHolidaysCount/{filter}/{search}";
            }            
            public static string AddServiceHoliday(string baseUri) => $"{baseUri}/ServiceHoliday"; 
            public static string UpdateServiceHoliday(string baseUri, int Id) => $"{baseUri}/ServiceHoliday/{Id}";
        }


        public static class OrganizationInfo
        {
            public static string GetOrganizationInfos(string baseUri) => $"{baseUri}/OrganizationInfo/GetOrganizationInfos";
            public static string GetOrganizationInfosCount(string baseUri) => $"{baseUri}/OrganizationInfo/GetOrganizationInfosCount"; 
            public static string AddOrganizationInfo(string baseUri) => $"{baseUri}/OrganizationInfo/Post"; 
            public static string GetOrganizationInfo(string baseUri) => $"{baseUri}/OrganizationInfo/Get"; 
            public static string UpdateOrganizationInfo(string baseUri, int Id) => $"{baseUri}/OrganizationInfo/{Id}"; 
            public static string DeleteOrganizationInfo(string baseUri, int Id) => $"{baseUri}/OrganizationInfo/{Id}"; 
            public static string UpdateOrganizationLogo(string baseUri) => $"{baseUri}/OrganizationInfo/PutOrganizationLogo";
            public static string IsExist(string baseUri, string FieldName, string value) => $"{baseUri}/OrganizationInfo/IsExistAsync?FieldName={FieldName}&Value={value}"; 
            public static string GetOrganizationMaxUsers(string baseUri) => $"{baseUri}/OrganizationInfo/GetOrganizationMaxUsers";            
            public static string GetCurrentUserOrganization(string baseUri) => $"{baseUri}/OrganizationInfo/GetCurrentUserOrganization";
            public static string GetImageBase64Content(string baseUri, int id) => $"{baseUri}/OrganizationInfo/GetImageContent/{id}";
        }

        public static class States
        {
            public static string GetStates(string baseUri) => $"{baseUri}/States/GetStates";
            public static string GetStatesByLanguage(string baseUri, string language) => $"{baseUri}/States/GetStatesByLanguage/{language}";
        }

        public static class Pincode
        {
            public static string GetStateByPincode(string baseUri, string pincode) => $"{baseUri}/PinCodes/{pincode}";
        }

        public static class Department
        {
            public static string GetDepartments(string baseUri) => $"{baseUri}/Department/GetDepartments";
            public static string GetDepartmentByOrganization(string baseUri) => $"{baseUri}/Department/GetDepartmentByOrganization";
            public static string GetDepartment(string baseUri) => $"{baseUri}/Department/Get";
            public static string UpdateDepartment(string baseUri, int Id) => $"{baseUri}/Department/{Id}";
            public static string DeleteDepartment(string baseUri, int Id) => $"{baseUri}/Department/{Id}";
            public static string AddDepartment(string baseUri) => $"{baseUri}/Department/Post";
            public static string IsExist(string baseUri) => $"{baseUri}/Department/IsExist";
        }

        public static class RolesConfiguration
        {
            public static string GetRolesConfigurations(string baseUri) => $"{baseUri}/RolesConfiguration/GetRolesConfigurations"; 
            public static string GetRoleConfiguration(string baseUri) => $"{baseUri}/RolesConfiguration/Get";
            public static string UpdateRolesConfiguration(string baseUri, int Id) => $"{baseUri}/RolesConfiguration/{Id}";
            public static string DeleteRolesConfiguration(string baseUri, int Id) => $"{baseUri}/RolesConfiguration/{Id}"; 
            public static string AddRolesConfiguration(string baseUri) => $"{baseUri}/RolesConfiguration";
            public static string IsExist(string baseUri) => $"{baseUri}/RolesConfiguration/IsExist";
        }

        public static class IncidentCategory
        {
            public static string GetIncidentCategorys(string baseUri) => $"{baseUri}/IncidentCategory/GetIncidentCategories";
            public static string GetIncidentCategory(string baseUri) => $"{baseUri}/IncidentCategory/Get";
            public static string UpdateIncidentCategory(string baseUri, int Id) => $"{baseUri}/IncidentCategory/{Id}";
            public static string AddIncidentCategory(string baseUri) => $"{baseUri}/IncidentCategory/Post";
            public static string IsExist(string baseUri) => $"{baseUri}/IncidentCategory/IsExist";
        }

        public static class IncidentReport
        {
            public static string GetIncidentReports(string baseUri) => $"{baseUri}/IncidentReport/GetIncidentReports";
            public static string AddIncidentReport(string baseUri) => $"{baseUri}/IncidentReport/Post";
            public static string GetIncidentReport(string baseUri) => $"{baseUri}/IncidentReport/Get";
            public static string UpdateIncidentReport(string baseUri, int Id) => $"{baseUri}/IncidentReport/{Id}";
            public static string DeleteIncidentReport(string baseUri, int Id) => $"{baseUri}/IncidentReport/{Id}";
            public static string PutIncidentReportPhoto(string baseUri) => $"{baseUri}/IncidentReport/PutIncidentReportPhoto";
            public static string IsExist(string baseUri) => $"{baseUri}/IncidentReport/IsExist"; 
            public static string GetIncidentReportsList(string baseUri) => $"{baseUri}/IncidentReport/GetIncidentReportsList";            
            public static string IsIncidentCreated(string baseUri) => $"{baseUri}/IncidentReport/IsIncidentCreated"; 
            public static string GetSingleIncidentReportsList(string baseUri) => $"{baseUri}/IncidentReport/GetSingleIncidentReportsList"; 
            public static string GetAllIncidentDetails(string baseUri) => $"{baseUri}/IncidentReport/GetAllIncidents"; 
            public static string GetIncidentReportsForManagers(string baseUri) => $"{baseUri}/IncidentReport/GetIncidentReportsForManagers"; 
            public static string GetCountOfAllStatus(string baseUri) => $"{baseUri}/IncidentReport/GetAllStatusCount"; 
            public static string GetOpenClosedIncidentsReport(string baseUri) => $"{baseUri}/IncidentReport/GetOpenClosedIncidentsReport"; 
            public static string ExportXlsx(string baseUri) => $"{baseUri}/IncidentReport/ExportXlsx/";
            public static string GetReportedIncidents(string baseUri) => $"{baseUri}/IncidentReport/GetReportedIncidents";
            public static string GetImageBase64Content(string baseUri, int Id) => $"{baseUri}/IncidentReport/GetImageContent/{Id}";
        }

        public static class IncidentAssignment
        {
            public static string GetIncidentAssignments(string baseUri) => $"{baseUri}/IncidentAssignment/GetIncidentAssignments";
            public static string AddIncidentAssignment(string baseUri) => $"{baseUri}/IncidentAssignment/Post";
            public static string GetIncidentAssignment(string baseUri) => $"{baseUri}/IncidentAssignment/Get";
            public static string UpdateIncidentAssignment(string baseUri, int Id) => $"{baseUri}/IncidentAssignment/{Id}";
            public static string DeleteIncidentAssignment(string baseUri, int Id) => $"{baseUri}/IncidentAssignment/{Id}"; 
            public static string GetIncidentsForActionTaken(string baseUri) => $"{baseUri}/IncidentAssignment/GetIncidentsForActionTaken";
        }

        public static class ActionTakenReport
        {
            public static string GetActionTakenReports(string baseUri) => $"{baseUri}/ActionTakenReport/GetActionTakenReports";
            public static string AddActionTakenReports(string baseUri) => $"{baseUri}/ActionTakenReport/Post";
            public static string GetActionTakenReport(string baseUri) => $"{baseUri}/ActionTakenReport/Get";
            public static string UpdateActionTakenReport(string baseUri, int Id) => $"{baseUri}/ActionTakenReport/Put/{Id}";
            public static string DeleteActionTakenReport(string baseUri, int Id) => $"{baseUri}/ActionTakenReport/{Id}";
        }

        public static class Competency
        {
            public static string GetCompetencies(string baseUri) => $"{baseUri}/Competency/GetCompetencies";
            public static string GetAllCompetencies(string baseUri) => $"{baseUri}/Competency/GetAllCompetencies";
            public static string GetCompetency(string baseUri) => $"{baseUri}/Competency/GetCompetency";
            public static string UpdateCompetency(string baseUri) => $"{baseUri}/Competency/Update";
            public static string DeleteCompetency(string baseUri) => $"{baseUri}/Competency/Delete";
            public static string AddCompetency(string baseUri) => $"{baseUri}/Competency/Add";
            public static string IsExist(string baseUri) => $"{baseUri}/Competency/IsExist";

        }

        public static class SecurityQuestion
        {
            public static string GetAllSecurityQuestions(string baseUri) => $"{baseUri}/UserMaster/GetAllSecurityQuestions";
        }

            #endregion

            #region Notifications

            //public static class SMSNotifications
            //{
            //    public static string SendUserSignupOTP(string baseUri) => $"{baseUri}/SMS/SendOTP";
            //}

            public static class UserNotification
        {
            public static string GetUserNotifications(string baseUri) => $"{baseUri}/UserNotifications";
            public static string ReadNotification(string baseUri, int notificationId) => $"{baseUri}/UserNotifications/{notificationId}";
        }

            public static class SMSTemplates
        {
            public static string GetSMSTemplate(string baseUri, int Id) => $"{baseUri}/SMSTemplate/{Id}";
            public static string GetSMSTemplates(string baseUri, int page = 1, int pageSize = 10, string filter = null, string search = null)
            {
                if (filter == null || filter == "")
                    return $"{baseUri}/SMSTemplate/GetSMSTemplates/{page}/{pageSize}/";
                return $"{baseUri}/SMSTemplate/GetSMSTemplates/{page}/{pageSize}/{filter}/{search}";
            }
            public static string GetSMSTemplatesCount(string baseUri, string filter = null, string search = null)
            {
                if (filter == null || filter == "")
                    return $"{baseUri}/SMSTemplate/GetSMSTemplatesCount/";
                return $"{baseUri}/SMSTemplate/GetSMSTemplatesCount/{filter}/{search}";
            }
            public static string UpdateSMSTemplateInfo(string baseUri, int Id) => $"{baseUri}/SMSTemplate/{Id}";
            public static string ExportXlsx(string baseUri, string filter = null, string search = null)
            {
                if (filter == null || filter == "")
                    return $"{baseUri}/SMSTemplate/ExportXlsx/";
                return $"{baseUri}/SMSTemplate/ExportXlsx?filter={filter}&search={search}";
            }
        }
        #endregion
    }
}
