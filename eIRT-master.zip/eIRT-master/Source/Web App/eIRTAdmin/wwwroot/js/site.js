﻿// Please see documentation at https://docs.microsoft.com/aspnet/core/client-side/bundling-and-minification
// for details on configuring this project to bundle and minify static web assets.

//const { data } = require("jquery");

$(function () {

    $('#modal-container').on('show.bs.modal', function (event) {
        var button = $(event.relatedTarget);
        var url = button.attr("href");
        var modal = $(this);
        modal.find('.modal-content').load(url);
        
    });

    $('#modal-container').on('hidden.bs.modal', function () {
        $(this).removeData('bs.modal');
        $('#modal-container .modal-content').empty();
    });
});


$(".UserHover").click(function () {
    $(".userPanel").show();
    $(".userIcon").addClass("activeUserIcon").removeClass("userIconDeactive");
    $(".downArrow").addClass("activeDownArrow");
});
$(".closeBtn").click(function () {
    $(".userPanel").hide();
    $(".userIcon").removeClass("activeUserIcon").addClass("userIconDeactive");
    $(".downArrow").removeClass("activeDownArrow");
});

$(document).ready(function () {
    $('#PincodeForMyProfile').change(function () {
        var pincode = $(this).val();
        getStateByPincode(pincode);

        //TO disable a save button of form and enable after form has some changes
        $('#disableBtnSave').prop('disabled', true);
        $(".disableSaveButton").on("keyup change paste", "input, select, textarea", function () {
            $('#disableBtnSave').prop('disabled', false);
        });
    })
});

$(document).ajaxStart(function () {
    $("#loader").fadeIn(300);
    $('#loader').show();
});

$(document).ajaxError(function (event, jqxhr, settings, exception) {
    if (jqxhr.status == 401) {
        bootbox.alert({
            message: "Sorry! Either your session has been expired or You do not have access.",
            callback: function () {
                window.location.href = "Account/Login";
            }
        });
    }
    else {
        bootbox.alert({
            message: "Sorry! Internal Server Error...",
            callback: function () {
                location.reload();
            }
        });
    }
});

$(document).ajaxStop(function () {
    $("#loader").fadeOut(300);
    $('#loader').hide();
});

function showInPopup (url) {
    //alert("popup");
    $.ajax({
        type: 'GET',
        url: url,
        success: function (res) {
            $('#form-modal .modal-content').html(res);
            $('#form-modal').modal('show');
        }
    })
}

function showInLargePopup(url) {
    //alert("popup");
    $.ajax({
        type: 'GET',
        url: url,
        success: function (res) {
            $('#search-modal .modal-content').html(res);
            $('#search-modal').modal('show');
        }
    })
}

function jQueryAjaxPost(form) {
    try {
        event.preventDefault();
        event.stopImmediatePropagation();
        $.ajax({
            type: 'POST',
            url: form.action,
            data: new FormData(form),
            contentType: false,
            processData: false,
            success: function (res) {
                //alert("res.html " + res);
                if (res.isValid) {
                    $('#view-all').html(res.html)
                    $('#form-modal .modal-content').html('');
                    $('#form-modal').modal('hide');
                    //alert("Posted on Link :" + form.action);

                    $.notify(SuccessfullyAddedMsg ?? "Successfully Saved!", { globalPosition: "top center", className: "success" });
                    if (res.pageRefresh == undefined && res.pageRefresh == null && res.pageRefresh == true) {
                        setTimeout(function () {
                            location.reload();
                        }, 3000);
                    }
                }
                else {
                    $('#form-modal .modal-content').html(res.html);
                    if (res.message != undefined && res.message != null && res.message != "") {
                        $.notify("Failed to Saved! " + res.message, { globalPosition: "top center", className: "error" });
                    }
                    if (res.notify != undefined && res.notify != null && res.notify == false) { }
                    else {
                        $.notify(FailedtoAddMsg ?? "Failed to Saved!", { globalPosition: "top center", className: "error" });
                    }
                }
            },
            error: function (err) {
                //alert("error" + JSON.stringify(err));
                console.log(err)
            }
        })
        //to prevent default form submit event
        return false;
    } catch (ex) {
        console.log(ex)
    }
}

function jQueryAjaxPut(form) {
    try {
        event.preventDefault();
        event.stopImmediatePropagation();
        $.ajax({
            type: 'POST',
            url: form.action,
            data: new FormData(form),
            contentType: false,
            processData: false,
            success: function (res) {
                if (res.isValid) {
                    $('#view-all').html(res.html)
                    $('#form-modal .modal-content').html('');
                    $('#form-modal').modal('hide');
                    //alert("Posted on Link :" + form.action);
                    $.notify(SuccessfullyUpdatedMsg ?? "Successfully Saved!", { globalPosition: "top center", className: "success" });
                    if (res.pageRefresh == undefined && res.pageRefresh == null && res.pageRefresh == true) {
                        setTimeout(function () {
                            location.reload();
                        }, 5000);
                    }
                }
                else {
                    $('#form-modal .modal-content').html(res.html);
                    if (res.message != undefined && res.message != null && res.message != "") {
                        $.notify("Failed to Saved! " + res.message, { globalPosition: "top center", className: "error" });
                    }
                    else {
                        $.notify("Failed to Saved!", { globalPosition: "top center", className: "error" });
                    }
                }
            },
            error: function (err) {
                console.log(err)
            }
        })
        //to prevent default form submit event
        return false;
    } catch (ex) {
        console.log(ex)
    }
}

function jQueryAjaxPostNoResultSet(form) {
    var pageNumber = $("#page").val();
    if (pageNumber == undefined || pageNumber == null || pageNumber == "" || parseInt(pageNumber) < 1)
        pageNumber = 1;
    try {
        event.preventDefault();
        event.stopImmediatePropagation();
        $.ajax({
            type: 'POST',
            url: form.action,
            data: new FormData(form),
            contentType: false,
            processData: false,
            success: function (res) {
                if (res.isValid) {
                    $('#form-modal .modal-content').html('');
                    $('#form-modal').modal('hide');
                    submitSearchDataOnPageChange(pageNumber);
                    $.notify(SuccessMsg == null ? "Successfully saved!" : SuccessMsg, { globalPosition: "top center", className: "success" });
                }
                else {
                    $('#form-modal .modal-content').html(res.html);
                    if (res.message != null && res.message != "") {
                        "Error! Could not save! : " + res.message;
                    }
                    $.notify("Error! Could not save!", { globalPosition: "top center", className: "error" });
                }
            },
            error: function (err) {
                $.notify("Error! Could not save!", { globalPosition: "top center", className: "error" });
                console.log(err);
            }
        })
        //to prevent default form submit event
        return false;
    } catch (ex) {
        console.log(ex)
    }
}

function jQueryAjaxPostNoModal(form) {
    try {
        event.preventDefault();
        event.stopImmediatePropagation();
        $.ajax({
            type: 'POST',
            url: form.action,
            data: new FormData(form),
            contentType: false,
            processData: false,
            success: function (res) {
                if (res.isValid) {
                    $('#view-all').html(res.html)
                    //alert("Successfully :" + res.html);
                    $.notify(SuccessMsg ?? "Successfull!", { globalPosition: "top center", className: "success" });
                }
                else {
                    //alert("Failed :" + res.html);
                    $('#view-all').html(res.html)
                    $.notify(FailedMsg ?? "Failed!", { globalPosition: "top center", className: "error" });
                }
            },
            error: function (err) {
                console.log(err)
            }
        })
        //to prevent default form submit event
        return false;
    } catch (ex) {
        console.log(ex)
    }
}

function jQueryAjaxSearch(form) {
    try {
        event.preventDefault();
        event.stopImmediatePropagation();
        $.ajax({
            type: 'POST',
            url: form.action,
            data: new FormData(form),
            contentType: false,
            processData: false,
            success: function (res) {
                if (res.isValid) {
                    $('#view-all-Search').html(res.html)

                }
                else {
                    $('#form-modal .modal-content').html(res.html);
                    $.notify(FailedtoUpdateMsg ?? "Failed to Saved!", { globalPosition: "top center", className: "error" });
                }
            },
            error: function (err) {
                console.log(err)
            }
        })
        //to prevent default form submit event
        return false;
    } catch (ex) {
        console.log(ex)
    }
}

/*Get State and City by Pincode for User Profile*/
function getStateByPincode(pincode) {
    //alert("Pincode" + pincode)
    $.ajax({
        //url: '@Url.Action("GetStateByPincode", "UserProfile")',
        url: 'GetStateByPincodeUserProfile',
        type: "GET",
        data: { pincode: pincode },
        error: function (xhr, ajaxOptions, thrownError) {
            alert("xhr status: " + xhr.status);
            alert("Thrown Error" + thrownError);
        },
        success: function (result) {
            //alert("Items result :" + JSON.stringify(result));
            if (result != undefined && result != null && result.stateCode != null) {
                //console.log(result.stateCode);
                $('#State option:selected').removeAttr('selected');
                $('#State option[value=' + result.stateCode + ']').attr("selected", "selected");
                $('#State').attr('readonly', true);
                $('#State').attr("style", "pointer-events:none;");
                $("#City").val(result.city);
                $('#City').attr('readonly', true);
            } else if (result.pincode == 0 && result.stateCode == null) {
                $('#State').attr('readonly', false);
                $('#State').attr("style", "pointer-events:visible;");
                $('#State option[value=""]').attr("selected", "selected");
                $("#City").attr('readonly', false).val("");
            } else {
                $('#State option[value=""]').attr("selected", "selected");
                $("#City").val(result.city);
            }
        },
    });
}

document.addEventListener("DOMContentLoaded", function (event) {

    const showNavbar = (toggleId, navId, bodyId, headerId) => {
        const toggle = document.getElementById(toggleId),
            nav = document.getElementById(navId),
            bodypd = document.getElementById(bodyId),
            headerpd = document.getElementById(headerId)

        // Validate that all variables exist
        if (toggle && nav && bodypd && headerpd) {
            toggle.addEventListener('click', () => {
                // show navbar
                nav.classList.toggle('shownav')
                bodypd.classList.toggle('body-pd')
                headerpd.classList.toggle('body-pd')
            })
        }
    }
    showNavbar('header-toggle', 'nav-bar', 'body-pd', 'header');
});

function menuActivation(menuId) {
    $(".nav_list").find("a.active").removeClass("active");
    $("#" + menuId).addClass("active");
}

Object.defineProperty(String.prototype, 'capitalize', {
    value: function () {
        return (this.charAt(0).toUpperCase() + this.slice(1)).replace(/([A-Z]+)/g, ' $1').trim();
    },
    enumerable: false
});

function GetListOfHeaderForExport(DataObj) {
    var headerArr = [];
    try {
        var headers = Object.getOwnPropertyNames(DataObj);

        for (var i = 0; i < headers.length; i++) {
            headerArr.push({
                alias: headers[i].capitalize(), //headers[i].toString().replace(/([A-Z]+)/g, ' $1').trim(),
                name: headers[i],
                flex: 1
            });
        }
    }
    catch (err) {
        console.log("Error: " + JSON.stringify(err));
    }
    return headerArr;
}

function Export(ExportInto, HeaderArr, DataArr, Title) {
    try {
        //console.log("ExportInto: " + ExportInto + " HeaderArr: " + JSON.stringify(HeaderArr) + " DataArr : " + DataArr + " Title : " + Title);
        if (ExportInto == "xls") {
            objectExporter({
                type: 'xls',
                documentTitle: Title,
                documentTitleStyle: 'font-size:18px; font-weight:bold; color:' + themeColor + ';',
                exportable: DataArr,
                headers: HeaderArr,
                fileName: Title.replace(" ", "_"),
                headerStyle: 'font-size:16px; font-weight:bold; color:' + themeColor + ';border: 1px solid ' + themeColor + ';',
                cellStyle: 'color:' + themeColor + '; border: 1px solid ' + themeColor + ';',
                sheetName: 'Users'
            })
        }
        if (ExportInto == "pdf") {
            objectExporter({
                type: 'pdf',
                exportable: DataArr,
                headers: HeaderArr,
                repeatHeader: true,
                fileName: Title.replace(" ", "_"),
                documentTitle: Title,
                documentTitleStyle: 'font-size:18px; margin-bottom:10px; font-weight: bold; text-align:center; color: ' + themeColor + ';',
                headerStyle: 'font-size:16px; font-weight: bold; padding: 5px; border: 1px solid ' + themeColor + '; color: ' + themeColor + '; background-color: ' + rgbColorResult + ';' ,
                cellStyle: 'border: 1px solid ' + themeColor + '; margin-bottom: -1px;'
            })
        }
    }
    catch (err) {
        console.log(JSON.stringify(err));
    }
}

//function AnyMatchInArray(targetArr, checkArr) {
//    //"use strict";
//    var result = false;
//    if (targetArr == null || checkArr == null || targetArr.length < 1 || checkArr.length < 1) {
//        return result;
//    }
//    else {
//        result = function (checkArr) {
//            var found = false;
//            for (var i = 0, j = checkArr.length; !found && i < j; i++) {
//                if (targetArr.indexOf(checkArr[i]) > -1) {
//                    found = true;
//                }
//            }
//            return found;
//        };
//        return result;
//    }
//}

function AnyMatchInArray(targetArr, checkArr) {
    var result = false;
    if (targetArr == null || checkArr == null || targetArr.length < 1 || checkArr.length < 1) {
        return result;
    }
    else {
        for (var i = 0; i < checkArr.length; i++) {
            if (targetArr.indexOf(checkArr[i]) > -1) {
                result = true;
                break;
            }
        }
    }
    return result;
}


