﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace eIRTAdmin
{
    public class AppSettings
    {
        public string AdminUrl { get; set; }
        public string AppUserUrl { get; set; }
        public string IdentityUrl { get; set; }
        public string NotificationUrl { get; set; }
        public string VersionReleaseNoteDocPath { get; set; }
        public string BankIconPath { get; set; }
        public string ProductImagePath { get; set; }
        public string ProductDocumentPath { get; set; }
        public string BrandingCompanyLogoPath { get; set; }
        public string BrandingProductLogoPath { get; set; }
        public string BusinessLineIconPath { get; set; }
        public string MyBusinessLogoPath { get; set; }
        public string UserProfilePicPath { get; set; }
        public string OrganizationLogoPath { get; set; }
        public string IncidentReportPhotoPath { get; set; }
    }
}
