﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using eIRTAdmin.Models;
using eIRTAdmin.Models.APIModels;

namespace eIRTAdmin.Mapping
{
    public class ModelToResourceProfile : Profile
    {
        public ModelToResourceProfile()
        {
            CreateMap<APIUserDetailsForExport, APIUserDetails>();
            CreateMap<APIUserDetails, APIUserDetailsForExport>();

            CreateMap<APIOpenClosedIncidentInfoExport, APIOpenClosedIncidentInfo>();
            CreateMap<APIOpenClosedIncidentInfo, APIOpenClosedIncidentInfoExport>();
        }
    }
}
