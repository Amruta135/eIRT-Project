using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using eIRTAdmin.Services;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Http;
using AutoMapper;
using Microsoft.AspNetCore.Mvc.Infrastructure;
using eIRTAdmin.Services.Interface;
using Microsoft.AspNetCore.Mvc.Razor;
using System;
using Ocelot.DependencyInjection;
using Ocelot.Middleware;

namespace eIRTAdmin
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddOcelot(Configuration);

            services.AddHttpClient<IAdminMasterService, AdminMasterService>();
            services.AddHttpClient<IUserMasterService, UserMasterService>();
            services.AddHttpClient<IUserProfileService, UserProfileService>();
            services.AddHttpClient<IUserIdentityService, UserIdentityService>();
            services.AddHttpClient<IUserDetailsService, UserDetailsService>();
            services.AddHttpClient<IStatesService, StatesService>();
            services.AddSingleton<IActionContextAccessor, ActionContextAccessor>();
            services.AddHttpClient<IPinCodeService, PinCodeService>();
            services.AddHttpClient<IUserNotificationService, UserNotificationService>();
            services.AddHttpClient<ILoginAssistanceService, LoginAssistanceService>();
            services.AddHttpClient<IOrganizationInfoService, OrganizationInfoService>();
            services.AddHttpClient<IDepartmentService, DepartmentService>();
            services.AddHttpClient<IRolesConfigurationService, RolesConfigurationService>();
            services.AddHttpClient<IIncidentCategoryService, IncidentCategoryService>();
            services.AddHttpClient<IIncidentReportService, IncidentReportService>();
            services.AddHttpClient<IIncidentAssignmentService, IncidentAssignmentService>();
            services.AddHttpClient<IActionTakenReportService, ActionTakenReportService>();
            services.AddHttpClient<ISecurityQuestionService, SecurityQuestionService>();
            services.AddHttpClient<ICompetencyService, CompetencyService>();

            //services.AddHttpContextAccessor();
            services.AddSingleton<IHttpContextAccessor, HttpContextAccessor>();
            //services.AddTransient<Infrastructure.ClaimCookie>();

            services.AddControllersWithViews();
            services.AddOptions();
            services.Configure<AppSettings>(Configuration);
            services.AddDataProtection();

            var mappingConfig = new MapperConfiguration(mc =>
            {
                mc.AddProfile(new Mapping.ModelToResourceProfile());
            });
            IMapper mapper = mappingConfig.CreateMapper();
            services.AddSingleton(mapper);
            services.AddAuthentication(options =>
            {
                options.DefaultScheme = CookieAuthenticationDefaults.AuthenticationScheme;
            })
                //(CookieAuthenticationDefaults.AuthenticationScheme)
                .AddCookie(options => {
                    options.LoginPath = "/account/login";
                    options.ExpireTimeSpan = TimeSpan.FromHours(3.55);
                    options.LogoutPath = "/account/logout";
                    options.AccessDeniedPath = "/Home/UnauthorizedError";
                });
            services.AddAntiforgery(options => { options.Cookie.Expiration = TimeSpan.Zero; });
            //services.ConfigureApplicationCookie(options => {
            //    options.Events.OnRedirectToLogin = context =>
            //    {
            //        context.Response.StatusCode = (int)HttpStatusCode.Unauthorized;
            //        return Task.CompletedTask;
            //    };
            //});
            services.AddControllersWithViews();
            services.AddSession(options => {
                options.IdleTimeout = TimeSpan.FromHours(3.55);
            });
            services.AddMvc()
               .AddViewLocalization(LanguageViewLocationExpanderFormat.Suffix)
               .AddDataAnnotationsLocalization();
        }
        
        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            app.UseSession();
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            else
            {
                app.UseExceptionHandler("/Account/Logout");
            }

            var cookiePolicyOptions = new CookiePolicyOptions
            {
                MinimumSameSitePolicy = SameSiteMode.Strict,
            };
            app.UseCookiePolicy(cookiePolicyOptions);

            app.UseStaticFiles();

            app.UseRouting();
            app.UseAuthentication();
            app.UseAuthorization();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllerRoute(
                    name: "default",
                    pattern: "{controller=Account}/{action=Login}/{id?}");
            });

            app.UseOcelot().Wait();
        }
    }
}
