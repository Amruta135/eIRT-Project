﻿using Microsoft.Extensions.Configuration;
using NETCore.Encrypt;
using System;
using System.IO;
using System.Security.Cryptography;
using System.Text;

namespace Identity.API.Helper
{
    public static class Security
    {
        public static IConfigurationRoot Configuration { get; set; }

        static Security()
        {
            var builder = new ConfigurationBuilder()
                .SetBasePath(Directory.GetCurrentDirectory())
                .AddJsonFile("appsettings.json");

            Configuration = builder.Build();
        }

        public static string EncryptSHA512(this string encrypt)
        {
            try
            {
                return EncryptProvider.Sha512(encrypt);
            }
            catch (Exception)
            {
                return encrypt;
            }
        }
        public static string Decrypt(string decryptText)
        {
            string Key = "9z8x7c1m2n3b5l4k";
            System.Text.UTF8Encoding encoding = new System.Text.UTF8Encoding();

            RijndaelManaged rijndaelCipher = new RijndaelManaged();
            rijndaelCipher.Mode = CipherMode.CBC;
            rijndaelCipher.Padding = PaddingMode.PKCS7;

            rijndaelCipher.KeySize = 0x80;
            rijndaelCipher.BlockSize = 0x80;

            byte[] encryptedData = Convert.FromBase64String(decryptText);
            byte[] pwdBytes = Encoding.UTF8.GetBytes(Key);
            byte[] keyBytes = new byte[0x10];
            int len = pwdBytes.Length;
            if (len > keyBytes.Length)
            {
                len = keyBytes.Length;
            }
            Array.Copy(pwdBytes, keyBytes, len);
            rijndaelCipher.Key = keyBytes;
            rijndaelCipher.IV = keyBytes;
            byte[] plainText = rijndaelCipher.CreateDecryptor().TransformFinalBlock(encryptedData, 0, encryptedData.Length);
            return encoding.GetString(plainText);
        }
    }
}
