﻿using AspNet.Security.OpenIdConnect.Extensions;
using AspNet.Security.OpenIdConnect.Primitives;
using AspNet.Security.OpenIdConnect.Server;
using Identity.API.Helper;
using Identity.API.Models;
using Identity.API.Repositories.Interface;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using OpenIddict.Abstractions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;

namespace Identity.API.Controllers
{
    [Route("api/[controller]")]
    //[ApiController]
    public class AuthorizationController : ControllerBase
    {
        private readonly IAdminMasterRepository _adminMasterRepository;
        private readonly IOptions<IdentityOptions> _identityOptions;
        private readonly ILoggedInHistoryRepository _loggedInHistoryRepository;
        public AuthorizationController(IAdminMasterRepository adminMasterRepository,
                                       IOptions<IdentityOptions> identityOptions,
                                       ILoggedInHistoryRepository loggedInHistoryRepository)
        {
            _adminMasterRepository = adminMasterRepository;
            _identityOptions = identityOptions;
            _loggedInHistoryRepository = loggedInHistoryRepository;
        }

        [HttpPost("~/connect/token"), Produces("application/json")]
        public async Task<IActionResult> Exchange(OpenIdConnectRequest openIdRequest)
        {
            try
            {
                string requestUsername = null;
                string requestPassword = null;
                string requestOrganizationCode = null;
                bool loggedInFromWeb = false;

                var loggedInWeb = (string)openIdRequest.GetParameter("loggedinweb");
                var organizationCode = (string)openIdRequest.GetParameter("organizationcode");
                var imei = "";


                if (IsLoggedInFromWeb(loggedInWeb) == true)
                {
                    string encryptedUsername = Security.Decrypt(openIdRequest.Username);
                    string encryptedPassword = Security.Decrypt(openIdRequest.Password);
                    string encryptedOrganizationCode = Security.Decrypt(organizationCode);
                    requestUsername = encryptedUsername.Substring(0, (encryptedUsername.Length) - 4);
                    requestPassword = encryptedPassword.Substring(0, (encryptedPassword.Length) - 4);
                    requestOrganizationCode = encryptedOrganizationCode.Substring(0, (encryptedOrganizationCode.Length) - 4);
                    requestPassword = Security.EncryptSHA512(requestPassword);
                    loggedInFromWeb = true;
                }
                else
                {
                    string encryptedUsername = Security.Decrypt(openIdRequest.Username);
                    string encryptedPassword = Security.Decrypt(openIdRequest.Password);
                    string encryptedOrganizationCode = Security.Decrypt(organizationCode);
                    requestUsername = encryptedUsername.Substring(0, (encryptedUsername.Length) - 4);
                    requestPassword = encryptedPassword.Substring(0, (encryptedPassword.Length) - 4);
                    requestOrganizationCode = encryptedOrganizationCode.Substring(0, (encryptedOrganizationCode.Length) - 4);
                    requestPassword = Security.EncryptSHA512(requestPassword);
                    loggedInFromWeb = false;
                }

                AdminInfo admin = new AdminInfo();
                admin = await _adminMasterRepository.GetAdminByCredentials(requestUsername, requestPassword, requestOrganizationCode);

                if (admin == null)
                {
                    return BadRequest(new OpenIdConnectResponse
                    {
                        Error = OpenIdConnectConstants.Errors.InvalidGrant,
                        ErrorDescription = "Invalid Credentials! Please retry"
                    });
                }

                // Create a new ClaimsIdentity holding the user identity.
                var identity = new ClaimsIdentity(
                    OpenIdConnectServerDefaults.AuthenticationScheme,
                    OpenIdConnectConstants.Claims.Name,
                     OpenIdConnectConstants.Claims.Role
                   );

                // Add a "sub" claim containing the user identifier, and attach
                // the "access_token" destination to allow OpenIddict to store it
                // in the access token, so it can be retrieved from your controllers.
                identity.AddClaim(OpenIdConnectConstants.Claims.Subject, admin.Id.ToString(),
                    OpenIdConnectConstants.Destinations.AccessToken);
                identity.AddClaim(OpenIdConnectConstants.Claims.Name, admin.Name,
                    OpenIdConnectConstants.Destinations.AccessToken);
                identity.AddClaim(OpenIdConnectConstants.Claims.Role, admin.Role,
                   OpenIdConnectConstants.Destinations.AccessToken);
                identity.AddClaim(OpenIdConnectConstants.Claims.KeyId, admin.OrganizationCode,
                   OpenIdConnectConstants.Destinations.AccessToken);

                var principal = new ClaimsPrincipal(identity);
                // Ask OpenIddict to generate a new token and return an OAuth2 token response.

                string resourses = "user_api,notification_api";
                string[] resourceServers = resourses.Split(",");

                var browserInfo = (string)openIdRequest.GetParameter("browserinfo");
                var ipAddress = (string)openIdRequest.GetParameter("ipaddress");

                await this._loggedInHistoryRepository.SetLoggedInHistoryTime(admin.Id, loggedInWeb, imei, browserInfo, ipAddress);

                var ticket = new AuthenticationTicket(principal, null, OpenIdConnectServerDefaults.AuthenticationScheme); ticket.SetScopes(openIdRequest.GetScopes());
                ticket.SetResources(resourceServers);

                if (loggedInFromWeb)
                {
                    ticket.SetIdentityTokenLifetime(TimeSpan.FromHours(4));
                    ticket.SetAccessTokenLifetime(TimeSpan.FromHours(4));
                    ticket.SetAuthorizationCodeLifetime(TimeSpan.FromHours(4));
                }
                else
                {
                    ticket.SetIdentityTokenLifetime(TimeSpan.FromDays(7));
                    ticket.SetAccessTokenLifetime(TimeSpan.FromDays(7));
                    ticket.SetAuthorizationCodeLifetime(TimeSpan.FromDays(7));
                }

                return SignIn(principal, ticket.Properties, OpenIdConnectServerDefaults.AuthenticationScheme);
            }
            catch (System.Exception ex)
            {
                return this.BadRequest(new ResponseMessage { StatusCode = 400, Message = EnumHelper.GetEnumName(MessageType.InvalidCredentials), Description = EnumHelper.GetEnumDescription(MessageType.InvalidCredentials) /*ex.Message + ex.StackTrace*/ });
                //return this.BadRequest(new ResponseMessage { StatusCode = 400, Message = EnumHelper.GetEnumName(MessageType.InvalidCredentials), Description = ex.Message + ex.StackTrace });
            }
        }

        private bool IsLoggedInFromWeb(string loggedInWeb)
        {
            try
            {
                bool? inWebLogin = null;

                if (!string.IsNullOrEmpty(loggedInWeb))
                {
                    inWebLogin = Convert.ToBoolean(Convert.ToInt32(loggedInWeb));
                    if (inWebLogin == true)
                        return true;
                    else
                        return false;
                }
            }
            catch (Exception)
            {

            }
            return false;
        }

        private bool IsMPinAuthentication(string mpinAuthentication)
        {
            try
            {
                bool? ismpinAuthentication = null;

                if (!string.IsNullOrEmpty(mpinAuthentication))
                {
                    ismpinAuthentication = Convert.ToBoolean(Convert.ToInt32(mpinAuthentication));
                    if (ismpinAuthentication == true)
                        return true;
                    else
                        return false;
                }
            }
            catch (Exception)
            {

            }
            return false;
        }
        private bool IsBiometricAuthentication(string biometricAuthentication)
        {
            try
            {
                bool? isBiometricAuthentication = null;

                if (!string.IsNullOrEmpty(biometricAuthentication))
                {
                    isBiometricAuthentication = Convert.ToBoolean(Convert.ToInt32(biometricAuthentication));
                    if (isBiometricAuthentication == true)
                        return true;
                    else
                        return false;
                }
            }
            catch (Exception)
            {

            }
            return false;
        }

        [HttpPost("~/connect/logout")]
        public IActionResult Logout()
        {

            var result = SignOut(OpenIdConnectServerDefaults.AuthenticationScheme);
            return result;
        }

        [HttpGet("~/connect/authorize")]
        public async Task<IActionResult> Authorize(OpenIdConnectRequest openIdRequest)
        {
            if (!User.Identity.IsAuthenticated)
            {
                // If the client application request promptless authentication,
                // return an error indicating that the user is not logged in.
                if (openIdRequest.HasPrompt(OpenIdConnectConstants.Prompts.None))
                {
                    var properties = new Microsoft.AspNetCore.Authentication.AuthenticationProperties(new Dictionary<string, string>
                    {
                        [OpenIdConnectConstants.Properties.Error] = OpenIdConnectConstants.Errors.LoginRequired,
                        [OpenIdConnectConstants.Properties.ErrorDescription] = "The user is not logged in."
                    });

                    // Ask OpenIddict to return a login_required error to the client application.
                    return Forbid(properties, OpenIdConnectServerDefaults.AuthenticationScheme);
                }

                return Challenge();
            }

            // Retrieve the profile of the logged in user.
            //var user = await _userManager.GetUserAsync(User);
            AdminInfo admin = new AdminInfo();

            admin = await _adminMasterRepository.GetAdminByCredentials(openIdRequest.Username, openIdRequest.Password, "");

            if (admin == null)
            {
                //return View("Error", new ErrorViewModel
                //{
                //    Error = OpenIdConnectConstants.Errors.ServerError,
                //    ErrorDescription = "An internal error has occurred"
                //});
            }

            // Create a new authentication ticket.
            var ticket = await CreateTicketAsync(openIdRequest, admin);

            // Returning a SignInResult will ask OpenIddict to issue the appropriate access/identity tokens.
            return SignIn(ticket.Principal, ticket.Properties, ticket.AuthenticationScheme);
        }

        [HttpGet("~/connect/introspect")]
        private async Task<AuthenticationTicket> CreateTicketAsync(OpenIdConnectRequest request, AdminInfo admin)
        {
            AdminInfo adminInfo = new AdminInfo();

            adminInfo = await _adminMasterRepository.GetAdminByCredentials(request.Username, request.Password, "");

            if (adminInfo == null)
            {
                return null;
            }

            // Create a new ClaimsIdentity holding the user identity.
            var identity = new ClaimsIdentity(
                OpenIdConnectServerDefaults.AuthenticationScheme,
                OpenIdConnectConstants.Claims.Name,
                 OpenIdConnectConstants.Claims.Role
               );

            // Add a "sub" claim containing the user identifier, and attach
            // the "access_token" destination to allow OpenIddict to store it
            // in the access token, so it can be retrieved from your controllers.
            //identity.AddClaim(OpenIdConnectConstants.Claims.Subject,
            //    user.UserId.ToString(),
            //    OpenIdConnectConstants.Destinations.AccessToken);
            //identity.AddClaim(OpenIdConnectConstants.Claims.Name, user.Name,
            //    OpenIdConnectConstants.Destinations.AccessToken);
            //identity.AddClaim(OpenIdConnectConstants.Claims.Role, user.Role,
            //   OpenIdConnectConstants.Destinations.AccessToken);

            identity.AddClaim(OpenIdConnectConstants.Claims.Subject, admin.Id.ToString(),
                 OpenIdConnectConstants.Destinations.AccessToken);
            identity.AddClaim(OpenIdConnectConstants.Claims.Name, admin.Name,
                OpenIdConnectConstants.Destinations.AccessToken);
            identity.AddClaim(OpenIdConnectConstants.Claims.Role, admin.Role,
               OpenIdConnectConstants.Destinations.AccessToken);
            identity.AddClaim(OpenIdConnectConstants.Claims.Username, admin.EmployeeCode,
               OpenIdConnectConstants.Destinations.AccessToken);

            // ... add other claims, if necessary.
            var principal = new ClaimsPrincipal(identity);

            // Create a new authentication ticket holding the user identity.
            var ticket = new AuthenticationTicket(principal,
                new Microsoft.AspNetCore.Authentication.AuthenticationProperties(),
                OpenIdConnectServerDefaults.AuthenticationScheme);

            // Set the list of scopes granted to the client application.
            ticket.SetScopes(new[]
            {
                OpenIdConnectConstants.Scopes.OpenId,
                OpenIdConnectConstants.Scopes.Email,
                OpenIdConnectConstants.Scopes.Profile,
                OpenIddictConstants.Scopes.Roles
            }.Intersect(request.GetScopes()));


            // Note: by default, claims are NOT automatically included in the access and identity tokens.
            // To allow OpenIddict to serialize them, you must attach them a destination, that specifies
            // whether they should be included in access tokens, in identity tokens or in both.

            foreach (var claim in ticket.Principal.Claims)
            {
                // Never include the security stamp in the access and identity tokens, as it's a secret value.
                if (claim.Type == _identityOptions.Value.ClaimsIdentity.SecurityStampClaimType)
                {
                    continue;
                }

                var destinations = new List<string>
                {
                    OpenIdConnectConstants.Destinations.AccessToken
                };

                // Only add the iterated claim to the id_token if the corresponding scope was granted to the client application.
                // The other claims will only be added to the access_token, which is encrypted when using the default format.
                if ((claim.Type == OpenIdConnectConstants.Claims.Name && ticket.HasScope(OpenIdConnectConstants.Scopes.Profile)) ||
                    (claim.Type == OpenIdConnectConstants.Claims.Email && ticket.HasScope(OpenIdConnectConstants.Scopes.Email)) ||
                    (claim.Type == OpenIdConnectConstants.Claims.Role && ticket.HasScope(OpenIddictConstants.Claims.Roles)))
                {
                    destinations.Add(OpenIdConnectConstants.Destinations.IdentityToken);
                }

                claim.SetDestinations(destinations);
            }
            return ticket;
        }
    }
}