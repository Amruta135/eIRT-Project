﻿using Identity.API.Data;
using Identity.API.Models;
using Identity.API.Repositories.Interface;
using Microsoft.EntityFrameworkCore;
using System;
using System.Linq;
using System.Threading.Tasks;

namespace Identity.API.Repositories
{
    public class AdminMasterRepository : Repository<UserMaster>, IAdminMasterRepository
    {
        private IdentityDbContext _db;
        public AdminMasterRepository(IdentityDbContext context) : base(context)
        {
            this._db = context;
        }

        public async Task<AdminInfo> GetAdminByCredentials(string userid, string password, string organizationCode)
        {
            var adminInfo = (from userMaster in _db.UserMaster
                             where ((userMaster.EmployeeCode == userid || userMaster.MobileNumber == userid) && userMaster.Password == password && userMaster.IsDeleted == false && userMaster.OrganizationCode == organizationCode) || (String.Equals(userMaster.EmployeeCode, userid) && userMaster.Password == password && userMaster.IsDeleted == false && userMaster.OrganizationCode == organizationCode)
                             select new AdminInfo { Id = userMaster.Id, EmployeeCode = userMaster.EmployeeCode, Name = userMaster.Name, Role = userMaster.Role, OrganizationCode = userMaster.OrganizationCode });

            return await adminInfo.AsNoTracking().FirstOrDefaultAsync();
        }
    }
}
