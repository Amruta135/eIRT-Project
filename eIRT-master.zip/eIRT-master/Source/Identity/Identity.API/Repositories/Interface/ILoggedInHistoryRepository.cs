﻿using Identity.API.Models;
using System.Threading.Tasks;

namespace Identity.API.Repositories.Interface
{
    public interface ILoggedInHistoryRepository : IRepository<LoggedInHistory>
    {
        Task<bool> SetLoggedInHistoryTime(int userId, string loggedInWeb, string imei, string browserInfo, string ipAddress);
    }
}
