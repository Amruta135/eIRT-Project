﻿using Identity.API.Models;
using System.Threading.Tasks;

namespace Identity.API.Repositories.Interface
{
    public interface IAdminMasterRepository : IRepository<UserMaster>
    {
        Task<AdminInfo> GetAdminByCredentials(string userid, string password, string requestOrganizationCode);
        //Task<AdminInfo> GetAdminByCredentials(string userid, string password, bool isMPinAuthentication, string mpin, string imei, bool isBiometricAuthentication);
    }
}
