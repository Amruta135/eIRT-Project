﻿using Identity.API.Data;
using Identity.API.Models;
using Identity.API.Repositories.Interface;
using System;
using System.Threading.Tasks;

namespace Identity.API.Repositories
{
    public class LoggedInHistoryRepository : Repository<LoggedInHistory>, ILoggedInHistoryRepository
    {
        private IdentityDbContext _db;
        public LoggedInHistoryRepository(IdentityDbContext context) : base(context)
        {
            this._db = context;
        }

        public async Task<bool> SetLoggedInHistoryTime(int userId, string loggedInWeb, string imei, string browserInfo, string ipAddress)
        {
            try
            {
                bool? inWebLogin = null;

                if (!string.IsNullOrEmpty(loggedInWeb))
                    inWebLogin = Convert.ToBoolean(Convert.ToInt32(loggedInWeb));

                LoggedInHistory loggedInHistory = new LoggedInHistory
                {
                    UserMasterId = userId,
                    IsLoggedInWeb = inWebLogin,
                    LoggedInTime = DateTime.Now,
                    IEMI = imei,
                    BrowserInfo = browserInfo,
                    IPAddress = ipAddress
                };
                await this.AddAsync(loggedInHistory);
            }
            catch (Exception)
            {

            }
            return true;
        }
    }
}
