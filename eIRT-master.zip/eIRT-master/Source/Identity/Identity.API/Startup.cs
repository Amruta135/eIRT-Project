﻿using AspNet.Security.OpenIdConnect.Primitives;
using Identity.API.Data;
using Identity.API.Models;
using Identity.API.Repositories;
using Identity.API.Repositories.Interface;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using OpenIddict.Abstractions;

namespace Identity.API
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddMvc(option => option.EnableEndpointRouting = false);

            var connection = Configuration.GetConnectionString("DefaultConnection");

            services.AddDbContext<IdentityDbContext>(options =>
            {
                options.UseSqlServer(Configuration.GetConnectionString("DefaultConnection"));
                options.UseOpenIddict();
            });

            services.AddIdentity<UserMaster, IdentityRole>();
            //.AddEntityFrameworkStores<IdentityDbContext>();

            // Configure Identity to use the same JWT claims as OpenIddict instead
            // of the legacy WS-Federation claims it uses by default (ClaimTypes),
            // which saves you from doing the mapping in your authorization controller.
            services.Configure<IdentityOptions>(options =>
            {
                options.ClaimsIdentity.UserNameClaimType = OpenIdConnectConstants.Claims.Name;
                options.ClaimsIdentity.UserIdClaimType = OpenIdConnectConstants.Claims.Subject;
                options.ClaimsIdentity.RoleClaimType = OpenIdConnectConstants.Claims.Role;
            });

            services.AddOpenIddict()
                // Register the OpenIddict core services.
                .AddCore(options =>
                {
                    // Register the Entity Framework stores and models.
                    options.UseEntityFrameworkCore()
                           .UseDbContext<IdentityDbContext>();
                })
                // Register the OpenIddict server handler.
                .AddServer(options =>
                {
                    options.UseMvc();
                    // Enable the authorization, logout, userinfo, and introspection endpoints.
                    options.EnableAuthorizationEndpoint("/connect/authorize")
                           .EnableLogoutEndpoint("/connect/logout")
                           .EnableIntrospectionEndpoint("/connect/introspect")
                           .EnableTokenEndpoint("/connect/token")
                           .EnableUserinfoEndpoint("/api/userinfo");

                    // Note: the sample only uses the implicit code flow but you can enable
                    // the other flows if you need to support implicit, password or client credentials.
                    options.AllowImplicitFlow();

                    // Mark the "email", "profile" and "roles" scopes as supported scopes.
                    options.RegisterScopes(OpenIdConnectConstants.Scopes.Email,
                               OpenIdConnectConstants.Scopes.Profile,
                               OpenIddictConstants.Scopes.Roles);

                    //options.EnableRequestCaching();

                    // During development, you can disable the HTTPS requirement.
                    options.DisableHttpsRequirement();

                    // Register a new ephemeral key, that is discarded when the application
                    // shuts down. Tokens signed using this key are automatically invalidated.
                    // This method should only be used during development.
                    options.AddEphemeralSigningKey();
                    //options.UseJsonWebTokens();

                    // On production, using a X.509 certificate stored in the machine store is recommended.
                    // You can generate a self-signed certificate using Pluralsight's self-cert utility:
                    // https://s3.amazonaws.com/pluralsight-free/keith-brown/samples/SelfCert.zip
                    //
                    // options.AddSigningCertificate("7D2A741FE34CC2C7369237A5F2078988E17A6A75");
                    //
                    // Alternatively, you can also store the certificate as an embedded .pfx resource
                    // directly in this assembly or in a file published alongside this project:
                    //
                    // options.AddSigningCertificate(
                    //     assembly: typeof(Startup).GetTypeInfo().Assembly,
                    //     resource: "AuthorizationServer.Certificate.pfx",
                    //     password: "OpenIddict");

                    // Note: to use JWT access tokens instead of the default
                    // encrypted format, the following line is required:
                    //
                    // options.UseJsonWebTokens();
                })
                // Register the OpenIddict validation handler.
                // Note: the OpenIddict validation handler is only compatible with the
                // default token format or with reference tokens and cannot be used with
                // JWT tokens. For JWT tokens, use the Microsoft JWT bearer handler.
                .AddValidation();

            //services.AddOpenIddict(options =>
            //{
            //    // Register the Entity Framework stores.
            //    options.AddEntityFrameworkCoreStores<IdentityDbContext>();
            //    // Register the ASP.NET Core MVC binder used by OpenIddict.
            //    // Note: if you don't call this method, you won't be able to
            //    // bind OpenIdConnectRequest or OpenIdConnectResponse parameters.
            //    options.AddMvcBinders();
            //    // Enable the token endpoint.
            //    options.EnableAuthorizationEndpoint("/connect/authorize")
            //           .EnableLogoutEndpoint("/connect/logout")
            //           .EnableIntrospectionEndpoint("/connect/introspect")
            //           .EnableTokenEndpoint("/connect/token")
            //           .EnableUserinfoEndpoint("/api/userinfo");

            //    options.AllowImplicitFlow();

            //    // Register a new ephemeral key, that is discarded when the application
            //    // shuts down. Tokens signed using this key are automatically invalidated.
            //    // This method should only be used during development.
            //    options.AddEphemeralSigningKey();

            //    //options.AddSigningCertificate(_cert);

            //    options.UseJsonWebTokens();

            //    // During development, you can disable the HTTPS requirement.
            //    options.DisableHttpsRequirement();
            //});

            //services.AddAuthentication(o =>
            //{
            //    o.DefaultAuthenticateScheme = OAuthValidationDefaults.AuthenticationScheme;
            //    o.DefaultChallengeScheme = OAuthValidationDefaults.AuthenticationScheme;
            //})
            //.AddOAuthValidation();

            services.AddScoped<IAdminMasterRepository, AdminMasterRepository>();
            services.AddScoped<ILoggedInHistoryRepository, LoggedInHistoryRepository>();

            //services.AddAuthorization(options =>
            //{
            //    options.AddPolicy("RequiredApplicationManagerRole", policy => policy.RequireRole("ApplicationManager"));
            //    options.AddPolicy("RequireAdministratorRole", policy => policy.RequireRole("Administrator"));
            //    options.AddPolicy("RequireUserRole", policy => policy.RequireRole("User"));
            //});

            services.AddCors();
            services.AddMvc();
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app)
        {
            //if (env.IsDevelopment())
            //{
            //    app.UseDeveloperExceptionPage();
            //}

            app.UseCors(builder =>
            builder.WithOrigins("*")
            .AllowAnyHeader()
            .AllowAnyMethod()
            );

            app.UseStaticFiles();
            app.UseAuthentication();

            app.UseMvc();
        }
    }
}
