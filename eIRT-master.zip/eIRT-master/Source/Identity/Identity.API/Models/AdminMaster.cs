﻿using System;
using System.ComponentModel.DataAnnotations.Schema;

namespace Identity.API.Models
{
    [Table("UserMaster", Schema = "User")]
    public class UserMaster : BaseEntity
    {
        public int Id { get; set; }
        public Guid GuId { get; set; }
        public string Name { get; set; }
        public string EmployeeCode { get; set; }
        public string MobileNumber { get; set; }
        public string Role { get; set; }
        public string Status { get; set; }
        public string Password { get; set; }
        public string OrganizationCode { get; set; }
    }
}
