﻿using Notification.API.Repository.Interface;
using System;
using System.Collections.Specialized;
using System.Net;
using System.Threading.Tasks;
using System.Web;

namespace Notification.API.Repository
{
    public class SMSSender : ISMSSender
    {
        public async Task<string> Send(string number, string message)
        {
            string result = string.Empty;
            try
            {
                string toSms = number;
                //string apiKey = "9CQFRPD0ge8-xtJyiSFiHgSswR216wSw1WgOzmSBMp";
                string apiKey = "9CQFRPD0ge8-zIdStIAaxtYbwNn424EStP6Izu42rv";

                String encodeMessage = HttpUtility.UrlEncode(message);
                using (var wb = new WebClient())
                {
                    byte[] response = wb.UploadValues("https://api.textlocal.in/send/", new NameValueCollection()
                    {
                    {"apikey" , apiKey},
                    {"numbers" , number},
                    {"message" , encodeMessage},
                    {"sender" , "POSIVI"},
                    {"unicode" , "1"}
                    });
                    result = System.Text.Encoding.UTF8.GetString(response);
                }
            }
            catch (Exception ex)
            {
                string error = ex.Message;
            }
            await Task.Delay(1);
            return result;
        }
    }
}
