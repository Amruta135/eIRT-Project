﻿using Microsoft.Extensions.Configuration;
using Notification.API.Repository.Interface;
using System;
using System.Threading.Tasks;
using Twilio;
using Twilio.Rest.Api.V2010.Account;

namespace Notification.API.Repository
{
    public class WhatsAppSender : IWhatsAppHandler
    {
        public IConfiguration _configuration { get; }
        private readonly string _accountSid;
        private readonly string _authToken;
        private readonly string _fromPhoneNumber;
        public WhatsAppSender(IConfiguration configuration)
        {
            _accountSid = configuration.GetSection("TwilioStrings").GetSection("accountSid").Value;
            _authToken = configuration.GetSection("TwilioStrings").GetSection("authToken").Value;
            _fromPhoneNumber = configuration.GetSection("TwilioStrings").GetSection("fromPhoneNumber").Value;
        }
        public async Task<bool> Send(string number, string message)
        {
            try
            {
                TwilioClient.Init(_accountSid, _authToken);
                
                string fromPhoneNumber = "whatsapp:" + _fromPhoneNumber;
                string toPhoneNumber = "whatsapp:+91" + number;

                var result = MessageResource.Create(
                    body: message,
                    from: new Twilio.Types.PhoneNumber(fromPhoneNumber),
                    to: new Twilio.Types.PhoneNumber(toPhoneNumber)

            //from: new Twilio.Types.PhoneNumber("whatsapp:+14155238886"),
            //body: "Hello, there!",
            //to: new Twilio.Types.PhoneNumber("whatsapp:+15005550006")

                );
                await Task.Delay(1);
            }
            catch (Exception ex)
            {

            }
            return true;
        }
    }
}
