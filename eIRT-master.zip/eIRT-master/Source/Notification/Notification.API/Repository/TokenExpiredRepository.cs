﻿using Microsoft.EntityFrameworkCore;
using Notification.API.Data;
using Notification.API.Models;
using Notification.API.Repository.Interface;
using System.Linq;
using System.Threading.Tasks;

namespace Notification.API.Repository
{
    public class TokenExpiredRepository : Repository<TokenExpired>, ITokenExpiredRepository
    {
        private NotificationDbContext _db;
        public TokenExpiredRepository(NotificationDbContext context) : base(context)
        {
            this._db = context;
        }
        public async Task<bool> TokenExists(string userToken)
        {
            return await this._db.TokenExpired.Where(s => s.Token == userToken).CountAsync() > 0;
        }
    }
}
