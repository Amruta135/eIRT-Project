﻿using Notification.API.Data;
using Notification.API.Models;
using Notification.API.Repository.Interface;
using System;
using System.Threading.Tasks;

namespace Notification.API.Repository
{
    public class SMSSentResultRepository : Repository<SMSSentResult>, ISMSSentResult
    {
        private NotificationDbContext _db;
        public SMSSentResultRepository(NotificationDbContext context) : base(context)
        {
            this._db = context;
        }
    }
}
