﻿using Notification.API.Models;
using Notification.API.Repository.Interface;
using System;
using System.Threading.Tasks;

namespace Notification.API.Repository
{
    public class NotificationSender : INotificationSender
    {
        private readonly IUserNotificationsRepository _userNotificationsRepository;

        public NotificationSender(IUserNotificationsRepository userNotificationsRepository)
        {
            _userNotificationsRepository = userNotificationsRepository;
        }

        public async Task<bool> Send(int userId, string message)
        {
            UserNotifications userNotification = new UserNotifications();
            userNotification.UserId = userId;
            userNotification.Text = message;
            userNotification.CreatedDate = DateTime.Now;
            userNotification.IsDeleted = false;
            userNotification.CreatedBy = userId; //todo used logged in userId

            await this._userNotificationsRepository.AddAsync(userNotification);
            return true;
        }
    }
}
