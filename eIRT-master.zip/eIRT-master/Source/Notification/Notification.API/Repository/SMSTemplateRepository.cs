﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Caching.Memory;
using Notification.API.APIModel;
using Notification.API.Data;
using Notification.API.Helper;
using Notification.API.Models;
using Notification.API.Repository.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Notification.API.Repository
{
    public class SMSTemplateRepository : Repository<SMSTemplate>, ISMSTemplate
    {
        private NotificationDbContext _db;
        private IMemoryCache _cacheSMSTemplate;
        public SMSTemplateRepository(NotificationDbContext context, IMemoryCache cacheSMSTemplate) : base(context)
        {
            _db = context;
            _cacheSMSTemplate = cacheSMSTemplate;
        }

        public async Task<string> GetTemplateContentByTitle(string title, string language)
        {
            if (language == null)
                language = "en";

            SMSTemplate smsTemplate = await GetCacheSMSTemplates(title, language);

            string templateContent;
            if (smsTemplate != null)
                templateContent = smsTemplate.Content;
            else
                templateContent = null;

            return templateContent;
        }

        private async Task<SMSTemplate> GetCacheSMSTemplates(string title, string language)
        {
            List<SMSTemplate> cacheSMSTemplates = new List<SMSTemplate>();
            // Look for cache key.
            if (!_cacheSMSTemplate.TryGetValue(CacheKeys.SMSTemplate, out cacheSMSTemplates))
            {
                // Key not in cache, so get data.
                cacheSMSTemplates = await this.GetSMSTemplates();

                // Set cache options.
                var cacheEntryOptions = new MemoryCacheEntryOptions()
                    // Keep in cache for this time, reset time if accessed.
                    .SetSlidingExpiration(TimeSpan.FromHours(1));

                // Save data in cache.
                _cacheSMSTemplate.Set(CacheKeys.SMSTemplate, cacheSMSTemplates, cacheEntryOptions);
            }
            return cacheSMSTemplates.Where(s => s.Title == title && s.IsDeleted == false && s.Status == Record.Active).FirstOrDefault();
        }

        private async Task<List<SMSTemplate>> GetSMSTemplates()
        {
            IQueryable<SMSTemplate> Query = (from s in _db.SMSTemplate
                                                    where (s.IsDeleted == false)
                                                    select s);
            return await Query.ToListAsync();
        }

        public async Task<APISMSTemplateSearch> GetSMSTemplate(int id)
        {
            var result = (from s in _db.SMSTemplate
                          where (s.IsDeleted == false && s.Id == id)
                          select new APISMSTemplateSearch
                          {
                              Id = s.Id,
                              Title = s.Title,
                              Content = s.Content,
                              Status = s.Status,
                          });

            return await result.FirstOrDefaultAsync();
        }


        public async Task<List<APISMSTemplateSearch>> GetSMSTemplates(int page, int pageSize, string filter = null, string search = null)
        {
            IQueryable<APISMSTemplateSearch> Query = (from s in _db.SMSTemplate
                                             where (s.IsDeleted == false)
                                             select new APISMSTemplateSearch
                                             {
                                                 Id = s.Id,
                                                 Title = s.Title,
                                                 Content = s.Content,
                                                 Status = s.Status,
                                             }).OrderByDescending(a => a.Id);

            if (!string.IsNullOrEmpty(search) && !string.IsNullOrEmpty(filter))
            {
                switch (filter.ToLower())
                {
                    case "title":
                        Query = Query.Where(r => r.Title.Contains(search)).OrderByDescending(r => r.Id);
                        break;
                    case "content":
                        Query = Query.Where(r => r.Content.Contains(search)).OrderByDescending(r => r.Id);
                        break;
                }
            }

            if (page != -1)
                Query = Query.Skip((page - 1) * pageSize);
            if (pageSize != -1)
                Query = Query.Take(pageSize);

            return await Query.ToListAsync();
        }

        public async Task<int> GetSMSTemplatesCount(string filter = null, string search = null)
        {
            if (!string.IsNullOrEmpty(search) && !string.IsNullOrEmpty(filter))
            {
                switch (filter.ToLower())
                {
                    case "title":
                        return await (from s in _db.SMSTemplate
                                   where (s.IsDeleted == false && s.Title.Contains(search))
                               select s.Id).CountAsync();
                    case "content":
                        return await (from s in _db.SMSTemplate
                                      where (s.IsDeleted == false && s.Content.Contains(search))
                                      select s.Id).CountAsync();
                }
            }
            return await (from s in _db.SMSTemplate
                          where (s.IsDeleted == false)
                          select s.Id).CountAsync();
        }


    }
}
