﻿using Microsoft.EntityFrameworkCore;
using Notification.API.Data;
using Notification.API.Helper;
using Notification.API.Models;
using Notification.API.Repository.Interface;
using System.Linq;
using System.Threading.Tasks;

namespace Notification.API.Repository
{
    public class UserMasterRepository : Repository<UserMaster>, IUserMasterRepository
    {
        private NotificationDbContext _db;
        public UserMasterRepository(NotificationDbContext context) : base(context)
        {
            this._db = context;
        }

        //public async Task<string> GetUserLanguage(int id)
        //{
        //    string language = await _db.UserMaster.Where(u => u.Id == id).Select(u => u.Language).FirstOrDefaultAsync();

        //    if (string.IsNullOrWhiteSpace(language))
        //    {
        //        language = LanguageCodes.English;
        //    }

        //    return language;
        //}
    }
}
