﻿using Notification.API.APIModel;
using Notification.API.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Notification.API.Repository.Interface
{
    public interface IUserNotificationsRepository : IRepository<UserNotifications>
    {
        Task<List<APIUserNotifications>> GetUserNotifications(int userId);
    }
}
