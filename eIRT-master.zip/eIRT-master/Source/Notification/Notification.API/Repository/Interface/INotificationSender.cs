﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Notification.API.Repository.Interface
{
    public interface INotificationSender
    {
        Task<bool> Send(int userId, string message);
    }
}
