﻿using Notification.API.Models;
using System.Threading.Tasks;

namespace Notification.API.Repository.Interface
{
    public interface ISMSSentResult : IRepository<SMSSentResult>
    {
        //Task<bool> AddSMSResult(string result, string title, int userId);
    }
}
