﻿using Notification.API.Models;
using System.Threading.Tasks;

namespace Notification.API.Repository.Interface
{
    public interface IUserMasterRepository : IRepository<UserMaster>
    {
        //Task<string> GetUserLanguage(int id);
    }
}
