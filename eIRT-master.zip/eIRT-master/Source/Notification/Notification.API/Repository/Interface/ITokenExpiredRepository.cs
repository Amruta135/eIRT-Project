﻿using Notification.API.Models;
using System.Threading.Tasks;

namespace Notification.API.Repository.Interface
{
    public interface ITokenExpiredRepository : IRepository<TokenExpired>
    {
        Task<bool> TokenExists(string userToken);
    }
}
