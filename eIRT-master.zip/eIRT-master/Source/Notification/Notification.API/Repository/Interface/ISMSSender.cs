﻿using System.Threading.Tasks;

namespace Notification.API.Repository.Interface
{
    public interface ISMSSender
    {
        Task<string> Send(string number, string message);
    }
}
