﻿using Notification.API.APIModel;
using Notification.API.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Notification.API.Repository.Interface
{
    public interface ISMSTemplate : IRepository<SMSTemplate>
    {
        Task<string> GetTemplateContentByTitle(string title, string language);
        Task<List<APISMSTemplateSearch>> GetSMSTemplates(int page, int pageSize, string filter = null, string search = null);
        Task<int> GetSMSTemplatesCount(string filter = null, string search = null);

        Task<APISMSTemplateSearch> GetSMSTemplate(int id);

    }
}
