﻿using System.Threading.Tasks;

namespace Notification.API.Repository.Interface
{
    public interface IWhatsAppHandler
    {
        Task<bool> Send(string number, string message);
    }
}
