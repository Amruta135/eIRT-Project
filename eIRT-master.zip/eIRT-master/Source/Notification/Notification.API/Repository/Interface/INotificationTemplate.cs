﻿using Notification.API.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Notification.API.Repository.Interface
{
    public interface INotificationTemplate : IRepository<NotificationTemplate>
    {
        Task<string> GetTemplateContentByTitle(string title);
        //Task<List<APISMSTemplateSearch>> GetSMSTemplates(int page, int pageSize, string filter = null, string search = null);
        //Task<int> GetSMSTemplatesCount(string filter = null, string search = null);

    }
}
