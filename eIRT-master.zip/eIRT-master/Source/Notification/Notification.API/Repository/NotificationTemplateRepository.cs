﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Caching.Memory;
using Notification.API.Data;
using Notification.API.Helper;
using Notification.API.Models;
using Notification.API.Repository.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Notification.API.Repository
{
    public class NotificationTemplateRepository : Repository<NotificationTemplate>, INotificationTemplate
    {
        private NotificationDbContext _db;
        private IMemoryCache _cacheNotificationTemplate;
        public NotificationTemplateRepository(NotificationDbContext context, IMemoryCache cacheNotificationTemplate) : base(context)
        {
            _db = context;
            _cacheNotificationTemplate = cacheNotificationTemplate;
        }

        public async Task<string> GetTemplateContentByTitle(string title)
        {
            NotificationTemplate NotificationTemplate = await GetCacheNotificationTemplates(title);

            string templateContent;
            if (NotificationTemplate != null)
                templateContent = NotificationTemplate.Content;
            else
                templateContent = null;

            return templateContent;
        }

        private async Task<NotificationTemplate> GetCacheNotificationTemplates(string title)
        {
            List<NotificationTemplate> cacheNotificationTemplates = new List<NotificationTemplate>();
            // Look for cache key.
            if (!_cacheNotificationTemplate.TryGetValue(CacheKeys.NotificationTemplate, out cacheNotificationTemplates))
            {
                // Key not in cache, so get data.
                cacheNotificationTemplates = await this.GetNotificationTemplates();

                // Set cache options.
                var cacheEntryOptions = new MemoryCacheEntryOptions()
                    // Keep in cache for this time, reset time if accessed.
                    .SetSlidingExpiration(TimeSpan.FromHours(4));

                // Save data in cache.
                _cacheNotificationTemplate.Set(CacheKeys.NotificationTemplate, cacheNotificationTemplates, cacheEntryOptions);
            }
            return cacheNotificationTemplates.Where(s => s.Title == title && s.IsDeleted == false && s.Status == Record.Active).FirstOrDefault();
        }

        private async Task<List<NotificationTemplate>> GetNotificationTemplates()
        {
            IQueryable<NotificationTemplate> Query = (from n in _db.NotificationTemplate
                                             where (n.IsDeleted == false)
                                             select n);
            return await Query.ToListAsync();
        }

        //public async Task<List<APINotificationTemplateSearch>> GetNotificationTemplates(int page, int pageSize, string filter = null, string search = null)
        //{
        //    IQueryable<APINotificationTemplateSearch> Query = (from s in _db.NotificationTemplate
        //                                              where (s.IsDeleted == false)
        //                                              select new APINotificationTemplateSearch
        //                                              {
        //                                                  Id = s.Id,
        //                                                  Title = s.Title,
        //                                                  Content = s.Content,
        //                                                  Status = s.Status
        //                                              }).OrderByDescending(a => a.Id);

        //    if (!string.IsNullOrEmpty(search) && !string.IsNullOrEmpty(filter))
        //    {
        //        switch (filter.ToLower())
        //        {
        //            case "title":
        //                Query = Query.Where(r => r.Title.Contains(search)).OrderByDescending(r => r.Id);
        //                break;
        //            case "content":
        //                Query = Query.Where(r => r.Content.Contains(search)).OrderByDescending(r => r.Id);
        //                break;
        //        }
        //    }

        //    if (page != -1)
        //        Query = Query.Skip((page - 1) * pageSize);
        //    if (pageSize != -1)
        //        Query = Query.Take(pageSize);

        //    return await Query.ToListAsync();
        //}

        //public async Task<int> GetNotificationTemplatesCount(string filter = null, string search = null)
        //{
        //    if (!string.IsNullOrEmpty(search) && !string.IsNullOrEmpty(filter))
        //    {
        //        switch (filter.ToLower())
        //        {
        //            case "title":
        //                return await (from s in _db.NotificationTemplate
        //                              where (s.IsDeleted == false && s.Title.Contains(search))
        //                              select s.Id).CountAsync();
        //            case "content":
        //                return await (from s in _db.NotificationTemplate
        //                              where (s.IsDeleted == false && s.Content.Contains(search))
        //                              select s.Id).CountAsync();
        //        }
        //    }
        //    return await (from s in _db.NotificationTemplate
        //                  where (s.IsDeleted == false)
        //                  select s.Id).CountAsync();
        //}


    }
}
