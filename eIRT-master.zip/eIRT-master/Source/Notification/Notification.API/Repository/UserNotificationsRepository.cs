﻿using Microsoft.EntityFrameworkCore;
using Notification.API.APIModel;
using Notification.API.Data;
using Notification.API.Models;
using Notification.API.Repository.Interface;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Notification.API.Repository
{
    public class UserNotificationsRepository : Repository<UserNotifications>, IUserNotificationsRepository
    {
        private NotificationDbContext _db;
        public UserNotificationsRepository(NotificationDbContext context) : base(context)
        {
            this._db = context;
        }

        public async Task<List<APIUserNotifications>> GetUserNotifications(int userId)
        {
            IQueryable<APIUserNotifications> Query = (from u in _db.UserNotifications
                                                      where (u.IsDeleted == false && u.IsRead == false && u.UserId == userId)
                                                      select new APIUserNotifications
                                                      {
                                                          Id = u.Id,
                                                          Text = u.Text
                                                      }).OrderByDescending(a => a.Id);

            return await Query.ToListAsync();
        }
    }
}
