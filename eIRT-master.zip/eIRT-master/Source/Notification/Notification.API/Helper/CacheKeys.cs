﻿namespace Notification.API.Helper
{
    public static class CacheKeys
    {
        public static string ProductInformation { get { return "_ProductInformation"; } }
        public static string SMSTemplate { get { return "_SMSTemplate"; } }

        public static string NotificationTemplate { get { return "_NotificationTemplate"; } }
        

    }
}
