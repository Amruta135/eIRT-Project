﻿namespace Notification.API.Helper
{
    public class Record
    {
        public const string Active = "Active";
        public const string Inactive = "Inactive";
        public const string active = "active";
        public const string inactive = "inactive";

        public const string TemplateErrorMessage = "Template is not available or status is inactive";
    }


    public class Template
    {
        public const string OTP = "OTP";
        public const string IRTAdminCreatesNewAccount = "IRTAdminCreatesNewAccount";
        public const string NewIncidentReported = "NewIncidentReported";
        public const string IncidentAssigned = "IncidentAssigned";
        public const string NewATRAdded = "NewATRAdded";
    }

    public class Token
    {
        public const string UserName = "[UserName]";
        public const string NewLine = "[NewLine]";
        public const string OTP = "[OTP]";
        public const string OrgID = "[OrgID]";
        public const string ClientAdmin = "[ClientAdmin]";
        public const string Department = "[Department]";
        public const string IncidentCategory = "[IncidentCategory]";
        public const string IncidentReportedUserName = "[IncidentReportedUserName]";
        public const string IncidentID = "[IncidentID]";
        public const string ActingUserName = "[ActingUserName]";
        public const string ATRStatus = "[ATRStatus]";
    }

    public class Roles
    {
        public const string User = "User";
        public const string Admin = "Admin";
        public const string Coordinator = "Coordinator";
    }
}
