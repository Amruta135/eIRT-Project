﻿using System.Collections.Generic;

namespace System
{
    public static class StringExtensions
    {
        public static string TokenLastNumberOfChars(this String str, int numberOfWords)
        {
            if (numberOfWords < 0)
                throw new ArgumentOutOfRangeException("numberOfWords should be greater than or equal to 0.");

            return str.Substring(str.Length - numberOfWords, numberOfWords);
        }

        public static string ReplaceTemplateTokens(this string text, Dictionary<string, string> replacements)
        {
            string retVal = text;
            foreach (string textToReplace in replacements.Keys)
            {
                retVal = retVal.Replace(textToReplace, replacements[textToReplace]);
            }
            return retVal;
        }
    }
}
