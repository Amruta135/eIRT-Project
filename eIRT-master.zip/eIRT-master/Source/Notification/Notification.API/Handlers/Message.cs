﻿using System.Collections.Generic;

namespace Notification.API.SMSHandler
{
    public class Message
    {
        public string Template { get; set; }
        public Dictionary<string, string> Tokens { get; set; }
        public string SenderMobileNumber { get; set; }
        public int SenderUerId { get; set; }

        public int TestCounter { get; set; } = 0;

        public string Language { get; set; }
    }
}