﻿using Notification.API.Helper;
using Notification.API.Repository.Interface;
using Notification.API.SMSHandler;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Notification.API.Handlers
{
    public class NotificationHandlerProcessor : INotificationHandler
    {
        private readonly INotificationSender _notificationSender;
        private readonly INotificationTemplate _notificationTemplateRepository;

        public NotificationHandlerProcessor(INotificationSender notificationSender,
                                            INotificationTemplate notificationTemplateRepository)
        {
            _notificationSender = notificationSender;
            _notificationTemplateRepository = notificationTemplateRepository;
        }
        public async Task<bool> Send(Message notificationMessage)
        {
            string content = await _notificationTemplateRepository.GetTemplateContentByTitle(notificationMessage.Template);
            //string result;
            bool status = false;

            if (!string.IsNullOrEmpty(content))
            {
                string message = content.ReplaceTemplateTokens(notificationMessage.Tokens);


                await _notificationSender.Send(notificationMessage.SenderUerId, message);


                status = true;
            }

            return status;
        }

        //private async Task<bool> AddUserNotification(int userId, string message)
        //{
        //    try
        //    {
        //        await _notificationSender.Send(userId, message);
        //    }
        //    catch (Exception)
        //    {

        //    }
        //    return true;
        //}
    }
}
