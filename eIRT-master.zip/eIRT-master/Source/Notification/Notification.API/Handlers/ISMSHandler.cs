﻿using System.Threading.Tasks;

namespace Notification.API.SMSHandler
{
    public interface ISMSHandler
    {
        Task<bool> Send(Message message);
    }
}
