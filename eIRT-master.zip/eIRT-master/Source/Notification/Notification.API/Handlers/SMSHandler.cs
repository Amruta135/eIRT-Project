﻿using Microsoft.Extensions.Configuration;
using Notification.API.Helper;
using Notification.API.Models;
using Notification.API.Repository.Interface;
using System;
using System.Threading.Tasks;

namespace Notification.API.SMSHandler
{
    public class SMSHandlerProcessor : ISMSHandler
    {
        private readonly ISMSSender _smsSender;
        private readonly ISMSSentResult _smsSentResultRepository;
        private readonly ISMSTemplate _smsTemplateRepository;
        private readonly IWhatsAppHandler _whatsAppSender;
        private bool _enableSendSMSToDummyMobile;
        private readonly string _dummyMobileNumber;
        

        public IConfiguration _configuration { get; }
        public SMSHandlerProcessor(ISMSSender smsSender, 
                                   IConfiguration configuration,
                                   ISMSSentResult smsSentResultRepository,
                                   ISMSTemplate smsTemplateRepository,
                                   IWhatsAppHandler whatsAppSender)
        {
            _smsSender = smsSender;
            _configuration = configuration;
            _smsSentResultRepository = smsSentResultRepository;
            _smsTemplateRepository = smsTemplateRepository;
            _whatsAppSender = whatsAppSender;
            _enableSendSMSToDummyMobile = (_configuration["EnableSendSMSToDummyMobile"] != null && _configuration["EnableSendSMSToDummyMobile"] == "1") ? true : false;
            _dummyMobileNumber = _configuration["DummyMobile"] != null ? _configuration["DummyMobile"] : string.Empty;
            
        }
        public async Task<bool> Send(Message sms)
        {
            //if (sms.SenderMobileNumber.Length > 10)
            //{
            //    sms.SenderMobileNumber = sms.SenderMobileNumber.Substring(sms.SenderMobileNumber.Length - 10);
            //}

            string content = await _smsTemplateRepository.GetTemplateContentByTitle(sms.Template, sms.Language);
            string result;
            bool status = false;

            if (!string.IsNullOrEmpty(content))
            {
                string message = content.ReplaceTemplateTokens(sms.Tokens);

                if (_enableSendSMSToDummyMobile)
                {
                    if (sms.TestCounter > 0)
                    {
                        return true;
                    }
                    result = await _smsSender.Send(_dummyMobileNumber, message);
                    //await _whatsAppSender.Send(_dummyMobileNumber, message);
                }
                else
                {
                    result = await _smsSender.Send(sms.SenderMobileNumber, message);
                }

                //await AddUserNotification(sms.SenderUerId, message);

                await AddSMSResult(result, sms.Template, sms.SenderUerId, message);

                status = true;
            }
            else
            {
                await AddSMSResult(Record.TemplateErrorMessage, sms.Template, 0, "");
            }

            return status;
        }

        //private async Task<bool> AddUserNotification(int userId, string message)
        //{
        //    try
        //    {
        //        await _notificationSender.Send(userId, message);
        //    }
        //    catch (Exception)
        //    {

        //    }
        //    return true;
        //}
        private async Task<bool> AddSMSResult(string result, string title, int userId, string message)
        {
            try
            {
                SMSSentResult smsSentResult = new SMSSentResult();
                smsSentResult.CreatedDate = DateTime.Now;
                smsSentResult.Result = result;
                smsSentResult.Title = title;
                smsSentResult.UserId = userId;
                smsSentResult.Messsage = message;

                await this._smsSentResultRepository.AddAsync(smsSentResult);
            }
            catch (Exception)
            {

            }
            return true;
        }
    }
}
