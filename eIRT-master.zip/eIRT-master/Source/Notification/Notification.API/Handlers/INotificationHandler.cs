﻿using Notification.API.SMSHandler;
using System.Threading.Tasks;

namespace Notification.API.Handlers
{
    public interface INotificationHandler
    {
        Task<bool> Send(Message message);
    }
}
