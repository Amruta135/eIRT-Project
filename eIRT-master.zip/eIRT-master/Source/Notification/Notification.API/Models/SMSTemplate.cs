﻿using System.ComponentModel.DataAnnotations;

namespace Notification.API.Models
{
    public class SMSTemplate : BaseEntity
    {
        public int Id { get; set; }

        [Required]
        [MaxLength(200)]
        public string Title { get; set; }

        [Required]
        [MaxLength(500)]
        public string Content { get; set; }

        [Required]
        [RegularExpression("Active|Inactive")]
        public string Status { get; set; } = "Active";
    }
}
