﻿using System;
using System.ComponentModel.DataAnnotations;

namespace Notification.API.Models
{
    public class SMSSentResult
    {
        public int Id { get; set; }

        [Required]
        [MaxLength(200)]
        public string Title { get; set; }

        [MaxLength(3000)]
        public string Result { get; set; }

        public DateTime CreatedDate { get; set; }

        public int UserId { get; set; }

        [MaxLength(3000)]
        public string Messsage { get; set; }
    }
}
