﻿using System;

namespace Notification.API.Models
{
    public class UserNotifications
    {
        public int Id { get; set; }
        public string Text { get; set; }
        public int UserId { get; set; }
        public bool IsRead { get; set; } = false;
        public DateTime CreatedDate { get; set; }
        public int CreatedBy { get; set; }
        public bool IsDeleted { get; set; }
    }
}
