﻿using System;
using System.ComponentModel.DataAnnotations.Schema;

namespace Notification.API.Models
{
    [Table("TokenExpired", Schema = "User")]
    public class TokenExpired
    {
        public int Id { get; set; }
        public DateTime CreatedDate { get; set; }
        public string Token { get; set; }
        public int UserId { get; set; }
        public bool IsDeleted { get; set; }
    }
}
