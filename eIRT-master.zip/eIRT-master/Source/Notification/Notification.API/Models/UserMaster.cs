﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Notification.API.Models
{
    [Table("UserMaster", Schema = "User")]
    public class UserMaster : BaseEntity
    {
        public int Id { get; set; }

        [Required]
        public Guid GuId { get; set; }
        [Required]
        [MaxLength(7)]
        public string OrganizationCode { get; set; }
        [Required]
        [MaxLength(15)]
        public string EmployeeCode { get; set; }
        [Required]
        [StringLength(100, ErrorMessage = "The {0} must be at least {2} and maximum {1} characters long.", MinimumLength = 1)]
        public string Name { get; set; }
        [MaxLength(500)]
        public string ProfilePicUrl { get; set; }
        [Required]
        public string DepartmentId { get; set; }
        [MaxLength(100)]
        public string Designation { get; set; }
        [Required]
        [StringLength(10, ErrorMessage = "Must have 10 digit long Number!", MinimumLength = 10)]
        [RegularExpression(@"^[0-9]{10}$", ErrorMessage = "Must have 10 digit long Number!")]
        public string MobileNumber { get; set; }
        [Required]
        [RegularExpression(@"^[^@\s]+@[^@\s]+\.[^@\s]+$", ErrorMessage = "Invalid email address!")]
        public string Email { get; set; }
        [Required]
        //[Validation.CustomValidation(AllowValue = new string[] { Roles.Admin, Roles.Coordinator, Roles.User })]
        [MaxLength(15)]
        public string Role { get; set; }
        [Required]
        [RegularExpression("active|inactive", ErrorMessage = "Value for {0} must be {1}, Case sensitive")]
        [MaxLength(10)]
        public string Status { get; set; }
    }
}
