﻿using System.Collections.Generic;

namespace Notification.API.Common
{
    public interface IExportManager<T> where T : class
    {
        byte[] ExportToXlsx(PropertyByName<T>[] properties, IEnumerable<T> itemsToExport);
    }
}
