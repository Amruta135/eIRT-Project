﻿using OfficeOpenXml.FormulaParsing.Excel.Functions.DateTime;
using System;

namespace Notification.API.APIModel
{
    public class APISMS
    {
        public int UserId { get; set; }
        public string UserName { get; set; }
        public string MobileNumber { get; set; }
        //public int UserMasterId { get; set; }
    }

    public class APISMSOTP : APISMS
    {
        public string OTP { get; set; }
    }

    public class APISMSNewLanguageActivation
    {
        public string LanguageCode { get; set; }
        public string LanguageName { get; set; }
    }

    public class APIIRTAdminCreatesNewAccount : APISMS
    {
        public string ClientAdmin { get; set; }
        public string OrgID { get; set; }
        public string OTP { get; set; }
    }
    public class APINewIncidentReported : APISMS
    {
        public string ClientAdmin { get; set; }
        public string Department { get; set; }
        public string IncidentCategory { get; set; }
    }
    public class APIIncidentAssigned : APISMS
    {
        public string ClientAdmin { get; set; }
        public string IncidentReportedUserName { get; set; }
        public string IncidentID { get; set; }
    }
    public class APINewATRAdded : APISMS
    {
        public string ActingUserName { get; set; }
        public string ATRStatus { get; set; }
        public string IncidentID { get; set; }
    }

}
