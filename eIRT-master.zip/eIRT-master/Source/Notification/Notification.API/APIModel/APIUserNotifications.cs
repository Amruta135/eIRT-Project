﻿namespace Notification.API.APIModel
{
    public class APIUserNotifications
    {
        public int Id { get; set; }
        public string Text { get; set; }

    }
}
