﻿using System.ComponentModel.DataAnnotations;

namespace Notification.API.APIModel
{
    public class APISMSTemplate
    {
        [Required]
        [MaxLength(200)]
        public string Title { get; set; }

        [Required]
        [MaxLength(500)]
        public string Content { get; set; }
        [Required]
        public string Status { get; set; }

        [Required]
        public string Language { get; set; }
    }

    public class APISMSTemplateSearch : APISMSTemplate
    {
        public int Id { get; set; }
    }
}
