using AspNet.Security.OAuth.Introspection;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.OpenApi.Models;
using Notification.API.Common;
using Notification.API.Data;
using Notification.API.Handlers;
using Notification.API.Repository;
using Notification.API.Repository.Interface;
using Notification.API.Services;
using Notification.API.SMSHandler;
using System;

namespace Notification.API
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddTransient<ISMSSender, SMSSender>();
            services.AddTransient<ISMSTemplate, SMSTemplateRepository>();
            services.AddTransient<ISMSSentResult, SMSSentResultRepository>();
            services.AddTransient<IUserMasterRepository, UserMasterRepository>();
            services.AddTransient<ITokenExpiredRepository, TokenExpiredRepository>();
            services.AddSingleton<IHttpContextAccessor, HttpContextAccessor>();
            services.AddTransient<IIdentityService, IdentityService>();
            services.AddTransient(typeof(IExportManager<>), typeof(ExportManager<>));
            services.AddTransient<ISMSHandler, SMSHandlerProcessor>();
            services.AddTransient<IWhatsAppHandler, WhatsAppSender>();
            services.AddTransient<IUserNotificationsRepository, UserNotificationsRepository>();
            services.AddTransient<INotificationSender, NotificationSender>();
            services.AddTransient<INotificationHandler, NotificationHandlerProcessor>();
            services.AddTransient<INotificationTemplate, NotificationTemplateRepository>();

            services.AddDbContext<NotificationDbContext>(options =>
            {
                options.UseSqlServer(this.Configuration.GetConnectionString("DefaultConnection"));
            });

            ConfigureAuthService(services);
            services.AddDistributedMemoryCache();

            services.AddMvc();
            services.AddApiVersioning();
            services.AddControllers();

            // Register the Swagger generator, defining 1 or more Swagger documents
            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v1", new OpenApiInfo { Title = "Notification", Version = "v1" });
            });
        }

        private void ConfigureAuthService(IServiceCollection services)
        {
            try
            {
                services.AddAuthentication(options =>
                {
                    options.DefaultScheme = OAuthIntrospectionDefaults.AuthenticationScheme;
                })
                .AddOAuthIntrospection(options =>
                {
                    options.Authority = new Uri(Configuration.GetValue<string>("IdentityUrl"));
                    options.Audiences.Add("notification_api");
                    options.ClientId = "notification_api";
                    options.ClientSecret = "ClientSecret";
                    options.RequireHttpsMetadata = false;
                });
            }
            catch (Exception)
            {

            }
        }
        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            app.UseStaticFiles();
            app.UseSwagger();

            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            app.UseSwaggerUI(c =>
            {
                c.SwaggerEndpoint("/swagger/v1/swagger.json", "Notification V1");
            });

            app.UseRouting();

            app.UseAuthorization();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });
        }
    }
}
