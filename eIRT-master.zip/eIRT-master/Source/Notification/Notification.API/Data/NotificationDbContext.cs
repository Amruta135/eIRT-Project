﻿using Microsoft.EntityFrameworkCore;
using Notification.API.Models;

namespace Notification.API.Data
{
    public class NotificationDbContext : DbContext
    {
        public NotificationDbContext(DbContextOptions<NotificationDbContext> options) : base(options)
        {
            ChangeTracker.QueryTrackingBehavior = QueryTrackingBehavior.NoTracking;
        }

        public DbSet<SMSTemplate> SMSTemplate { get; set; }
        public DbSet<TokenExpired> TokenExpired { get; set; }
        public DbSet<SMSSentResult> SMSSentResult { get; set; }
        public DbSet<UserMaster> UserMaster { get; set; }
        public DbSet<UserNotifications> UserNotifications { get; set; }
        public DbSet<NotificationTemplate> NotificationTemplate { get; set; }
        

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
            modelBuilder.HasDefaultSchema("Notification");
        }
    }
}
