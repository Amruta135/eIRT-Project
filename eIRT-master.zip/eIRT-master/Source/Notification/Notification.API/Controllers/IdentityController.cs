﻿using AspNet.Security.OpenIdConnect.Extensions;
using AspNet.Security.OpenIdConnect.Primitives;
using Microsoft.AspNetCore.Mvc;
using Notification.API.Services;
using System;

namespace Notification.API.Controllers
{
    public class IdentityController : ControllerBase
    {
        private string _userId;
        private string _role;
        private int _dbId;
        private readonly IIdentityService _identitySvc;
        private string _token;
        private string _language;
        public IdentityController(IIdentityService identitySvc)
        {
            this._identitySvc = identitySvc;
        }
        protected string _loggedInUserId
        {
            get
            {
                _userId = _identitySvc.GetUserName();
                return _userId;
            }
        }
        protected string _userRole
        {
            get
            {
                if (_role == null)
                {
                    _role = User.GetClaim(OpenIdConnectConstants.Claims.Role);
                }
                return _role;
            }
        }

        protected int _loggedInUserDBId
        {
            get
            {
                _dbId = Convert.ToInt32(_identitySvc.GetUserIdentity());
                return _dbId;
            }
        }

        protected string _loggedInUserToken
        {
            get
            {
                _token = _identitySvc.GetToken();
                return _token;
            }
        }

        protected string _loggedInUserLanguage
        {
            get
            {
                _language = _identitySvc.GetUserLanguage();
                return _language;
            }
        }
    }
}
