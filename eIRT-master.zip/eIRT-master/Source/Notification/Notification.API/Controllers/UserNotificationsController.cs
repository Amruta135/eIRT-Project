﻿using System.Threading.Tasks;
using AspNet.Security.OAuth.Introspection;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Notification.API.Models;
using Notification.API.Repository.Interface;
using Notification.API.Services;
using static Notification.API.Validation.TokenValidation;

namespace Notification.API.Controllers
{
    [ApiVersion("1.0")]
    [Route("api/v{version:apiVersion}/[controller]")]
    [ApiController]
    [Authorize(AuthenticationSchemes = OAuthIntrospectionDefaults.AuthenticationScheme)]
    [Authorize]
    [TokenValid]
    public class UserNotificationsController : IdentityController
    {
        private readonly IUserNotificationsRepository _userNotificationsRepository;

        public UserNotificationsController(IUserNotificationsRepository userNotificationsRepository,
                                           IIdentityService identitySvc,
                                           IHttpContextAccessor httpContextAccessor) : base(identitySvc)
        {
            _userNotificationsRepository = userNotificationsRepository;
        }

        [HttpGet]
        public async Task<IActionResult> GetUserNotifications()
        {
            return Ok(await _userNotificationsRepository.GetUserNotifications(_loggedInUserDBId));
        }
        [HttpGet("{id}")]
        public async Task<IActionResult> ReadNotification(int notificationId)
        {
            UserNotifications existingUserNotifications = await this._userNotificationsRepository.GetAsync(notificationId);

            if (existingUserNotifications != null)
            {
                existingUserNotifications.IsRead = true;
                await this._userNotificationsRepository.UpdateAsync(existingUserNotifications);
            }
            bool status = true;
            return Ok(status);
        }
    }
}