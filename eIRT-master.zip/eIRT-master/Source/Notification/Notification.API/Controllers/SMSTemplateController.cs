﻿using AspNet.Security.OAuth.Introspection;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Notification.API.APIModel;
using Notification.API.Helper;
using Notification.API.Models;
using Notification.API.Repository.Interface;
using Notification.API.Services;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Notification.API.Common;
using static Notification.API.Validation.TokenValidation;

namespace Notification.API.Controllers
{
    [ApiVersion("1.0")]
    [Route("api/v{version:apiVersion}/[controller]")]
    [ApiController]
    [Authorize(AuthenticationSchemes = OAuthIntrospectionDefaults.AuthenticationScheme)]
    [Authorize]
    [TokenValid]
    public class SMSTemplateController : IdentityController
    {
        ISMSTemplate _smsTemplate;
        private readonly IExportManager<APISMSTemplateSearch> _exportManager;
        public SMSTemplateController(ISMSTemplate smsTemplate,
                                     IIdentityService identitySvc,
                                     IHttpContextAccessor httpContextAccessor,
                                     IExportManager<APISMSTemplateSearch> exportManager) : base(identitySvc)
        {
            this._smsTemplate = smsTemplate;
            _exportManager = exportManager;
        }

        //// GET: api/SMSTemplate
        //[HttpGet]
        //public async Task<IActionResult> GetAll()
        //{
        //    IEnumerable<SMSTemplate> smsTemplates = await this._smsTemplate.GetAllAsync();
        //    return Ok(smsTemplates);
        //}

        // GET: api/SMSTemplate/5
        [HttpGet("{id:int}")]
        public async Task<IActionResult> Get(int id)
        {
            return Ok(await this._smsTemplate.GetSMSTemplate(id));
        }

        [HttpGet("GetSMSTemplates/{page:int}/{pageSize:int}/{filter?}/{search?}")]
        public async Task<IActionResult> GetSMSTemplates(int page, int pageSize, string filter = null, string search = null)
        {
            try
            {
                return Ok(await this._smsTemplate.GetSMSTemplates(page, pageSize, filter, search));
            }
            catch (Exception ex)
            {
                return BadRequest(new ResponseMessage { Message = EnumHelper.GetEnumName(MessageType.InternalServerError), Description = ex.StackTrace });
            }
        }

        [HttpGet("GetSMSTemplatesCount/{filter?}/{search?}")]
        public async Task<IActionResult> GetSMSTemplatesCount(string filter = null, string search = null)
        {
            try
            {
                return Ok(await this._smsTemplate.GetSMSTemplatesCount(filter, search));
            }
            catch (Exception)
            {
                return BadRequest(new ResponseMessage { Message = EnumHelper.GetEnumName(MessageType.InternalServerError), Description = EnumHelper.GetEnumDescription(MessageType.InternalServerError) });
            }
        }

        // POST: api/SMSTemplate
        [HttpPost]
        public async Task<IActionResult> Post([FromBody] APISMSTemplate apiSMSTemplate)
        {
            try
            {
                if (!ModelState.IsValid)
                    return this.BadRequest(this.ModelState);

                SMSTemplate smsTemplate = new SMSTemplate();
                smsTemplate.Title = apiSMSTemplate.Title;
                smsTemplate.Content = apiSMSTemplate.Content;
                smsTemplate.CreatedDate = DateTime.Now;
                smsTemplate.CreatedBy = _loggedInUserDBId;
                smsTemplate.ModifiedDate = DateTime.Now;
                smsTemplate.ModifiedBy = _loggedInUserDBId;
                smsTemplate.Status = apiSMSTemplate.Status;
                //smsTemplate.Language = apiSMSTemplate.Language;

                await this._smsTemplate.AddAsync(smsTemplate);
                return Ok();
            }
            catch (System.Exception ex)
            {
                return this.BadRequest(new ResponseMessage { Message = EnumHelper.GetEnumName(MessageType.InternalServerError), Description = ex.StackTrace });
            }
        }

        // PUT: api/SMSTemplate/5
        [HttpPut("{id}")]
        public async Task<IActionResult> Put(int id, [FromBody] APISMSTemplate apiSMSTemplate)
        {
            try
            {
                if (!ModelState.IsValid)
                    return this.BadRequest(this.ModelState);

                SMSTemplate smsTemplate = await this._smsTemplate.GetAsync(id);
                if (smsTemplate == null)
                {
                    return this.BadRequest(new ResponseMessage { Message = EnumHelper.GetEnumName(MessageType.NotExist), Description = EnumHelper.GetEnumDescription(MessageType.NotExist) });
                }
                smsTemplate.Id = id;
                //smsTemplate.Title = apiSMSTemplate.Title;
                //smsTemplate.Content = apiSMSTemplate.Content;
                smsTemplate.ModifiedDate = DateTime.Now;
                smsTemplate.ModifiedBy = _loggedInUserDBId;
                smsTemplate.Status = apiSMSTemplate.Status;

                await this._smsTemplate.UpdateAsync(smsTemplate);
                return Ok();
            }
            catch (System.Exception ex)
            {
                return this.BadRequest(new ResponseMessage { Message = EnumHelper.GetEnumName(MessageType.InternalServerError), Description = ex.StackTrace });
            }
        }

        // DELETE: api/ApiWithActions/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            if (!ModelState.IsValid)
                return this.BadRequest(this.ModelState);

            SMSTemplate smsTemplate = await this._smsTemplate.GetAsync(id);
            if (smsTemplate == null)
            {
                return this.BadRequest(new ResponseMessage { Message = EnumHelper.GetEnumName(MessageType.NotExist), Description = EnumHelper.GetEnumDescription(MessageType.NotExist) });
            }
            smsTemplate.IsDeleted = true;
            smsTemplate.ModifiedDate = DateTime.Now;
            smsTemplate.ModifiedBy = _loggedInUserDBId;

            await this._smsTemplate.UpdateAsync(smsTemplate);
            return Ok();
        }

        [HttpGet]
        [Route("Exportxlsx")]
        public async Task<IActionResult> ExportXlsx(string filter = null, string search = null)
        {
            try
            {
                IEnumerable<APISMSTemplateSearch> smsTemplateSearches = await this._smsTemplate.GetSMSTemplates(1, 200000, filter, search);

                var properties = new[]
                    {
                        new PropertyByName<APISMSTemplateSearch>("Title", p => p.Title),
                        new PropertyByName<APISMSTemplateSearch>("Item Desc", p => p.Content),
                        new PropertyByName<APISMSTemplateSearch>("Status", p => p.Status),
                        new PropertyByName<APISMSTemplateSearch>("Language", p => p.Language),
                    };

                byte[] bytes = _exportManager.ExportToXlsx(properties, smsTemplateSearches);

                return File(bytes, "text/xls", "SMSTemplates.xlsx");

            }
            catch (Exception)
            {
                return BadRequest(new ResponseMessage { Message = EnumHelper.GetEnumName(MessageType.InternalServerError), Description = EnumHelper.GetEnumDescription(MessageType.InternalServerError) });
            }
        }
    }
}
