﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Notification.API.APIModel;
using Notification.API.Handlers;
using Notification.API.Helper;
using Notification.API.Models;
using Notification.API.Repository.Interface;
using Notification.API.SMSHandler;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Notification.API.Controllers
{
    [ApiVersion("1.0")]
    [Route("api/v{version:apiVersion}/[controller]")]
    [ApiController]
    public class NotificationController : ControllerBase
    {
        private readonly ISMSSender _smsSender;
        private readonly IUserMasterRepository _userMasterRepository;
        private readonly ISMSHandler _smsHandler;
        private readonly INotificationHandler _notificationHandler;

        public IConfiguration _configuration { get; }

        public NotificationController(ISMSSender smsSender,
                             IConfiguration configuration,
                             IUserMasterRepository userMasterRepository,
                             ISMSHandler smsHandler,
                             INotificationHandler notificationHandler)
        {
            _smsSender = smsSender;
            _configuration = configuration;
            _userMasterRepository = userMasterRepository;
            _smsHandler = smsHandler;
            _notificationHandler = notificationHandler;
        }

        [HttpPost("SendOTP")]
        public async Task<ActionResult> SendOTP([FromBody] APISMSOTP apiSMSOTP)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    Message smsMessage = new Message();
                    smsMessage.Template = Template.OTP;

                    Dictionary<string, string> smsTokensToReplace = new Dictionary<string, string>();
                    smsTokensToReplace.Add(Token.UserName, apiSMSOTP.UserName);
                    smsTokensToReplace.Add(Token.NewLine, System.Environment.NewLine);
                    smsTokensToReplace.Add(Token.OTP, apiSMSOTP.OTP);
                    smsMessage.Tokens = smsTokensToReplace;
                    smsMessage.SenderMobileNumber = apiSMSOTP.MobileNumber;
                    smsMessage.SenderUerId = apiSMSOTP.UserId;

                    bool status = await _smsHandler.Send(smsMessage);
                    return Ok(new { status });
                }
                catch (Exception)
                {
                    return BadRequest(new ResponseMessage { Message = EnumHelper.GetEnumName(MessageType.InternalServerError), Description = EnumHelper.GetEnumDescription(MessageType.InternalServerError) });
                }
            }
            return this.BadRequest(this.ModelState);
        }

        [HttpPost("SendIRTAdminCreatesNewAccount")]
        public async Task<ActionResult> SendIRTAdminCreatesNewAccount([FromBody] APIIRTAdminCreatesNewAccount apiIRTAdminCreatesNewAccount)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    Message smsMessage = new Message();
                    smsMessage.Template = Template.IRTAdminCreatesNewAccount;
                    bool status = false;
                    string message = string.Empty;
                    string result = string.Empty;

                    Dictionary<string, string> smsTokensToReplace;

                    smsTokensToReplace = new Dictionary<string, string>();
                    smsTokensToReplace.Add(Token.UserName, apiIRTAdminCreatesNewAccount.UserName);
                    smsTokensToReplace.Add(Token.NewLine, System.Environment.NewLine);
                    smsTokensToReplace.Add(Token.ClientAdmin, apiIRTAdminCreatesNewAccount.ClientAdmin);
                    smsTokensToReplace.Add(Token.OrgID, apiIRTAdminCreatesNewAccount.OrgID);
                    smsTokensToReplace.Add(Token.OTP, apiIRTAdminCreatesNewAccount.OTP);

                    smsMessage.Tokens = smsTokensToReplace;
                    smsMessage.SenderMobileNumber = apiIRTAdminCreatesNewAccount.MobileNumber;
                    smsMessage.SenderUerId = apiIRTAdminCreatesNewAccount.UserId;

                    status = await _smsHandler.Send(smsMessage);
                    smsTokensToReplace.Clear();

                    return Ok(new { status });
                }
                catch (Exception)
                {
                    return BadRequest(new ResponseMessage { Message = EnumHelper.GetEnumName(MessageType.InternalServerError), Description = EnumHelper.GetEnumDescription(MessageType.InternalServerError) });
                }
            }
            return this.BadRequest(this.ModelState);
        }

        [HttpPost("SendNewIncidentReported")]
        public async Task<ActionResult> SendNewIncidentReported([FromBody] APINewIncidentReported apiNewIncidentReported)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    Message smsMessage = new Message();
                    smsMessage.Template = Template.NewIncidentReported;
                    bool status = false;
                    string message = string.Empty;
                    string result = string.Empty;

                    Dictionary<string, string> smsTokensToReplace;

                    smsTokensToReplace = new Dictionary<string, string>();
                    smsTokensToReplace.Add(Token.UserName, apiNewIncidentReported.UserName);
                    smsTokensToReplace.Add(Token.NewLine, System.Environment.NewLine);
                    smsTokensToReplace.Add(Token.ClientAdmin, apiNewIncidentReported.ClientAdmin);
                    smsTokensToReplace.Add(Token.Department, apiNewIncidentReported.Department);
                    smsTokensToReplace.Add(Token.IncidentCategory, apiNewIncidentReported.IncidentCategory);

                    smsMessage.Tokens = smsTokensToReplace;
                    smsMessage.SenderMobileNumber = apiNewIncidentReported.MobileNumber;
                    smsMessage.SenderUerId = apiNewIncidentReported.UserId;

                    status = await _smsHandler.Send(smsMessage);
                    smsTokensToReplace.Clear();

                    return Ok(new { status });
                }
                catch (Exception)
                {
                    return BadRequest(new ResponseMessage { Message = EnumHelper.GetEnumName(MessageType.InternalServerError), Description = EnumHelper.GetEnumDescription(MessageType.InternalServerError) });
                }
            }
            return this.BadRequest(this.ModelState);
        }

        [HttpPost("SendIncidentAssigned")]
        public async Task<ActionResult> SendIncidentAssigned([FromBody] APIIncidentAssigned apiIncidentAssigned)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    Message smsMessage = new Message();
                    smsMessage.Template = Template.IncidentAssigned;
                    bool status = false;
                    string message = string.Empty;
                    string result = string.Empty;

                    Dictionary<string, string> smsTokensToReplace;

                    smsTokensToReplace = new Dictionary<string, string>();
                    smsTokensToReplace.Add(Token.UserName, apiIncidentAssigned.UserName);
                    smsTokensToReplace.Add(Token.NewLine, System.Environment.NewLine);
                    smsTokensToReplace.Add(Token.ClientAdmin, apiIncidentAssigned.ClientAdmin);
                    smsTokensToReplace.Add(Token.IncidentReportedUserName, apiIncidentAssigned.IncidentReportedUserName);
                    smsTokensToReplace.Add(Token.IncidentID, apiIncidentAssigned.IncidentID);

                    smsMessage.Tokens = smsTokensToReplace;
                    smsMessage.SenderMobileNumber = apiIncidentAssigned.MobileNumber;
                    smsMessage.SenderUerId = apiIncidentAssigned.UserId;

                    status = await _smsHandler.Send(smsMessage);
                    smsTokensToReplace.Clear();

                    return Ok(new { status });
                }
                catch (Exception)
                {
                    return BadRequest(new ResponseMessage { Message = EnumHelper.GetEnumName(MessageType.InternalServerError), Description = EnumHelper.GetEnumDescription(MessageType.InternalServerError) });
                }
            }
            return this.BadRequest(this.ModelState);
        }

        [HttpPost("SendNewATRAdded")]
        public async Task<ActionResult> SendNewATRAdded([FromBody] APINewATRAdded apiNewATRAdded)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    Message smsMessage = new Message();
                    smsMessage.Template = Template.NewATRAdded;
                    bool status = false;
                    string message = string.Empty;
                    string result = string.Empty;

                    Dictionary<string, string> smsTokensToReplace;

                    smsTokensToReplace = new Dictionary<string, string>();
                    smsTokensToReplace.Add(Token.UserName, apiNewATRAdded.UserName);
                    smsTokensToReplace.Add(Token.NewLine, System.Environment.NewLine);
                    smsTokensToReplace.Add(Token.ActingUserName, apiNewATRAdded.ActingUserName);
                    smsTokensToReplace.Add(Token.ATRStatus, apiNewATRAdded.ATRStatus);
                    smsTokensToReplace.Add(Token.IncidentID, apiNewATRAdded.IncidentID);

                    smsMessage.Tokens = smsTokensToReplace;
                    smsMessage.SenderMobileNumber = apiNewATRAdded.MobileNumber;
                    smsMessage.SenderUerId = apiNewATRAdded.UserId;

                    status = await _smsHandler.Send(smsMessage);
                    smsTokensToReplace.Clear();

                    return Ok(new { status });
                }
                catch (Exception)
                {
                    return BadRequest(new ResponseMessage { Message = EnumHelper.GetEnumName(MessageType.InternalServerError), Description = EnumHelper.GetEnumDescription(MessageType.InternalServerError) });
                }
            }
            return this.BadRequest(this.ModelState);
        }
    }
}