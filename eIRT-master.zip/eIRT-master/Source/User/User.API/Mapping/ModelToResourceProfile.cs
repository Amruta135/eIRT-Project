﻿using AutoMapper;
using User.API.APIModel;
using User.API.Models;

namespace User.API.Mapping
{
    public class ModelToResourceProfile : Profile
    {
        public ModelToResourceProfile()
        {
            CreateMap<OrganizationInfo, APIOrganizationInfo>();
            CreateMap<APIOrganizationInfo, OrganizationInfo>();

            CreateMap<IncidentReport, APIIncidentReport>();
            CreateMap<APIIncidentReport, IncidentReport>();
            
            CreateMap<IncidentAssignment, APIIncidentAssignment>();
            CreateMap<APIIncidentAssignment, IncidentAssignment>();

            CreateMap<APIUserDetails, UserMaster>();
            CreateMap<UserMaster, APIUserDetails>();

            CreateMap<ActionTakenReport, APIActionTakenReport>();
            CreateMap<APIActionTakenReport, ActionTakenReport>();

            CreateMap<UserMaster, APIUserProfile>();
            CreateMap<APIUserProfile, UserMaster>();
        }
    }
}
