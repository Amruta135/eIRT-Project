﻿namespace User.API
{
    public class AppSetting
    {
        public string AdminUrl { get; set; }
        public string AppUserUrl { get; set; }
        public string IdentityUrl { get; set; }
        public string NotificationUrl { get; set; }
    }
}
