﻿using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using System;
using System.IO;
using System.Linq;
using System.Text;

namespace User.API.Helper
{
    public class FileHelper
    {
        private static IConfiguration _AppConfig { get; set; }

        public FileHelper()
        {
            var builder = new ConfigurationBuilder()
                .SetBasePath(Directory.GetCurrentDirectory())
                .AddJsonFile("appsettings.json");
            _AppConfig = builder.Build();
        }
        public static EnumImageFormat GetImageFormat(byte[] bytes)
        {
            var bmp = Encoding.ASCII.GetBytes("BM");     // BMP
            var gif = Encoding.ASCII.GetBytes("GIF");    // GIF
            var png = new byte[] { 137, 80, 78, 71 };              // PNG
            var jpeg = new byte[] { 255, 216, 255, 224 };          // jpeg
            var jpeg2 = new byte[] { 255, 216, 255, 225 };         // jpeg canon

            if (bmp.SequenceEqual(bytes.Take(bmp.Length)))
                return EnumImageFormat.bmp;

            if (gif.SequenceEqual(bytes.Take(gif.Length)))
                return EnumImageFormat.gif;

            if (png.SequenceEqual(bytes.Take(png.Length)))
                return EnumImageFormat.png;

            if (jpeg.SequenceEqual(bytes.Take(jpeg.Length)))
                return EnumImageFormat.jpeg;

            if (jpeg2.SequenceEqual(bytes.Take(jpeg2.Length)))
                return EnumImageFormat.jpeg;

            return EnumImageFormat.unknown;
        }

        /// Method to check if file is image file
        public static bool CheckIfImageFile(IFormFile file)
        {
            byte[] fileBytes;
            using (var ms = new MemoryStream())
            {
                file.CopyTo(ms);
                fileBytes = ms.ToArray();
            }
            return GetImageFormat(fileBytes) != EnumImageFormat.unknown;
        }

        public static string GetSaveFilePath(EnumFileUploadFor uploadFor)
        {
            string DirPath = "";

            FileHelper FUH = new FileHelper();

            switch (uploadFor)
            {
                case EnumFileUploadFor.UserProfilePic:
                    DirPath = _AppConfig.GetSection("UplodedFileDir").GetSection("UserProfilePicPath").Value;
                    break;
                case EnumFileUploadFor.Temp:
                    DirPath = _AppConfig.GetSection("UplodedFileDir").GetSection("Temp").Value;
                    break;
                case EnumFileUploadFor.OrganizationLogo:
                    DirPath = _AppConfig.GetSection("UplodedFileDir").GetSection("OrganizationLogoPath").Value;
                    break;
                case EnumFileUploadFor.IncidentReportPhoto:
                    DirPath = _AppConfig.GetSection("UplodedFileDir").GetSection("IncidentReportPhotoPath").Value;
                    break;
                default:
                    DirPath = "";
                    break;
            }
            return DirPath;
        }

        public static string GetSavedFileWebPath(EnumFileUploadFor uploadFor)
        {
            string DirPath = "";

            FileHelper FUH = new FileHelper();

            switch (uploadFor)
            {
                case EnumFileUploadFor.UserProfilePic:
                    DirPath = _AppConfig["UplodedFileWebDir:UserProfilePicPath"];
                    break;
                case EnumFileUploadFor.Temp:
                    DirPath = _AppConfig.GetSection("UplodedFileWebDir").GetSection("Temp").Value;
                    break;
                case EnumFileUploadFor.OrganizationLogo:
                    DirPath = _AppConfig.GetSection("UplodedFileWebDir").GetSection("OrganizationLogoPath").Value;
                    break;
                case EnumFileUploadFor.IncidentReportPhoto:
                    DirPath = _AppConfig.GetSection("UplodedFileWebDir").GetSection("IncidentReportPhotoPath").Value;
                    break;
                default:
                    DirPath = "";
                    break;
            }
            return DirPath;
        }

        public static bool DeleteFile(EnumFileUploadFor uplodedFor, string fileName)
        {
            bool isDeleted = false;
            string rootDir = AppDomain.CurrentDomain.BaseDirectory;
            rootDir = rootDir.Contains("bin") ? rootDir.Substring(0, rootDir.IndexOf("bin") - 1) : rootDir.EndsWith("\\") ? rootDir.Substring(0, rootDir.LastIndexOf("\\")) : rootDir;
            try
            {
                string fullPath = rootDir + GetSaveFilePath(uplodedFor);//Path.Combine( GetSaveFilePath(uplodedFor), fileName);
                fullPath = Path.Combine(fullPath, fileName);
                
                string thumbPath = fullPath + "\\Thumbs";
                thumbPath = Path.Combine(thumbPath, fileName);
                
                if (File.Exists(fullPath))
                {
                    File.Delete(fullPath);
                    isDeleted = true;
                }
                if (File.Exists(thumbPath))
                {
                    File.Delete(thumbPath);
                    isDeleted = true;
                }
            }
            catch (Exception e)
            {
                isDeleted = false;
            }
            return isDeleted;
        }

        public static string GetFile(EnumFileUploadFor uplodedFor, string fileName)
        {
            //string p = webRootPath;
            string rootDir = AppDomain.CurrentDomain.BaseDirectory;
            rootDir = rootDir.Contains("bin") ? rootDir.Substring(0, rootDir.IndexOf("bin") - 1) : rootDir.EndsWith("\\") ? rootDir.Substring(0, rootDir.LastIndexOf("\\")) : rootDir;
            string mimeType = "";
            byte[] byteFile = null;
            try
            {
                string fullPath = rootDir + GetSaveFilePath(uplodedFor);
                fullPath = Path.Combine(fullPath, fileName);
                //string fileBase64 = "";
                if (File.Exists(fullPath))
                {
                    byteFile = System.IO.File.ReadAllBytes(fullPath);
                    string fileExtention = Path.GetExtension(fileName);

                    switch (fileExtention.ToLower())
                    {
                        case ".jpg":
                            mimeType = "image/jpeg";
                            break;
                        case ".jpeg":
                            mimeType = "image/jpeg";
                            break;
                        case ".png":
                            mimeType = "image/png";
                            break;
                        case ".pdf":
                            mimeType = "application/pdf";
                            break;
                        case ".xls":
                            mimeType = "application/vnd.ms-excel";
                            break;
                        case ".xlsx":
                            mimeType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                            break;
                        default:
                            mimeType = "application/octet-stream";
                            break;
                    }
                }
                if (!string.IsNullOrWhiteSpace(mimeType) && mimeType.Trim().Length > 0 && byteFile != null && byteFile.Length > 0)
                    return "data:" + mimeType + ";base64," + Convert.ToBase64String(byteFile);
                else
                    return "";
            }

            catch (Exception e)
            {
                return "";
            }
        }

        public static string GetThumb(EnumFileUploadFor uplodedFor, string fileName)
        {
            string rootDir = AppDomain.CurrentDomain.BaseDirectory;
            rootDir = rootDir.Contains("bin") ? rootDir.Substring(0, rootDir.IndexOf("bin") - 1) : rootDir.EndsWith("\\") ? rootDir.Substring(0, rootDir.LastIndexOf("\\")) : rootDir;
            string mimeType = "";
            byte[] byteFile = null;
            try
            {
                string fullPath = rootDir + GetSaveFilePath(uplodedFor) + "\\Thumbs";
                fullPath = Path.Combine(fullPath, fileName);
                if (File.Exists(fullPath))
                {
                    byteFile = System.IO.File.ReadAllBytes(fullPath);
                    string fileExtention = Path.GetExtension(fileName);

                    switch (fileExtention.ToLower())
                    {
                        case ".jpg":
                            mimeType = "image/jpeg";
                            break;
                        case ".jpeg":
                            mimeType = "image/jpeg";
                            break;
                        case ".png":
                            mimeType = "image/png";
                            break;
                    }
                }
                if (!string.IsNullOrWhiteSpace(mimeType) && mimeType.Trim().Length > 0 && byteFile != null && byteFile.Length > 0)
                    return "data:" + mimeType + ";base64," + Convert.ToBase64String(byteFile);
                else
                    return "";
            }
            catch (Exception e)
            {
                return "";
            }
        }
    }
}
