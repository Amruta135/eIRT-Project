﻿using System.ComponentModel;

namespace User.API.Helper
{
    public class ResponseMessage
    {
        public int StatusCode { get; set; }
        public string Message { get; set; }
        public string Description { get; set; }
    }
    public enum MessageType
    {
        [Description("Record was saved successfully")]
        Success,
        [Description("Failed to save")]
        Fail,
        [Description("Deleted record")]
        Delete,
        [Description("No record found!")]
        NotFound,
        [Description("Record does not exist!")]
        RecordFound,
        [Description("Record exist!")]
        NotExist,
        [Description("Duplicate! Already exist.")]
        Duplicate,
        [Description("Data not available")]
        DataNotAvailable,
        [Description("Invalid data!")]
        InvalidData,
        [Description("Invalid file formate!")]
        InvalidFile,
        [Description("Internal Server Error!")]
        InternalServerError,
        [Description("Unique value changed!")]
        UniqueChanged,
        [Description("Does Not Exist!")]
        DoesNotExist,
        [Description("Self ReportTo Not Allow")]
        SelfReportToNotAllow,
        [Description("Access Restricted")]
        Unauthorized,
        [Description("Max limit reach")]
        MaxLimitReached,
        [Description("Start Date should not less than Created Date")]
        StartDateCheck
    }
}
