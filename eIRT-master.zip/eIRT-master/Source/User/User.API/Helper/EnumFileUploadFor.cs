﻿using System.ComponentModel;

namespace User.API.Helper
{
    public enum EnumFileUploadFor
    {
        [Description("User Profile Picture")]
        UserProfilePic,
        [Description("Temperory Store before Compress")]
        Temp,
        [Description("Organization Logo")]
        OrganizationLogo,
        [Description("Incident Report Photo")]
        IncidentReportPhoto,
    }
}
