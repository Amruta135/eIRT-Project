﻿namespace User.API.Helper
{
    public enum EnumFileType
    {
        Image,
        Document
    }

    public static class SatusType
    {
        public static string Active = "active";
        public static string InActive = "inactive";
    }
}
