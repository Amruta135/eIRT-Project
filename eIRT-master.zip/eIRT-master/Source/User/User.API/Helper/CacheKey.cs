﻿namespace User.API.Helper
{
    public static class CacheKeys
    {
        public static string States { get { return "_States"; } }
        public static string PinCodes { get { return "_PinCodes"; } }
        public static string Status { get { return "_Status"; } }
        public static string ConfigurableValues { get { return "_ConfigurableValues"; } }
    }
}
