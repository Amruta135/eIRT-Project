﻿namespace User.API.Helper
{
    public class Record
    {
        public const string CSV = "csv";
        public const string XLSX = "xlsx";

        public const string active = "active";
        public const string inactive = "inactive";

        public const string Yes = "Yes";
        public const string No = "No";
    }

    public class Status
    {
        public const string Active = "active";
        public const string Inactive = "inactive";
    }

    public class Role
    {
        public const string Posiview_Admin = "Posiview Admin";
        public const string IRT_Client_Admin = "IRT Client Admin";
        public const string EHS_Monitor = "EHS Monitor";
        public const string EHS_Manager = "EHS Manager";
        public const string EHS_Inspector = "EHS Inspector";
    }

    public class RoleCode
    {
        public const string Posiview_Admin = "PA";
        public const string IRT_Client_Admin = "CA";
        public const string EHS_Monitor = "EO";
        public const string EHS_Manager = "EM";
        public const string EHS_Inspector = "EI";
    }

    public class IncidentReportingStatus
    {
        public const string Draft = "Draft";
        public const string Reported = "Reported";
        public const string Cancelled = "Cancelled";
        public const string WorkInProgress = "Work in Progress";
        public const string Closed = "Closed";
        public const string Assigned = "Assigned";
    }

    public class IncidentCategoryCode
    {
        public const string High = "High";
        public const string Medium = "Medium";
        public const string Low = "Low";
    }

    public class Template
    {
        public const string OTP = "OTP";
        public const string IRTAdminCreatesNewAccount = "IRTAdminCreatesNewAccount";
        public const string NewIncidentReported = "NewIncidentReported";
        public const string IncidentAssigned = "IncidentAssigned";
        public const string NewATRAdded = "NewATRAdded";
    }

    public class FileContentType
    {
        public static string Excel = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
    }

    public class ImportCustomer
    {
        public const string CustomerGroupName = "Customer Group Name";
        public const string CustomerMobile = "Customer Mobile Number";
        public const string CustomerName = "Customer Name";
        public const string Address = "Address";
        public const string Pincode = "Pincode";
        public const string State = "State";
        public const string City = "City";
        public const string SecurityDeposit = "Security Deposit";
        public const string MonthlyCharges = "Monthly Charges";
    }
}
