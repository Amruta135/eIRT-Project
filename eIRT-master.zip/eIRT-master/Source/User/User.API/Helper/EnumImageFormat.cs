﻿namespace User.API.Helper
{
    public enum EnumImageFormat
    {
        bmp,
        jpeg,
        //jpg,
        gif,
        png,
        unknown
    }
}
