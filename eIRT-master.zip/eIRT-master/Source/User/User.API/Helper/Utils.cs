﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace User.API.Helper
{
    public class Utils
    {
        public static int CountDaysBetweenDates(DateTime startDate, DateTime endDate, string strDays)
        {
            if (strDays == null || string.IsNullOrWhiteSpace(strDays))
                return 0;

            string[] DaysArray = strDays.Split(',').ToArray();
            if (DaysArray.Length == 0)
            {
                return 0;
            }
            int weekEndCount = 0;
            if (startDate > endDate)
            {
                DateTime temp = startDate;
                startDate = endDate;
                endDate = temp;
            }
            TimeSpan diff = endDate - startDate;
            int days = diff.Days;
            for (var i = 0; i <= days; i++)
            {
                var testDate = startDate.AddDays(i);
                for (var j = 0; j < DaysArray.Length; j++)
                {
                    if (testDate.DayOfWeek.GetEnumName() == Enum.GetName(typeof(DayOfWeek), Convert.ToInt32(DaysArray[j])))
                    {
                        weekEndCount += 1;
                    }
                }
            }
            return weekEndCount;
        }

        public static List<DateTime> GetDatesByDays(DateTime startDate, DateTime endDate, string strDays)
        {
            List<DateTime> ListOfDates = new List<DateTime>();
            if (strDays == null || string.IsNullOrWhiteSpace(strDays))
                return ListOfDates;

            string[] DaysArray = strDays.Split(',').ToArray();
            if (DaysArray.Length == 0)
            {
                return ListOfDates;
            }
            
            if (startDate > endDate)
            {
                DateTime temp = startDate;
                startDate = endDate;
                endDate = temp;
            }
            TimeSpan diff = endDate - startDate;
            int days = diff.Days;
            for (var i = 0; i <= days; i++)
            {
                var testDate = startDate.AddDays(i);
                for (var j = 0; j < DaysArray.Length; j++)
                {
                    if (testDate.DayOfWeek.GetEnumName() == Enum.GetName(typeof(DayOfWeek), Convert.ToInt32(DaysArray[j])))
                    {
                        ListOfDates.Add(testDate);
                    }
                }
            }
            return ListOfDates;
        }

        public static List<DateTime> GetDatesByDates(DateTime startDate, DateTime endDate, string strDays)
        {
            List<DateTime> ListOfDates = new List<DateTime>();
            if (strDays == null || string.IsNullOrWhiteSpace(strDays))
                return ListOfDates;

            string[] DaysArray = strDays.Split(',').ToArray();
            if (DaysArray.Length == 0)
            {
                return ListOfDates;
            }
            for (int i = 0; i < DaysArray.Length; i++)
            {
                DateTime dt1 = new DateTime(startDate.Year, startDate.Month, Convert.ToInt32(DaysArray[i]));
                DateTime dt2 = new DateTime(endDate.Year, endDate.Month, Convert.ToInt32(DaysArray[i]));
                if (dt1 >= startDate && dt1 < endDate)
                    ListOfDates.Add(dt1);
                else if (dt2 >= startDate && dt2 < startDate)
                    ListOfDates.Add(dt2);
            }
            return ListOfDates;
        }
    }
}
