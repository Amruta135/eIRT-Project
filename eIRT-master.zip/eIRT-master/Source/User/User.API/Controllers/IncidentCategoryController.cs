﻿using AspNet.Security.OAuth.Introspection;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using User.API.APIModel;
using User.API.Helper;
using User.API.Models;
using User.API.Repositories.Interface;
using User.API.Services;
using static User.API.Validation.TokenValidation;

namespace User.API.Controllers
{
    [ApiVersion("1.0")]
    [Route("user/api/v{version:apiVersion}/[controller]")]
    [ApiController]
    [Authorize(AuthenticationSchemes = OAuthIntrospectionDefaults.AuthenticationScheme)]
    [Authorize]
    [TokenValid]
    public class IncidentCategoryController : IdentityController
    {
        private readonly IIncidentCategoryRepository _incidentCategoryRepository;
        private readonly IIdentityService _identitySvc;
        private readonly IHttpContextAccessor _httpContextAccessor;
        public IncidentCategoryController(IIncidentCategoryRepository incidentCategoryRepository,
                                          IIdentityService identitySvc,
                                          IHttpContextAccessor httpContextAccessor) : base(identitySvc)

        {
            _incidentCategoryRepository = incidentCategoryRepository;
            _identitySvc = identitySvc;
            _httpContextAccessor = httpContextAccessor;
        }


        [HttpPost("Get")]
        public async Task<IActionResult> Get(APIId apiId)
        {
            IncidentCategory incidentCategory = await this._incidentCategoryRepository.GetAsync(apiId.Id);

            if (incidentCategory != null)
                return this.Ok(incidentCategory);
            else
                return this.BadRequest(new ResponseMessage { Message = EnumHelper.GetEnumName(MessageType.NotFound), Description = "" });
        }

        [HttpPost("GetIncidentCategories")]
        public async Task<IActionResult> GetIncidentCategories(APISearchInfo apiSearchInfo)
        {
            try
            {
                List<APIIncidentCategory> apiIncidentCategories = await this._incidentCategoryRepository.GetIncidentCategories(_loggedInUserOrganizationCode, apiSearchInfo.page, apiSearchInfo.pageSize, apiSearchInfo.filter, apiSearchInfo.search);

                int count = await this._incidentCategoryRepository.GetIncidentCategoriesCount(_loggedInUserOrganizationCode, apiSearchInfo.filter, apiSearchInfo.search);
                return Ok(new { apiIncidentCategories, count });
            }
            catch (Exception)
            {
                return BadRequest(new ResponseMessage { Message = EnumHelper.GetEnumName(MessageType.InternalServerError), Description = EnumHelper.GetEnumDescription(MessageType.InternalServerError) });
            }
        }

        [HttpPost("GetIncidentCategoriesCount")]
        public async Task<IActionResult> GetIncidentCategoriesCount(APISearchInfo apiSearchInfo)
        {
            try
            {
                return Ok(await this._incidentCategoryRepository.GetIncidentCategoriesCount(_loggedInUserOrganizationCode, apiSearchInfo.filter, apiSearchInfo.search));
            }
            catch (Exception)
            {
                return BadRequest(new ResponseMessage { Message = EnumHelper.GetEnumName(MessageType.InternalServerError), Description = EnumHelper.GetEnumDescription(MessageType.InternalServerError) });
            }
        }

        [HttpPost("Post")]
        public async Task<IActionResult> Post([FromBody] APIIncidentCategory apiIncidentCategory)
        {
            try
            {
                if (!ModelState.IsValid)
                    return this.BadRequest(this.ModelState);

                if (await this._incidentCategoryRepository.FindAsync(s => s.Category == apiIncidentCategory.Category))
                    return this.BadRequest(new ResponseMessage { Message = EnumHelper.GetEnumName(MessageType.Duplicate), Description = "Category already exists!" });

                IncidentCategory incidentCategory = new IncidentCategory();
                incidentCategory.OrganizationCode = _loggedInUserOrganizationCode;
                incidentCategory.Category = apiIncidentCategory.Category;
                incidentCategory.CreatedDate = DateTime.Now;
                incidentCategory.ModifiedDate = DateTime.Now;
                incidentCategory.CreatedBy = _loggedInUserDBId;
                incidentCategory.ModifiedBy = _loggedInUserDBId;

                return Ok(await this._incidentCategoryRepository.AddAndReturnEntityAsync(incidentCategory));
            }
            catch (System.Exception ex)
            {
                return this.BadRequest(new ResponseMessage { Message = EnumHelper.GetEnumName(MessageType.InternalServerError), Description = ex.StackTrace });
            }
        }
        [HttpPut("{id}")]
        public async Task<IActionResult> Put(int Id, [FromBody] APIIncidentCategory apiIncidentCategory)
        {
            try
            {
                if (!ModelState.IsValid)
                    return this.BadRequest(this.ModelState);

                IncidentCategory existingIncidentCategory = await _incidentCategoryRepository.GetAsync(Id);

                if (existingIncidentCategory == null)
                    return this.BadRequest(new ResponseMessage { Message = EnumHelper.GetEnumName(MessageType.NotExist), Description = "" });

                existingIncidentCategory.Category = apiIncidentCategory.Category;
                existingIncidentCategory.ModifiedDate = DateTime.Now;
                existingIncidentCategory.ModifiedBy = _loggedInUserDBId;

                await this._incidentCategoryRepository.UpdateAsync(existingIncidentCategory);

                return Ok(apiIncidentCategory);
            }
            catch (System.Exception ex)
            {
                return this.BadRequest(new ResponseMessage { Message = EnumHelper.GetEnumName(MessageType.InternalServerError), Description = ex.StackTrace });
            }
        }

        [HttpPost("IsExist")]
        public async Task<IActionResult> IsExist(APIIsExistInput apiIsExistInput)
        {
            bool exists = false;
            switch (apiIsExistInput.FieldName.ToLower())
            {
                case "category":
                    exists = await this._incidentCategoryRepository.FindAsync(x => x.Category == apiIsExistInput.value && x.IsDeleted != true);
                    break;
            }
            return Ok(new { exists });
        }
    }
}
