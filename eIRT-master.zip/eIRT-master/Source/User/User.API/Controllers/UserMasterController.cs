﻿using AspNet.Security.OAuth.Introspection;
using AutoMapper;
using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using User.API.APIModel;
using User.API.Common;
using User.API.Helper;
using User.API.MediatR.Command;
using User.API.Models;
using User.API.Repositories.Interface;
using User.API.Services;
using static User.API.Validation.TokenValidation;
using Microsoft.AspNetCore.Hosting;

namespace User.API.Controllers
{
    [ApiVersion("1.0")]
    [Route("user/api/v{version:apiVersion}/[controller]")]
    [ApiController]
    [Authorize(AuthenticationSchemes = OAuthIntrospectionDefaults.AuthenticationScheme)]
    [Authorize]
    [TokenValid]
    public class UserMasterController : IdentityController
    {
        private readonly IUserMasterRepository _userMasterRepository;
        private readonly IMapper _mapper;
        private readonly IExportManager<APIUserDetails> _exportManager;
        private readonly IIdentityService _identitySvc;
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly ITokenExpiredRepository _tokenExpiredRepository;
        private readonly ITokensRepository _tokensRepository;
        private readonly IMediator _mediator;
        private readonly IFileUploaderRepository _fileUploadRepository;
        private readonly ISecurityQuestionRepository _secQuestionRepository;
        private IWebHostEnvironment _env;
        public IConfiguration _configuration { get; }

        public UserMasterController(IUserMasterRepository userMasterRepository,
                                    IMapper mapper,
                                    IConfiguration configuration,
                                    IExportManager<APIUserDetails> exportManager,
                                    IIdentityService identitySvc,
                                    IHttpContextAccessor httpContextAccessor,
                                    ITokenExpiredRepository tokenExpiredRepository,
                                    ITokensRepository tokensRepository,
                                    IMediator mediator,
                                    IFileUploaderRepository fileUploadRepository,
                                    ISecurityQuestionRepository secQuestionRepository,
                                    IWebHostEnvironment env) : base(identitySvc)

        {
            _userMasterRepository = userMasterRepository;
            _mapper = mapper;
            _configuration = configuration;
            _exportManager = exportManager;
            _identitySvc = identitySvc;
            _httpContextAccessor = httpContextAccessor;
            _tokenExpiredRepository = tokenExpiredRepository;
            _tokensRepository = tokensRepository;
            _mediator = mediator;
            _fileUploadRepository = fileUploadRepository;
            _secQuestionRepository = secQuestionRepository;
            _env = env;
        }

        [HttpGet("GetUserDetails")]
        public async Task<IActionResult> GetUserDetails()
        {
            APIUserDetails apiUserDetails = await _userMasterRepository.GetUserDetails(_loggedInUserDBId, _loggedInUserToken);
            if (apiUserDetails != null)
            {
                return this.Ok(apiUserDetails);
            }
            else
                return this.BadRequest(new ResponseMessage { Message = EnumHelper.GetEnumName(MessageType.NotFound), Description = "" });
        }

        [HttpGet("GetUserProfileBase64")]
        public async Task<IActionResult> GetUserProfileBase64()
        {
            APIFileBase64Model file = new APIFileBase64Model();
            APIUserDetails apiUserDetails = await _userMasterRepository.GetUserDetails(_loggedInUserDBId, _loggedInUserToken);
            if (apiUserDetails != null)
            {
                file.Id = apiUserDetails.Id;
                file.GuId = apiUserDetails.GuId;
                file.FileName = apiUserDetails.UserProfilePic;
                if (!string.IsNullOrEmpty(apiUserDetails.UserProfilePic))
                    file.FileBase64 = Helper.FileHelper.GetThumb(EnumFileUploadFor.UserProfilePic, apiUserDetails.UserProfilePic);
                return this.Ok(file);
            }
            else
                return this.BadRequest(new ResponseMessage { Message = EnumHelper.GetEnumName(MessageType.NotFound), Description = "" });
        }

        [HttpGet("GetCurrentUserImageContent")]
        public async Task<IActionResult> GetCurrentUserImageContent()
        {
            APIFileBase64Model image = new APIFileBase64Model() { Id = _loggedInUserDBId };
            APIUserDetails user = await _userMasterRepository.GetUserDetails(_loggedInUserDBId, _loggedInUserToken);

            if ((_userRole != Helper.RoleCode.Posiview_Admin ? _loggedInUserOrganizationCode == user.OrganizationCode : true) && !string.IsNullOrEmpty(user.ProfilePicUrl))
            {
                image.FileName = user.ProfilePicUrl;
                image.FileBase64 = Helper.FileHelper.GetFile(EnumFileUploadFor.UserProfilePic, user.ProfilePicUrl);
                image.Caption = user.Name;
            }
            return Ok(image);
        }

        [HttpGet("GetCurrentUserThumbImageContent")]
        public async Task<IActionResult> GetCurrentUserThumbImageContent()
        {
            APIFileBase64Model image = new APIFileBase64Model() { Id = _loggedInUserDBId };
            APIUserDetails user = await _userMasterRepository.GetUserDetails(_loggedInUserDBId, _loggedInUserToken);

            if ((_userRole != Helper.RoleCode.Posiview_Admin ? _loggedInUserOrganizationCode == user.OrganizationCode : true) && !string.IsNullOrEmpty(user.ProfilePicUrl))
            {
                image.FileName = user.ProfilePicUrl;
                image.FileBase64 = Helper.FileHelper.GetThumb(EnumFileUploadFor.UserProfilePic, user.ProfilePicUrl);
                image.Caption = user.Name;
            }
            return Ok(image);
        }

        [HttpGet("GetImageContent/{id}")]
        public async Task<IActionResult> GetImageContent(int Id)
        {
            APIFileBase64Model image = new APIFileBase64Model() { Id = Id };
            UserMaster user = await this._userMasterRepository.GetAsync(Id);

            if ((_userRole != Helper.RoleCode.Posiview_Admin ? _loggedInUserOrganizationCode == user.OrganizationCode : true ) && !string.IsNullOrEmpty(user.ProfilePicUrl))
            {
                image.FileName = user.ProfilePicUrl;
                image.FileBase64 = Helper.FileHelper.GetFile(EnumFileUploadFor.UserProfilePic, user.ProfilePicUrl);
                image.Caption = user.Name;
            }
            return Ok(image);
        }

        [HttpGet("GetThumbImangeContent/{id}")]
        public async Task<IActionResult> GetThumbImangeContent(int Id)
        {
            APIFileBase64Model image = new APIFileBase64Model() { Id = Id };
            UserMaster user = await this._userMasterRepository.GetAsync(Id);

            if ((_userRole != Helper.RoleCode.Posiview_Admin ? _loggedInUserOrganizationCode == user.OrganizationCode : true) && !string.IsNullOrEmpty(user.ProfilePicUrl))
            {
                image.FileName = user.ProfilePicUrl;
                image.FileBase64 = Helper.FileHelper.GetThumb(EnumFileUploadFor.UserProfilePic, user.ProfilePicUrl);
                image.Caption = user.Name;
            }
            return Ok(image);
        }

        //// GET: api/UserMaster
        //[HttpGet]
        //public async Task<IActionResult> GetAllUsersSignUpDetails()
        //{
        //    IEnumerable<UserMaster> userMasters = await this._userMasterRepository.GetAll(s => s.IsDeleted != true && s.Role == Roles.User);
        //    List<APIUserMasterSignUp> apiUser = new List<APIUserMasterSignUp>();

        //    foreach (UserMaster bm in userMasters)
        //    {
        //        apiUser.Add(_mapper.Map<APIUserMasterSignUp>(bm));
        //    }
        //    return Ok(apiUser);
        //}

        [HttpPost("GetUsersForPA")]
        public async Task<IActionResult> GetUsersForPA(APISearchInfo aPISearchInfo)
        {
            try
            {
                List<APIUserDetails> apiUserDetails = await this._userMasterRepository.GetUsersForPA(aPISearchInfo.page, aPISearchInfo.pageSize, aPISearchInfo.filter, aPISearchInfo.search);

                int count = await this._userMasterRepository.GetUsersForPACount(aPISearchInfo.filter, aPISearchInfo.search);

                return Ok(new { apiUserDetails, count });
            }
            catch (Exception)
            {
                return BadRequest(new ResponseMessage { Message = EnumHelper.GetEnumName(MessageType.InternalServerError), Description = EnumHelper.GetEnumDescription(MessageType.InternalServerError) });
            }
        }

        [HttpPost("GetUsersForCA")]
        public async Task<IActionResult> GetUsersForCA(APISearchInfo aPISearchInfo)
        {
            try
            {
                List<APIUserDetails> apiUserDetails = await this._userMasterRepository.GetUsersForCA(_loggedInUserOrganizationCode, aPISearchInfo.page, aPISearchInfo.pageSize, aPISearchInfo.filter, aPISearchInfo.search);

                int count = await this._userMasterRepository.GetUsersForCACount(_loggedInUserOrganizationCode, aPISearchInfo.filter, aPISearchInfo.search);

                return Ok(new { apiUserDetails, count });
            }
            catch (Exception)
            {
                return BadRequest(new ResponseMessage { Message = EnumHelper.GetEnumName(MessageType.InternalServerError), Description = EnumHelper.GetEnumDescription(MessageType.InternalServerError) });
            }
        }

        [HttpGet]
        [Route("ExportXlsx")]
        public async Task<IActionResult> ExportXlsx(string filter = null, string search = null)
        {
            try
            {
                IEnumerable<APIUserDetails> userMasterSearch = await this._userMasterRepository.GetUsersForPA(1, 200000, filter, search);

                var properties = new[]
                {
                    new PropertyByName<APIUserDetails>("Name", p => p.Name),
                    //new PropertyByName<APIUserDetails>("User Id", p => p.UserId),
                    new PropertyByName<APIUserDetails>("Mobile", p => p.MobileNumber),
                    new PropertyByName<APIUserDetails>("Role", p => p.Role),
                    //new PropertyByName<APIUserDetails>("Language", p => p.Language),
                    new PropertyByName<APIUserDetails>("Status", p => p.Status),
                };

                byte[] bytes = _exportManager.ExportToXlsx(properties, userMasterSearch);

                ////added to test generated file
                //string filePath = "d:\\"; // this._configuration["SpreadsheetFilePath"];
                //filePath = Path.Combine(filePath);
                //string fileName = "UserMaster.xlsx";
                //using (var fs = new FileStream(filePath + fileName, FileMode.Create, FileAccess.Write))
                //{
                //    fs.Write(bytes, 0, bytes.Length);
                //}

                return File(bytes, "text/xls", "UserMaster.xlsx");

            }
            catch (Exception ex)
            {
                return BadRequest(new ResponseMessage { Message = EnumHelper.GetEnumName(MessageType.InternalServerError), Description = EnumHelper.GetEnumDescription(MessageType.InternalServerError) });
            }
        }

        [HttpGet("{id:int}")]
        public async Task<IActionResult> Get(int id)
        {
            UserMaster userMaster = await this._userMasterRepository.GetAsync(id);
            if (userMaster != null && userMaster.Id > 0)
            {
                APIUserDetails apiUserMaster = _mapper.Map<APIUserDetails>(userMaster);
                if (!string.IsNullOrEmpty(userMaster.ProfilePicUrl))
                    apiUserMaster.ProfilePicBase64 = Helper.FileHelper.GetFile(EnumFileUploadFor.OrganizationLogo, userMaster.ProfilePicUrl);                           
                
                return this.Ok(apiUserMaster);
            }
            else
                return this.BadRequest(new ResponseMessage { Message = EnumHelper.GetEnumName(MessageType.NotFound), Description = EnumHelper.GetEnumDescription(MessageType.NotExist) });
        }
                
        [HttpPost("PostUserProfileDetails")]
        public async Task<IActionResult> PostUserProfileDetails([FromBody] APIUserDetails apiUserDetails)
        {
            try
            {
                if (!ModelState.IsValid)
                    return this.BadRequest(this.ModelState);

                if (await this._userMasterRepository.FindAsync(a => a.IsDeleted != true && (a.EmployeeCode.ToLower() == apiUserDetails.EmployeeCode.ToLower() || a.MobileNumber==apiUserDetails.MobileNumber) && a.OrganizationCode == _loggedInUserOrganizationCode))
                    return this.BadRequest(new ResponseMessage { Message = EnumHelper.GetEnumName(MessageType.Duplicate), Description = "User Information already exists!" });

                UserMaster userMaster = new UserMaster();
                userMaster = _mapper.Map<UserMaster>(apiUserDetails);
                userMaster.CreatedDate = DateTime.Now;
                userMaster.ModifiedDate = DateTime.Now;
                userMaster.CreatedBy = _loggedInUserDBId;
                userMaster.ModifiedBy = _loggedInUserDBId;
                userMaster.Password = Security.EncryptSHA512(apiUserDetails.OTP);
                userMaster.PasswordModifiedDate = DateTime.Now;
                userMaster.IsFirstLogin = true;

                UserMaster newUserMaster = await this._userMasterRepository.AddAndReturnEntityAsync(userMaster);

                if(newUserMaster!=null)
                {
                    APIUserProfile userDetails = await this._userMasterRepository.GetDetailsById(_loggedInUserOrganizationCode,_userRole,newUserMaster.CreatedBy);

                    JObject NewUserDetails = new JObject();
                    NewUserDetails.Add("UserName", newUserMaster.Name);
                    NewUserDetails.Add("OrgID", newUserMaster.OrganizationCode);
                    NewUserDetails.Add("ClientAdmin", userDetails.Name);
                    NewUserDetails.Add("MobileNumber", userDetails.MobileNumber);
                    NewUserDetails.Add("OTP", apiUserDetails.OTP);
                    NewUserDetails.Add("UserId", userDetails.Id);

                    var command = new SendIRTAdminCreatesNewAccountCommand(NewUserDetails);
                    //dont add await, as it works as background task
                    _mediator.Send(command);
                }

                return Ok(newUserMaster);
            }
            catch (System.Exception ex)
            {
                return this.BadRequest(new ResponseMessage { Message = EnumHelper.GetEnumName(MessageType.InternalServerError), Description = ex.StackTrace });
            }
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Put(int id, [FromBody] APIUserDetails apiUserDetails)
        {
            try
            {
                if (!ModelState.IsValid)
                    return this.BadRequest(this.ModelState);

                UserMaster existingUserMaster = await _userMasterRepository.GetAsync(id);

                if (existingUserMaster == null)
                {
                    return this.BadRequest(new ResponseMessage { Message = EnumHelper.GetEnumName(MessageType.NotExist), Description = "" });
                }

                if (await this._userMasterRepository.FindAsync(a => a.IsDeleted != true && (a.EmployeeCode.ToLower() == apiUserDetails.EmployeeCode.ToLower() || a.MobileNumber == apiUserDetails.MobileNumber) && a.OrganizationCode == _loggedInUserOrganizationCode && a.Id != id))
                    return this.BadRequest(new ResponseMessage { Message = EnumHelper.GetEnumName(MessageType.Duplicate), Description = "User Information already exists!" });

                var createdBy = existingUserMaster.CreatedBy;
                var createdDate = existingUserMaster.CreatedDate;
                var fileName = existingUserMaster.ProfilePicUrl;
                var password = existingUserMaster.Password;
                var passwordModifiedDate = existingUserMaster.PasswordModifiedDate;
                var isFirstLogin = existingUserMaster.IsFirstLogin;

                existingUserMaster = _mapper.Map<UserMaster>(apiUserDetails);
                existingUserMaster.Id = id;
                if (string.IsNullOrWhiteSpace(existingUserMaster.ProfilePicUrl) || string.IsNullOrEmpty(existingUserMaster.ProfilePicUrl))
                    existingUserMaster.ProfilePicUrl = fileName;

                existingUserMaster.CreatedDate = createdDate;
                existingUserMaster.ModifiedDate = DateTime.Now;
                existingUserMaster.CreatedBy = createdBy;
                existingUserMaster.ModifiedBy = _loggedInUserDBId;                

                if (string.IsNullOrWhiteSpace(apiUserDetails.OTP))
                {
                    existingUserMaster.Password = password;
                    existingUserMaster.PasswordModifiedDate = passwordModifiedDate;
                    existingUserMaster.IsFirstLogin = isFirstLogin;
                }

                if (apiUserDetails.OTP != null && apiUserDetails.OTP.Trim() != "" && Security.EncryptSHA512(apiUserDetails.OTP) != password)
                {
                    existingUserMaster.Password = Security.EncryptSHA512(apiUserDetails.OTP);
                    existingUserMaster.PasswordModifiedDate = DateTime.Now;
                    existingUserMaster.IsFirstLogin = true;
                }

                await this._userMasterRepository.UpdateAsync(existingUserMaster);

                return Ok(apiUserDetails);
            }
            catch (System.Exception ex)
            {
                return this.BadRequest(new ResponseMessage { Message = EnumHelper.GetEnumName(MessageType.InternalServerError), Description = ex.StackTrace });
            }
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            try
            {
                if (!ModelState.IsValid)
                    return this.BadRequest(this.ModelState);                           
                
                UserMaster existingUserMaster = await _userMasterRepository.GetAsync(id);

                if (existingUserMaster == null)
                {
                    return this.BadRequest(new ResponseMessage { Message = EnumHelper.GetEnumName(MessageType.NotExist), Description = "" });
                }

                existingUserMaster.IsDeleted = true;
                existingUserMaster.ModifiedDate = DateTime.Now;
                existingUserMaster.ModifiedBy = _loggedInUserDBId;

                await this._userMasterRepository.UpdateAsync(existingUserMaster);

                return Ok();
            }
            catch (System.Exception ex)
            {
                return this.BadRequest(new ResponseMessage { Message = EnumHelper.GetEnumName(MessageType.InternalServerError), Description = ex.StackTrace });
            }
        }

        [HttpPut("PutProfilePicture")]
        public async Task<IActionResult> PutProfilePicture([FromForm] APIUserProfilePic profilePic)
        {
            string fileName = "";
            string ProfilePicUrl = "";
            string baseUrl = $"{this.Request.Scheme}://{this.Request.Host}{this.Request.PathBase}" + Helper.FileHelper.GetSavedFileWebPath(EnumFileUploadFor.UserProfilePic);
            try
            {
                if (!ModelState.IsValid)
                    return this.BadRequest(this.ModelState);

                int UId = await _userMasterRepository.GetUserId(profilePic.UserMasterGuId);
                if (UId == 0)
                    return this.BadRequest(new ResponseMessage { Message = EnumHelper.GetEnumName(MessageType.NotExist), Description = "User not exist!" });

                if (FileHelper.CheckIfImageFile(profilePic.ProfilePic))
                {
                    fileName = await _fileUploadRepository.Upload(EnumFileUploadFor.UserProfilePic, EnumFileType.Image, profilePic.ProfilePic, true);
                }
                else
                    return this.BadRequest(new ResponseMessage { Message = EnumHelper.GetEnumName(MessageType.InvalidFile), Description = EnumHelper.GetEnumDescription(MessageType.InvalidFile) });

                if (fileName != null && fileName.Trim().Length > 0)
                {
                    UserMaster userMaster = await this._userMasterRepository.GetAsync(_loggedInUserDBId);
                    if (userMaster.ProfilePicUrl != null && userMaster.ProfilePicUrl.Trim().Length > 0)
                    {
                        FileHelper.DeleteFile(EnumFileUploadFor.UserProfilePic, userMaster.ProfilePicUrl);
                    }
                    userMaster.ProfilePicUrl = fileName;
                    userMaster.ModifiedDate = DateTime.Now;

                    await this._userMasterRepository.UpdateAsync(userMaster);
                    ProfilePicUrl = baseUrl + "/" + fileName;
                    return Ok(ProfilePicUrl);
                }
                else
                    return this.BadRequest(new ResponseMessage { Message = EnumHelper.GetEnumName(MessageType.Fail), Description = EnumHelper.GetEnumDescription(MessageType.Fail) });

            }
            catch (System.Exception ex)
            {
                return this.BadRequest(new ResponseMessage { Message = EnumHelper.GetEnumName(MessageType.InternalServerError), Description = ex.StackTrace });
            }
        }

        [HttpPut("PutProfilePictureWithBase64")]
        public async Task<IActionResult> PutProfilePictureWithBase64([FromBody] APIUserProfilePicWithBase64 profilePic)
        {
            string fileName = "";
            string ProfilePicUrl = "";
            string contentRootPath = _env.ContentRootPath;
            //string fileDirectory = this._configuration["ProfilePicPhysicalPath"];
            string fileDirectory = FileHelper.GetSaveFilePath(EnumFileUploadFor.UserProfilePic);
            string baseUrl = $"{this.Request.Scheme}://{this.Request.Host}{this.Request.PathBase}" + Helper.FileHelper.GetSavedFileWebPath(EnumFileUploadFor.UserProfilePic);
            string file = "";
            string fileExtention = ".jpg";
            try
            {
                if (!ModelState.IsValid)
                    return this.BadRequest(this.ModelState);

                if (string.IsNullOrEmpty(profilePic.Base64String))
                {
                    return this.BadRequest(new ResponseMessage { Message = EnumHelper.GetEnumName(MessageType.InvalidData), Description = EnumHelper.GetEnumDescription(MessageType.InvalidData) });
                }
                var bytes = Convert.FromBase64String(profilePic.Base64String);

                if (bytes.Length > 0)
                {
                    string fileclass = bytes[0].ToString();
                    fileclass += bytes[1].ToString();
                    if (fileclass == "255216" || fileclass == "7173" || fileclass == "13780" || fileclass == "6677")//7173=.gif 255216=.jpg 6677=.bmp 13780=.png
                    {
                        fileExtention = fileclass == "255216" ? ".jpg" : fileclass == "7173" ? ".gif" : fileclass == "13780" ? ".png" : "";
                        fileName = DateTime.UtcNow.Ticks.ToString() + fileExtention;
                        file = Path.Combine(contentRootPath + fileDirectory, fileName);
                        using (var stream = new FileStream(file, FileMode.Create))
                        {
                            stream.Write(bytes, 0, bytes.Length);
                            stream.Flush();
                        }
                        //_fileUploadRepository.SaveThumb(fileDirectory, fileName);
                    }
                    else
                    {
                        return this.BadRequest(new ResponseMessage { Message = EnumHelper.GetEnumName(MessageType.InvalidFile), Description = EnumHelper.GetEnumDescription(MessageType.InvalidFile) });
                    }
                }

                int userId = await _userMasterRepository.GetUserId(profilePic.UserMasterGuId);

                if (userId == 0)
                    return this.BadRequest(new ResponseMessage { Message = EnumHelper.GetEnumName(MessageType.NotExist), Description = "User not exist!" });

                fileName = file.Substring(file.LastIndexOf("\\")).Replace(@"\", "");

                if (fileName != null && fileName.Trim().Length > 0)
                {
                    _fileUploadRepository.SaveThumb(fileDirectory, fileName);
                    UserMaster userMaster = await this._userMasterRepository.GetAsync(userId);
                    if (userMaster != null && userMaster.ProfilePicUrl != null && userMaster.ProfilePicUrl.Trim().Length > 0)
                    {
                        FileHelper.DeleteFile(EnumFileUploadFor.UserProfilePic, userMaster.ProfilePicUrl);
                    }
                    userMaster.ProfilePicUrl = fileName;
                    userMaster.ModifiedDate = DateTime.Now;

                    await this._userMasterRepository.UpdateAsync(userMaster);
                    ProfilePicUrl = baseUrl + "/" + fileName;
                    return Ok(fileName);
                }
                else
                    return this.BadRequest(new ResponseMessage { Message = EnumHelper.GetEnumName(MessageType.Fail), Description = EnumHelper.GetEnumDescription(MessageType.Fail) });

            }
            catch (System.Exception ex)
            {
                return this.BadRequest(new ResponseMessage { Message = EnumHelper.GetEnumName(MessageType.InternalServerError), Description = ex.StackTrace });
            }
        }

        [HttpGet("GetActiveUsersCount")]
        public async Task<IActionResult> GetActiveUsersCount()
        {
            try
            {
                if (!ModelState.IsValid)
                    return BadRequest();

                return Ok(await this._userMasterRepository.GetActiveUsersCount(_loggedInUserOrganizationCode));
            }
            catch (System.Exception ex)
            {
                return this.BadRequest(new ResponseMessage { Message = EnumHelper.GetEnumName(MessageType.InternalServerError), Description = ex.StackTrace });
            }
        }

        [HttpPost("IsExist")]
        public async Task<IActionResult> IsExist(APIIsExistInput apiIsExistInput)
        {
            bool exists = false;
            switch (apiIsExistInput.FieldName.ToLower())
            {
                case "departmentname":
                    exists = await this._userMasterRepository.FindAsync(x => x.DepartmentId == apiIsExistInput.value && x.IsDeleted != true && x.OrganizationCode==_loggedInUserOrganizationCode);
                    break;
                case "employeecode":
                    exists = await this._userMasterRepository.FindAsync(x => x.EmployeeCode == apiIsExistInput.value && x.IsDeleted != true && x.OrganizationCode == apiIsExistInput.OrganizationCode);
                    break; 
                case "mobilenumber":
                    exists = await this._userMasterRepository.FindAsync(x => x.MobileNumber == apiIsExistInput.value && x.IsDeleted != true && x.OrganizationCode == apiIsExistInput.OrganizationCode);
                    break;
                case "email":
                    exists = await this._userMasterRepository.FindAsync(x => x.Email == apiIsExistInput.value && x.IsDeleted != true && x.OrganizationCode == apiIsExistInput.OrganizationCode);
                    break;                    
            }
            return Ok(new { exists });
        }

        [HttpPut("ChangeUserPassword")]
        public async Task<IActionResult> ChangeUserPassword([FromBody] APIUserMasterPasswordChange aPIUserMasterPassword)
        {
            bool success = false;
            string message = "";
            try
            {
                if (!ModelState.IsValid)
                    return this.BadRequest(this.ModelState);

                //int id = await this._userMasterRepository.GetUserId(GuId);
                UserMaster userMaster = _userMasterRepository.Get(_loggedInUserDBId);
                if (userMaster == null)
                {
                    return this.BadRequest(new ResponseMessage { Message = EnumHelper.GetEnumName(MessageType.NotExist), Description = "" });
                }
                JObject UserDetails = new JObject();
                UserDetails.Add("UserId", userMaster.Id);
                UserDetails.Add("UserName", userMaster.Name);
                UserDetails.Add("MobileNumber", userMaster.MobileNumber);

                if (userMaster.Password == Security.EncryptSHA512(aPIUserMasterPassword.OldPassword))
                {
                    if (userMaster.Password == Security.EncryptSHA512(aPIUserMasterPassword.Password))
                    {
                        success = false;
                        message = "Old Password and new password should not be same!";
                    }
                    else
                    {
                        userMaster.ModifiedDate = DateTime.Now;
                        userMaster.Password = Security.EncryptSHA512(aPIUserMasterPassword.Password);
                        userMaster.PasswordModifiedDate = DateTime.Now;
                        userMaster.IsFirstLogin = false;
                        userMaster.SecurityQuestionId = aPIUserMasterPassword.SecurityQuestionID;
                        userMaster.SecurityAnswer = aPIUserMasterPassword.Answer.Trim();
                        await this._userMasterRepository.UpdateAsync(userMaster);
                        success = true;
                    }
                }
                else
                {
                    success = false;
                    message = "Wrong Password!";
                }
                //APIUserMasterSignUp newUser = _mapper.Map<APIUserMasterSignUp>(userMaster);
                //if (newUser != null && newUser.GuId != Guid.Empty)
                //{}
                //success = true;
                return Ok(new { success, message });
            }
            catch (System.Exception ex)
            {
                //return this.BadRequest(new ResponseMessage { Message = EnumHelper.GetEnumName(MessageType.InternalServerError), Description = ex.Message });
                success = false;
                message = ex.Message;
                return Ok(new { success, message });
            }
        }

        // DELETE: api/ApiWithActions/5
        [HttpDelete("{GuId:Guid}")]
        public async Task<IActionResult> DeleteUserSignUpDetails(Guid GuId)
        {
            if (!ModelState.IsValid)
                return BadRequest(this.ModelState);

            int id = await this._userMasterRepository.GetUserId(GuId);
            UserMaster userMaster = await this._userMasterRepository.GetAsync(id);

            if (userMaster == null)
            {
                return this.BadRequest(new ResponseMessage { Message = EnumHelper.GetEnumName(MessageType.NotExist), Description = EnumHelper.GetEnumDescription(MessageType.NotExist) });
            }

            userMaster.IsDeleted = true;
            userMaster.ModifiedDate = DateTime.Now;
            await this._userMasterRepository.UpdateAsync(userMaster);
            bool success = true;
            return Ok(new { success });
        }

        [AllowAnonymous]
        [HttpGet("IsExistAsync")]
        public async Task<IActionResult> IsExistAsync(string fieldName, string value)
        {
            bool exists = false;
            switch (fieldName.ToLower())
            {
                case "employeecode":
                    
                    exists = await this._userMasterRepository.FindAsync(x => x.IsDeleted !=true && x.OrganizationCode == _loggedInUserOrganizationCode && x.EmployeeCode.Trim().ToLower() == value.Trim().ToLower() && x.IsDeleted != true);
                    break;
                case "mobilenumber":
                    exists = await this._userMasterRepository.FindAsync(x => x.IsDeleted != true && x.OrganizationCode == _loggedInUserOrganizationCode && x.MobileNumber.Trim() == value.Trim() && x.IsDeleted != true);
                    
                    break;
            }
            return Ok(new { exists });
        }

        [AllowAnonymous]
        [HttpPut("ForgotPassword")]
        public async Task<IActionResult> ForgotPassword([FromBody] APIForgotPassword forgotPassword)
        {
            IsSuccess result = new IsSuccess() { success = false, message = "" };
            
            try
            {
                if (!ModelState.IsValid)
                {
                    result.message = "Invalid request!";
                }
                var users = await _userMasterRepository.GetAll(x => x.IsDeleted == false && x.OrganizationCode == forgotPassword.OrgCode && (x.MobileNumber == forgotPassword.UserId || x.EmployeeCode == forgotPassword.UserId));
                UserMaster userMaster = users != null ? users.FirstOrDefault() : null;
                if (userMaster == null)
                {
                    result.message = "User Not Found!";
                }

                if (userMaster.SecurityQuestionId > 0 && forgotPassword.SecurityQuestionID > 0
                    && userMaster.SecurityQuestionId == forgotPassword.SecurityQuestionID
                    && userMaster.SecurityAnswer.Trim().ToLower() == forgotPassword.Answer.Trim().ToLower())
                {
                    userMaster.ModifiedDate = DateTime.Now;
                    userMaster.Password = Security.EncryptSHA512(forgotPassword.Password.Trim());
                    userMaster.PasswordModifiedDate = DateTime.Now;
                    await this._userMasterRepository.UpdateAsync(userMaster);
                    result.success = true;
                }
                else
                {
                    result.success = false;
                    result.message = "User id or answer is wrong!";
                }
                return Ok(result);
            }
            catch (System.Exception ex)
            {
                result.success = false;
                result.message = ex.Message;
                return Ok(result);
            }
        }

        [HttpGet("UserLogout")]
        public async Task<IActionResult> UserLogOut()
        {
            try
            {
                ////added to tack user out time
                //LoggedInHistory loggedInHistory = await this._loggedInHistoryRepository.GetLatestRecord(_loggedInUserDBId);

                //if (loggedInHistory != null)
                //{
                //    loggedInHistory.LogOutTime = DateTime.Now;
                //    await this._loggedInHistoryRepository.UpdateAsync(loggedInHistory);
                //}

                //add token entry in token expiry, if the user has logged out
                string tokenLastTwentychars = _loggedInUserToken.TokenLastNumberOfChars(20);
                TokenExpired tokenExpired = new TokenExpired();
                tokenExpired.CreatedDate = DateTime.Now;
                tokenExpired.Token = tokenLastTwentychars;
                tokenExpired.UserId = _loggedInUserDBId;
                await this._tokenExpiredRepository.AddAsync(tokenExpired);

                Tokens userToken = await _tokensRepository.GetUserTokenRecord(_loggedInUserDBId, tokenLastTwentychars);
                if (userToken != null)
                {
                    userToken.IsDeleted = true;
                    await this._tokensRepository.UpdateAsync(userToken);
                }
                bool success = true;
                return Ok(new { success });
            }
            catch (System.Exception ex)
            {
                return this.BadRequest(new ResponseMessage { Message = EnumHelper.GetEnumName(MessageType.InternalServerError), Description = ex.StackTrace });
            }
        }
        
        private string GetSystemSuggestedUserId(string userName, string mobileNumber)
        {
            string result = "";
            char[] delimiterChars = { ' ', ',', '.' };

            string[] words = userName.Split(delimiterChars);

            foreach (var word in words)
            {
                if (word.Length >= 3)
                    result += word.Substring(0, 3);
                if (word.Length == 1)
                    result += word.Substring(0, 1);

                if (result.Length >= 3)
                    break;
            }

            char[] lowers = new char[] { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'j', 'k', 'm', 'n', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z' };
            char[] uppers = new char[] { 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'J', 'K', 'M', 'N', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z' };
            char[] numbers = new char[] { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9' };

            int l = lowers.Length;
            int n = numbers.Length;

            Random random = new Random();

            //result += lowers[random.Next(0, l)].ToString();
            //result += lowers[random.Next(0, l)].ToString();
            //result += lowers[random.Next(0, l)].ToString();

            //result += uppers[random.Next(0, u)].ToString();
            //result += uppers[random.Next(0, u)].ToString();
            //result += uppers[random.Next(0, u)].ToString();

            if (string.IsNullOrWhiteSpace(mobileNumber))
            {
                result += numbers[random.Next(0, n)].ToString();
                result += numbers[random.Next(0, n)].ToString();
                result += numbers[random.Next(0, n)].ToString();
                result += numbers[random.Next(0, n)].ToString();
                result += numbers[random.Next(0, n)].ToString();
                return result;
            }
            else
                return result + mobileNumber.Substring(mobileNumber.Length-5 , 5);
        }

        [HttpGet("GetUserProfileDetails/{id:int}")]
        public async Task<IActionResult> GetUserProfileDetails(int id)
        {
            if (id < 1)
                throw new Exception("error in get()");
            UserMaster userMaster = await this._userMasterRepository.GetAsync(id);
            string baseUrl = $"{this.Request.Scheme}://{this.Request.Host}{this.Request.PathBase}" + Helper.FileHelper.GetSavedFileWebPath(EnumFileUploadFor.UserProfilePic);

            if (userMaster != null && userMaster.Id > 0)
            {
                APIUserProfile aPIUserProfile = _mapper.Map<APIUserProfile>(userMaster);
                aPIUserProfile.GuId = userMaster.GuId;
                if (userMaster.ProfilePicUrl != null && userMaster.ProfilePicUrl.Trim().Length > 0)
                    aPIUserProfile.ProfilePicBase64 = Helper.FileHelper.GetFile(EnumFileUploadFor.UserProfilePic, userMaster.ProfilePicUrl);
                return this.Ok(aPIUserProfile);
            }
            else
                return this.BadRequest(new ResponseMessage { Message = EnumHelper.GetEnumName(MessageType.NotFound), Description = EnumHelper.GetEnumDescription(MessageType.NotExist) });
        }

        [HttpGet("GetUserProfileDetails")]
        public async Task<IActionResult> GetUserProfileDetails()
        {
            //int id = await this._userMasterRepository.GetUserId(_loggedInUserDBId);
            APIUserProfile APIUserProfile = await this._userMasterRepository.GetDetailsById(_loggedInUserOrganizationCode, _userRole, _loggedInUserDBId);

            //APIUserProfile userProfile = _mapper.Map<APIUserProfile>(UserMaster);

            if (APIUserProfile != null && APIUserProfile.Id > 0)
            {
                if (!string.IsNullOrEmpty(APIUserProfile.ProfilePicUrl))
                {
                    string base64ProfilePic = Helper.FileHelper.GetFile(EnumFileUploadFor.UserProfilePic, APIUserProfile.ProfilePicUrl);
                    APIUserProfile.ProfilePicBase64 = base64ProfilePic;
                    if (!string.IsNullOrEmpty(base64ProfilePic))
                    {
                        string base64WithoutMIMEType = base64ProfilePic.Substring(base64ProfilePic.IndexOf("base64,") + 7);
                        APIUserProfile.ProfilePicBase64WithoutMIMEType = base64WithoutMIMEType;
                    }
                    else
                        APIUserProfile.ProfilePicBase64WithoutMIMEType = "";
                }
                else
                    APIUserProfile.ProfilePicBase64WithoutMIMEType = "";
                return this.Ok(APIUserProfile);
            }
            else
                return this.Ok(APIUserProfile);
        }

        [HttpPut("PutUserProfileDetails/{id:int}")]
        public async Task<IActionResult> PutUserProfileDetails(int id, [FromBody] APIUserProfile aPIUserProfile)
        {
            try
            {
                if (!ModelState.IsValid)
                    return this.BadRequest(this.ModelState);

                if (id == 0 || aPIUserProfile.Id != id || aPIUserProfile.Id == 0)
                {
                    return this.BadRequest(new ResponseMessage { Message = EnumHelper.GetEnumName(MessageType.NotExist), Description = "User  profile id Not match  or it is zero!" });
                }
                string filename = "";

                UserMaster existingUserMaster = await this._userMasterRepository.GetAsync(id);

                if (existingUserMaster.ProfilePicUrl != null && existingUserMaster.ProfilePicUrl.Trim().Length > 0)
                    filename = existingUserMaster.ProfilePicUrl;
                var createdBy = existingUserMaster.CreatedBy;
                var createdDate = existingUserMaster.CreatedDate;
                var password = existingUserMaster.Password;
                var passwordModifiedDate = existingUserMaster.PasswordModifiedDate;
                var status = existingUserMaster.Status;
                var role = existingUserMaster.Role;
                var employeeCode = existingUserMaster.EmployeeCode;
                var department = existingUserMaster.DepartmentId;
                bool IsFirstLogin = existingUserMaster.IsFirstLogin;
                
                existingUserMaster = _mapper.Map<UserMaster>(aPIUserProfile);
                existingUserMaster.Id = id;
                existingUserMaster.CreatedBy = createdBy;
                existingUserMaster.CreatedDate = createdDate;
                existingUserMaster.ModifiedDate = DateTime.Now;
                existingUserMaster.ModifiedBy = _loggedInUserDBId;
                existingUserMaster.Password = password;
                existingUserMaster.PasswordModifiedDate = passwordModifiedDate;
                existingUserMaster.ProfilePicUrl = filename;
                existingUserMaster.Status = status;
                existingUserMaster.Role = role;
                existingUserMaster.EmployeeCode = employeeCode;
                existingUserMaster.DepartmentId = department;
                existingUserMaster.IsFirstLogin = IsFirstLogin;

                await this._userMasterRepository.UpdateAsync(existingUserMaster);

                return Ok(aPIUserProfile);
            }
            catch (System.Exception ex)
            {
                return this.BadRequest(new ResponseMessage { Message = EnumHelper.GetEnumName(MessageType.InternalServerError), Description = ex.StackTrace });
            }
        }

        [AllowAnonymous]
        [HttpGet("GetAllSecurityQuestions")]
        public async Task<IActionResult> GetAllSecurityQuestions()
        {
            return Ok( await _secQuestionRepository.GetAll(x=>x.Status == Helper.Status.Active) ?? new List<SecurityQuestion>());
        }

        [HttpGet("GetUserSecurityQuestion")]
        public async Task<IActionResult> GetUserSecurityQuestion()
        {
            APIUserSecurityQuestion question = await this._userMasterRepository.GetUserSecurityQuestion(_loggedInUserOrganizationCode, _loggedInUserDBId);
                return this.Ok(question ?? new APIUserSecurityQuestion());
        }
    }
}
