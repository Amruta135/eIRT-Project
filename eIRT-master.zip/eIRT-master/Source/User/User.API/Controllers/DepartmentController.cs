﻿using AspNet.Security.OAuth.Introspection;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using User.API.APIModel;
using User.API.Helper;
using User.API.Models;
using User.API.Repositories.Interface;
using User.API.Services;
using static User.API.Validation.TokenValidation;

namespace User.API.Controllers
{
    [ApiVersion("1.0")]
    [Route("user/api/v{version:apiVersion}/[controller]")]
    [ApiController]
    [Authorize(AuthenticationSchemes = OAuthIntrospectionDefaults.AuthenticationScheme)]
    [Authorize]
    [TokenValid]
    public class DepartmentController : IdentityController
    {
        private readonly IDepartmentRepository _departmentRepository;
        private readonly IIdentityService _identitySvc;
        private readonly IHttpContextAccessor _httpContextAccessor;
        public DepartmentController(IDepartmentRepository departmentRepository,
                                    IIdentityService identitySvc,
                                    IHttpContextAccessor httpContextAccessor) : base(identitySvc)

        {
            _departmentRepository = departmentRepository;
            _identitySvc = identitySvc;
            _httpContextAccessor = httpContextAccessor;
        }


        [HttpPost("Get")]
        public async Task<IActionResult> Get(APIId apiId)
        {
            Department department = await this._departmentRepository.GetAsync(apiId.Id);

            if (department != null)
                return this.Ok(department);
            else
                return this.BadRequest(new ResponseMessage { Message = EnumHelper.GetEnumName(MessageType.NotFound), Description = "" });
        }

        [HttpPost("GetDepartments")]
        public async Task<IActionResult> GetDepartments(APISearchInfo apiSearchInfo)
        {
            try
            {
                List<APIDepartments> apiDepartments = await this._departmentRepository.GetDepartments(_loggedInUserOrganizationCode, apiSearchInfo.page, apiSearchInfo.pageSize, apiSearchInfo.filter, apiSearchInfo.search);

                int count = await this._departmentRepository.GetDepartmentsCount(_loggedInUserOrganizationCode, apiSearchInfo.filter, apiSearchInfo.search);
                return Ok(new { apiDepartments, count });
            }
            catch (Exception)
            {
                return BadRequest(new ResponseMessage { Message = EnumHelper.GetEnumName(MessageType.InternalServerError), Description = EnumHelper.GetEnumDescription(MessageType.InternalServerError) });
            }
        }

        [HttpPost("GetDepartmentsCount")]
        public async Task<IActionResult> GetRolesConfigurationsCount(APISearchInfo apiSearchInfo)
        {
            try
            {
                return Ok(await this._departmentRepository.GetDepartmentsCount(_loggedInUserOrganizationCode, apiSearchInfo.filter, apiSearchInfo.search));
            }
            catch (Exception)
            {
                return BadRequest(new ResponseMessage { Message = EnumHelper.GetEnumName(MessageType.InternalServerError), Description = EnumHelper.GetEnumDescription(MessageType.InternalServerError) });
            }
        }

        [HttpPost("Post")]
        public async Task<IActionResult> Post([FromBody] APIDepartments apiDepartments)
        {
            try
            {
                if (!ModelState.IsValid)
                    return this.BadRequest(this.ModelState);

                if (await this._departmentRepository.FindAsync(s => (s.Name == apiDepartments.Name || s.Code == apiDepartments.Code) && s.OrganizationCode == _loggedInUserOrganizationCode))
                    return this.BadRequest(new ResponseMessage { Message = EnumHelper.GetEnumName(MessageType.Duplicate), Description = "Department Name already exists!" });

                Department department = new Department();
                department.OrganizationCode = _loggedInUserOrganizationCode;
                department.Name = apiDepartments.Name;
                department.Code = apiDepartments.Code;
                department.CreatedDate = DateTime.Now;
                department.ModifiedDate = DateTime.Now;
                department.CreatedBy = _loggedInUserDBId;
                department.ModifiedBy = _loggedInUserDBId;

                return Ok(await this._departmentRepository.AddAndReturnEntityAsync(department));
            }
            catch (System.Exception ex)
            {
                return this.BadRequest(new ResponseMessage { Message = EnumHelper.GetEnumName(MessageType.InternalServerError), Description = ex.StackTrace });
            }
        }
        [HttpPut("{id}")]
        public async Task<IActionResult> Put(int Id, [FromBody] APIDepartments apiDepartments)
        {
            try
            {
                if (!ModelState.IsValid)
                    return this.BadRequest(this.ModelState);

                Department  existingDepartment = await _departmentRepository.GetAsync(Id);

                if (existingDepartment == null)
                    return this.BadRequest(new ResponseMessage { Message = EnumHelper.GetEnumName(MessageType.NotExist), Description = "" });

                if (await this._departmentRepository.FindAsync(s => (s.Name == apiDepartments.Name || s.Code == apiDepartments.Code) && s.OrganizationCode == _loggedInUserOrganizationCode && s.Id != Id))
                    return this.BadRequest(new ResponseMessage { Message = EnumHelper.GetEnumName(MessageType.Duplicate), Description = "Department Name already exists!" });

                existingDepartment.Name = apiDepartments.Name;
                existingDepartment.Code = apiDepartments.Code;
                existingDepartment.ModifiedDate = DateTime.Now;
                existingDepartment.ModifiedBy = _loggedInUserDBId;

                await this._departmentRepository.UpdateAsync(existingDepartment);

                return Ok(apiDepartments);
            }
            catch (System.Exception ex)
            {
                return this.BadRequest(new ResponseMessage { Message = EnumHelper.GetEnumName(MessageType.InternalServerError), Description = ex.StackTrace });
            }
        }

        [HttpPost("GetDepartmentByOrganization")]
        public async Task<IActionResult> GetDepartmentByOrganization(APIDepartmentsWithOrganization apiDepartments)
        {
            try
            {                
                return Ok(await this._departmentRepository.GetDepartmentByOrganization(apiDepartments.OrganizationCode));
            }
            catch (Exception)
            {
                return BadRequest(new ResponseMessage { Message = EnumHelper.GetEnumName(MessageType.InternalServerError), Description = EnumHelper.GetEnumDescription(MessageType.InternalServerError) });
            }
        }

        [HttpPost("IsExist")]
        public async Task<IActionResult> IsExist(APIIsExistInput apiIsExistInput)
        {
            bool exists = false;
            switch (apiIsExistInput.FieldName.ToLower())
            {
                case "name":
                    exists = await this._departmentRepository.FindAsync(x => x.Name == apiIsExistInput.value && x.IsDeleted != true);
                    break;
                case "code":
                    exists = await this._departmentRepository.FindAsync(x => x.Code == apiIsExistInput.value && x.IsDeleted != true);
                    break;
            }
            return Ok(new { exists });
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            try
            {
                if (!ModelState.IsValid)
                    return this.BadRequest(this.ModelState);

                Department existingDepartment = await _departmentRepository.GetAsync(id);

                if (existingDepartment == null)
                {
                    return this.BadRequest(new ResponseMessage { Message = EnumHelper.GetEnumName(MessageType.NotExist), Description = "" });
                }

                existingDepartment.IsDeleted = true;
                existingDepartment.ModifiedDate = DateTime.Now;
                existingDepartment.ModifiedBy = _loggedInUserDBId;

                await this._departmentRepository.UpdateAsync(existingDepartment);

                return Ok();
            }
            catch (System.Exception ex)
            {
                return this.BadRequest(new ResponseMessage { Message = EnumHelper.GetEnumName(MessageType.InternalServerError), Description = ex.StackTrace });
            }
        }
    }
}
