﻿using AspNet.Security.OAuth.Introspection;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using User.API.APIModel;
using User.API.Helper;
using User.API.Models.User.API.Models;
using User.API.Repositories.Interface;
using User.API.Services;
using static User.API.Validation.TokenValidation;

namespace User.API.Controllers
{
    [ApiVersion("1.0")]
    [Route("user/api/v{version:apiVersion}/[controller]")]
    [ApiController]
    [Authorize(AuthenticationSchemes = OAuthIntrospectionDefaults.AuthenticationScheme)]
    [Authorize]
    [TokenValid]
    public class RolesConfigurationController : IdentityController
    {
        private readonly IRolesConfigurationRepository _rolesConfigurationRepository;
        private readonly IIdentityService _identitySvc;
        private readonly IHttpContextAccessor _httpContextAccessor;
        public RolesConfigurationController(IRolesConfigurationRepository rolesConfigurationRepository,
                                            IIdentityService identitySvc,
                                            IHttpContextAccessor httpContextAccessor) : base(identitySvc)

        {
            _rolesConfigurationRepository = rolesConfigurationRepository;
            _identitySvc = identitySvc;
            _httpContextAccessor = httpContextAccessor;
        }

        [HttpPost("Get")]
        public async Task<IActionResult> Get(APIId apiId)
        {
            RolesConfiguration rolesConfiguration = await this._rolesConfigurationRepository.GetAsync(apiId.Id);

            if (rolesConfiguration != null)
                return this.Ok(rolesConfiguration);
            else
                return this.BadRequest(new ResponseMessage { Message = EnumHelper.GetEnumName(MessageType.NotFound), Description = "" });
        }

        [HttpPost("GetRolesConfigurations")]
        public async Task<IActionResult> GetRolesConfigurations(APISearchInfo apiSearchInfo)
        {
            try
            {
                List<APIRolesConfigurations> apiRolesConfigurations = await this._rolesConfigurationRepository.GetRolesConfigurations(_loggedInUserOrganizationCode, apiSearchInfo.page, apiSearchInfo.pageSize, apiSearchInfo.filter, apiSearchInfo.search);
                int count = await this._rolesConfigurationRepository.GetRolesConfigurationCount(_loggedInUserOrganizationCode, apiSearchInfo.filter, apiSearchInfo.search);

                return Ok(new { apiRolesConfigurations, count });
            }
            catch (Exception)
            {
                return BadRequest(new ResponseMessage { Message = EnumHelper.GetEnumName(MessageType.InternalServerError), Description = EnumHelper.GetEnumDescription(MessageType.InternalServerError) });
            }
        }

        [HttpPost("GetRolesConfigurationsCount")]
        public async Task<IActionResult> GetRolesConfigurationsCount(APISearchInfo apiSearchInfo)
        {
            try
            {
                return Ok(await this._rolesConfigurationRepository.GetRolesConfigurationCount(_loggedInUserOrganizationCode, apiSearchInfo.filter, apiSearchInfo.search));
            }
            catch (Exception)
            {
                return BadRequest(new ResponseMessage { Message = EnumHelper.GetEnumName(MessageType.InternalServerError), Description = EnumHelper.GetEnumDescription(MessageType.InternalServerError) });
            }
        }

        [HttpPost]
        public async Task<IActionResult> Post([FromBody] APIRolesConfigurations apiRolesConfiguration)
        {
            try
            {
                if (!ModelState.IsValid)
                    return this.BadRequest(this.ModelState);

                if (await this._rolesConfigurationRepository.FindAsync(s => s.IsDeleted == false && s.OrganizationCode == _loggedInUserOrganizationCode && s.OriginalRoleDescription == apiRolesConfiguration.OriginalRoleDescription))
                    return this.BadRequest(new ResponseMessage { Message = EnumHelper.GetEnumName(MessageType.Duplicate), Description = "Roles Configuration already exists!" });

                RolesConfiguration rolesConfiguration = new RolesConfiguration();
                rolesConfiguration.OrganizationCode = _loggedInUserOrganizationCode;
                rolesConfiguration.OriginalRoleCode = apiRolesConfiguration.OriginalRoleCode;
                rolesConfiguration.OriginalRoleDescription = apiRolesConfiguration.OriginalRoleDescription;
                rolesConfiguration.ChangedRoleDescription = apiRolesConfiguration.ChangedRoleDescription;
                rolesConfiguration.CreatedDate = DateTime.Now;
                rolesConfiguration.ModifiedDate = DateTime.Now;
                rolesConfiguration.CreatedBy = _loggedInUserDBId;
                rolesConfiguration.ModifiedBy = _loggedInUserDBId;

                return Ok(await this._rolesConfigurationRepository.AddAndReturnEntityAsync(rolesConfiguration));
            }
            catch (System.Exception ex)
            {
                return this.BadRequest(new ResponseMessage { Message = EnumHelper.GetEnumName(MessageType.InternalServerError), Description = ex.StackTrace });
            }
        }

        [HttpPut("{Id}")]
        public async Task<IActionResult> Put(int Id, [FromBody] APIRolesConfigurations apiRolesConfiguration)
        {
            try
            {
                if (!ModelState.IsValid)
                    return this.BadRequest(this.ModelState);

                RolesConfiguration existingRolesConfiguration = await _rolesConfigurationRepository.GetAsync(Id);

                if (existingRolesConfiguration == null)
                    return this.BadRequest(new ResponseMessage { Message = EnumHelper.GetEnumName(MessageType.NotExist), Description = "" });

                if (await this._rolesConfigurationRepository.FindAsync(s => s.IsDeleted == false && s.OrganizationCode == _loggedInUserOrganizationCode && s.OriginalRoleDescription == apiRolesConfiguration.OriginalRoleDescription.Trim() && s.Id != Id))
                    return this.BadRequest(new ResponseMessage { Message = EnumHelper.GetEnumName(MessageType.Duplicate), Description = "Roles Configuration already exists!" });

                existingRolesConfiguration.ChangedRoleDescription = apiRolesConfiguration.ChangedRoleDescription;
                existingRolesConfiguration.ModifiedDate = DateTime.Now;
                existingRolesConfiguration.ModifiedBy = _loggedInUserDBId;

                await this._rolesConfigurationRepository.UpdateAsync(existingRolesConfiguration);

                return Ok(apiRolesConfiguration);
            }
            catch (System.Exception ex)
            {
                return this.BadRequest(new ResponseMessage { Message = EnumHelper.GetEnumName(MessageType.InternalServerError), Description = ex.StackTrace });
            }
        }

        [HttpPut("Delete")]
        public async Task<IActionResult> Delete(APIId apiId)
        {
            try
            {
                if (!ModelState.IsValid)
                    return this.BadRequest(this.ModelState);
                
                RolesConfiguration existingRolesConfiguration = await _rolesConfigurationRepository.GetAsync(apiId.Id);
               
                if (existingRolesConfiguration == null)
                    return this.BadRequest(new ResponseMessage { Message = EnumHelper.GetEnumName(MessageType.NotExist), Description = "" });

                existingRolesConfiguration.IsDeleted = true;
                await this._rolesConfigurationRepository.UpdateAsync(existingRolesConfiguration);

                return Ok();
            }
            catch (System.Exception ex)
            {
                return this.BadRequest(new ResponseMessage { Message = EnumHelper.GetEnumName(MessageType.InternalServerError), Description = ex.StackTrace });
            }
        }

        [HttpPost("IsExist")]
        public async Task<IActionResult> IsExist(APIIsExistInput apiIsExistInput)
        {
            bool exists = false;
            switch (apiIsExistInput.FieldName.ToLower())
            {
                case "changedroledescription":
                    exists = await this._rolesConfigurationRepository.FindAsync(x => x.ChangedRoleDescription == apiIsExistInput.value && x.IsDeleted != true && x.OrganizationCode==_loggedInUserOrganizationCode);
                    break;
            }
            return Ok(new { exists });
        }
    }
}
