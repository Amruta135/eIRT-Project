﻿using AspNet.Security.OAuth.Introspection;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using AutoMapper;
using System;
using System.Threading.Tasks;
using User.API.APIModel;
using User.API.Helper;
using User.API.Models;
using User.API.Repositories.Interface;
using User.API.Services;
using static User.API.Validation.TokenValidation;
using System.Collections.Generic;
using System.IO;
using Microsoft.Extensions.Configuration;
using System.Linq;
using User.API.Common;
using Newtonsoft.Json.Linq;
using MediatR;
using User.API.MediatR.Command;
using Microsoft.AspNetCore.Hosting;

namespace User.API.Controllers
{
    [ApiVersion("1.0")]
    [Route("user/api/v{version:apiVersion}/[controller]")]
    [ApiController]
    [Authorize(AuthenticationSchemes = OAuthIntrospectionDefaults.AuthenticationScheme)]
    [Authorize]
    [TokenValid]
    public class IncidentReportController : IdentityController
    {
        private readonly IIncidentReportRepository _incidentReportRepository;
        private readonly IIdentityService _identitySvc;
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly IMapper _mapper;
        private readonly IFileUploaderRepository _fileUploadRepository;
        private readonly IIncidentAssignmentRepository _incidentAssignmentRepository;
        private readonly IOrganizationInfoRepository _organizationInfoRepository;
        private readonly IExportManager<APIOpenClosedIncidentInfo> _exportManager;
        private readonly IUserMasterRepository _userMasterRepository;
        private readonly IMediator _mediator;
        private readonly IIncidentCategoryRepository _incidentCategoryRepository;
        private readonly IDepartmentRepository _departmentRepository;
        private IWebHostEnvironment _env;
        public IConfiguration _configuration { get; }
        public IncidentReportController(IIncidentReportRepository incidentReportRepository,
                                        IMapper mapper,
                                        IIdentityService identitySvc,
                                        IHttpContextAccessor httpContextAccessor,
                                        IFileUploaderRepository fileUploadRepository,
                                        IConfiguration configuration,
                                        IIncidentAssignmentRepository incidentAssignmentRepository,
                                        IOrganizationInfoRepository organizationInfoRepository,
                                        IExportManager<APIOpenClosedIncidentInfo> exportManager,
                                        IUserMasterRepository userMasterRepository,
                                        IMediator mediator,
                                        IIncidentCategoryRepository incidentCategoryRepository,
                                        IDepartmentRepository departmentRepository,
                                        IWebHostEnvironment env) : base(identitySvc)

        {
            _incidentReportRepository = incidentReportRepository;
            _identitySvc = identitySvc;
            _httpContextAccessor = httpContextAccessor;
            _mapper = mapper;
            _fileUploadRepository = fileUploadRepository;
            _configuration = configuration;
            _incidentAssignmentRepository = incidentAssignmentRepository;
            _organizationInfoRepository = organizationInfoRepository;
            _exportManager = exportManager;
            _userMasterRepository = userMasterRepository;
            _mediator = mediator;
            _incidentCategoryRepository = incidentCategoryRepository;
            _departmentRepository = departmentRepository;
            _env = env;
        }


        [HttpPost("Get")]
        public async Task<IActionResult> Get(APIId apiId)
        {
            IncidentReport incidentReport = await this._incidentReportRepository.GetAsync(apiId.Id);

            if (incidentReport != null) 
                return this.Ok(incidentReport);
            else
                return this.BadRequest(new ResponseMessage { Message = EnumHelper.GetEnumName(MessageType.NotFound), Description = "" });
        }

        [HttpPost("GetAllIncidents")]
        public async Task<IActionResult> GetAllIncidents(APISearchInfo apiSearchInfo)
        {
            try
            {
                List<APIIncidentReport> apiIncidentReports = await this._incidentReportRepository.GetAllIncidents(_loggedInUserOrganizationCode, apiSearchInfo.page, apiSearchInfo.pageSize, apiSearchInfo.filter, apiSearchInfo.search);

                int count = await this._incidentReportRepository.GetAllIncidentsCount(_loggedInUserOrganizationCode, apiSearchInfo.filter, apiSearchInfo.search);
                return Ok(new { apiIncidentReports, count });
            }
            catch (Exception)
            {
                return BadRequest(new ResponseMessage { Message = EnumHelper.GetEnumName(MessageType.InternalServerError), Description = EnumHelper.GetEnumDescription(MessageType.InternalServerError) });
            }
        }

        [HttpPost("GetIncidentReports")]
        public async Task<IActionResult> GetIncidentReports(APISearchInfo apiSearchInfo)
        {
            try
            {
                List<APIIncidentReport> apiIncidentReports = await this._incidentReportRepository.GetIncidentReports(_loggedInUserDBId, _loggedInUserOrganizationCode, apiSearchInfo.page, apiSearchInfo.pageSize, apiSearchInfo.filter, apiSearchInfo.search);

                int count = await this._incidentReportRepository.GetIncidentReportsCount(_loggedInUserDBId, _loggedInUserOrganizationCode, apiSearchInfo.filter, apiSearchInfo.search);
                return Ok(new { apiIncidentReports, count });
            }
            catch (Exception)
            {
                return BadRequest(new ResponseMessage { Message = EnumHelper.GetEnumName(MessageType.InternalServerError), Description = EnumHelper.GetEnumDescription(MessageType.InternalServerError) });
            }
        }

        [HttpPost("Post")]
        public async Task<IActionResult> Post([FromBody] APIIncidentReport apiIncidentReport)
        {
            try
            {
                if (!ModelState.IsValid)
                    return this.BadRequest(this.ModelState);

                IncidentReport incidentReport = new IncidentReport();
                incidentReport = _mapper.Map<IncidentReport>(apiIncidentReport);
                incidentReport.OrganizationCode = _loggedInUserOrganizationCode;
                incidentReport.CreatedDate = DateTime.Now;
                incidentReport.ModifiedDate = DateTime.Now;
                incidentReport.CreatedBy = _loggedInUserDBId;
                incidentReport.ModifiedBy = _loggedInUserDBId;

                IncidentReport newIncidentReport = await this._incidentReportRepository.AddAndReturnEntityAsync(incidentReport);

                if(newIncidentReport!=null)
                {
                    APIUserProfile userProfile = await this._userMasterRepository.GetDetailsById(_loggedInUserOrganizationCode, _userRole, newIncidentReport.CreatedBy);

                    APIUser user = await this._userMasterRepository.GetUserDetails(_loggedInUserOrganizationCode);

                    JObject IncidentReport = new JObject();
                    IncidentReport.Add("UserName", userProfile.Name);
                    IncidentReport.Add("ClientAdmin", user.Name);

                    Department department = await this._departmentRepository.GetAsync(newIncidentReport.LinkedToDepartmentId);
                    IncidentCategory incidentCategory = await this._incidentCategoryRepository.GetAsync(newIncidentReport.IncidentCategoryId);

                    IncidentReport.Add("Department", department.Name);
                    IncidentReport.Add("IncidentCategory", incidentCategory.Category);
                    IncidentReport.Add("UserId", userProfile.Id);
                    IncidentReport.Add("MobileNumber", userProfile.MobileNumber);

                    var command = new SendNewIncidentReportedCommand(IncidentReport);
                    //dont add await, as it works as background task
                    _mediator.Send(command);
                }

                return Ok(newIncidentReport);
            }
            catch (System.Exception ex)
            {
                return this.BadRequest(new ResponseMessage { Message = EnumHelper.GetEnumName(MessageType.InternalServerError), Description = ex.StackTrace });
            }
        }
        [HttpPut("{id}")]
        public async Task<IActionResult> Put(int Id, [FromBody] APIIncidentReport apiIncidentReport)
        {
            try
            {
                if (!ModelState.IsValid)
                    return this.BadRequest(this.ModelState);

                IncidentReport existingIncidentReport = await _incidentReportRepository.GetAsync(Id);

                if (existingIncidentReport == null)
                    return this.BadRequest(new ResponseMessage { Message = EnumHelper.GetEnumName(MessageType.NotExist), Description = "" });

                var createdBy = existingIncidentReport.CreatedBy;
                var createdDate = existingIncidentReport.CreatedDate;
                var photo = existingIncidentReport.Photo;
                var organizationCode = existingIncidentReport.OrganizationCode;
                bool IsAssigned = existingIncidentReport.IsAssigned;
                string Status = existingIncidentReport.Status;
                DateTime closureDate = existingIncidentReport.ClosureDate;

                existingIncidentReport = _mapper.Map<IncidentReport>(apiIncidentReport);
                existingIncidentReport.Id = Id;
                existingIncidentReport.CreatedBy = createdBy;
                existingIncidentReport.CreatedDate = existingIncidentReport.Status == Helper.IncidentReportingStatus.Draft && apiIncidentReport.Status != Helper.IncidentReportingStatus.Draft ? DateTime.Now : createdDate;
                existingIncidentReport.ModifiedDate = DateTime.Now;
                existingIncidentReport.ModifiedBy = _loggedInUserDBId;
                existingIncidentReport.OrganizationCode = organizationCode;
                existingIncidentReport.IsAssigned = IsAssigned;
                existingIncidentReport.ClosureDate = closureDate;
                
                if (string.IsNullOrWhiteSpace(existingIncidentReport.Photo) || string.IsNullOrEmpty(existingIncidentReport.Photo))
                    existingIncidentReport.Photo = photo;

                await this._incidentReportRepository.UpdateAsync(existingIncidentReport);

                return Ok(apiIncidentReport);
            }
            catch (System.Exception ex)
            {
                return this.BadRequest(new ResponseMessage { Message = EnumHelper.GetEnumName(MessageType.InternalServerError), Description = ex.StackTrace });
            }
        }

        [HttpPut("PutIncidentReportPhoto")]
        public async Task<IActionResult> PutIncidentReportPhoto([FromForm] APIIncidentReportPhoto incidentReportPhoto)
        {
            string fileName = "";
            string BusinessLogoUrl = "";
            string baseUrl = $"{this.Request.Scheme}://{this.Request.Host}{this.Request.PathBase}" + Helper.FileHelper.GetSavedFileWebPath(EnumFileUploadFor.IncidentReportPhoto);
            try
            {
                if (!ModelState.IsValid)
                    return this.BadRequest(this.ModelState);

                if (incidentReportPhoto.PhotoFile != null && incidentReportPhoto.PhotoFile.Length > 0)
                {
                    if (FileHelper.CheckIfImageFile(incidentReportPhoto.PhotoFile))
                    {
                        fileName = await _fileUploadRepository.Upload(EnumFileUploadFor.IncidentReportPhoto, EnumFileType.Image, incidentReportPhoto.PhotoFile, true);
                    }
                    else
                    {
                        return this.BadRequest(new ResponseMessage { Message = EnumHelper.GetEnumName(MessageType.InvalidFile), Description = EnumHelper.GetEnumDescription(MessageType.InvalidFile) });
                    }
                }
                else
                    return this.BadRequest(new ResponseMessage { Message = EnumHelper.GetEnumName(MessageType.InvalidFile), Description = EnumHelper.GetEnumDescription(MessageType.InvalidFile) });

                if (fileName != null && fileName.Trim().Length > 0)
                {
                    IncidentReport incidentReport = await this._incidentReportRepository.GetAsync(incidentReportPhoto.Id);
                    if (incidentReport.Photo != null && incidentReport.Photo.Trim().Length > 0)
                    {
                        bool deleted = _fileUploadRepository.DeleteFile(EnumFileUploadFor.IncidentReportPhoto, incidentReport.Photo.Trim());
                    }
                    incidentReport.Photo = fileName;
                    incidentReport.ModifiedDate = DateTime.Now;

                    await this._incidentReportRepository.UpdateAsync(incidentReport);
                    BusinessLogoUrl = baseUrl + "/" + fileName;
                    return Ok(BusinessLogoUrl);
                }
                else
                    return this.BadRequest(new ResponseMessage { Message = EnumHelper.GetEnumName(MessageType.Fail), Description = EnumHelper.GetEnumDescription(MessageType.Fail) });

            }
            catch (System.Exception ex)
            {
                return this.BadRequest(new ResponseMessage { Message = EnumHelper.GetEnumName(MessageType.InternalServerError), Description = ex.StackTrace });
            }
        }

        [HttpPut("PutIncidentReportPhotoWithBase64")]
        public async Task<IActionResult> PutIncidentReportPhotoWithBase64([FromBody] APIIncidentReportPhotoWithBase64 photoWithBase64)
        {
            string fileName = "";
            string contentRootPath = _env.ContentRootPath;
            string fileDirectory = FileHelper.GetSaveFilePath(EnumFileUploadFor.IncidentReportPhoto);
            //string baseUrl = $"{this.Request.Scheme}://{this.Request.Host}{this.Request.PathBase}" + Helper.FileHelper.GetSavedFileWebPath(EnumFileUploadFor.IncidentReportPhoto);
            string file = "";
            string fileExtention = ".jpg";
            try
            {
                if (!ModelState.IsValid)
                    return this.BadRequest(this.ModelState);

                if (string.IsNullOrEmpty(photoWithBase64.Base64String))
                {
                    return this.BadRequest(new ResponseMessage { Message = EnumHelper.GetEnumName(MessageType.InvalidData), Description = EnumHelper.GetEnumDescription(MessageType.InvalidData) });
                }
                var bytes = Convert.FromBase64String(photoWithBase64.Base64String);

                if (bytes.Length > 0)
                {
                    string fileclass = bytes[0].ToString();
                    fileclass += bytes[1].ToString();
                    if (fileclass == "255216" || fileclass == "7173" || fileclass == "13780" || fileclass == "6677")//7173=.gif 255216=.jpg 6677=.bmp 13780=.png
                    {
                        fileExtention = fileclass == "255216" ? ".jpg" : fileclass == "7173" ? ".gif" : fileclass == "13780" ? ".png" : "";
                        fileName = DateTime.UtcNow.Ticks.ToString() + fileExtention;
                        file = Path.Combine(contentRootPath + fileDirectory, fileName);
                        using (var stream = new FileStream(file, FileMode.Create))
                        {
                            stream.Write(bytes, 0, bytes.Length);
                            stream.Flush();
                        }
                        //_fileUploadRepository.SaveThumb(fileDirectory, fileName);
                    }
                    else
                    {
                        return this.BadRequest(new ResponseMessage { Message = EnumHelper.GetEnumName(MessageType.InvalidFile), Description = EnumHelper.GetEnumDescription(MessageType.InvalidFile) });
                    }
                }

                if (photoWithBase64.Id == 0)
                    return this.BadRequest(new ResponseMessage { Message = EnumHelper.GetEnumName(MessageType.NotExist), Description = "Incident not exist!" });
                      
                fileName = file.Substring(file.LastIndexOf("\\")).Replace(@"\", "");

                if (fileName != null && fileName.Trim().Length > 0)
                {
                    _fileUploadRepository.SaveThumb(fileDirectory, fileName);
                    IncidentReport incidentReport = await this._incidentReportRepository.GetAsync(photoWithBase64.Id);
                    if (incidentReport != null && incidentReport.Photo != null && incidentReport.Photo.Trim().Length > 0)
                    {
                        FileHelper.DeleteFile(EnumFileUploadFor.UserProfilePic, incidentReport.Photo);
                    }
                    incidentReport.Photo = fileName;
                    incidentReport.ModifiedDate = DateTime.Now;

                    await this._incidentReportRepository.UpdateAsync(incidentReport);
                    return Ok(fileName);
                }
                else
                    return this.BadRequest(new ResponseMessage { Message = EnumHelper.GetEnumName(MessageType.Fail), Description = EnumHelper.GetEnumDescription(MessageType.Fail) });
            }
            catch (System.Exception ex)
            {
                return this.BadRequest(new ResponseMessage { Message = EnumHelper.GetEnumName(MessageType.InternalServerError), Description = ex.StackTrace });
            }
        }

        [HttpPost("IsExist")]
        public async Task<IActionResult> IsExist(APIIsExistInput apiIsExistInput)
        {
            bool exists = false;
            switch (apiIsExistInput.FieldName.ToLower())
            {
                case "description":
                    exists = await this._incidentReportRepository.FindAsync(x => x.Description == apiIsExistInput.value && x.IsDeleted != true);
                    break;
            }
            return Ok(new { exists });
        }

        [HttpPost("GetOpenClosedIncidentsReport")]
        public async Task<IActionResult> GetOpenClosedIncidentsReport(APIOpenClosedIncidentSearch apiOpenClosedIncidentSearchInfo)
        {
            try
            {
                APIOpenClosedIncidentReport apiOpenClosedIncidentReport = new APIOpenClosedIncidentReport();

                APIOrganizationInfo apiOrganizationInfo = await _organizationInfoRepository.GetCurrentUserOrganization(_loggedInUserOrganizationCode);
                if (apiOrganizationInfo != null)
                {
                    apiOpenClosedIncidentReport.organizationName = apiOrganizationInfo.OrganizationName;
                    apiOpenClosedIncidentReport.address = apiOrganizationInfo.Address;
                    apiOpenClosedIncidentReport.city = apiOrganizationInfo.City;
                    apiOpenClosedIncidentReport.pinCode = apiOrganizationInfo.Pincode;
                }

                List<APIOpenClosedIncidentInfo> apiOpenClosedIncidentInfo = await this._incidentReportRepository.GetOpenClosedIncidentsReport(_loggedInUserOrganizationCode, apiOpenClosedIncidentSearchInfo);
                apiOpenClosedIncidentReport.reportDate = apiOpenClosedIncidentInfo;

                return Ok(apiOpenClosedIncidentReport);
            }
            catch (Exception)
            {
                return BadRequest(new ResponseMessage { Message = EnumHelper.GetEnumName(MessageType.InternalServerError), Description = EnumHelper.GetEnumDescription(MessageType.InternalServerError) });
            }
        }

        [HttpPost("GetIncidentReportsList")]
        public async Task<IActionResult> GetIncidentReportsList(APISearchInfo apiSearchInfo)
        {
            try
            {
                List<APIIncidentReport> apiIncidentReports = await this._incidentReportRepository.GetIncidentReportsList(_loggedInUserOrganizationCode, apiSearchInfo.page, apiSearchInfo.pageSize, apiSearchInfo.filter, apiSearchInfo.search);

                return Ok(apiIncidentReports);
            }
            catch (Exception)
            {
                return BadRequest(new ResponseMessage { Message = EnumHelper.GetEnumName(MessageType.InternalServerError), Description = EnumHelper.GetEnumDescription(MessageType.InternalServerError) });
            }
        }

        [HttpPost("GetSingleIncidentReportsList")]
        public async Task<IActionResult> GetSingleIncidentReportsList(APIId apiId)
        {
            try
            {
                List<APIIncidentReport> apiIncidentReports = await this._incidentReportRepository.GetSingleIncidentReportsList(_loggedInUserOrganizationCode, apiId.Id);

                return Ok(apiIncidentReports);
            }
            catch (Exception)
            {
                return BadRequest(new ResponseMessage { Message = EnumHelper.GetEnumName(MessageType.InternalServerError), Description = EnumHelper.GetEnumDescription(MessageType.InternalServerError) });
            }
        }

        [HttpPost("GetReportedIncidents")]
        public async Task<IActionResult> GetReportedIncidents(APISearchIncident searchInfo)
        {
            try
            {
                searchInfo.page = searchInfo.page == 0 ? 1 : searchInfo.page;
                searchInfo.pageSize = searchInfo.pageSize == 0 ? 10 : searchInfo.pageSize;
                List <APIIncidentReport> apiIncidentReports = await this._incidentReportRepository.GetReportedIncidents(_loggedInUserDBId, _loggedInUserOrganizationCode, _userRole, searchInfo);
                //List<APIIncidentReport> apiIncidentReportsAssigned = await this._incidentAssignmentRepository.GetIncidentAssignmentsForManagers(_loggedInUserDBId, _loggedInUserOrganizationCode, apiSearchInfo.status, apiSearchInfo.page, apiSearchInfo.pageSize, apiSearchInfo.filter, apiSearchInfo.search);

                int count = await this._incidentReportRepository.GetReportedIncidentsCount(_loggedInUserDBId, _loggedInUserOrganizationCode, _userRole, searchInfo);
                //count = count + await this._incidentAssignmentRepository.GetIncidentAssignmentsForManagersCount(_loggedInUserDBId, _loggedInUserOrganizationCode, apiSearchInfo.status, apiSearchInfo.filter, apiSearchInfo.search);

                //List<APIIncidentReport> apiIncidentReports = apiIncidentReportsCreated.Concat(apiIncidentReportsAssigned).ToList();

                foreach (APIIncidentReport item in apiIncidentReports)
                {
                    if (!string.IsNullOrEmpty(item.Photo))
                        item.PhotoBase64 = Helper.FileHelper.GetThumb(EnumFileUploadFor.IncidentReportPhoto, item.Photo);
                }

                return Ok(new { apiIncidentReports, count });
            }
            catch (Exception ex)
            {
                return BadRequest(new ResponseMessage { Message = EnumHelper.GetEnumName(MessageType.InternalServerError), Description = EnumHelper.GetEnumDescription(MessageType.InternalServerError) });
            }
        }

        [HttpPost("GetIncidentReportsForManagers")]
        public async Task<IActionResult> GetIncidentReportsForManagers(APISearchInfoForManagers apiSearchInfo)
        {
            try
            {
                List<APIIncidentReport> apiIncidentReports = await this._incidentReportRepository.GetIncidentReportsForManagers( _loggedInUserDBId, _loggedInUserOrganizationCode, apiSearchInfo.status, apiSearchInfo.page, apiSearchInfo.pageSize, apiSearchInfo.filter, apiSearchInfo.search);
                //List<APIIncidentReport> apiIncidentReportsAssigned = await this._incidentAssignmentRepository.GetIncidentAssignmentsForManagers(_loggedInUserDBId, _loggedInUserOrganizationCode, apiSearchInfo.status, apiSearchInfo.page, apiSearchInfo.pageSize, apiSearchInfo.filter, apiSearchInfo.search);

                int count = await this._incidentReportRepository.GetIncidentReportsForManagersCount(_loggedInUserDBId, _loggedInUserOrganizationCode, apiSearchInfo.status, apiSearchInfo.filter, apiSearchInfo.search);
                //count = count + await this._incidentAssignmentRepository.GetIncidentAssignmentsForManagersCount(_loggedInUserDBId, _loggedInUserOrganizationCode, apiSearchInfo.status, apiSearchInfo.filter, apiSearchInfo.search);

                //List<APIIncidentReport> apiIncidentReports = apiIncidentReportsCreated.Concat(apiIncidentReportsAssigned).ToList();

                foreach (APIIncidentReport item in apiIncidentReports)
                {
                    if (!string.IsNullOrEmpty(item.Photo))
                        item.PhotoBase64 = Helper.FileHelper.GetFile(EnumFileUploadFor.IncidentReportPhoto, item.Photo);
                }

                return Ok(new { apiIncidentReports, count });
            }
            catch (Exception ex)
            {
                return BadRequest(new ResponseMessage { Message = EnumHelper.GetEnumName(MessageType.InternalServerError), Description = EnumHelper.GetEnumDescription(MessageType.InternalServerError) });
            }
        }

        [HttpGet("GetImageContent/{id}")]
        public async Task<IActionResult> GetImageContent(int Id)
        {
            APIFileBase64Model image = new APIFileBase64Model() { Id = Id };
            IncidentReport incident = await this._incidentReportRepository.GetAsync(Id);

            if (_loggedInUserOrganizationCode == incident.OrganizationCode && !string.IsNullOrEmpty(incident.Photo))
            {
                image.FileName = incident.Photo;
                image.FileBase64 = Helper.FileHelper.GetFile(EnumFileUploadFor.IncidentReportPhoto, incident.Photo);
                image.Caption = "Incident Reported On :" + incident.CreatedDate.ToString("dd-MMM-yyyy");
            }
            return Ok(image);
        }

        [HttpGet("GetThumbImageContent/{id}")]
        public async Task<IActionResult> GetThumbImageContent(int Id)
        {
            APIFileBase64Model image = new APIFileBase64Model() { Id = Id };
            IncidentReport incident = await this._incidentReportRepository.GetAsync(Id);

            if (_loggedInUserOrganizationCode == incident.OrganizationCode && !string.IsNullOrEmpty(incident.Photo))
            {
                image.FileName = incident.Photo;
                image.FileBase64 = Helper.FileHelper.GetThumb(EnumFileUploadFor.IncidentReportPhoto, incident.Photo);
                image.Caption = "Incident Reported On :" + incident.CreatedDate.ToString("dd-MMM-yyyy");
            }
            return Ok(image);
        }

        [HttpPost("IsIncidentCreated")]
        public async Task<IActionResult> IsIncidentCreated(APIIsIncidentCreated apiIsIncidentCreated)
        {
            bool exists = false;

            if (apiIsIncidentCreated != null)
                exists = await this._incidentReportRepository.FindAsync(x => x.CreatedBy == apiIsIncidentCreated.userId && x.IsDeleted != true && x.OrganizationCode == _loggedInUserOrganizationCode && x.Id == apiIsIncidentCreated.incidentId);

            return Ok(new { exists });
        }

        [HttpGet("GetAllStatusCount")]
        public async Task<IActionResult> GetAllStatusCount()
        {
            try
            {
                APIIncidentReportCount apiIncidentReportCount = new APIIncidentReportCount();

                apiIncidentReportCount.OpenIncidentCount = await this._incidentReportRepository.GetStatusCount(_loggedInUserOrganizationCode, Helper.IncidentReportingStatus.Reported);
                apiIncidentReportCount.AssignedIncidentCount = await this._incidentReportRepository.GetStatusCount(_loggedInUserOrganizationCode, Helper.IncidentReportingStatus.Assigned);
                apiIncidentReportCount.WorkInProgressIncidentCount = await this._incidentReportRepository.GetStatusCount(_loggedInUserOrganizationCode, Helper.IncidentReportingStatus.WorkInProgress);
                apiIncidentReportCount.ClosedIncidentCount = await this._incidentReportRepository.GetStatusCount(_loggedInUserOrganizationCode, Helper.IncidentReportingStatus.Closed);
                apiIncidentReportCount.AverageClosuerPeriod = await this._incidentReportRepository.GetAverageClosuerPeriod(_loggedInUserOrganizationCode);
                apiIncidentReportCount.DaysSinceLastIncident = await this._incidentReportRepository.GetDaysSinceLastIncident(_loggedInUserOrganizationCode);

                return Ok(apiIncidentReportCount);
            }
            catch (Exception ex)
            {
                return BadRequest(new ResponseMessage { Message = EnumHelper.GetEnumName(MessageType.InternalServerError), Description = EnumHelper.GetEnumDescription(MessageType.InternalServerError) });
            }
        }

        [HttpPost("Exportxlsx")]
        public async Task<IActionResult> ExportXlsx(APIOpenClosedIncidentSearch apiOpenClosedIncidentSearchInfo)
        {
            try
            {
                APIOpenClosedIncidentReport apiOpenClosedIncidentReport = new APIOpenClosedIncidentReport();

                APIOrganizationInfo apiOrganizationInfo = await _organizationInfoRepository.GetCurrentUserOrganization(_loggedInUserOrganizationCode);
                
                IEnumerable<APIOpenClosedIncidentInfo> apiOpenClosedIncidentInfo = await this._incidentReportRepository.GetOpenClosedIncidentsReport(_loggedInUserOrganizationCode, apiOpenClosedIncidentSearchInfo);

                List<APIHeaderForExport> apiHeaderForExport = new List<APIHeaderForExport>();
                //apiHeaderForExport.Add(new APIHeaderForExport("", "Bill Detail - " + billNumber, ""));
                if (apiOrganizationInfo != null)
                {
                    apiHeaderForExport.Add(new APIHeaderForExport("", "", ""));
                    apiHeaderForExport.Add(new APIHeaderForExport("", apiOrganizationInfo.OrganizationName, ""));
                    apiHeaderForExport.Add(new APIHeaderForExport("", apiOrganizationInfo.Address, ""));
                    apiHeaderForExport.Add(new APIHeaderForExport("", apiOrganizationInfo.City+","+apiOrganizationInfo.Pincode, ""));
                    apiHeaderForExport.Add(new APIHeaderForExport("", "", ""));
                    apiHeaderForExport.Add(new APIHeaderForExport("", "Incidents and Corrective Actions Implement Report –"+apiOpenClosedIncidentSearchInfo.month+" "+apiOpenClosedIncidentSearchInfo.year, ""));
                }

                var headerProperties = new[]
                {
                        new PropertyByName<APIHeaderForExport>("Name", p => p.Name),
                        new PropertyByName<APIHeaderForExport>("Value", p => p.Value),
                        new PropertyByName<APIHeaderForExport>("NewValue", p => p.NewValue),
                };

                var properties = new[]
                {
                        new PropertyByName<APIOpenClosedIncidentInfo>("Incident Id", p => p.IncidentId),
                        new PropertyByName<APIOpenClosedIncidentInfo>("Date Reported", p => p.DateReported.ToString("dd/MMM/yyyy")),
                        new PropertyByName<APIOpenClosedIncidentInfo>("Reported By", p => p.ReportedBy),
                        new PropertyByName<APIOpenClosedIncidentInfo>("Designation", p => p.Designation),
                        new PropertyByName<APIOpenClosedIncidentInfo>("Brief Description", p => p.BriefDescription),
                        new PropertyByName<APIOpenClosedIncidentInfo>("IncidentCategory", p => p.IncidentCategory),
                        new PropertyByName<APIOpenClosedIncidentInfo>("Status", p => p.Status),
                        new PropertyByName<APIOpenClosedIncidentInfo>("Last Action Taken", p => p.LastActionTaken),//.Value.ToString("dd/MMM/yyyy")),
                        new PropertyByName<APIOpenClosedIncidentInfo>("Corrective Actions", p => p.CorrectiveActions),
                        new PropertyByName<APIOpenClosedIncidentInfo>("ATR Reported By", p => p.ATRReportedBy),
                };

                byte[] bytes = _exportManager.ExportToXlsx(properties, apiOpenClosedIncidentInfo, apiHeaderForExport.ToList(), headerProperties);

                return File(bytes, "text/xls", "OpenClosedIncidentReport.xlsx");

            }
            catch (Exception ex)
            {
                return BadRequest(new ResponseMessage { Message = EnumHelper.GetEnumName(MessageType.InternalServerError), Description = EnumHelper.GetEnumDescription(MessageType.InternalServerError) });
            }
        }
    }
}
