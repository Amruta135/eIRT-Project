﻿using AspNet.Security.OAuth.Introspection;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using User.API.APIModel;
using User.API.Helper;
using User.API.Models;
using User.API.Repositories.Interface;
using User.API.Repositories;
using User.API.Services;
using static User.API.Validation.TokenValidation;

namespace User.API.Controllers
{
    [ApiVersion("1.0")]
    [Route("user/api/v{version:apiVersion}/[controller]")]
    [ApiController]
    [Authorize(AuthenticationSchemes = OAuthIntrospectionDefaults.AuthenticationScheme)]
    [Authorize]
    [TokenValid]
    public class CompetencyController : IdentityController
    {
        private readonly ICompetencyRepository _competencyRepository;
        private readonly IIdentityService _identitySvc;
        private readonly IHttpContextAccessor _httpContextAccessor;
        public CompetencyController(ICompetencyRepository competencyRepository,
                                    IIdentityService identitySvc,
                                    IHttpContextAccessor httpContextAccessor) : base(identitySvc)

        {
            _competencyRepository = competencyRepository;
            _identitySvc = identitySvc;
            _httpContextAccessor = httpContextAccessor;
        }

        [HttpGet("GetCompetency")]
        public async Task<IActionResult> GetCompetency(APIId apiId)
        {
            APICompetency competency = await this._competencyRepository.GetCompetency(apiId.Id, _loggedInUserOrganizationCode);

            if (competency != null)
                return this.Ok(competency);
            else
                return this.BadRequest(new ResponseMessage { Message = EnumHelper.GetEnumName(MessageType.NotFound), Description = "" });
        }

        [HttpGet("GetAllCompetencies")]
        public async Task<IActionResult> GetAllCompetencies()
        {
            try
            {
                List<Competency> competencies = await this._competencyRepository.GetAll(x => x.IsDeleted == false && x.OrganizationCode == _loggedInUserOrganizationCode);
                return Ok(competencies);
            }
            catch (Exception)
            {
                return BadRequest(new ResponseMessage { Message = EnumHelper.GetEnumName(MessageType.InternalServerError), Description = EnumHelper.GetEnumDescription(MessageType.InternalServerError) });
            }
        }

        [HttpPost("GetCompetencies")]
        public async Task<IActionResult> GetCompetencies(APISearchInfo apiSearchInfo)
        {
            try
            {
                List<APICompetency> Competencies = await this._competencyRepository.GetCompetencies(_loggedInUserOrganizationCode, apiSearchInfo.page, apiSearchInfo.pageSize, apiSearchInfo.filter, apiSearchInfo.search);
                int Count = await this._competencyRepository.GetCompetenciesCount(_loggedInUserOrganizationCode, apiSearchInfo.filter, apiSearchInfo.search);

                return Ok(new { Competencies, Count });
            }
            catch (Exception)
            {
                return BadRequest(new ResponseMessage { Message = EnumHelper.GetEnumName(MessageType.InternalServerError), Description = EnumHelper.GetEnumDescription(MessageType.InternalServerError) });
            }
        }

        [HttpPost("GetCompetenciesAssignedToUser")]
        public async Task<IActionResult> GetCompetenciesAssignedToUser(APIId apiId)
        {
            List<APICompetency> competencies = await this._competencyRepository.GetCompetenciesAssignedToUser( _loggedInUserOrganizationCode, apiId.Id);

            if (competencies != null)
                return this.Ok(competencies);
            else
                return this.BadRequest(new ResponseMessage { Message = EnumHelper.GetEnumName(MessageType.NotFound), Description = "" });
        }

        [HttpPost("GetCompetenciesAssignedToIncedent")]
        public async Task<IActionResult> GetCompetenciesAssignedToIncedent(APIId apiId)
        {
            List<APICompetency> competencies = await this._competencyRepository.GetCompetenciesAssignedToIncedent(_loggedInUserOrganizationCode, apiId.Id);

            if (competencies != null)
                return this.Ok(competencies);
            else
                return this.BadRequest(new ResponseMessage { Message = EnumHelper.GetEnumName(MessageType.NotFound), Description = "" });
        }

        [HttpPost("Add")]
        public async Task<IActionResult> Post([FromBody] APICompetency info)
        {
            IsSuccess result = new IsSuccess() { success = false, message = "" };
            try
            {
                if (!ModelState.IsValid)
                {
                    result.message = "Invalid data!";
                    return Ok(result);
                }

                if (await this._competencyRepository.FindAsync(s => s.IsDeleted == false && s.OrganizationCode == _loggedInUserOrganizationCode && s.CompetencyDescription.ToLower() == info.CompetencyDescription.Trim().ToLower()))
                {
                    result.message = "Already exists!";
                    return Ok(result);
                }

                Competency competency = new Competency();
                competency.OrganizationCode = _loggedInUserOrganizationCode;
                competency.CompetencyDescription = info.CompetencyDescription.Trim();
                competency.CreatedDate = DateTime.Now;
                competency.ModifiedDate = DateTime.Now;
                competency.CreatedBy = _loggedInUserDBId;
                competency.ModifiedBy = _loggedInUserDBId;
                await this._competencyRepository.AddAndReturnEntityAsync(competency);
                result.success = true;
                return Ok(result);
            }
            catch (System.Exception ex)
            {
                result.message = "internal Server Error!";
                return Ok(result);
            }
        }

        [HttpPut("Update")]
        public async Task<IActionResult> Put([FromBody] APICompetency info)
        {
            IsSuccess result = new IsSuccess() { success = false, message = "" };
            try
            {
                if (!ModelState.IsValid)
                {
                    result.message = "Invalid data!";
                    return Ok(result);
                } 

                Competency existingCompetency = await _competencyRepository.GetAsync(info.Id);
                if (existingCompetency == null)
                {
                    result.message = "Not Found!";
                    return Ok(result);
                }

                if (await this._competencyRepository.FindAsync(s => s.IsDeleted == false && s.OrganizationCode == _loggedInUserOrganizationCode && s.CompetencyDescription.ToLower() == info.CompetencyDescription.Trim().ToLower() && s.Id != info.Id))
                {
                    result.message = "Already exists!";
                    return Ok(result);
                }
 
                existingCompetency.CompetencyDescription = info.CompetencyDescription.Trim();
                existingCompetency.ModifiedDate = DateTime.Now;
                existingCompetency.ModifiedBy = _loggedInUserDBId;

                await this._competencyRepository.UpdateAsync(existingCompetency);
                result.success = true;
                return Ok(result);
            }
            catch (System.Exception ex)
            {
                result.message = "internal Server Error!";
                return Ok(result);
            }
        }

        [HttpPut("Delete")]
        public async Task<IActionResult> Delete([FromBody] APIId apiId)
        {
            IsSuccess result = new IsSuccess() { success = false, message = "" };
            try
            {
                if (!ModelState.IsValid || apiId.Id == 0)
                {
                    result.message = "Invalid data!";
                    return Ok(result);
                }

                Competency existingCompetency = await _competencyRepository.GetAsync(apiId.Id);
                if (existingCompetency == null)
                {
                    result.message = "Not Found!";
                    return Ok(result);
                }
                existingCompetency.IsDeleted = true;
                existingCompetency.ModifiedDate = DateTime.Now;
                existingCompetency.ModifiedBy = _loggedInUserDBId;

                await this._competencyRepository.UpdateAsync(existingCompetency);
                result.success = true;
                return Ok(result);
            }
            catch (System.Exception ex)
            {
                result.message = "internal Server Error!";
                return Ok(result);
            }
        }

        [HttpPost("IsExist")]
        public async Task<IActionResult> IsExist(APIIsExistInput apiIsExistInput)
        {
            bool exists = false;
            if (apiIsExistInput.Id == 0)
            {
                switch (apiIsExistInput.FieldName.ToLower())
                {
                    case "competencydescription":
                        exists = await this._competencyRepository.FindAsync(x => x.IsDeleted == false && x.CompetencyDescription.ToLower() == apiIsExistInput.value.Trim().ToLower() && x.OrganizationCode == _loggedInUserOrganizationCode);
                        break;
                }
            }
            else
            {
                switch (apiIsExistInput.FieldName.ToLower())
                {
                    case "competencydescription":
                        exists = await this._competencyRepository.FindAsync(x => x.IsDeleted == false && x.CompetencyDescription.ToLower() == apiIsExistInput.value.Trim().ToLower() && x.OrganizationCode == _loggedInUserOrganizationCode && x.Id != apiIsExistInput.Id);
                        break;
                }
            }
            return Ok(new { exists });
        }
    }
}
