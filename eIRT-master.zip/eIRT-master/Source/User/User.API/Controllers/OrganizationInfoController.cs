﻿using AspNet.Security.OAuth.Introspection;
using AutoMapper;
using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using User.API.APIModel;
using User.API.Helper;
using User.API.Models;
using User.API.Repositories.Interface;
using User.API.Services;
using static User.API.Validation.TokenValidation;

namespace User.API.Controllers
{
    [ApiVersion("1.0")]
    [Route("user/api/v{version:apiVersion}/[controller]")]
    [ApiController]
    [Authorize(AuthenticationSchemes = OAuthIntrospectionDefaults.AuthenticationScheme)]
    [Authorize(Roles = "PA, CA")]
    [TokenValid]
    public class OrganizationInfoController : IdentityController
    {
        private readonly IOrganizationInfoRepository _organizationInfoRepository;
        private readonly IMapper _mapper;
        private readonly IIdentityService _identitySvc;
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly ITokenExpiredRepository _tokenExpiredRepository;
        private readonly ITokensRepository _tokensRepository;
        private readonly IMediator _mediator;
        private readonly IFileUploaderRepository _fileUploadRepository;
        private readonly IRolesConfigurationRepository _rolesConfigurationRepository;
        private readonly IIncidentCategoryRepository _incidentCategoryRepository;

        public OrganizationInfoController(IOrganizationInfoRepository organizationInfoRepository,
                                          IMapper mapper,
                                          IIdentityService identitySvc,
                                          IHttpContextAccessor httpContextAccessor,
                                          ITokenExpiredRepository tokenExpiredRepository,
                                          ITokensRepository tokensRepository,
                                          IMediator mediator,
                                          IFileUploaderRepository fileUploadRepository,
                                          IRolesConfigurationRepository rolesConfigurationRepository,
                                          IIncidentCategoryRepository incidentCategoryRepository) : base(identitySvc)

        {
            _organizationInfoRepository = organizationInfoRepository;
            _mapper = mapper;
            _identitySvc = identitySvc;
            _httpContextAccessor = httpContextAccessor;
            _tokenExpiredRepository = tokenExpiredRepository;
            _tokensRepository = tokensRepository;
            _mediator = mediator;
            _fileUploadRepository = fileUploadRepository;
            _rolesConfigurationRepository = rolesConfigurationRepository;
            _incidentCategoryRepository = incidentCategoryRepository;
        }

        [HttpPost("Get")]
        public async Task<IActionResult> Get(APIId apiOrganizationInfoId)
        {
            OrganizationInfo organizationInfo = await this._organizationInfoRepository.GetAsync(apiOrganizationInfoId.Id);
            if (organizationInfo != null)
            {
                var logoBase64 = "";
                if (!string.IsNullOrEmpty(organizationInfo.Logo))
                    logoBase64 = Helper.FileHelper.GetFile(EnumFileUploadFor.OrganizationLogo, organizationInfo.Logo);

                var NoofUsers = Security.Decrypt(organizationInfo.NoofUsers);
                int NoOfUsers = Convert.ToInt32(NoofUsers.Substring(0, (NoofUsers.Length) - 5));

                var AccountValidityDate = Security.Decrypt(organizationInfo.AccountValidityDate);
                DateTime accountValidityDate = !string.IsNullOrWhiteSpace(AccountValidityDate) ? Convert.ToDateTime(AccountValidityDate.Substring(0, (AccountValidityDate.Length) - 5)) : DateTime.MinValue;

                var DomainName = "";
                string domainName = "";

                if (!String.IsNullOrEmpty(organizationInfo.DomainName))
                {
                    DomainName = Security.Decrypt(organizationInfo.DomainName);
                    domainName = DomainName.Substring(0, (DomainName.Length) - 5);
                }

                var x = new APIOrganizationInfo { 
                    Id = organizationInfo.Id, 
                    OrganizationCode = organizationInfo.OrganizationCode, 
                    OrganizationName = organizationInfo.OrganizationName, 
                    Address = organizationInfo.Address, 
                    Pincode = organizationInfo.Pincode, 
                    City = organizationInfo.City, 
                    State = organizationInfo.State, 
                    MobileNumber = organizationInfo.MobileNumber, 
                    Website = organizationInfo.Website, 
                    DeliveryModel = organizationInfo.DeliveryModel, 
                    DomainName = domainName, 
                    WorkflowOption = organizationInfo.WorkflowOption, 
                    NoofUsers = NoOfUsers, 
                    AccountValidityDate = accountValidityDate, 
                    Logo = organizationInfo.Logo, 
                    LogoBase64 = logoBase64, 
                    RGBCode = organizationInfo.RGBCode, 
                    AppName = string.IsNullOrWhiteSpace(organizationInfo.AppName)? "Incident Reporting Tool" : organizationInfo.AppName
                };
                return Ok(x);
            }
            else
                return this.BadRequest(new ResponseMessage { Message = EnumHelper.GetEnumName(MessageType.NotFound), Description = "" });
        }

        [HttpPost("GetOrganizationInfos")]
        public async Task<IActionResult> GetOrganizationInfos([FromBody] APISearchInfo apiSearchInfo)
        {
            try
            {
                List<APIOrganizationInfo_Internal> apiOrganizationInfo_Internal = await this._organizationInfoRepository.GetOrganizationInfos(apiSearchInfo.page, apiSearchInfo.pageSize, apiSearchInfo.filter, apiSearchInfo.search);
                List<APIOrganizationInfo> apiOrganizationInfo = new List<APIOrganizationInfo>();

                foreach (APIOrganizationInfo_Internal item in apiOrganizationInfo_Internal)
                {
                    var logoBase64 = "";
                    if (!string.IsNullOrEmpty(item.Logo))
                        logoBase64 = Helper.FileHelper.GetThumb(EnumFileUploadFor.OrganizationLogo, item.Logo);

                    var NoofUsers = Security.Decrypt(item.NoofUsers);
                    int NoOfUsers = Convert.ToInt32(NoofUsers.Substring(0, (NoofUsers.Length) - 5));

                    var AccountValidityDate = Security.Decrypt(item.AccountValidityDate);
                    DateTime accountValidityDate = !string.IsNullOrWhiteSpace(AccountValidityDate) ? Convert.ToDateTime(AccountValidityDate.Substring(0, (AccountValidityDate.Length) - 5)) : DateTime.MinValue;

                    var DomainName = "";
                    string domainName = "";

                    if (!String.IsNullOrEmpty(item.DomainName))
                    {
                        DomainName = Security.Decrypt(item.DomainName);
                        domainName = DomainName.Substring(0, (DomainName.Length) - 5);
                    }

                    var x = new APIOrganizationInfo { Id = item.Id, OrganizationCode = item.OrganizationCode, 
                                                      OrganizationName = item.OrganizationName, Address = item.Address, 
                                                      Pincode = item.Pincode, City = item.City, State = item.State, 
                                                      MobileNumber = item.MobileNumber, Website = item.Website, 
                                                      DeliveryModel = item.DeliveryModel, DomainName = domainName, 
                                                      WorkflowOption = item.WorkflowOption, NoofUsers = NoOfUsers, 
                                                      AccountValidityDate = accountValidityDate, Logo = item.Logo, 
                                                      LogoBase64 = logoBase64, RGBCode = item.RGBCode, CreatedBy=item.CreatedBy,
                                                      HasAdmin = item.HasAdmin, 
                                                      AppName = string.IsNullOrWhiteSpace(item.AppName) ? "Incident Reporting Tool" : item.AppName
                    };
                    apiOrganizationInfo.Add(x);
                }

                int count = await this._organizationInfoRepository.GetOrganizationInfosCount(apiSearchInfo.filter, apiSearchInfo.search);
                return Ok(new { apiOrganizationInfo, count });
            }
            catch (Exception ex)
            {
                return BadRequest(new ResponseMessage { Message = EnumHelper.GetEnumName(MessageType.InternalServerError), Description = EnumHelper.GetEnumDescription(MessageType.InternalServerError) });
            }
        }


        [HttpPost("GetOrganizationInfosCount")]
        public async Task<IActionResult> GetOrganizationInfosCount(APISearchInfo apiSearchInfo)
        {
            try
            {
                return Ok(await this._organizationInfoRepository.GetOrganizationInfosCount(apiSearchInfo.filter, apiSearchInfo.search));
            }
            catch (Exception)
            {
                return BadRequest(new ResponseMessage { Message = EnumHelper.GetEnumName(MessageType.InternalServerError), Description = EnumHelper.GetEnumDescription(MessageType.InternalServerError) });
            }
        }

        [HttpPost("Post")]
        public async Task<IActionResult> Post([FromBody] APIOrganizationInfo apiOrganizationInfo)
        {
            try
            {
                if (!ModelState.IsValid)
                    return this.BadRequest(this.ModelState);

                if (await this._organizationInfoRepository.FindAsync(a => a.IsDeleted != true && a.OrganizationName == apiOrganizationInfo.OrganizationName))
                    return this.BadRequest(new ResponseMessage { Message = EnumHelper.GetEnumName(MessageType.Duplicate), Description = "Organization Information already exists!" });

                Random random = new Random();
                OrganizationInfo organizationInfo = new OrganizationInfo();
                organizationInfo = _mapper.Map<OrganizationInfo>(apiOrganizationInfo);
                organizationInfo.NoofUsers = Security.Encrypt(apiOrganizationInfo.NoofUsers.ToString() + random.Next(10000, 99999).ToString());
                organizationInfo.AccountValidityDate = Security.Encrypt(apiOrganizationInfo.AccountValidityDate.ToString("yyyy-MMM-dd hh:mm tt") + random.Next(10000, 99999).ToString());
                apiOrganizationInfo.DomainName = apiOrganizationInfo.DomainName ?? "";
                if (!String.IsNullOrEmpty(apiOrganizationInfo.DomainName))
                    organizationInfo.DomainName = Security.Encrypt(apiOrganizationInfo.DomainName + random.Next(10000, 99999).ToString());
                organizationInfo.CreatedDate = DateTime.Now;
                organizationInfo.ModifiedDate = DateTime.Now;
                organizationInfo.CreatedBy = _loggedInUserDBId;
                organizationInfo.ModifiedBy = _loggedInUserDBId;
                organizationInfo.DomainName = apiOrganizationInfo.DomainName ?? "";

                OrganizationInfo newOrganizationInfo = await this._organizationInfoRepository.AddAndReturnEntityAsync(organizationInfo);

                if (newOrganizationInfo != null)
                {
                    await _rolesConfigurationRepository.AddDefaultRolesConfiguration(newOrganizationInfo.OrganizationCode, _loggedInUserDBId);
                    await _incidentCategoryRepository.AddDefaultIncidentCategory(newOrganizationInfo.OrganizationCode, _loggedInUserDBId);
                }

                apiOrganizationInfo.Id = newOrganizationInfo.Id;
                return Ok(apiOrganizationInfo);
            }
            catch (System.Exception ex)
            {
                return this.BadRequest(new ResponseMessage { Message = EnumHelper.GetEnumName(MessageType.InternalServerError), Description = ex.StackTrace });
            }
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Put(int id, [FromBody] APIOrganizationInfo apiOrganizationInfo)
        {
            try
            {
                if (!ModelState.IsValid)
                    return this.BadRequest(this.ModelState);

                OrganizationInfo existingOrganizationInfo = await _organizationInfoRepository.GetAsync(id);

                if (existingOrganizationInfo == null)
                {
                    return this.BadRequest(new ResponseMessage { Message = EnumHelper.GetEnumName(MessageType.NotExist), Description = "" });
                }

                var createdBy = existingOrganizationInfo.CreatedBy;
                var createdDate = existingOrganizationInfo.CreatedDate;
                var fileName = existingOrganizationInfo.Logo;

                existingOrganizationInfo = _mapper.Map<OrganizationInfo>(apiOrganizationInfo);
                existingOrganizationInfo.Id = id;
                existingOrganizationInfo.DomainName = existingOrganizationInfo.DomainName ?? "";
                if (string.IsNullOrWhiteSpace(apiOrganizationInfo.Logo) || string.IsNullOrEmpty(apiOrganizationInfo.Logo))
                    existingOrganizationInfo.Logo = fileName;

                Random random = new Random();
                existingOrganizationInfo.NoofUsers = Security.Encrypt(apiOrganizationInfo.NoofUsers.ToString() + random.Next(10000, 99999).ToString());
                existingOrganizationInfo.AccountValidityDate = Security.Encrypt(apiOrganizationInfo.AccountValidityDate.ToString("yyyy-MMM-dd hh:mm tt") + random.Next(10000, 99999).ToString());
                if (!String.IsNullOrEmpty(apiOrganizationInfo.DomainName))
                    existingOrganizationInfo.DomainName = Security.Encrypt(apiOrganizationInfo.DomainName + random.Next(10000, 99999).ToString());
                existingOrganizationInfo.CreatedDate = createdDate;
                existingOrganizationInfo.ModifiedDate = DateTime.Now;
                existingOrganizationInfo.CreatedBy = createdBy;
                existingOrganizationInfo.ModifiedBy = _loggedInUserDBId;

                await this._organizationInfoRepository.UpdateAsync(existingOrganizationInfo);

                return Ok(apiOrganizationInfo);
            }
            catch (System.Exception ex)
            {
                return this.BadRequest(new ResponseMessage { Message = EnumHelper.GetEnumName(MessageType.InternalServerError), Description = ex.StackTrace });
            }
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            try
            {
                if (!ModelState.IsValid)
                    return this.BadRequest(this.ModelState);

                OrganizationInfo existingOrganizationInfo = await _organizationInfoRepository.GetAsync(id);

                if (existingOrganizationInfo == null)
                {
                    return this.BadRequest(new ResponseMessage { Message = EnumHelper.GetEnumName(MessageType.NotExist), Description = "" });
                }

                existingOrganizationInfo.IsDeleted = true;
                existingOrganizationInfo.ModifiedDate = DateTime.Now;
                existingOrganizationInfo.ModifiedBy = _loggedInUserDBId;

                await this._organizationInfoRepository.UpdateAsync(existingOrganizationInfo);

                return Ok();
            }
            catch (System.Exception ex)
            {
                return this.BadRequest(new ResponseMessage { Message = EnumHelper.GetEnumName(MessageType.InternalServerError), Description = ex.StackTrace });
            }
        }

        [HttpPut("PutOrganizationLogo")]
        public async Task<IActionResult> PutOrganizationLogo([FromForm] APIOrganizationLogo organizationLogo)
        {
            string fileName = "";
            string BusinessLogoUrl = "";
            string baseUrl = $"{this.Request.Scheme}://{this.Request.Host}{this.Request.PathBase}" + Helper.FileHelper.GetSavedFileWebPath(EnumFileUploadFor.OrganizationLogo);
            try
            {
                if (!ModelState.IsValid)
                    return this.BadRequest(this.ModelState);

                if (organizationLogo.LogoFile != null && organizationLogo.LogoFile.Length > 0)
                {
                    if (FileHelper.CheckIfImageFile(organizationLogo.LogoFile))
                    {
                        fileName = await _fileUploadRepository.Upload(EnumFileUploadFor.OrganizationLogo, EnumFileType.Image, organizationLogo.LogoFile, true);
                    }
                    else
                    {
                        return this.BadRequest(new ResponseMessage { Message = EnumHelper.GetEnumName(MessageType.InvalidFile), Description = EnumHelper.GetEnumDescription(MessageType.InvalidFile) });
                    }
                }
                else
                    return this.BadRequest(new ResponseMessage { Message = EnumHelper.GetEnumName(MessageType.InvalidFile), Description = EnumHelper.GetEnumDescription(MessageType.InvalidFile) });

                if (fileName != null && fileName.Trim().Length > 0)
                {
                    OrganizationInfo organizationInfo = await this._organizationInfoRepository.GetAsync(organizationLogo.Id);
                    if (organizationInfo.Logo != null && organizationInfo.Logo.Trim().Length > 0)
                    {
                        bool deleted = _fileUploadRepository.DeleteFile(EnumFileUploadFor.OrganizationLogo, organizationInfo.Logo.Trim());
                    }
                    organizationInfo.Logo = fileName;
                    organizationInfo.ModifiedDate = DateTime.Now;

                    await this._organizationInfoRepository.UpdateAsync(organizationInfo);
                    BusinessLogoUrl = baseUrl + "/" + fileName;
                    return Ok(BusinessLogoUrl);
                }
                else
                    return this.BadRequest(new ResponseMessage { Message = EnumHelper.GetEnumName(MessageType.Fail), Description = EnumHelper.GetEnumDescription(MessageType.Fail) });

            }
            catch (System.Exception ex)
            {
                return this.BadRequest(new ResponseMessage { Message = EnumHelper.GetEnumName(MessageType.InternalServerError), Description = ex.StackTrace });
            }
        }

        [HttpGet("IsExistAsync")]
        public async Task<IActionResult> IsExistAsync(string fieldName, string value)
        {
            bool exists = false;
            switch (fieldName.ToLower())
            {
                case "organizationname":
                    exists = await this._organizationInfoRepository.FindAsync(x => x.OrganizationName == value && x.IsDeleted != true);
                    break;
                case "domainname":
                    exists = await this._organizationInfoRepository.FindAsync(x => x.DomainName == value && x.IsDeleted != true);
                    break;
                case "organizationcode":
                    exists = await this._organizationInfoRepository.FindAsync(x => x.OrganizationCode == value && x.IsDeleted != true);
                    break;
            }
            return Ok(new { exists });
        }

        [Authorize(Roles = "PA, CA")]
        [HttpGet("GetOrganizationMaxUsers")]
        public async Task<IActionResult> GetOrganizationMaxUsers()
        {
            try
            {
                var NoofUsers = Security.Decrypt(await this._organizationInfoRepository.GetOrganizationMaxUsers(_loggedInUserOrganizationCode));
                int NoOfUsers = Convert.ToInt32(NoofUsers.Substring(0, (NoofUsers.Length) - 5));
                return Ok(new { NoOfUsers });
            }
            catch (Exception)
            {
                return BadRequest(new ResponseMessage { Message = EnumHelper.GetEnumName(MessageType.InternalServerError), Description = EnumHelper.GetEnumDescription(MessageType.InternalServerError) });
            }
        }

        [AllowAnonymous]
        [HttpGet("GetCurrentUserOrganization")]
        public async Task<IActionResult> GetCurrentUserOrganization()
        {
            try
            {
                APIOrganizationInfo Org = await this._organizationInfoRepository.GetCurrentUserOrganization(_loggedInUserOrganizationCode);
                if (Org != null && !string.IsNullOrWhiteSpace(Org.Logo))
                    Org.LogoBase64 = Helper.FileHelper.GetThumb(EnumFileUploadFor.OrganizationLogo, Org.Logo);
                return Ok(Org);
            }
            catch (Exception)
            {
                return BadRequest(new ResponseMessage { Message = EnumHelper.GetEnumName(MessageType.InternalServerError), Description = EnumHelper.GetEnumDescription(MessageType.InternalServerError) });
            }
        }

        [HttpGet("GetCurrentOrganizationImageContent/{id}")]
        public async Task<IActionResult> GetCurrentOrganizationImageContent(int Id)
        {
            APIFileBase64Model image = new APIFileBase64Model() { Id = Id };
            APIOrganizationInfo org = await this._organizationInfoRepository.GetCurrentUserOrganization(_loggedInUserOrganizationCode);

            if (_loggedInUserOrganizationCode == org.OrganizationCode && !string.IsNullOrEmpty(org.Logo))
            {
                image.FileName = org.Logo;
                image.FileBase64 = Helper.FileHelper.GetFile(EnumFileUploadFor.OrganizationLogo, org.Logo);
                image.Caption = org.OrganizationName;
            }
            return Ok(image);
        }

        [HttpGet("GetCurrentOrganizationThumbImageContent/{id}")]
        public async Task<IActionResult> GetCurrentOrganizationThumbImageContent(int Id)
        {
            APIFileBase64Model image = new APIFileBase64Model() { Id = Id };
            APIOrganizationInfo org = await this._organizationInfoRepository.GetCurrentUserOrganization(_loggedInUserOrganizationCode);

            if (_loggedInUserOrganizationCode == org.OrganizationCode && !string.IsNullOrEmpty(org.Logo))
            {
                image.FileName = org.Logo;
                image.FileBase64 = Helper.FileHelper.GetThumb(EnumFileUploadFor.OrganizationLogo, org.Logo);
                image.Caption = org.OrganizationName;
            }
            return Ok(image);
        }

        [HttpGet("GetImageContent/{id}")]
        public async Task<IActionResult> GetImageContent(int Id)
        {
            APIFileBase64Model image = new APIFileBase64Model() { Id = Id };
            OrganizationInfo org = await this._organizationInfoRepository.GetAsync(Id);

            if (_loggedInUserOrganizationCode == org.OrganizationCode && !string.IsNullOrEmpty(org.Logo))
            {
                image.FileName = org.Logo;
                image.FileBase64 = Helper.FileHelper.GetFile(EnumFileUploadFor.OrganizationLogo, org.Logo);
                image.Caption = org.OrganizationName;
            }
            return Ok(image);
        }

        [HttpGet("GetThumbImageContent/{id}")]
        public async Task<IActionResult> GetThumbImageContent(int Id)
        {
            APIFileBase64Model image = new APIFileBase64Model() { Id = Id };
            OrganizationInfo org = await this._organizationInfoRepository.GetAsync(Id);

            if (_loggedInUserOrganizationCode == org.OrganizationCode && !string.IsNullOrEmpty(org.Logo))
            {
                image.FileName = org.Logo;
                image.FileBase64 = Helper.FileHelper.GetThumb(EnumFileUploadFor.OrganizationLogo, org.Logo);
                image.Caption = org.OrganizationName;
            }
            return Ok(image);
        }
    }
}
