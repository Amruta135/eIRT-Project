﻿using AspNet.Security.OAuth.Introspection;
using AutoMapper;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Threading.Tasks;
using User.API.APIModel;
using User.API.Helper;
using User.API.Models;
using User.API.Repositories.Interface;
using User.API.Services;
using static User.API.Validation.TokenValidation;


namespace User.API.Controllers
{
    [ApiVersion("1.0")]
    [Route("user/api/v{version:apiVersion}/[controller]")]
    [ApiController]
    [Authorize(AuthenticationSchemes = OAuthIntrospectionDefaults.AuthenticationScheme)]
    [TokenValid]
    public class ConfigurableValuesController : IdentityController
    {
        private readonly IConfigurableValuesRepository _configurableValuesRepository;
        private readonly IIdentityService _identitySvc;
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly ITokenExpiredRepository _tokenExpiredRepository;
        private readonly ITokensRepository _tokensRepository;
        private readonly IMapper _mapper;

        public ConfigurableValuesController(IConfigurableValuesRepository configurableValuesRepository,
                                            IIdentityService identitySvc,
                                            IHttpContextAccessor httpContextAccessor,
                                            ITokenExpiredRepository tokenExpiredRepository,
                                            ITokensRepository tokensRepository,
                                            IMapper mapper) : base(identitySvc)

        {
            _configurableValuesRepository = configurableValuesRepository;
            _identitySvc = identitySvc;
            _httpContextAccessor = httpContextAccessor;
            _tokenExpiredRepository = tokenExpiredRepository;
            _tokensRepository = tokensRepository;
            _mapper = mapper;
        }

        [HttpGet("{id:int}")]
        public async Task<IActionResult> Get(int id)
        {
            ConfigurableValues configurableValues = await this._configurableValuesRepository.GetAsync(id);
            APIConfigurableValues apiConfigurableValues = _mapper.Map<APIConfigurableValues>(configurableValues);
            apiConfigurableValues.Code = configurableValues.ValueCode;
            apiConfigurableValues.Name = configurableValues.ValueName;
            return Ok(apiConfigurableValues);
        }

        [HttpGet]
        public async Task<IActionResult> GetConfigurableValues()
        {
            return Ok(await this._configurableValuesRepository.GetAllConfigurableValues());
        }

        [HttpGet("GetConfigurableValues/{typeCode}")]
        public async Task<IActionResult> GetConfigurableValuesByType(string typeCode)
        {
            return Ok(await this._configurableValuesRepository.GetConfigurableValues(typeCode));
        }

        [HttpGet("GetTypeName")]
        public async Task<IActionResult> GetTypeName()
        {
            try
            {
                return Ok(await this._configurableValuesRepository.GetTypeName());
            }
            catch (Exception ex)
            {
                return BadRequest(new ResponseMessage { Message = EnumHelper.GetEnumName(MessageType.InternalServerError), Description = ex.StackTrace });
            }
        }
    }
}
