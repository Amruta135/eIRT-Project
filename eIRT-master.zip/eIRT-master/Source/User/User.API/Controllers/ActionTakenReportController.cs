﻿using AspNet.Security.OAuth.Introspection;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using AutoMapper;
using System;
using System.Threading.Tasks;
using User.API.APIModel;
using User.API.Helper;
using User.API.Models;
using User.API.Repositories.Interface;
using User.API.Services;
using static User.API.Validation.TokenValidation;
using System.Collections.Generic;
using MediatR;
using Newtonsoft.Json.Linq;
using User.API.MediatR.Command;

namespace User.API.Controllers
{
    [ApiVersion("1.0")]
    [Route("user/api/v{version:apiVersion}/[controller]")]
    [ApiController]
    [Authorize(AuthenticationSchemes = OAuthIntrospectionDefaults.AuthenticationScheme)]
    [Authorize]
    [TokenValid]
    public class ActionTakenReportController : IdentityController
    {
        private readonly IActionTakenReportRepository _actionTakenReportRepository;
        private readonly IIdentityService _identitySvc;
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly IMapper _mapper;
        private readonly IIncidentReportRepository _incidentReportRepository;
        private readonly IUserMasterRepository _userMasterRepository;
        private readonly IMediator _mediator;
        public ActionTakenReportController(IActionTakenReportRepository actionTakenReportRepository,
                                           IMapper mapper,
                                           IIdentityService identitySvc,
                                           IHttpContextAccessor httpContextAccessor,
                                           IIncidentReportRepository incidentReportRepository,
                                            IUserMasterRepository userMasterRepository,
                                            IMediator mediator) : base(identitySvc)

        {
            _actionTakenReportRepository = actionTakenReportRepository;
            _identitySvc = identitySvc;
            _httpContextAccessor = httpContextAccessor;
            _mapper = mapper;
            _incidentReportRepository = incidentReportRepository;
            _userMasterRepository = userMasterRepository;
            _mediator = mediator;
        }


        [HttpPost("Get")]
        public async Task<IActionResult> Get(APIId apiId)
        {
            ActionTakenReport actionTakenReport = await this._actionTakenReportRepository.GetAsync(apiId.Id);

            if (actionTakenReport != null)
                return this.Ok(actionTakenReport);
            else
                return this.BadRequest(new ResponseMessage { Message = EnumHelper.GetEnumName(MessageType.NotFound), Description = "" });
        }

        [HttpPost("GetActionTakenReports")]
        public async Task<IActionResult> GetActionTakenReports(APISearchActionTeken SearchInfo)
        {
            try
            {
                SearchInfo.page = SearchInfo.page == 0 ? 1 : SearchInfo.page;
                SearchInfo.pageSize = SearchInfo.pageSize == 0 ? 10 : SearchInfo.pageSize;
                List<APIActionTakenReport> apiActionTakenReports = await this._actionTakenReportRepository.GetActionTakenReports(_loggedInUserDBId, _loggedInUserOrganizationCode, SearchInfo.IncidentId,_userRole, SearchInfo.page, SearchInfo.pageSize, SearchInfo.filter, SearchInfo.search);

                int count = await this._actionTakenReportRepository.GetActionTakenReportsCount(_loggedInUserDBId, _loggedInUserOrganizationCode, SearchInfo.IncidentId, _userRole, SearchInfo.filter, SearchInfo.search);

                return Ok(new { apiActionTakenReports, count });
            }
            catch (Exception)
            {
                return BadRequest(new ResponseMessage { Message = EnumHelper.GetEnumName(MessageType.InternalServerError), Description = EnumHelper.GetEnumDescription(MessageType.InternalServerError) });
            }
        }

        [HttpPost("Post")]
        public async Task<IActionResult> Post([FromBody] APIActionTakenReport apiActionTakenReport)
        {
            try
            {
                if (!ModelState.IsValid)
                    return this.BadRequest(this.ModelState);

                ActionTakenReport actionTakenReport = new ActionTakenReport();
                actionTakenReport = _mapper.Map<ActionTakenReport>(apiActionTakenReport);
                actionTakenReport.OrganizationCode = _loggedInUserOrganizationCode;
                actionTakenReport.CreatedDate = DateTime.Now;
                actionTakenReport.ModifiedDate = DateTime.Now;
                actionTakenReport.CreatedBy = _loggedInUserDBId;
                actionTakenReport.ModifiedBy = _loggedInUserDBId;

                ActionTakenReport newActionTakenReport = await this._actionTakenReportRepository.AddAndReturnEntityAsync(actionTakenReport);

                IncidentReport existingincidentReport = await this._incidentReportRepository.GetAsync(newActionTakenReport.ReferenceIncidentId);
                existingincidentReport.ModifiedBy = _loggedInUserDBId;
                existingincidentReport.ModifiedDate = DateTime.Now;
                existingincidentReport.Status = newActionTakenReport.IncidentStatus;
                if (newActionTakenReport.IncidentStatus.Equals(Helper.IncidentReportingStatus.Closed))
                {
                    TimeSpan span = DateTime.Now.Date.Subtract(existingincidentReport.CreatedDate.Date);
                    existingincidentReport.ClosurePeriod = span.Days;
                }
                await this._incidentReportRepository.UpdateAsync(existingincidentReport);

                if (newActionTakenReport != null)
                {
                    APIUserProfile incidentReportedUser = await this._userMasterRepository.GetDetailsById(_loggedInUserOrganizationCode, _userRole, existingincidentReport.CreatedBy);

                    APIUserProfile userProfile = await this._userMasterRepository.GetDetailsById(_loggedInUserOrganizationCode, _userRole, newActionTakenReport.CreatedBy);

                    JObject ActionTakenReport = new JObject();
                    ActionTakenReport.Add("UserName", incidentReportedUser.Name);
                    ActionTakenReport.Add("ActingUserName", userProfile.Name);
                    ActionTakenReport.Add("ATRStatus", newActionTakenReport.IncidentStatus);
                    ActionTakenReport.Add("IncidentID", existingincidentReport.Id.ToString());

                    ActionTakenReport.Add("UserId", userProfile.Id);
                    ActionTakenReport.Add("MobileNumber", userProfile.MobileNumber);

                    var command = new SendNewATRAddedCommand(ActionTakenReport);
                    //dont add await, as it works as background task
                    _mediator.Send(command);
                }

                return Ok(newActionTakenReport);

            }
            catch (System.Exception ex)
            {
                return this.BadRequest(new ResponseMessage { Message = EnumHelper.GetEnumName(MessageType.InternalServerError), Description = ex.StackTrace });
            }
        }

        [HttpPut("Put/{id}")]
        public async Task<IActionResult> Put(int Id, [FromBody] APIActionTakenReport apiActionTakenReport)
        {
            try
            {
                if (!ModelState.IsValid)
                    return this.BadRequest(this.ModelState);

                ActionTakenReport existingActionTakenReport = await _actionTakenReportRepository.GetAsync(Id);

                if (existingActionTakenReport == null)
                    return this.BadRequest(new ResponseMessage { Message = EnumHelper.GetEnumName(MessageType.NotExist), Description = "" });

                var createdBy = existingActionTakenReport.CreatedBy;
                var createdDate = existingActionTakenReport.CreatedDate;
                string orgCode = existingActionTakenReport.OrganizationCode;

                existingActionTakenReport = _mapper.Map<ActionTakenReport>(apiActionTakenReport);
                existingActionTakenReport.Id = Id;
                existingActionTakenReport.ModifiedDate = DateTime.Now;
                existingActionTakenReport.ModifiedBy = _loggedInUserDBId;
                existingActionTakenReport.OrganizationCode = orgCode;

                await this._actionTakenReportRepository.UpdateAsync(existingActionTakenReport);

                IncidentReport existingincidentReport = await this._incidentReportRepository.GetAsync(existingActionTakenReport.ReferenceIncidentId);
                existingincidentReport.ModifiedBy = _loggedInUserDBId;
                existingincidentReport.ModifiedDate = DateTime.Now;
                existingincidentReport.Status = existingActionTakenReport.IncidentStatus;

                await this._incidentReportRepository.UpdateAsync(existingincidentReport);

                return Ok(apiActionTakenReport);
            }
            catch (System.Exception ex)
            {
                return this.BadRequest(new ResponseMessage { Message = EnumHelper.GetEnumName(MessageType.InternalServerError), Description = ex.StackTrace });
            }
        }

    }
}

