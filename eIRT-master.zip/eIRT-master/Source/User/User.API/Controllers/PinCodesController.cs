﻿using AspNet.Security.OAuth.Introspection;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;
using User.API.Repositories.Interface;
using User.API.Services;
using static User.API.Validation.TokenValidation;

namespace User.API.Controllers
{
    [ApiVersion("1.0")]
    [Route("user/api/v{version:apiVersion}/[controller]")]
    [ApiController]
    [Authorize(AuthenticationSchemes = OAuthIntrospectionDefaults.AuthenticationScheme)]
    [Authorize]
    [TokenValid]
    public class PinCodesController : IdentityController
    {
        private readonly IPinCodesRepository _pinCodesRepository;
        private readonly IIdentityService _identitySvc;
        private readonly IHttpContextAccessor _httpContextAccessor;
        public PinCodesController(IPinCodesRepository pinCodesRepository,
                                IIdentityService identitySvc,
                                IHttpContextAccessor httpContextAccessor) : base(identitySvc)

        {
            _pinCodesRepository = pinCodesRepository;
            _identitySvc = identitySvc;
            _httpContextAccessor = httpContextAccessor;
        }

        [HttpGet("{pincode:int}")]
        [AllowAnonymous]
        public async Task<IActionResult> GetPinCode(int pincode)
        {
            return Ok(await this._pinCodesRepository.GetPinCodeDetails(pincode));
        }
    }
}
