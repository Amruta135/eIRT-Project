﻿using AspNet.Security.OAuth.Introspection;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;
using User.API.Repositories.Interface;
using User.API.Services;
using static User.API.Validation.TokenValidation;

namespace User.API.Controllers
{
    [ApiVersion("1.0")]
    [Route("user/api/v{version:apiVersion}/[controller]")]
    [ApiController]
    [Authorize(AuthenticationSchemes = OAuthIntrospectionDefaults.AuthenticationScheme)]
    [Authorize]
    [TokenValid]
    public class StatesController : IdentityController
    {
        private readonly IStatesRepository _statesRepository;
        private readonly IIdentityService _identitySvc;
        private readonly IHttpContextAccessor _httpContextAccessor;
        public StatesController(IStatesRepository statesRepository,
                                IIdentityService identitySvc,
                                IHttpContextAccessor httpContextAccessor) : base(identitySvc)

        {
            _statesRepository = statesRepository;
            _identitySvc = identitySvc;
            _httpContextAccessor = httpContextAccessor;
        }

        [HttpGet("GetStates")]
        public async Task<IActionResult> GetStates()
        {
            return Ok(await this._statesRepository.GetStates());
        }
    }
}
