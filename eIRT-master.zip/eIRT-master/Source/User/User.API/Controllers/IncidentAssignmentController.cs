﻿using AspNet.Security.OAuth.Introspection;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using AutoMapper;
using System;
using System.Threading.Tasks;
using User.API.APIModel;
using User.API.Helper;
using User.API.Models;
using User.API.Repositories.Interface;
using User.API.Services;
using static User.API.Validation.TokenValidation;
using System.Collections.Generic;
using MediatR;
using Newtonsoft.Json.Linq;
using User.API.MediatR.Command;
using System.Linq;

namespace User.API.Controllers
{
    [ApiVersion("1.0")]
    [Route("user/api/v{version:apiVersion}/[controller]")]
    [ApiController]
    [Authorize(AuthenticationSchemes = OAuthIntrospectionDefaults.AuthenticationScheme)]
    [Authorize]
    [TokenValid]
    public class IncidentAssignmentController : IdentityController
    {
        private readonly IIncidentAssignmentRepository _incidentAssignmentRepository;
        private readonly IIdentityService _identitySvc;
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly IMapper _mapper;
        private readonly IIncidentReportRepository _incidentReportRepository;
        private readonly IUserMasterRepository _userMasterRepository;
        private readonly IMediator _mediator;
        private readonly ICompetencyRepository _competencyRepository;
        public IncidentAssignmentController(IIncidentAssignmentRepository incidentAssignmentRepository,
                                            IMapper mapper,
                                            IIdentityService identitySvc,
                                            IHttpContextAccessor httpContextAccessor,
                                            IIncidentReportRepository incidentReportRepository,
                                            IUserMasterRepository userMasterRepository,
                                            IMediator mediator,
                                            ICompetencyRepository competencyRepository) : base(identitySvc)

        {
            _incidentAssignmentRepository = incidentAssignmentRepository;
            _identitySvc = identitySvc;
            _httpContextAccessor = httpContextAccessor;
            _mapper = mapper;
            _incidentReportRepository = incidentReportRepository;
            _userMasterRepository = userMasterRepository;
            _mediator = mediator;
            _competencyRepository = competencyRepository;
        }


        [HttpPost("Get")]
        public async Task<IActionResult> Get(APIId apiId)
        {
            APIIncidentAssignment incidentAssignment = await this._incidentAssignmentRepository.GetIncidentAssignment(_loggedInUserOrganizationCode, apiId.Id);

            if (incidentAssignment != null)
                return this.Ok(incidentAssignment);
            else
                return this.BadRequest(new ResponseMessage { Message = EnumHelper.GetEnumName(MessageType.NotFound), Description = "" });
        }

        [HttpPost("GetIncidentAssignments")]
        public async Task<IActionResult> GetIncidentAssignments(APISearchIncidentAssignment SearchInfo)
        {
            try
            {
                List<APIIncidentAssignment> apiIncidentAssignments = await this._incidentAssignmentRepository.GetIncidentAssignments(_loggedInUserOrganizationCode, SearchInfo.IncidentId, SearchInfo.page, SearchInfo.pageSize, SearchInfo.filter, SearchInfo.search);

                if (apiIncidentAssignments != null && apiIncidentAssignments.Count() > 0 && apiIncidentAssignments.Where(x => string.IsNullOrWhiteSpace(x.CompetencyIds)).Any())
                {
                    foreach (APIIncidentAssignment incidentAssignment in apiIncidentAssignments.Where(x => string.IsNullOrWhiteSpace(x.CompetencyIds)))
                    {
                        incidentAssignment.Competencies = new List<APICompetency>();
                        incidentAssignment.Competencies.AddRange(await _competencyRepository.GetCompetenciesAssignedToIncedent(_loggedInUserOrganizationCode, incidentAssignment.ReferenceIncidentId));
                    }
                }

                int count = await this._incidentAssignmentRepository.GetIncidentAssignmentsCount(_loggedInUserOrganizationCode, SearchInfo.IncidentId, SearchInfo.filter, SearchInfo.search);
                return Ok(new { apiIncidentAssignments, count });
            }
            catch (Exception)
            {
                return BadRequest(new ResponseMessage { Message = EnumHelper.GetEnumName(MessageType.InternalServerError), Description = EnumHelper.GetEnumDescription(MessageType.InternalServerError) });
            }
        }

        [HttpPost("GetIncidentAssignmentsCount")]
        public async Task<IActionResult> GetIncidentAssignmentsCount(APISearchIncidentAssignment SearchInfo)
        {
            try
            {
                return Ok(await this._incidentAssignmentRepository.GetIncidentAssignmentsCount(_loggedInUserOrganizationCode, SearchInfo.IncidentId, SearchInfo.filter, SearchInfo.search));
            }
            catch (Exception)
            {
                return BadRequest(new ResponseMessage { Message = EnumHelper.GetEnumName(MessageType.InternalServerError), Description = EnumHelper.GetEnumDescription(MessageType.InternalServerError) });
            }
        }

        [HttpPost("Post")]
        public async Task<IActionResult> Post([FromBody] APIIncidentAssignment apiIncidentAssignment)
        {
            try
            {
                if (!ModelState.IsValid)
                    return this.BadRequest(this.ModelState);

                IncidentAssignment incidentAssignment = new IncidentAssignment();
                incidentAssignment = _mapper.Map<IncidentAssignment>(apiIncidentAssignment);
                incidentAssignment.OrganizationCode = _loggedInUserOrganizationCode;
                incidentAssignment.CreatedDate = DateTime.Now;
                incidentAssignment.ModifiedDate = DateTime.Now;
                incidentAssignment.CreatedBy = _loggedInUserDBId;
                incidentAssignment.ModifiedBy = _loggedInUserDBId;
                incidentAssignment.AssignedDate = DateTime.Now;

                IncidentAssignment newIncidentAssignment = await this._incidentAssignmentRepository.AddAndReturnEntityAsync(incidentAssignment);

                IncidentReport existingincidentReport = await this._incidentReportRepository.GetAsync(newIncidentAssignment.ReferenceIncidentId);
                existingincidentReport.ModifiedBy = _loggedInUserDBId;
                existingincidentReport.ModifiedDate = DateTime.Now;
                existingincidentReport.IsAssigned = true;
                existingincidentReport.CompetencyIds = apiIncidentAssignment.CompetencyIds;
                existingincidentReport.ClosureDate = apiIncidentAssignment.ClosureDate;
                await this._incidentReportRepository.UpdateAsync(existingincidentReport);

                if(newIncidentAssignment!=null)
                {
                    APIUser user = await this._userMasterRepository.GetUserDetails(_loggedInUserOrganizationCode);

                    APIUserProfile incidentReportedUser= await this._userMasterRepository.GetDetailsById(_loggedInUserOrganizationCode, _userRole, existingincidentReport.CreatedBy);

                    APIUserProfile userProfile = new APIUserProfile();
                    if(newIncidentAssignment.PrimaryAssignToId>0)
                    {
                        userProfile = await this._userMasterRepository.GetDetailsById(_loggedInUserOrganizationCode, _userRole, newIncidentAssignment.PrimaryAssignToId);

                        JObject IncidentAssignment = new JObject();
                        IncidentAssignment.Add("UserName", userProfile.Name);
                        IncidentAssignment.Add("ClientAdmin", user.Name);
                        IncidentAssignment.Add("IncidentReportedUserName", incidentReportedUser.Name);
                        IncidentAssignment.Add("IncidentID", existingincidentReport.Id.ToString());

                        IncidentAssignment.Add("UserId", userProfile.Id);
                        IncidentAssignment.Add("MobileNumber", userProfile.MobileNumber);

                        var command = new SendIncidentAssignedCommand(IncidentAssignment);
                        //dont add await, as it works as background task
                        _mediator.Send(command);
                    }

                    if (newIncidentAssignment.SecondaryAssignToId > 0)
                    {
                        userProfile = await this._userMasterRepository.GetDetailsById(_loggedInUserOrganizationCode, _userRole, newIncidentAssignment.SecondaryAssignToId);

                        JObject IncidentAssignment = new JObject();
                        IncidentAssignment.Add("UserName", userProfile.Name);
                        IncidentAssignment.Add("ClientAdmin", user.Name);
                        IncidentAssignment.Add("IncidentReportedUserName", incidentReportedUser.Name);
                        IncidentAssignment.Add("IncidentID", existingincidentReport.Id.ToString());

                        IncidentAssignment.Add("UserId", userProfile.Id);
                        IncidentAssignment.Add("MobileNumber", userProfile.MobileNumber);

                        var command = new SendIncidentAssignedCommand(IncidentAssignment);
                        //dont add await, as it works as background task
                        _mediator.Send(command);
                    }
                }

                return Ok(newIncidentAssignment);
            }
            catch (System.Exception ex)
            {
                return this.BadRequest(new ResponseMessage { Message = EnumHelper.GetEnumName(MessageType.InternalServerError), Description = ex.StackTrace });
            }
        }
        [HttpPut("{id}")]
        public async Task<IActionResult> Put(int Id, [FromBody] APIIncidentAssignment apiIncidentAssignment)
        {
            try
            {
                if (!ModelState.IsValid)
                    return this.BadRequest(this.ModelState);

                IncidentAssignment existingIncidentAssignment = await _incidentAssignmentRepository.GetAsync(Id);

                if (existingIncidentAssignment == null)
                    return this.BadRequest(new ResponseMessage { Message = EnumHelper.GetEnumName(MessageType.NotExist), Description = "" });

                var createdBy = existingIncidentAssignment.CreatedBy;
                var createdDate = existingIncidentAssignment.CreatedDate;
                var OrganizationCode = existingIncidentAssignment.OrganizationCode;
                var assignedDate = existingIncidentAssignment.AssignedDate;

                existingIncidentAssignment = _mapper.Map<IncidentAssignment>(apiIncidentAssignment);
                existingIncidentAssignment.Id = Id;
                existingIncidentAssignment.CreatedBy = createdBy;
                existingIncidentAssignment.CreatedDate = createdDate;
                existingIncidentAssignment.ModifiedDate = DateTime.Now;
                existingIncidentAssignment.ModifiedBy = _loggedInUserDBId;
                existingIncidentAssignment.OrganizationCode = OrganizationCode;
                existingIncidentAssignment.AssignedDate = assignedDate;

                await this._incidentAssignmentRepository.UpdateAsync(existingIncidentAssignment);
                if(!string.IsNullOrWhiteSpace(apiIncidentAssignment.CompetencyIds))
                {
                    IncidentReport existingincidentReport = await this._incidentReportRepository.GetAsync(apiIncidentAssignment.ReferenceIncidentId);
                    existingincidentReport.ModifiedBy = _loggedInUserDBId;
                    existingincidentReport.ModifiedDate = DateTime.Now;
                    existingincidentReport.CompetencyIds = apiIncidentAssignment.CompetencyIds;
                    existingincidentReport.ClosureDate = apiIncidentAssignment.ClosureDate;
                    await this._incidentReportRepository.UpdateAsync(existingincidentReport);
                }
                return Ok(apiIncidentAssignment);
            }
            catch (System.Exception ex)
            {
                return this.BadRequest(new ResponseMessage { Message = EnumHelper.GetEnumName(MessageType.InternalServerError), Description = ex.StackTrace });
            }
        }

        [HttpPost("GetIncidentsForActionTaken")]
        public async Task<IActionResult> GetIncidentsForActionTaken(APISearchInfo apiSearchInfo)
        {
            try
            {
                List<APIIncidentReport> apiIncidentReports = await this._incidentAssignmentRepository.GetIncidentsForActionTaken(_loggedInUserOrganizationCode, _loggedInUserDBId, apiSearchInfo.page, apiSearchInfo.pageSize, apiSearchInfo.filter, apiSearchInfo.search);

                return Ok(apiIncidentReports);
            }
            catch (Exception)
            {
                return BadRequest(new ResponseMessage { Message = EnumHelper.GetEnumName(MessageType.InternalServerError), Description = EnumHelper.GetEnumDescription(MessageType.InternalServerError) });
            }
        }

    }
}
