﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace User.API.Migrations
{
    public partial class Department_IncidentCategoryV2 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "CreatedBy",
                schema: "User",
                table: "IncidentCategory",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<DateTime>(
                name: "CreatedDate",
                schema: "User",
                table: "IncidentCategory",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.AddColumn<bool>(
                name: "IsDeleted",
                schema: "User",
                table: "IncidentCategory",
                nullable: false,
                defaultValue: false);

            migrationBuilder.AddColumn<int>(
                name: "ModifiedBy",
                schema: "User",
                table: "IncidentCategory",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<DateTime>(
                name: "ModifiedDate",
                schema: "User",
                table: "IncidentCategory",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.AddColumn<int>(
                name: "CreatedBy",
                schema: "User",
                table: "Department",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<DateTime>(
                name: "CreatedDate",
                schema: "User",
                table: "Department",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.AddColumn<bool>(
                name: "IsDeleted",
                schema: "User",
                table: "Department",
                nullable: false,
                defaultValue: false);

            migrationBuilder.AddColumn<int>(
                name: "ModifiedBy",
                schema: "User",
                table: "Department",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<DateTime>(
                name: "ModifiedDate",
                schema: "User",
                table: "Department",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "CreatedBy",
                schema: "User",
                table: "IncidentCategory");

            migrationBuilder.DropColumn(
                name: "CreatedDate",
                schema: "User",
                table: "IncidentCategory");

            migrationBuilder.DropColumn(
                name: "IsDeleted",
                schema: "User",
                table: "IncidentCategory");

            migrationBuilder.DropColumn(
                name: "ModifiedBy",
                schema: "User",
                table: "IncidentCategory");

            migrationBuilder.DropColumn(
                name: "ModifiedDate",
                schema: "User",
                table: "IncidentCategory");

            migrationBuilder.DropColumn(
                name: "CreatedBy",
                schema: "User",
                table: "Department");

            migrationBuilder.DropColumn(
                name: "CreatedDate",
                schema: "User",
                table: "Department");

            migrationBuilder.DropColumn(
                name: "IsDeleted",
                schema: "User",
                table: "Department");

            migrationBuilder.DropColumn(
                name: "ModifiedBy",
                schema: "User",
                table: "Department");

            migrationBuilder.DropColumn(
                name: "ModifiedDate",
                schema: "User",
                table: "Department");
        }
    }
}
