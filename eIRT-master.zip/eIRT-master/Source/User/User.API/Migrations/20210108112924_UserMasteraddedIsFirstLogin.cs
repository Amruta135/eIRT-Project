﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace User.API.Migrations
{
    public partial class UserMasteraddedIsFirstLogin : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<bool>(
                name: "IsFirstLogin",
                schema: "User",
                table: "UserMaster",
                nullable: false,
                defaultValue: false);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "IsFirstLogin",
                schema: "User",
                table: "UserMaster");
        }
    }
}
