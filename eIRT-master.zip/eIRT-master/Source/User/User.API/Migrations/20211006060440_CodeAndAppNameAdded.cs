﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace User.API.Migrations
{
    public partial class CodeAndAppNameAdded : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "AppName",
                schema: "User",
                table: "OrganizationInfo",
                maxLength: 100,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "Code",
                schema: "User",
                table: "Department",
                maxLength: 50,
                nullable: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "AppName",
                schema: "User",
                table: "OrganizationInfo");

            migrationBuilder.DropColumn(
                name: "Code",
                schema: "User",
                table: "Department");
        }
    }
}
