﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace User.API.Migrations
{
    public partial class CompetencyTableAdded : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "CompetencyIds",
                schema: "User",
                table: "UserMaster",
                nullable: true);

            migrationBuilder.AddColumn<DateTime>(
                name: "ClosureDate",
                schema: "User",
                table: "IncidentReport",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.AddColumn<string>(
                name: "CompetencyIds",
                schema: "User",
                table: "IncidentReport",
                nullable: true);

            migrationBuilder.CreateTable(
                name: "Competency",
                schema: "User",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    CreatedBy = table.Column<int>(nullable: false),
                    CreatedDate = table.Column<DateTime>(nullable: false),
                    ModifiedBy = table.Column<int>(nullable: false),
                    ModifiedDate = table.Column<DateTime>(nullable: false),
                    IsDeleted = table.Column<bool>(nullable: false),
                    OrganizationCode = table.Column<string>(maxLength: 7, nullable: false),
                    CompetencyDescription = table.Column<string>(maxLength: 100, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Competency", x => x.Id);
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Competency",
                schema: "User");

            migrationBuilder.DropColumn(
                name: "CompetencyIds",
                schema: "User",
                table: "UserMaster");

            migrationBuilder.DropColumn(
                name: "ClosureDate",
                schema: "User",
                table: "IncidentReport");

            migrationBuilder.DropColumn(
                name: "CompetencyIds",
                schema: "User",
                table: "IncidentReport");
        }
    }
}
