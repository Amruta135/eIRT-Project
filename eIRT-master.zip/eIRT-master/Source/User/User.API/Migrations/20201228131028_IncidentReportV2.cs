﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace User.API.Migrations
{
    public partial class IncidentReportV2 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Category",
                schema: "User",
                table: "IncidentReport");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "Category",
                schema: "User",
                table: "IncidentReport",
                type: "nvarchar(100)",
                maxLength: 100,
                nullable: true);
        }
    }
}
