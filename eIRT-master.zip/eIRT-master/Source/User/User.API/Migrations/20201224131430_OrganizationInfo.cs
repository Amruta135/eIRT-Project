﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace User.API.Migrations
{
    public partial class OrganizationInfo : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "OrganizationInfo",
                schema: "User",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    CreatedBy = table.Column<int>(nullable: false),
                    CreatedDate = table.Column<DateTime>(nullable: false),
                    ModifiedBy = table.Column<int>(nullable: false),
                    ModifiedDate = table.Column<DateTime>(nullable: false),
                    IsDeleted = table.Column<bool>(nullable: false),
                    OrganizationCode = table.Column<string>(maxLength: 7, nullable: true),
                    OrganizationName = table.Column<string>(nullable: false),
                    Address = table.Column<string>(maxLength: 200, nullable: false),
                    Pincode = table.Column<string>(maxLength: 6, nullable: false),
                    City = table.Column<string>(maxLength: 100, nullable: true),
                    State = table.Column<string>(maxLength: 100, nullable: true),
                    MobileNumber = table.Column<string>(maxLength: 10, nullable: false),
                    Website = table.Column<string>(maxLength: 100, nullable: true),
                    DeliveryModel = table.Column<string>(maxLength: 100, nullable: true),
                    DomainName = table.Column<string>(maxLength: 100, nullable: false),
                    WorkflowOption = table.Column<string>(maxLength: 100, nullable: false),
                    NoofUsers = table.Column<int>(maxLength: 9999, nullable: false),
                    AccountValidityDate = table.Column<DateTime>(nullable: false),
                    Logo = table.Column<string>(maxLength: 200, nullable: true),
                    RGBCode = table.Column<string>(maxLength: 50, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_OrganizationInfo", x => x.Id);
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "OrganizationInfo",
                schema: "User");
        }
    }
}
