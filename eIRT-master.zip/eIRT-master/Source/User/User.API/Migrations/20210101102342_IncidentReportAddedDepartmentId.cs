﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace User.API.Migrations
{
    public partial class IncidentReportAddedDepartmentId : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "LinkedToDepartment",
                schema: "User",
                table: "IncidentReport");

            migrationBuilder.AddColumn<int>(
                name: "LinkedToDepartmentId",
                schema: "User",
                table: "IncidentReport",
                nullable: false,
                defaultValue: 0);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "LinkedToDepartmentId",
                schema: "User",
                table: "IncidentReport");

            migrationBuilder.AddColumn<string>(
                name: "LinkedToDepartment",
                schema: "User",
                table: "IncidentReport",
                type: "nvarchar(max)",
                nullable: true);
        }
    }
}
