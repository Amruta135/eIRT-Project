﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace User.API.Migrations
{
    public partial class SqcurutyQuestionTable : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "SecurityAnswer",
                schema: "User",
                table: "UserMaster",
                maxLength: 100,
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "SecurityQuestionId",
                schema: "User",
                table: "UserMaster",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.CreateTable(
                name: "SecurityQuestion",
                schema: "User",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Question = table.Column<string>(maxLength: 200, nullable: false),
                    Status = table.Column<string>(nullable: true),
                    CreatedDate = table.Column<DateTime>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_SecurityQuestion", x => x.Id);
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "SecurityQuestion",
                schema: "User");

            migrationBuilder.DropColumn(
                name: "SecurityAnswer",
                schema: "User",
                table: "UserMaster");

            migrationBuilder.DropColumn(
                name: "SecurityQuestionId",
                schema: "User",
                table: "UserMaster");
        }
    }
}
