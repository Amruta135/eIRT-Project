﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace User.API.Migrations
{
    public partial class OrgBaseLocationAndGeoFencingDistAdded : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "BaseLocation",
                schema: "User",
                table: "OrganizationInfo",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "GeoFencingDistance",
                schema: "User",
                table: "OrganizationInfo",
                nullable: false,
                defaultValue: 0);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "BaseLocation",
                schema: "User",
                table: "OrganizationInfo");

            migrationBuilder.DropColumn(
                name: "GeoFencingDistance",
                schema: "User",
                table: "OrganizationInfo");
        }
    }
}
