﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace User.API.Migrations
{
    public partial class NoofUsers : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AlterColumn<string>(
                name: "NoofUsers",
                schema: "User",
                table: "OrganizationInfo",
                nullable: false,
                oldClrType: typeof(int),
                oldType: "int",
                oldMaxLength: 9999);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AlterColumn<int>(
                name: "NoofUsers",
                schema: "User",
                table: "OrganizationInfo",
                type: "int",
                maxLength: 9999,
                nullable: false,
                oldClrType: typeof(string));
        }
    }
}
