﻿using OfficeOpenXml;
using OfficeOpenXml.Style;
using System.Collections.Generic;
using System.IO;
using User.API.APIModel;

namespace User.API.Common
{
    public partial class ExportManager<T> : IExportManager<T> where T : class
    {
        public ExportManager()
        {

        }

        public virtual byte[] ExportToXlsx(PropertyByName<T>[] properties, IEnumerable<T> itemsToExport, string worksheetName=null)
        {
            using (var stream = new MemoryStream())
            {
                using (var xlPackage = new ExcelPackage(stream))
                {
                    var worksheet = worksheetName == null ? xlPackage.Workbook.Worksheets.Add(typeof(T).Name) : xlPackage.Workbook.Worksheets.Add(worksheetName);

                    var manager = new PropertyManager<T>(properties);
                    manager.WriteCaption(worksheet, SetCaptionStyle);

                    var row = 2;
                    foreach (var items in itemsToExport)
                    {
                        manager.CurrentObject = items;
                        manager.WriteToXlsx(worksheet, row++);
                    }

                    xlPackage.Save();
                }
                return stream.ToArray();
            }
        }

        public virtual byte[] ExportToXlsx(PropertyByName<T>[] properties, IEnumerable<T> itemsToExport, IEnumerable<APIHeaderForExport> itemheader, PropertyByName<APIHeaderForExport>[] headerProperties)
        {
            using (var stream = new MemoryStream())
            {
                using (var xlPackage = new ExcelPackage(stream))
                {
                    var worksheet = xlPackage.Workbook.Worksheets.Add("Data");
                    var manager = new PropertyManager<T>(properties);
                    var managerHeader = new PropertyManager<APIHeaderForExport>(headerProperties);
                    var row = 2;

                    foreach (var items in itemheader)
                    {
                        managerHeader.CurrentObject = items;
                        managerHeader.WriteToXlsx(worksheet, row++);
                    }
                    row++;
                    manager.WriteCaptionWithHeader(row++, worksheet, SetCaptionStyle);

                    foreach (var items in itemsToExport)
                    {
                        manager.CurrentObject = items;
                        manager.WriteToXlsx(worksheet, row++);
                    }

                    xlPackage.Save();
                }
                return stream.ToArray();
            }
        }
        private void SetCaptionStyle(ExcelStyle style)
        {
            style.Fill.PatternType = ExcelFillStyle.Solid;
            style.Fill.BackgroundColor.SetColor(System.Drawing.Color.FromArgb(184, 204, 228));
            style.Font.Bold = true;
        }

    }
}
