﻿using System.Collections.Generic;
using User.API.APIModel;

namespace User.API.Common
{
    public interface IExportManager<T> where T : class
    {
        byte[] ExportToXlsx(PropertyByName<T>[] properties, IEnumerable<T> itemsToExport, string worksheetName = null);

        byte[] ExportToXlsx(PropertyByName<T>[] properties, IEnumerable<T> itemsToExport, IEnumerable<APIHeaderForExport> itemHeader, PropertyByName<APIHeaderForExport>[] headerProperties);
    }
}
