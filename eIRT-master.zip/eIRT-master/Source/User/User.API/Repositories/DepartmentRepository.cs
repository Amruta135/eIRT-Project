﻿using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using User.API.APIModel;
using User.API.Data;
using User.API.Models;
using User.API.Repositories.Interface;

namespace User.API.Repositories
{
    public class DepartmentRepository : Repository<Department>, IDepartmentRepository
    {
        private UserDbContext _db;

        public DepartmentRepository(UserDbContext context) : base(context)
        {
            _db = context;
        }

        public async Task<List<APIDepartments>> GetDepartmentByOrganization(string OrganizationCode)
        {
            IQueryable<APIDepartments> Query = (from d in _db.Department
                                                where (d.IsDeleted == false && d.OrganizationCode == OrganizationCode)
                                                select new APIDepartments
                                                {
                                                    Id = d.Id,
                                                    Name = d.Name,
                                                    Code = d.Code
                                                });

            return await Query.ToListAsync();
        }

        public async Task<List<APIDepartments>> GetDepartments(string loggedInUserOrganizationCode, int page, int pageSize, string filter = null, string search = null)
        {
            IQueryable<APIDepartments> Query = (from d in _db.Department
                                                where (d.IsDeleted == false && d.OrganizationCode == loggedInUserOrganizationCode)
                                                select new APIDepartments
                                                {
                                                    Id = d.Id,
                                                    Name = d.Name,
                                                    Code = d.Code
                                                }).OrderByDescending(a=>a.Id);

            if (page != -1)
                Query = Query.Skip((page - 1) * pageSize);
            if (pageSize != -1)
                Query = Query.Take(pageSize);

            return await Query.ToListAsync();

        }

        public async Task<int> GetDepartmentsCount(string loggedInUserOrganizationCode, string filter = null, string search = null)
        {
            return await (from d in _db.Department
                         where (d.IsDeleted == false && d.OrganizationCode == loggedInUserOrganizationCode)
                         select d.Id).CountAsync();
        }
    }
}