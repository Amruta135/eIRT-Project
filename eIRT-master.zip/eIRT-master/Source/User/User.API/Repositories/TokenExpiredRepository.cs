﻿using Microsoft.EntityFrameworkCore;
using System.Linq;
using System.Threading.Tasks;
using User.API.Data;
using User.API.Models;
using User.API.Repositories.Interface;

namespace User.API.Repositories
{
    public class TokenExpiredRepository : Repository<TokenExpired>, ITokenExpiredRepository
    {
        private UserDbContext _db;
        public TokenExpiredRepository(UserDbContext context) : base(context)
        {
            this._db = context;
        }
        public async Task<bool> TokenExists(string userToken)
        {
            return await this._db.TokenExpired.Where(s => s.Token == userToken).CountAsync() > 0;
        }
    }
}
