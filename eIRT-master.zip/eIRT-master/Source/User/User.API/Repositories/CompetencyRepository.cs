﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Caching.Memory;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using User.API.APIModel;
using User.API.Data;
using User.API.Helper;
using User.API.Models;
using User.API.Repositories.Interface;

namespace User.API.Repositories
{
    public class CompetencyRepository : Repository<Competency>,ICompetencyRepository
    {
        private UserDbContext _db;

        public CompetencyRepository(UserDbContext context) : base(context)
        {
            _db = context;
        }

        public async Task<APICompetency> GetCompetency(int id, string loggedInUserOrganizationCode)
        {
            return await (from C in _db.Competency.Where(x=>x.IsDeleted == false && x.OrganizationCode == loggedInUserOrganizationCode && x.Id == id)
                          join U in _db.UserMaster on C.CreatedBy equals U.Id         
                                select new APICompetency
                                {
                                    Id = C.Id,
                                    CompetencyDescription = C.CompetencyDescription,
                                    ModifiedDate = C.ModifiedDate,
                                    ModifiedBy = U.Name
                                }).FirstOrDefaultAsync();
        }

        public async Task<List<APICompetency>> GetCompetencies(string loggedInUserOrganizationCode, int page, int pageSize, string filter = null, string search = null)
        {
            IQueryable<APICompetency> Query = (from C in _db.Competency.Where(x => x.IsDeleted == false && x.OrganizationCode == loggedInUserOrganizationCode)
                                               join U in _db.UserMaster on C.CreatedBy equals U.Id
                                               select new APICompetency
                                               {
                                                   Id = C.Id,
                                                   CompetencyDescription = C.CompetencyDescription,
                                                   ModifiedDate = C.ModifiedDate,
                                                   ModifiedBy = U.Name
                                               });

            if (page != -1)
                Query = Query.Skip((page - 1) * pageSize);
            if (pageSize != -1)
                Query = Query.Take(pageSize);

            return await Query.ToListAsync();
        }

        public async Task<int> GetCompetenciesCount(string loggedInUserOrganizationCode, string filter = null, string search = null)
        {
            IQueryable<APICompetency> Query = (from C in _db.Competency.Where(x => x.IsDeleted == false && x.OrganizationCode == loggedInUserOrganizationCode)
                                               join U in _db.UserMaster on C.CreatedBy equals U.Id
                                               select new APICompetency
                                               {
                                                   Id = C.Id,
                                                   CompetencyDescription = C.CompetencyDescription,
                                                   ModifiedDate = C.ModifiedDate,
                                                   ModifiedBy = U.Name
                                               });
            return await Query.CountAsync();
        }

        public async Task<List<APICompetency>> GetCompetenciesAssignedToUser(string loggedInUserOrganizationCode, int userId)
        {
            List<APICompetency> competencies = new List<APICompetency>(); 
            var CompetencyIds = _db.UserMaster.Where(x => x.IsDeleted == false && x.Id == userId).Select(x => x.CompetencyIds).FirstOrDefault();
            if (!string.IsNullOrWhiteSpace(CompetencyIds))
            {
                string[] stringValues = CompetencyIds.Split(',');
                int[] intValues = Array.ConvertAll(stringValues, s => int.Parse(s));
                IQueryable<APICompetency> Query = (from C in _db.Competency.Where(x => x.IsDeleted == false && x.OrganizationCode == loggedInUserOrganizationCode && intValues.Contains(x.Id))
                                                   join U in _db.UserMaster on C.CreatedBy equals U.Id
                                                   select new APICompetency
                                                   {
                                                       Id = C.Id,
                                                       CompetencyDescription = C.CompetencyDescription,
                                                       ModifiedDate = C.ModifiedDate,
                                                       ModifiedBy = U.Name
                                                   });
                return await Query.ToListAsync();
            }
            else
                return competencies;
        }

        public async Task<List<APICompetency>> GetCompetenciesAssignedToIncedent(string loggedInUserOrganizationCode, int incidentId)
        {
            List<APICompetency> competencies = new List<APICompetency>();
            var CompetencyIds = _db.IncidentReport.Where(x => x.IsDeleted == false && x.Id == incidentId).Select(x => x.CompetencyIds).FirstOrDefault();
            if (!string.IsNullOrWhiteSpace(CompetencyIds))
            {
                string[] stringValues = CompetencyIds.Split(',');
                int[] intValues = Array.ConvertAll(stringValues, s => int.Parse(s));
                IQueryable<APICompetency> Query = (from C in _db.Competency.Where(x => x.IsDeleted == false && x.OrganizationCode == loggedInUserOrganizationCode && intValues.Contains(x.Id))
                                                   join U in _db.UserMaster on C.CreatedBy equals U.Id
                                                   select new APICompetency
                                                   {
                                                       Id = C.Id,
                                                       CompetencyDescription = C.CompetencyDescription,
                                                       ModifiedDate = C.ModifiedDate,
                                                       ModifiedBy = U.Name
                                                   });
                return await Query.ToListAsync();
            }
            else
                return competencies;
        }
    }
}
