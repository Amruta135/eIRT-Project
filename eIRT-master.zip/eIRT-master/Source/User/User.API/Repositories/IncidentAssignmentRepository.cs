﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using User.API.APIModel;
using User.API.Data;
using User.API.Models;
using User.API.Repositories.Interface;

namespace User.API.Repositories
{
    public class IncidentAssignmentRepository : Repository<IncidentAssignment>, IIncidentAssignmentRepository
    {
        private UserDbContext _db;
        private readonly ICompetencyRepository _competencyRepository;

        public IncidentAssignmentRepository(UserDbContext context, ICompetencyRepository competencyRepository) : base(context)
        {
            _db = context;
            _competencyRepository = competencyRepository;
        }

        public async Task<APIIncidentAssignment> GetIncidentAssignment(string loggedInUserOrganizationCode, int Id)
        {
            APIIncidentAssignment assignment = await (from i in _db.IncidentAssignment.Where(x => x.IsDeleted == false && x.Id == Id && x.OrganizationCode == loggedInUserOrganizationCode)
                                                       join irpt in _db.IncidentReport.Where(x => x.IsDeleted == false) on i.ReferenceIncidentId equals irpt.Id
                                                       join c in _db.IncidentCategory.Where(x => x.IsDeleted == false) on irpt.IncidentCategoryId equals c.Id
                                                       join u in _db.UserMaster on i.PrimaryAssignToId equals u.Id
                                                       join u2 in this._db.UserMaster on i.SecondaryAssignToId equals u2.Id into UserMasterTbl
                                                       from u2 in UserMasterTbl.DefaultIfEmpty()
                                                       where (i.IsDeleted == false && i.OrganizationCode == loggedInUserOrganizationCode)
                                                       select new APIIncidentAssignment
                                                       {
                                                           Id = i.Id,
                                                           Category = c.Category,
                                                           ReferenceIncidentId = i.ReferenceIncidentId,
                                                           ReferenceIncident = irpt.Description,
                                                           PrimaryAssignToId = i.PrimaryAssignToId,
                                                           PrimaryAssignToName = u.Name,
                                                           SecondaryAssignToId = i.SecondaryAssignToId,
                                                           SecondaryAssignToName = u2.Name,
                                                           AssignedDate = i.AssignedDate,
                                                           Remarks = i.Remarks,
                                                           CompetencyIds = irpt.CompetencyIds,
                                                           ClosureDate = irpt.ClosureDate
                                                       }).FirstOrDefaultAsync();
            if (!string.IsNullOrWhiteSpace(assignment.CompetencyIds))
            {
                assignment.Competencies = new List<APICompetency>();
                assignment.Competencies.AddRange(await _competencyRepository.GetCompetenciesAssignedToIncedent(loggedInUserOrganizationCode, assignment.ReferenceIncidentId));
            }
            return assignment;

        }

        public async Task<List<APIIncidentAssignment>> GetIncidentAssignments(string loggedInUserOrganizationCode, int incidentId, int page, int pageSize, string filter = null, string search = null)
        {
            IQueryable<APIIncidentAssignment> Query = (from i in _db.IncidentAssignment.Where(x=>x.IsDeleted == false && x.ReferenceIncidentId == (incidentId > 0 ? incidentId : x.ReferenceIncidentId))
                                                       join irpt in _db.IncidentReport.Where(x => x.IsDeleted == false) on i.ReferenceIncidentId equals irpt.Id
                                                       join c in _db.IncidentCategory.Where(x => x.IsDeleted == false) on irpt.IncidentCategoryId equals c.Id
                                                       join u in _db.UserMaster on i.PrimaryAssignToId equals u.Id
                                                       join u2 in this._db.UserMaster on i.SecondaryAssignToId equals u2.Id into UserMasterTbl
                                                       from u2 in UserMasterTbl.DefaultIfEmpty()
                                                       where (i.IsDeleted == false && i.OrganizationCode == loggedInUserOrganizationCode)
                                                       select new APIIncidentAssignment
                                                       {
                                                           Id = i.Id,
                                                           Category = c.Category,
                                                           ReferenceIncidentId = i.ReferenceIncidentId,
                                                           ReferenceIncident=irpt.Description,
                                                           PrimaryAssignToId = i.PrimaryAssignToId,
                                                           PrimaryAssignToName = u.Name,
                                                           SecondaryAssignToId = i.SecondaryAssignToId,
                                                           SecondaryAssignToName = u2.Name,
                                                           AssignedDate = i.AssignedDate,
                                                           Remarks = i.Remarks,
                                                           CompetencyIds = irpt.CompetencyIds,
                                                           ClosureDate = irpt.ClosureDate
                                                       }).OrderByDescending(s=>s.Id);

            if (page != -1)
                Query = Query.Skip((page - 1) * pageSize);
            if (pageSize != -1)
                Query = Query.Take(pageSize);

            List<APIIncidentAssignment> incidents = await Query.ToListAsync();
            foreach (APIIncidentAssignment inc in incidents.Where(x => !string.IsNullOrWhiteSpace(x.CompetencyIds)))
            {
                inc.Competencies = new List<APICompetency>();
                inc.Competencies.AddRange(await _competencyRepository.GetCompetenciesAssignedToIncedent(loggedInUserOrganizationCode, inc.Id));
            }
            return incidents;
        }

        public async Task<int> GetIncidentAssignmentsCount(string loggedInUserOrganizationCode, int incidentId, string filter = null, string search = null)
        {
            return await (from i in _db.IncidentAssignment.Where(x => x.IsDeleted == false && x.ReferenceIncidentId == (incidentId > 0 ? incidentId : x.ReferenceIncidentId))
                          join irpt in _db.IncidentReport.Where(x => x.IsDeleted == false) on i.ReferenceIncidentId equals irpt.Id
                          join c in _db.IncidentCategory.Where(x => x.IsDeleted == false) on irpt.IncidentCategoryId equals c.Id
                          join u in _db.UserMaster on i.PrimaryAssignToId equals u.Id
                          join u2 in this._db.UserMaster on i.SecondaryAssignToId equals u2.Id into UserMasterTbl
                          from u2 in UserMasterTbl.DefaultIfEmpty()
                          where (i.IsDeleted == false && i.OrganizationCode == loggedInUserOrganizationCode)
                          select i.Id).CountAsync();
        }
        public async Task<List<APIIncidentReport>> GetIncidentAssignmentsForManagers(int loggedInUserDBId, string loggedInUserOrganizationCode, string status, int page, int pageSize, string filter = null, string search = null)
        {
            IQueryable<APIIncidentReport> Query;
            if (status.Equals("Open"))
            {
                Query = (from i in _db.IncidentAssignment
                        join r in _db.IncidentReport on i.ReferenceIncidentId equals r.Id
                        join c in _db.IncidentCategory on r.IncidentCategoryId equals c.Id
                        join d in _db.Department on r.LinkedToDepartmentId equals d.Id
                        join u in _db.UserMaster on r.CreatedBy equals u.Id
                        where (i.IsDeleted == false && i.OrganizationCode == loggedInUserOrganizationCode && r.Status == Helper.IncidentReportingStatus.Reported || r.Status == Helper.IncidentReportingStatus.WorkInProgress && (i.PrimaryAssignToId == loggedInUserDBId || i.SecondaryAssignToId == loggedInUserDBId))
                        select new APIIncidentReport
                        {
                            Id = r.Id,
                            IncidentCategory = c.Category,
                            IncidentLocation = r.IncidentLocation,
                            LinkedToDepartment = d.Name,
                            Description = r.Description,
                            Photo = r.Photo,
                            AdditionalDescription = r.AdditionalDescription,
                            Status = r.Status,
                            ReportStatus = "Assigned",
                            ReportedDate=r.CreatedDate,
                            ReportedUserName=u.Name,
                            CompetencyIds = r.CompetencyIds,
                            IsAssigned = r.IsAssigned,
                            AssignmentDate = i.CreatedDate,
                            IncidentCategoryId = r.IncidentCategoryId,
                            LinkedToDepartmentId = r.LinkedToDepartmentId,
                            PrimaryAssignedToId = i.PrimaryAssignToId,
                            PrimaryAssignedTo = _db.UserMaster.Where(x => x.Id == i.PrimaryAssignToId).Select(x => x.Name).FirstOrDefault(),
                            SecondaryAssignedToId = i.SecondaryAssignToId,
                            SecondaryAssignedTo = i.SecondaryAssignToId > 0 ? _db.UserMaster.Where(x => x.Id == i.SecondaryAssignToId).Select(x => x.Name).FirstOrDefault() : "",
                            ModifiedDate = i.ModifiedDate,
                            RemarkByAdmin = i.Remarks,
                            ClosureDate = r.ClosureDate
                        }).OrderByDescending(s => s.Id);
            }
            else
            {
                Query = (from i in _db.IncidentAssignment
                        join r in _db.IncidentReport on i.ReferenceIncidentId equals r.Id
                        join c in _db.IncidentCategory on r.IncidentCategoryId equals c.Id
                        join d in _db.Department on r.LinkedToDepartmentId equals d.Id
                        join u in _db.UserMaster on r.CreatedBy equals u.Id
                        where (i.IsDeleted == false && i.OrganizationCode == loggedInUserOrganizationCode && r.Status == status && (i.PrimaryAssignToId == loggedInUserDBId || i.SecondaryAssignToId == loggedInUserDBId))
                        select new APIIncidentReport
                        {
                            Id = r.Id,
                            IncidentCategory = c.Category,
                            IncidentLocation = r.IncidentLocation,
                            LinkedToDepartment = d.Name,
                            Description = r.Description,
                            Photo = r.Photo,
                            AdditionalDescription = r.AdditionalDescription,
                            Status = r.Status,
                            ReportStatus = "Assigned",
                            ReportedDate = r.CreatedDate,
                            ReportedUserName = u.Name,
                            CompetencyIds = r.CompetencyIds,
                            IsAssigned = r.IsAssigned,
                            AssignmentDate = i.CreatedDate,
                            IncidentCategoryId = r.IncidentCategoryId,
                            LinkedToDepartmentId = r.LinkedToDepartmentId,
                            PrimaryAssignedToId = i.PrimaryAssignToId,
                            PrimaryAssignedTo = _db.UserMaster.Where(x => x.Id == i.PrimaryAssignToId).Select(x => x.Name).FirstOrDefault(),
                            SecondaryAssignedToId = i.SecondaryAssignToId,
                            SecondaryAssignedTo = i.SecondaryAssignToId > 0 ? _db.UserMaster.Where(x => x.Id == i.SecondaryAssignToId).Select(x => x.Name).FirstOrDefault() : "",
                            ModifiedDate = i.ModifiedDate,
                            RemarkByAdmin = i.Remarks,
                            ClosureDate = r.ClosureDate
                        }).OrderByDescending(s => s.Id);
            }
            if (page != -1)
                Query = Query.Skip((page - 1) * pageSize);
            if (pageSize != -1)
                Query = Query.Take(pageSize);

            List<APIIncidentReport> incidents = await Query.ToListAsync();
            foreach (APIIncidentReport inc in incidents.Where(x => !string.IsNullOrWhiteSpace(x.CompetencyIds)))
            {
                inc.Competencies = new List<APICompetency>();
                inc.Competencies.AddRange(await _competencyRepository.GetCompetenciesAssignedToIncedent(loggedInUserOrganizationCode, inc.Id));
            }
            return incidents;
        }
        public async Task<int> GetIncidentAssignmentsForManagersCount(int loggedInUserDBId, string loggedInUserOrganizationCode, string status, string filter = null, string search = null)
        {
            if (status.Equals("Open"))
            {
                return await (from i in _db.IncidentAssignment
                              join r in _db.IncidentReport on i.ReferenceIncidentId equals r.Id
                              join c in _db.IncidentCategory on r.IncidentCategoryId equals c.Id
                              join d in _db.Department on r.LinkedToDepartmentId equals d.Id
                              join u in _db.UserMaster on r.CreatedBy equals u.Id
                              where (i.IsDeleted == false && i.OrganizationCode == loggedInUserOrganizationCode && r.Status == Helper.IncidentReportingStatus.Reported || r.Status == Helper.IncidentReportingStatus.WorkInProgress && (i.PrimaryAssignToId == loggedInUserDBId || i.SecondaryAssignToId == loggedInUserDBId))
                              select i.Id).CountAsync();
            }
            else
            {
                return await (from i in _db.IncidentAssignment
                              join r in _db.IncidentReport on i.ReferenceIncidentId equals r.Id
                              join c in _db.IncidentCategory on r.IncidentCategoryId equals c.Id
                              join d in _db.Department on r.LinkedToDepartmentId equals d.Id
                              join u in _db.UserMaster on r.CreatedBy equals u.Id
                              where (i.IsDeleted == false && i.OrganizationCode == loggedInUserOrganizationCode && r.Status == status && (i.PrimaryAssignToId == loggedInUserDBId || i.SecondaryAssignToId == loggedInUserDBId))
                              select i.Id).CountAsync();
            }
        }

        public async Task<List<APIIncidentReport>> GetIncidentsForActionTaken(string loggedInUserOrganizationCode, int loggedInUserDBId, int page, int pageSize, string filter = null, string search = null)
        {
            IQueryable<APIIncidentReport> Query = (from a in _db.IncidentAssignment //.Where(x=> !_db.ActionTakenReport.Select(y=>y.ReferenceIncidentId).Contains(x.ReferenceIncidentId))
                                                   join i in _db.IncidentReport on a.ReferenceIncidentId equals i.Id
                                                   join c in _db.IncidentCategory on i.IncidentCategoryId equals c.Id
                                                   join d in _db.Department on i.LinkedToDepartmentId equals d.Id
                                                   join u in _db.UserMaster on i.CreatedBy equals u.Id
                                                   where(i.IsDeleted == false && i.OrganizationCode == loggedInUserOrganizationCode && (a.PrimaryAssignToId == loggedInUserDBId || a.SecondaryAssignToId == loggedInUserDBId )) //&& !(from t in _db.ActionTakenReport select t.ReferenceIncidentId).Contains(i.Id))
                                                   select new APIIncidentReport
                                                   {
                                                       Id = i.Id,
                                                       IncidentCategory = c.Category,
                                                       IncidentLocation = i.IncidentLocation,
                                                       LinkedToDepartment = d.Name,
                                                       Description = GetTrimDescription(i.Description),
                                                       Photo = i.Photo,
                                                       AdditionalDescription = i.AdditionalDescription,
                                                       Status = i.Status,
                                                       ReportedUserName = u.Name,
                                                       ReportedDate = i.CreatedDate,
                                                       CompetencyIds = i.CompetencyIds,
                                                       IsAssigned = i.IsAssigned,
                                                       AssignmentDate = a.CreatedDate,
                                                       IncidentCategoryId = i.IncidentCategoryId,
                                                       LinkedToDepartmentId = i.LinkedToDepartmentId,
                                                       PrimaryAssignedToId = a.PrimaryAssignToId,
                                                       PrimaryAssignedTo = _db.UserMaster.Where(x=>x.Id == a.PrimaryAssignToId).Select(x=>x.Name).FirstOrDefault(),
                                                       SecondaryAssignedToId = a.SecondaryAssignToId,
                                                       SecondaryAssignedTo = a.SecondaryAssignToId > 0 ? _db.UserMaster.Where(x => x.Id == a.SecondaryAssignToId).Select(x => x.Name).FirstOrDefault() : "",
                                                       ModifiedDate = a.ModifiedDate,
                                                       RemarkByAdmin = a.Remarks,
                                                       ReportStatus = i.Status,
                                                       ClosureDate = i.ClosureDate
                                                   }).OrderByDescending(s => s.Id);
            

            if (page != -1)
                Query = Query.Skip((page - 1) * pageSize);
            if (pageSize != -1)
                Query = Query.Take(pageSize);
            List<APIIncidentReport> incidents = await Query.ToListAsync();
            incidents = incidents.Where(x => _db.ActionTakenReport.Where(y => y.IsDeleted == false && y.ReferenceIncidentId == x.Id).Count() == 0).ToList();
            foreach (APIIncidentReport inc in incidents.Where(x=> !string.IsNullOrWhiteSpace(x.CompetencyIds)))
            {
                inc.Competencies = new List<APICompetency>();
                inc.Competencies.AddRange(await _competencyRepository.GetCompetenciesAssignedToIncedent(loggedInUserOrganizationCode, inc.Id));
            }
                return incidents;
        }
        public static string GetTrimDescription(string description)
        {
            int length = 60;
            // Return if the string is less than or equal to the truncation length
            if (description == null || description.Length <= length)
                return description;

            // Do a simple tuncation at the desired length
            string result = description.Substring(0, length);

            // Truncate the string at the word
            // List of characters that denote the start or a new word (add to or remove more as necessary)
            //List<char> alternativeCutOffs = new List<char>() { ' ', ',', '.', '?', '/', ':', ';', '\'', '\"', '\'', '-' };
            List<char> alternativeCutOffs = new List<char>() { ' ' };

            // Get the index of the last space in the truncated string
            int lastSpace = result.LastIndexOf(' ');

            // If the last space index isn't -1 and also the next character in the original
            // string isn't contained in the alternativeCutOffs List (which means the previous
            // truncation actually truncated at the end of a word),then shorten string to the last space
            if (lastSpace != -1 && (description.Length >= length + 1 && !alternativeCutOffs.Contains(description.ToCharArray()[length])))
                result = result.Remove(lastSpace);

            result += " ...";

            return result;
        }
    }
}

