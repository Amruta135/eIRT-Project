﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using User.API.APIModel;
using User.API.Data;
using User.API.Models;
using User.API.Repositories.Interface;

namespace User.API.Repositories
{
    public class OrganizationInfoRepository : Repository<OrganizationInfo>, IOrganizationInfoRepository
    {
        private UserDbContext _db;
        public OrganizationInfoRepository(UserDbContext context) : base(context)
        {
            this._db = context;
        }

        public async Task<APIOrganizationInfo> GetCurrentUserOrganization(string loggedInUserOrganizationCode)
        {
            IQueryable<APIOrganizationInfo> Query = (from organizationInfo in _db.OrganizationInfo
                                                     where (organizationInfo.IsDeleted == false && organizationInfo.OrganizationCode==loggedInUserOrganizationCode)
                                                     select new APIOrganizationInfo
                                                     {
                                                         Id = organizationInfo.Id,
                                                         OrganizationCode = organizationInfo.OrganizationCode,
                                                         OrganizationName = organizationInfo.OrganizationName,
                                                         Address = organizationInfo.Address,
                                                         Pincode = organizationInfo.Pincode,
                                                         City = organizationInfo.City,
                                                         State = organizationInfo.State,
                                                         MobileNumber = organizationInfo.MobileNumber,
                                                         Website = organizationInfo.Website,
                                                         Logo = organizationInfo.Logo,
                                                         DeliveryModel = organizationInfo.DeliveryModel,
                                                         DomainName = organizationInfo.DomainName,
                                                         WorkflowOption = organizationInfo.WorkflowOption,
                                                         RGBCode = organizationInfo.RGBCode,
                                                         CreatedBy = organizationInfo.CreatedBy,
                                                         AppName = organizationInfo.AppName,
                                                         BaseLocation = organizationInfo.BaseLocation,
                                                         GeoFencingDistance = organizationInfo.GeoFencingDistance
                                                     }).OrderByDescending(a => a.Id);

            return await Query.FirstOrDefaultAsync();
        }

        public async Task<List<APIOrganizationInfo_Internal>> GetOrganizationInfos(int page, int pageSize, string filter = null, string search = null)
        {
            IQueryable<APIOrganizationInfo_Internal> Query = (from organizationInfo in _db.OrganizationInfo
                                                     where (organizationInfo.IsDeleted == false)
                                                     select new APIOrganizationInfo_Internal
                                                     {
                                                         Id = organizationInfo.Id,
                                                         OrganizationCode = organizationInfo.OrganizationCode,
                                                         OrganizationName = organizationInfo.OrganizationName,
                                                         Address = organizationInfo.Address,
                                                         Pincode = organizationInfo.Pincode,
                                                         City = organizationInfo.City,
                                                         State = organizationInfo.State,
                                                         MobileNumber = organizationInfo.MobileNumber,
                                                         Website = organizationInfo.Website,
                                                         Logo = organizationInfo.Logo,
                                                         DeliveryModel = organizationInfo.DeliveryModel,
                                                         DomainName = organizationInfo.DomainName,
                                                         WorkflowOption = organizationInfo.WorkflowOption,
                                                         NoofUsers = organizationInfo.NoofUsers,
                                                         AccountValidityDate = organizationInfo.AccountValidityDate,
                                                         RGBCode = organizationInfo.RGBCode,
                                                         CreatedBy=organizationInfo.CreatedBy,
                                                         AppName = organizationInfo.AppName,
                                                         HasAdmin = _db.UserMaster.Where(x=>x.OrganizationCode == organizationInfo.OrganizationCode && x.Role == Helper.RoleCode.IRT_Client_Admin).Any()
                                                     }).OrderByDescending(a => a.Id);

            if (page != -1)
                Query = Query.Skip((page - 1) * pageSize);
            if (pageSize != -1)
                Query = Query.Take(pageSize);
            //foreach (var org in Query)
            //{
            //    org.HasAdmin = _db.UserMaster.Where(x => x.OrganizationCode == org.OrganizationCode && x.Role == Helper.RoleCode.IRT_Client_Admin).Any();
            //}
            return await Query.ToListAsync();
        }

        public async Task<int> GetOrganizationInfosCount(string filter = null, string search = null)
        {
            return await (from organizationInfo in _db.OrganizationInfo
                          where (organizationInfo.IsDeleted == false)
                          select organizationInfo.Id).CountAsync();
        }

        
        public async Task<string> GetOrganizationMaxUsers(string loggedInUserOrganizationCode)
        {
            return await (from organizationInfo in _db.OrganizationInfo
                          where (organizationInfo.IsDeleted == false && organizationInfo.OrganizationCode == loggedInUserOrganizationCode)
                          select organizationInfo.NoofUsers).FirstOrDefaultAsync();
        }
    }
}
