﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Caching.Memory;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using User.API.APIModel;
using User.API.Data;
using User.API.Helper;
using User.API.Models.User.API.Models;
using User.API.Repositories.Interface;

namespace User.API.Repositories
{
    public class RolesConfigurationRepository : Repository<RolesConfiguration>, IRolesConfigurationRepository
    {
        private UserDbContext _db;

        public RolesConfigurationRepository(UserDbContext context) : base(context)
        {
            _db = context;
        }

        public async Task<List<APIRolesConfigurations>> GetRolesConfigurations(string loggedInUserOrganizationCode, int page, int pageSize, string filter = null, string search = null)
        {
            IQueryable<APIRolesConfigurations> Query = (from r in _db.RolesConfiguration
                                                     where (r.IsDeleted == false && r.OrganizationCode == loggedInUserOrganizationCode)
                                                     select new APIRolesConfigurations
                                                     {
                                                         Id = r.Id,
                                                         OriginalRoleCode = r.OriginalRoleCode,
                                                         OriginalRoleDescription = r.OriginalRoleDescription,
                                                         ChangedRoleDescription = r.ChangedRoleDescription
                                                     });

            if (page != -1)
                Query = Query.Skip((page - 1) * pageSize);
            if (pageSize != -1)
                Query = Query.Take(pageSize);

            return await Query.ToListAsync();
        }

        public async Task<int> GetRolesConfigurationCount(string loggedInUserOrganizationCode, string filter = null, string search = null)
        {
            return await (from r in _db.RolesConfiguration
                          where (r.IsDeleted == false && r.OrganizationCode == loggedInUserOrganizationCode)
                          select r.Id).CountAsync();
        }

        public async Task<int> AddDefaultRolesConfiguration(string OrganizationCode, int loggedInUserDBId)
        {
            try
            {

                if (string.IsNullOrEmpty(OrganizationCode))
                    return 0;

                if (!await this.FindAsync(s => s.OrganizationCode == OrganizationCode && s.OriginalRoleCode == RoleCode.IRT_Client_Admin))
                {
                    RolesConfiguration rolesConfiguration = new RolesConfiguration();
                    rolesConfiguration.OrganizationCode = OrganizationCode;
                    rolesConfiguration.OriginalRoleCode = RoleCode.IRT_Client_Admin;
                    rolesConfiguration.OriginalRoleDescription = Role.IRT_Client_Admin;
                    rolesConfiguration.ChangedRoleDescription = Role.IRT_Client_Admin;
                    rolesConfiguration.CreatedDate = DateTime.Now;
                    rolesConfiguration.ModifiedDate = DateTime.Now;
                    rolesConfiguration.CreatedBy = loggedInUserDBId;
                    rolesConfiguration.ModifiedBy = loggedInUserDBId;
                    await AddAndReturnEntityAsync(rolesConfiguration);
                }

                if (!await this.FindAsync(s => s.OrganizationCode == OrganizationCode && s.OriginalRoleCode == RoleCode.EHS_Manager))
                {
                    RolesConfiguration rolesConfiguration = new RolesConfiguration();
                    rolesConfiguration.OrganizationCode = OrganizationCode;
                    rolesConfiguration.OriginalRoleCode = RoleCode.EHS_Manager;
                    rolesConfiguration.OriginalRoleDescription = Role.EHS_Manager;
                    rolesConfiguration.ChangedRoleDescription = Role.EHS_Manager;
                    rolesConfiguration.CreatedDate = DateTime.Now;
                    rolesConfiguration.ModifiedDate = DateTime.Now;
                    rolesConfiguration.CreatedBy = loggedInUserDBId;
                    rolesConfiguration.ModifiedBy = loggedInUserDBId;
                    await AddAndReturnEntityAsync(rolesConfiguration);
                }

                if (!await this.FindAsync(s => s.OrganizationCode == OrganizationCode && s.OriginalRoleCode == RoleCode.EHS_Inspector))
                {
                    RolesConfiguration rolesConfiguration = new RolesConfiguration();
                    rolesConfiguration.OrganizationCode = OrganizationCode;
                    rolesConfiguration.OriginalRoleCode = RoleCode.EHS_Inspector;
                    rolesConfiguration.OriginalRoleDescription = Role.EHS_Inspector;
                    rolesConfiguration.ChangedRoleDescription = Role.EHS_Inspector;
                    rolesConfiguration.CreatedDate = DateTime.Now;
                    rolesConfiguration.ModifiedDate = DateTime.Now;
                    rolesConfiguration.CreatedBy = loggedInUserDBId;
                    rolesConfiguration.ModifiedBy = loggedInUserDBId;
                    await AddAndReturnEntityAsync(rolesConfiguration);
                }

                if (!await this.FindAsync(s => s.OrganizationCode == OrganizationCode && s.OriginalRoleCode == RoleCode.EHS_Monitor))
                {
                    RolesConfiguration rolesConfiguration = new RolesConfiguration();
                    rolesConfiguration.OrganizationCode = OrganizationCode;
                    rolesConfiguration.OriginalRoleCode = RoleCode.EHS_Monitor;
                    rolesConfiguration.OriginalRoleDescription = Role.EHS_Monitor;
                    rolesConfiguration.ChangedRoleDescription = Role.EHS_Monitor;
                    rolesConfiguration.CreatedDate = DateTime.Now;
                    rolesConfiguration.ModifiedDate = DateTime.Now;
                    rolesConfiguration.CreatedBy = loggedInUserDBId;
                    rolesConfiguration.ModifiedBy = loggedInUserDBId;
                    await AddAndReturnEntityAsync(rolesConfiguration);
                }

                return 1;
            }
            catch (System.Exception)
            {
                return 0;
            }
        }
    }
}
