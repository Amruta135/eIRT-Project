﻿using Microsoft.EntityFrameworkCore;
using System.Linq;
using System.Threading.Tasks;
using User.API.Data;
using User.API.Models;
using User.API.Repositories.Interface;

namespace User.API.Repositories
{
    public class TokensRepository : Repository<Tokens>, ITokensRepository
    {
        private readonly UserDbContext _db;
        public TokensRepository(UserDbContext context) : base(context)
        {
            _db = context;
        }
        public async Task<Tokens> GetUserTokenRecord(int userId, string userToken)
        {
            Tokens token = await this._db.Tokens.Where(s => s.UserId == userId && s.Token == userToken).FirstOrDefaultAsync();
            return token;
        }
    }
}
