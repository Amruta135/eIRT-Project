﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Caching.Memory;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using User.API.APIModel;
using User.API.Data;
using User.API.Helper;
using User.API.Models;
using User.API.Repositories.Interface;

namespace User.API.Repositories
{
    public class ConfigurableValuesRepository : Repository<ConfigurableValues>, IConfigurableValuesRepository
    {
        private UserDbContext _db;
        private IMemoryCache _cacheConfigurableValues;
        public ConfigurableValuesRepository(UserDbContext context, IMemoryCache cacheConfigurableValues) : base(context)
        {
            _db = context;
            _cacheConfigurableValues = cacheConfigurableValues;
        }

        public async Task<List<APIConfigurableValues>> GetAllConfigurableValues()
        {
            return await GetCacheConfigurableValues(null);
        }

        public async Task<List<APIConfigurableValues>> GetConfigurableValues(string typeCode)
        {
            return await GetCacheConfigurableValues(typeCode);
        }

        public async Task<List<APIConfigurableValues>> GetTypeName()
        {
            IQueryable<APIConfigurableValues> Query = (from c in _db.ConfigurableValues
                                                       where (c.IsDeleted == false)
                                                       select new APIConfigurableValues
                                                       {
                                                           TypeName = c.TypeName
                                                       }).OrderBy(s => s.TypeName).Distinct();

            return await Query.ToListAsync();
        }

        private async Task<List<APIConfigurableValues>> GetCacheConfigurableValues(string typeCode)
        {
            List<APIConfigurableValues> cacheEntryConfigurableValues = new List<APIConfigurableValues>();
            // Look for cache key.
            if (!_cacheConfigurableValues.TryGetValue(CacheKeys.ConfigurableValues, out cacheEntryConfigurableValues))
            {
                // Key not in cache, so get data.
                cacheEntryConfigurableValues = await this.GetConfigurableValues();

                // Set cache options.
                var cacheEntryOptions = new MemoryCacheEntryOptions()
                    // Keep in cache for this time, reset time if accessed.
                    .SetSlidingExpiration(TimeSpan.FromHours(1));

                // Save data in cache.
                _cacheConfigurableValues.Set(CacheKeys.ConfigurableValues, cacheEntryConfigurableValues, cacheEntryOptions);
            }
            if (string.IsNullOrEmpty(typeCode))
                return cacheEntryConfigurableValues.ToList();
            return cacheEntryConfigurableValues.Where(s => s.TypeCode == typeCode).ToList();
        }

        private async Task<List<APIConfigurableValues>> GetConfigurableValues()
        {
            IQueryable<APIConfigurableValues> Query = (from c in _db.ConfigurableValues
                                                       where (c.IsDeleted == false)
                                                       select new APIConfigurableValues
                                                       {
                                                           TypeCode = c.TypeCode,
                                                           Code = c.ValueCode,
                                                           Name = c.ValueName,
                                                           Sequence = c.Sequence
                                                       }).OrderBy(s => s.TypeCode).ThenBy(s => s.Sequence);
            return await Query.ToListAsync();
        }
    }
}
