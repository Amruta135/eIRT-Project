﻿using System.Threading.Tasks;
using User.API.Models;

namespace User.API.Repositories.Interface
{
    public interface ILoggedInHistoryRepository : IRepository<LoggedInHistory>
    {
        Task<LoggedInHistory> GetLatestRecord(int userId);
    }
}
