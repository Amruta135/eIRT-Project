﻿using Microsoft.AspNetCore.Http;
using System.Threading.Tasks;
using User.API.Helper;

namespace User.API.Repositories.Interface
{
    public interface IFileUploaderRepository
    {
        Task<string> Upload(EnumFileUploadFor uploadFor, EnumFileType fileType, IFormFile file, bool Compress);
        bool SaveThumb(string FromFilePath, string fileName);
        bool DeleteFile(EnumFileUploadFor uploadFor, string fileName);
    }
}
