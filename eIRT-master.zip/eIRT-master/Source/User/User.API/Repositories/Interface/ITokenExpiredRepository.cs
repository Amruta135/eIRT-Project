﻿using System.Threading.Tasks;
using User.API.Models;

namespace User.API.Repositories.Interface
{
    public interface ITokenExpiredRepository : IRepository<TokenExpired>
    {
        Task<bool> TokenExists(string userToken);
    }
}
