﻿using System.Collections.Generic;
using System.Threading.Tasks;
using User.API.APIModel;
using User.API.Models;

namespace User.API.Repositories.Interface
{
    public interface IConfigurableValuesRepository : IRepository<ConfigurableValues>
    {
        Task<List<APIConfigurableValues>> GetAllConfigurableValues();
        Task<List<APIConfigurableValues>> GetConfigurableValues(string typeCode);
        Task<List<APIConfigurableValues>> GetTypeName();
    }
}
