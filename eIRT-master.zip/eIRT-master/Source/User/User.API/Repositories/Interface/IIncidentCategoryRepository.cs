﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using User.API.APIModel;
using User.API.Models;

namespace User.API.Repositories.Interface
{
    public interface IIncidentCategoryRepository : IRepository<IncidentCategory>
    {
        Task<List<APIIncidentCategory>> GetIncidentCategories(string loggedInUserOrganizationCode, int page, int pageSize, string filter = null, string search = null);
        Task<int> GetIncidentCategoriesCount(string loggedInUserOrganizationCode, string filter = null, string search = null);
        Task<int> AddDefaultIncidentCategory(string organizationCode, int loggedInUserDBId);
    }
}
