﻿using System.Collections.Generic;
using System.Threading.Tasks;
using User.API.APIModel;
using User.API.Models;

namespace User.API.Repositories.Interface
{
    public interface ICompetencyRepository : IRepository<Competency>
    {
        Task<APICompetency> GetCompetency(int id, string loggedInUserOrganizationCode);
        Task<List<APICompetency>> GetCompetencies(string loggedInUserOrganizationCode, int page, int pageSize, string filter = null, string search = null);
        Task<int> GetCompetenciesCount(string loggedInUserOrganizationCode, string filter = null, string search = null);
        Task<List<APICompetency>> GetCompetenciesAssignedToUser(string loggedInUserOrganizationCode, int userId);
        Task<List<APICompetency>> GetCompetenciesAssignedToIncedent(string loggedInUserOrganizationCode, int incidentId);
    }
}
