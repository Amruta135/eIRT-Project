﻿using System.Collections.Generic;
using System.Threading.Tasks;
using User.API.APIModel;
using User.API.Models;

namespace User.API.Repositories.Interface
{
    public interface IDepartmentRepository : IRepository<Department>
    {
        Task<List<APIDepartments>> GetDepartments(string loggedInUserOrganizationCode, int page, int pageSize, string filter = null, string search = null);
        Task<int> GetDepartmentsCount(string loggedInUserOrganizationCode, string filter = null, string search = null);
        Task<List<APIDepartments>> GetDepartmentByOrganization(string OrganizationCode);
    }
}
