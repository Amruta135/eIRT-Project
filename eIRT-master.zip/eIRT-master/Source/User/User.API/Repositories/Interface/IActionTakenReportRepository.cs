﻿using System.Collections.Generic;
using System.Threading.Tasks;
using User.API.APIModel;
using User.API.Models;

namespace User.API.Repositories.Interface
{
    public interface IActionTakenReportRepository : IRepository<ActionTakenReport>
    {
        Task<List<APIActionTakenReport>> GetActionTakenReports(int loggedInUserDBId, string loggedInUserOrganizationCode, int incidentId, string userRole, int page, int pageSize, string filter = null, string search = null);
        Task<int> GetActionTakenReportsCount(int loggedInUserDBId, string loggedInUserOrganizationCode, int incidentId, string userRole,  string filter = null, string search = null);
    }
}
