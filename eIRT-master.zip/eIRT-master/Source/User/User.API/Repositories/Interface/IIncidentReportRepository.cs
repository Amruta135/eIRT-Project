﻿using System.Collections.Generic;
using System.Threading.Tasks;
using User.API.APIModel;
using User.API.Models;

namespace User.API.Repositories.Interface
{
    public interface IIncidentReportRepository : IRepository<IncidentReport>
    {
        Task<List<APIIncidentReport>> GetIncidentReports(int loggedInUserDBId, string loggedInUserOrganizationCode, int page, int pageSize, string filter = null, string search = null);
        Task<int> GetIncidentReportsCount(int loggedInUserDBId, string loggedInUserOrganizationCode, string filter = null, string search = null);
        Task<List<APIOpenClosedIncidentInfo>> GetOpenClosedIncidentsReport(string loggedInUserOrganizationCode, APIOpenClosedIncidentSearch apiOpenClosedIncidentSearch);
        Task<List<APIIncidentReport>> GetIncidentReportsList(string loggedInUserOrganizationCode, int page, int pageSize, string filter = null, string search = null);
        Task<List<APIIncidentReport>> GetIncidentReportsForManagers(int loggedInUserDBId, string loggedInUserOrganizationCode, string status, int page, int pageSize, string filter = null, string search = null);
        Task<int> GetIncidentReportsForManagersCount(int loggedInUserDBId, string loggedInUserOrganizationCode, string status, string filter = null, string search = null);
        Task<List<APIIncidentReport>> GetSingleIncidentReportsList(string loggedInUserOrganizationCode, int id); 
        Task<List<APIIncidentReport>> GetAllIncidents(string loggedInUserOrganizationCode, int page, int pageSize, string filter = null, string search = null);
        Task<int> GetAllIncidentsCount(string loggedInUserOrganizationCode, string filter = null, string search = null);
        Task<int> GetStatusCount(string loggedInUserOrganizationCode, string status);
        Task<double> GetAverageClosuerPeriod(string loggedInUserOrganizationCode);
        Task<int> GetDaysSinceLastIncident(string loggedInUserOrganizationCode);

        Task<List<APIIncidentReport>> GetReportedIncidents(int loggedInUserDBId, string loggedInUserOrganizationCode, string role, APISearchIncident searchInfo);
        Task<int> GetReportedIncidentsCount(int loggedInUserDBId, string loggedInUserOrganizationCode, string role, APISearchIncident searchInfo);
    }
}
