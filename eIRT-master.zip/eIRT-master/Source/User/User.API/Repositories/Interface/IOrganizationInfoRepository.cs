﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using User.API.APIModel;
using User.API.Models;

namespace User.API.Repositories.Interface
{
    public interface IOrganizationInfoRepository : IRepository<OrganizationInfo>
    {
        public Task<List<APIOrganizationInfo_Internal>> GetOrganizationInfos(int page, int pageSize, string filter = null, string search = null);
        public Task<int> GetOrganizationInfosCount(string filter = null, string search = null);
        Task<string> GetOrganizationMaxUsers(string loggedInUserOrganizationCode);
        Task<APIOrganizationInfo> GetCurrentUserOrganization(string loggedInUserOrganizationCode);
    }
}
