﻿using System.Collections.Generic;
using System.Threading.Tasks;
using User.API.APIModel;
using User.API.Models.User.API.Models;

namespace User.API.Repositories.Interface
{
    public interface IRolesConfigurationRepository : IRepository<RolesConfiguration>
    {
        Task<List<APIRolesConfigurations>> GetRolesConfigurations(string loggedInUserOrganizationCode, int page, int pageSize, string filter = null, string search = null);
        Task<int> GetRolesConfigurationCount(string loggedInUserOrganizationCode, string filter = null, string search = null);
        Task<int> AddDefaultRolesConfiguration(string OrganizationCode, int loggedInUserDBId);
    }
}
