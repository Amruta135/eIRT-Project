﻿using System.Threading.Tasks;
using User.API.APIModel;
using User.API.Models;

namespace User.API.Repositories.Interface
{
    public interface IPinCodesRepository : IRepository<PinCodes>
    {
        Task<APIPinCode> GetPinCodeDetails(int pincode);
    }
}
