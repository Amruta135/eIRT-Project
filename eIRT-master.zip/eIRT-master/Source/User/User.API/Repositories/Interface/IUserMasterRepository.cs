﻿using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using User.API.APIModel;
using User.API.Models;

namespace User.API.Repositories.Interface
{
    public interface IUserMasterRepository : IRepository<UserMaster>
    {
        Task<APIUserDetails> GetUserDetails(int userMasterId, string token);
        Task<int> GetUserId(Guid guid);
        Task<List<APIUserDetails>> GetUsersForPA(int page, int pageSize, string filter = null, string search = null);
        Task<int> GetUsersForPACount(string filter = null, string search = null);
        Task<List<APIUserDetails>> GetUsersForCA(string loggedInUserOrganizationCode, int page, int pageSize, string filter = null, string search = null);
        Task<int> GetUsersForCACount(string loggedInUserOrganizationCode, string filter = null, string search = null);
        Task<UserMaster> GetUserData(Guid guid);
        Task<int> GetActiveUsersCount(string loggedInUserOrganizationCode);
        Task<APIUserProfile> GetDetailsById(string loggedInUserOrganizationCode, string userRole, int id);
        Task<APIUser> GetUserDetails(string loggedInUserOrganizationCode);
        Task<APIUserSecurityQuestion> GetUserSecurityQuestion(string loggedInUserOrganizationCode, int loggedInUserDbId);
    }
}
