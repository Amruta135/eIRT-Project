﻿using System.Threading.Tasks;
using User.API.Models;

namespace User.API.Repositories.Interface
{
    public interface ITokensRepository : IRepository<Tokens>
    {
        Task<Tokens> GetUserTokenRecord(int userId, string userToken);
    }
}
