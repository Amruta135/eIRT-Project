﻿using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Threading.Tasks;

namespace User.API.Repositories.Interface
{
    public interface IRepository<T> where T : class
    {
        IEnumerable<T> GetAll();
        T Get(int id);
        Task<T> GetAsync(int id);
        void Add(T entity);
        Task AddAsync(T entity);
        Task<T> AddAndReturnEntityAsync(T entity);
        void Update(T entity);
        void Delete(T entity);
        Task DeleteAsync(T entity);
        Task<IEnumerable<T>> GetAllAsync();
        Task<List<T>> GetAll(Expression<Func<T, bool>> match);
        Task<int> CountAsync();
        Task<bool> FindAsync(Expression<Func<T, bool>> match);
        Task UpdateAsync(T entity);

    }
}
