﻿
using User.API.Models;

namespace User.API.Repositories.Interface
{
    public interface ISecurityQuestionRepository : IRepository<SecurityQuestion>
    {
    }
}
