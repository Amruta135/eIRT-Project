﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using User.API.APIModel;

namespace User.API.Repositories.Interface
{
    public interface IStatesRepository : IRepository<Models.States>
    {
        Task<List<APIStates>> GetStates();
    }
}
