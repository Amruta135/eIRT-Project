﻿using System.Collections.Generic;
using System.Threading.Tasks;
using User.API.APIModel;
using User.API.Models;

namespace User.API.Repositories.Interface
{
    public interface IIncidentAssignmentRepository : IRepository<IncidentAssignment>
    {
        Task<APIIncidentAssignment> GetIncidentAssignment(string loggedInUserOrganizationCode, int Id);
        Task<List<APIIncidentAssignment>> GetIncidentAssignments(string loggedInUserOrganizationCode, int incidentId, int page, int pageSize, string filter = null, string search = null);
        Task<int> GetIncidentAssignmentsCount(string loggedInUserOrganizationCode, int incidentId, string filter = null, string search = null);
        Task<List<APIIncidentReport>> GetIncidentAssignmentsForManagers(int loggedInUserDBId, string loggedInUserOrganizationCode, string status, int page, int pageSize, string filter = null, string search = null);
        Task<int> GetIncidentAssignmentsForManagersCount(int loggedInUserDBId, string loggedInUserOrganizationCode, string status, string filter = null, string search = null);
        Task<List<APIIncidentReport>> GetIncidentsForActionTaken(string loggedInUserOrganizationCode, int loggedInUserDBId, int page, int pageSize, string filter = null, string search = null);
    }
}
