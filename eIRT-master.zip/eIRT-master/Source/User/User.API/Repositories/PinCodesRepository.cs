﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Caching.Memory;
using System.IO;
using System.Net;
using User.API.Repositories.Interface;
using User.API.Data;
using User.API.Models;
using User.API.APIModel;
using LitJson;
using User.API.Helper;

namespace User.API.Repositories
{
    public class PinCodesRepository : Repository<PinCodes>, IPinCodesRepository
    {
        private UserDbContext _db;
        private IMemoryCache _cachePinCodes;
        public PinCodesRepository(UserDbContext context, IMemoryCache cachePinCodes) : base(context)
        {
            _db = context;
            _cachePinCodes = cachePinCodes;
        }

        public async Task<APIPinCode> GetPinCodeDetails(int pincode)
        {
            List<APIPinCode> pincodeEntries = await GetCachePinCodes(pincode);
            if (pincodeEntries == null || pincodeEntries.Count == 0)
            {
                APIPostalPinCode apiPostalPinCode = await GetPostalPincode(pincode);
                if (apiPostalPinCode != null && apiPostalPinCode.City != null)
                {
                    APIPinCode apiPinCode = new APIPinCode();
                    apiPinCode.City = apiPostalPinCode.City;
                    apiPinCode.State = apiPostalPinCode.State;
                    apiPinCode.Pincode = apiPostalPinCode.Pincode;
                    apiPinCode.PostOfficeName = apiPostalPinCode.PostOfficeName;
                    apiPinCode.StateCode = await GetStateCode(apiPostalPinCode.State);
                    await AddPincodeToDB(apiPinCode, apiPostalPinCode.District);
                    return apiPinCode;
                }
            }
            return pincodeEntries.FirstOrDefault();
        }

        private async Task<bool> AddPincodeToDB(APIPinCode apiPinCode, string district)
        {
            PinCodes pinCode = new PinCodes();
            pinCode.Pincode = apiPinCode.Pincode;
            pinCode.City = apiPinCode.City;
            pinCode.State = apiPinCode.State;
            pinCode.StateCode = apiPinCode.StateCode;
            pinCode.PostOfficeName = apiPinCode.PostOfficeName;
            pinCode.District = district;
            pinCode.IsDeleted = false;

            if (!await PincodeExists(apiPinCode.Pincode))
                await AddAsync(pinCode);

            return true;
        }
        private async Task<string> GetStateCode(string state)
        {
            return await _db.PinCodes.Where(s => s.State == state).Select(s => s.StateCode).FirstOrDefaultAsync();
        }
        private async Task<bool> PincodeExists(int pincode)
        {
            if (await _db.PinCodes.Where(x => x.Pincode == pincode && x.IsDeleted != true).CountAsync() > 0)
                return true;
            else
                return false;
        }

        private async Task<APIPostalPinCode> GetPostalPincode(int pincode)
        {
            PostOfficeResult postOfficeResult = null;
            APIPostalPinCode apiPostalPinCode = new APIPostalPinCode();
            try
            {
                string userAuthenticationURI = "http://postalpincode.in/api/pincode/" + pincode;

                if (!string.IsNullOrEmpty(userAuthenticationURI))
                {
                    HttpWebRequest request = (HttpWebRequest)WebRequest.Create(userAuthenticationURI);
                    request.Method = "GET";
                    request.ContentType = "application/json";
                    WebResponse response = await request.GetResponseAsync();
                    using (var reader = new StreamReader(response.GetResponseStream()))
                    {
                        var ApiStatus = reader.ReadToEnd();
                        JsonData data = JsonMapper.ToObject(ApiStatus);
                        string status = data["Status"].ToString();
                        if (status.ToLower() == "success")
                        {
                            postOfficeResult = JsonMapper.ToObject<PostOfficeResult>(ApiStatus);

                        }
                        if (postOfficeResult != null)
                        {
                            apiPostalPinCode.PostOfficeName = postOfficeResult.PostOffice[0].Name;
                            apiPostalPinCode.City = postOfficeResult.PostOffice[0].Circle.Replace("City", "");
                            apiPostalPinCode.State = postOfficeResult.PostOffice[0].State;
                            apiPostalPinCode.Pincode = pincode;
                            apiPostalPinCode.District = postOfficeResult.PostOffice[0].District;
                        }
                    }
                }
            }
            catch
            {
            }
            return apiPostalPinCode;
        }

        public async Task<List<APICities>> GetCitiesByPin(int pincode)
        {
            List<APIPinCode> pincodeEntries = await GetCachePinCodes(pincode);
            APIPinCode pinCode = pincodeEntries.FirstOrDefault();
            if (pinCode != null)
            {
                return await GetCitiesByPinCode(pinCode.StateCode);
            }
            return null;
        }

        private async Task<List<APIPinCode>> GetCachePinCodes(int pincode)
        {
            List<APIPinCode> cacheEntryPinCodes = new List<APIPinCode>();
            // Look for cache key.
            if (!_cachePinCodes.TryGetValue(CacheKeys.PinCodes, out cacheEntryPinCodes))
            {
                // Key not in cache, so get data.
                cacheEntryPinCodes = await this.GetPinCodes();

                // Set cache options.
                var cacheEntryOptions = new MemoryCacheEntryOptions()
                    // Keep in cache for this time, reset time if accessed.
                    .SetSlidingExpiration(TimeSpan.FromMinutes(60));

                // Save data in cache.
                _cachePinCodes.Set(CacheKeys.PinCodes, cacheEntryPinCodes, cacheEntryOptions);
            }
            return cacheEntryPinCodes.Where(s => s.Pincode == pincode).ToList();
        }

        private async Task<List<APIPinCode>> GetPinCodes()
        {
            IQueryable<APIPinCode> Query = (from p in _db.PinCodes
                                            where (p.IsDeleted == false)
                                            select new APIPinCode
                                            {
                                                Pincode = p.Pincode,
                                                PostOfficeName = p.PostOfficeName,
                                                City = p.City,
                                                State = p.State,
                                                StateCode = p.StateCode
                                            }).OrderBy(s => s.Pincode);
            return await Query.ToListAsync();
        }

        private async Task<List<APICities>> GetCitiesByPinCode(string stateCode)
        {
            IQueryable<APICities> Query = (from p in _db.PinCodes
                                           where (p.IsDeleted == false && p.StateCode == stateCode)
                                           select new APICities
                                           {
                                               CityCode = p.City,
                                               City = p.City
                                           }).Distinct().OrderBy(s => s.City);

            return await Query.ToListAsync();
        }
    }
}
