﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;
using User.API.Repositories.Interface;

namespace User.API.Repositories
{
    public abstract class Repository<T> : IRepository<T> where T : class
    {
        private readonly DbContext _context;
        private DbSet<T> _entities;
        string errorMessage = string.Empty;

        public Repository(DbContext context)
        {
            this._context = context;
            this._entities = context.Set<T>();
        }

        public void Delete(T entity)
        {
            if (entity == null)
            {
                throw new ArgumentNullException("entity");
            }
            _entities.Remove(entity);
            _context.SaveChanges();
        }

        public async virtual Task DeleteAsync(T entity)
        {
            if (entity == null)
            {
                throw new ArgumentNullException("entity");
            }
            this._entities.Remove(entity);
            await this._context.SaveChangesAsync();
        }

        public T Get(int id)
        {
            return _entities.Find(id);
        }

        public async virtual Task<T> GetAsync(int id)
        {
            try
            {
                var entity = this._entities.FindAsync(id);
                this._entities.AsNoTracking();
                this._context.Entry(entity.Result).State = EntityState.Detached;
                return await entity;
            }
            catch (Exception ex)
            {
                string e = ex.Message;
            }
            return null;
        }

        public IEnumerable<T> GetAll()
        {
            return _entities.AsEnumerable();
        }

        public async Task<IEnumerable<T>> GetAllAsync()
        {
            return await this._entities.AsNoTracking().ToListAsync();
        }

        public async Task<List<T>> GetAll(Expression<Func<T, bool>> match)
        {
            return await this._entities.Where(match).ToListAsync();
        }

        public async Task<int> CountAsync()
        {
            return await this._entities.CountAsync();
        }

        public async Task<bool> FindAsync(Expression<Func<T, bool>> match)
        {
            if (await this._entities.Where(match).CountAsync() > 0)
                return true;
            else
                return false;
        }


        public void Add(T entity)
        {
            if (entity == null)
            {
                throw new ArgumentNullException("entity");
            }
            _entities.Add(entity);
            _context.SaveChanges();
        }

        public async virtual Task AddAsync(T entity)
        {
            using (var transaction = this._context.Database.BeginTransaction())
            {
                try
                {
                    this._context.Entry(entity).State = EntityState.Added;
                    await this._context.SaveChangesAsync();
                    transaction.Commit();
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex);
                    transaction.Rollback();
                    throw ex;
                }
            }
        }

        public async virtual Task<T> AddAndReturnEntityAsync(T entity)
        {
            using (var transaction = this._context.Database.BeginTransaction())
            {
                try
                {
                    this._context.Entry(entity).State = EntityState.Added;
                    int Id = await this._context.SaveChangesAsync();
                    transaction.Commit();
                    //var AddedEntity = this._entities.FindAsync(Id);
                    this._context.Entry(entity).State = EntityState.Detached;
                    return entity;
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex);
                    transaction.Rollback();
                    throw ex;
                }
            }
            return entity;
        }

        public void Update(T entity)
        {
            if (entity == null)
            {
                throw new ArgumentNullException("entity");
            }
            _context.SaveChanges();
        }

        public async virtual Task UpdateAsync(T entity)
        {
            using (var transaction = this._context.Database.BeginTransaction())
            {
                try
                {
                    this._context.Entry(entity).State = EntityState.Modified;
                    await this._context.SaveChangesAsync();
                    transaction.Commit();
                }
                catch (Exception ex)
                {
                    string e = ex.Message;
                    transaction.Rollback();
                    throw ex;
                }
            }
        }
    }
}
