﻿using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Linq;
using System.Threading.Tasks;
using User.API.APIModel;
using User.API.Data;
using User.API.Models;
using User.API.Repositories.Interface;

namespace User.API.Repositories
{
    public class IncidentReportRepository : Repository<IncidentReport>, IIncidentReportRepository
    {
        private UserDbContext _db;
        private readonly ICompetencyRepository _competencyRepository;

        public IncidentReportRepository(UserDbContext context, ICompetencyRepository competencyRepository) : base(context)
        {
            _db = context;
            _competencyRepository = competencyRepository;
        }

        public async Task<List<APIIncidentReport>> GetReportedIncidents(int loggedInUserDBId, string loggedInUserOrganizationCode, string role, APISearchIncident searchInfo)
        {
            List<APIIncidentReport> incidentReports = new List<APIIncidentReport>();
            IQueryable<APIIncidentReport> Query = incidentReports.AsQueryable();
            try
            {
                Query = (from i in _db.IncidentReport.Where(x => x.IsDeleted == false && x.OrganizationCode == loggedInUserOrganizationCode
                                                            && x.LinkedToDepartmentId == (searchInfo.DepartmentId > 0 ? searchInfo.DepartmentId : x.LinkedToDepartmentId)
                                                            && (!string.IsNullOrWhiteSpace(searchInfo.status) && searchInfo.status == "Open" ? x.Status != Helper.IncidentReportingStatus.Closed
                                                                :!string.IsNullOrWhiteSpace(searchInfo.status) && searchInfo.status == "Assigned" || searchInfo.status == "NotAssigned" ? x.Status != Helper.IncidentReportingStatus.Closed && x.Status != Helper.IncidentReportingStatus.Cancelled && 
                                                                                    (searchInfo.status == "Assigned" ? x.IsAssigned : !x.IsAssigned)
                                                                : string.IsNullOrWhiteSpace(searchInfo.status) ? x.Status == x.Status
                                                                : x.Status == searchInfo.status)
                                                             && (x.CreatedBy != loggedInUserDBId ? x.Status != Helper.IncidentReportingStatus.Draft : true) )
                         join c in _db.IncidentCategory.Where(x => x.IsDeleted == false) on i.IncidentCategoryId equals c.Id
                         join d in _db.Department.Where(x => x.IsDeleted == false) on i.LinkedToDepartmentId equals d.Id
                         join u in _db.UserMaster on i.CreatedBy equals u.Id
                         join ia in _db.IncidentAssignment.Where(x => x.IsDeleted == false) on i.Id equals ia.ReferenceIncidentId
                         into temp
                         from IA in temp.DefaultIfEmpty()
                         where (searchInfo.AssignedTo > 0 && IA != null ? IA.PrimaryAssignToId == searchInfo.AssignedTo || IA.SecondaryAssignToId == searchInfo.AssignedTo : true)
                         select new APIIncidentReport
                         {
                             Id = i.Id,
                             IncidentCategory = c.Category,
                             IncidentLocation = i.IncidentLocation,
                             LinkedToDepartment = d.Name,
                             Description = i.Description,
                             Photo = i.Photo,
                             AdditionalDescription = i.AdditionalDescription,
                             Status = i.Status,
                             ReportStatus = "Created",
                             ReportedDate = i.CreatedDate,
                             ReportedUserName = u.Name,
                             IsAssigned = i.IsAssigned,
                             PrimaryAssignedToId = IA != null ? IA.PrimaryAssignToId : 0,
                             SecondaryAssignedToId = IA != null ? IA.SecondaryAssignToId : 0,
                             AssignmentDate = IA != null ? IA.CreatedDate : DateTime.MinValue,
                             RemarkByAdmin = IA != null ? IA.Remarks : "",
                             ModifiedDate = i.ModifiedDate,
                             IncidentCategoryId = i.IncidentCategoryId,
                             LinkedToDepartmentId = i.LinkedToDepartmentId,
                             CompetencyIds = i.CompetencyIds,
                             ClosureDate = i.ClosureDate
                         }).OrderByDescending(s => searchInfo.status != "Open" ? s.ModifiedDate :  s.ReportedDate);

                incidentReports = await Query.ToListAsync();

                //IQueryable<APIIncidentReport> report = reports.AsQueryable();

                if (searchInfo.page != -1)
                    incidentReports = incidentReports.Skip((searchInfo.page - 1) * searchInfo.pageSize).ToList();
                if (searchInfo.pageSize != -1)
                    incidentReports = incidentReports.Take(searchInfo.pageSize).ToList();

                foreach (var incident in incidentReports)
                {
                    if (incident.IsAssigned)
                    {
                        incident.PrimaryAssignedTo = (//from ia in _db.IncidentAssignment.Where(x => x.IsDeleted == false && x.ReferenceIncidentId == incident.Id)
                                                      from u in _db.UserMaster.Where(x => x.Id == incident.PrimaryAssignedToId) //on ia.PrimaryAssignToId equals u.Id
                                                      select u.Name).FirstOrDefault();
                        if (incident.SecondaryAssignedToId > 0)
                        {
                            incident.SecondaryAssignedTo = (//from ia in _db.IncidentAssignment.Where(x => x.IsDeleted == false && x.ReferenceIncidentId == incident.Id)
                                                      from u in _db.UserMaster.Where(x => x.Id == incident.SecondaryAssignedToId) //on ia.SecondaryAssignToId equals u.Id
                                                      select u.Name).FirstOrDefault();
                        }
                    }
                    if (!string.IsNullOrWhiteSpace(incident.CompetencyIds))
                    {
                        incident.Competencies = new List<APICompetency>();
                        incident.Competencies.AddRange(await _competencyRepository.GetCompetenciesAssignedToIncedent(loggedInUserOrganizationCode, incident.Id));
                    }
                }

                return incidentReports;
            }
            catch (Exception e)
            {
                return incidentReports;
            }
        }
        public async Task<int> GetReportedIncidentsCount(int loggedInUserDBId, string loggedInUserOrganizationCode, string role, APISearchIncident searchInfo)
        {
            IQueryable<APIIncidentReport> Query = (from i in _db.IncidentReport.Where(x => x.IsDeleted == false && x.OrganizationCode == loggedInUserOrganizationCode
                                                            && x.LinkedToDepartmentId == (searchInfo.DepartmentId > 0 ? searchInfo.DepartmentId : x.LinkedToDepartmentId)
                                                            && (!string.IsNullOrWhiteSpace(searchInfo.status) && searchInfo.status == "Open" ? x.Status != Helper.IncidentReportingStatus.Closed
                                                                : !string.IsNullOrWhiteSpace(searchInfo.status) && searchInfo.status == "Assigned" || searchInfo.status == "NotAssigned" ? x.Status != Helper.IncidentReportingStatus.Closed && x.Status != Helper.IncidentReportingStatus.Cancelled &&
                                                                                    (searchInfo.status == "Assigned" ? x.IsAssigned : !x.IsAssigned)
                                                                : string.IsNullOrWhiteSpace(searchInfo.status) ? x.Status == x.Status
                                                                : x.Status == searchInfo.status)
                                                             && (x.CreatedBy != loggedInUserDBId ? x.Status != Helper.IncidentReportingStatus.Draft : true))
                                                   join c in _db.IncidentCategory.Where(x => x.IsDeleted == false) on i.IncidentCategoryId equals c.Id
                                                   join d in _db.Department.Where(x => x.IsDeleted == false) on i.LinkedToDepartmentId equals d.Id
                                                   join u in _db.UserMaster on i.CreatedBy equals u.Id
                                                   join ia in _db.IncidentAssignment.Where(x => x.IsDeleted == false) on i.Id equals ia.ReferenceIncidentId
                                                   into temp
                                                   from IA in temp.DefaultIfEmpty()
                                                   where (searchInfo.AssignedTo > 0 && IA != null ? IA.PrimaryAssignToId == searchInfo.AssignedTo || IA.SecondaryAssignToId == searchInfo.AssignedTo : true)
                                                   select new APIIncidentReport
                                                   {
                                                       Id = i.Id,
                                                       IncidentCategory = c.Category,
                                                       IncidentLocation = i.IncidentLocation,
                                                       LinkedToDepartment = d.Name,
                                                       Description = i.Description,
                                                       Photo = i.Photo,
                                                       AdditionalDescription = i.AdditionalDescription,
                                                       Status = i.Status,
                                                       ReportStatus = "Created",
                                                       ReportedDate = i.CreatedDate,
                                                       ReportedUserName = u.Name,
                                                       IsAssigned = i.IsAssigned,
                                                       PrimaryAssignedToId = IA != null ? IA.PrimaryAssignToId : 0,
                                                       SecondaryAssignedToId = IA != null ? IA.SecondaryAssignToId : 0,
                                                       AssignmentDate = IA != null ? IA.CreatedDate : DateTime.MinValue,
                                                   });
            return await Query.CountAsync();
        }

        public async Task<List<APIIncidentReport>> GetIncidentReports(int loggedInUserDBId, string loggedInUserOrganizationCode, int page, int pageSize, string filter = null, string search = null)
        {
            IQueryable<APIIncidentReport> Query = (from i in _db.IncidentReport
                                                   join c in _db.IncidentCategory on i.IncidentCategoryId equals c.Id
                                                   join d in _db.Department on i.LinkedToDepartmentId equals d.Id
                                                   where (i.IsDeleted == false && i.OrganizationCode == loggedInUserOrganizationCode && i.CreatedBy==loggedInUserDBId)
                                                   select new APIIncidentReport
                                                   {
                                                       Id = i.Id,
                                                       IncidentCategory = c.Category,
                                                       IncidentLocation = i.IncidentLocation,
                                                       LinkedToDepartment = d.Name,
                                                       Description = i.Description,
                                                       Photo = i.Photo,
                                                       AdditionalDescription = i.AdditionalDescription,
                                                       Status = i.Status,
                                                       CompetencyIds = i.CompetencyIds,
                                                       ClosureDate = i.ClosureDate
                                                   }).OrderByDescending(a=>a.Id);

            if (page != -1)
                Query = Query.Skip((page - 1) * pageSize);
            if (pageSize != -1)
                Query = Query.Take(pageSize);

            List<APIIncidentReport> incidents = await Query.ToListAsync();
            foreach (APIIncidentReport inc in incidents.Where(x => !string.IsNullOrWhiteSpace(x.CompetencyIds)))
            {
                inc.Competencies = new List<APICompetency>();
                inc.Competencies.AddRange(await _competencyRepository.GetCompetenciesAssignedToIncedent(loggedInUserOrganizationCode, inc.Id));
            }
            return incidents;
        }

        public async Task<int> GetIncidentReportsCount(int loggedInUserDBId, string loggedInUserOrganizationCode, string filter = null, string search = null)
        {
            return await (from i in _db.IncidentReport
                          join c in _db.IncidentCategory on i.IncidentCategoryId equals c.Id
                          join d in _db.Department on i.LinkedToDepartmentId equals d.Id
                          where (i.IsDeleted == false && i.OrganizationCode == loggedInUserOrganizationCode && i.CreatedBy == loggedInUserDBId)
                          select i.Id).CountAsync();
        }

        public async Task<List<APIOpenClosedIncidentInfo>> GetOpenClosedIncidentsReport(string loggedInUserOrganizationCode, APIOpenClosedIncidentSearch apiOpenClosedIncidentSearch)
        {
            try
            {
                using (DbConnection connection = this._db.Database.GetDbConnection())
                {
                    if (connection.State == ConnectionState.Broken || connection.State == ConnectionState.Closed)
                        connection.Open();

                    List<APIOpenClosedIncidentInfo> apiOpenClosedIncidentInfo = new List<APIOpenClosedIncidentInfo>();

                    APIOpenClosedIncidentInfo item = null;
                    using (var cmd = connection.CreateCommand())
                    {
                        cmd.CommandText = "GetOpenClosedIncidents";
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.Add(new SqlParameter("@LoggedInUserOrganizationCode", SqlDbType.VarChar) { Value = loggedInUserOrganizationCode });
                        cmd.Parameters.Add(new SqlParameter("@StartDate", SqlDbType.Date) { Value = apiOpenClosedIncidentSearch.startDate.Date });
                        cmd.Parameters.Add(new SqlParameter("@EndDate", SqlDbType.Date) { Value = apiOpenClosedIncidentSearch.endDate.Date });
                        cmd.Parameters.Add(new SqlParameter("@Status", SqlDbType.VarChar) { Value = apiOpenClosedIncidentSearch.status });
                        cmd.Parameters.Add(new SqlParameter("@Category", SqlDbType.VarChar) { Value = apiOpenClosedIncidentSearch.category });
                        cmd.Parameters.Add(new SqlParameter("@DepartmentId", SqlDbType.Int) { Value = apiOpenClosedIncidentSearch.departmentId });
                        cmd.Parameters.Add(new SqlParameter("@CompetencyIds", SqlDbType.VarChar) { Value = apiOpenClosedIncidentSearch.CompetencyIds });

                        DbDataReader reader = await cmd.ExecuteReaderAsync();
                        DataTable dt = new DataTable();
                        dt.Load(reader);

                        if (dt.Rows.Count > 0)
                        {
                            foreach (DataRow row in dt.Rows)
                            {
                                item = new APIOpenClosedIncidentInfo
                                {
                                    IncidentId = Convert.ToInt32(row["IncidentId"].ToString()),
                                    DateReported = Convert.ToDateTime(row["DateReported"].ToString()),
                                    ReportedBy = row["ReportedBy"].ToString(),
                                    Designation = row["Designation"].ToString(),
                                    BriefDescription = row["BriefDescription"].ToString(),
                                    IncidentCategory = row["IncidentCategory"].ToString(),
                                    Status = row["Status"].ToString(),
                                    LastActionTaken = string.IsNullOrEmpty(row["LastActionTaken"].ToString()) ? (DateTime?)null : Convert.ToDateTime(row["LastActionTaken"].ToString()),
                                    CorrectiveActions = row["CorrectiveActions"].ToString(),
                                    ATRReportedBy = row["ATRReportedBy"].ToString(),
                                    Department = row["Department"].ToString(),
                                    CompetencyIds = row["CompetencyIds"].ToString(),
                                    ClosureDate = string.IsNullOrEmpty(row["ClosureDate"].ToString()) ? DateTime.MinValue : Convert.ToDateTime(row["ClosureDate"].ToString()),
                                };
                                apiOpenClosedIncidentInfo.Add(item);
                            }
                        }
                        reader.Dispose();
                    }
                    connection.Close();
                    foreach (APIOpenClosedIncidentInfo inc in apiOpenClosedIncidentInfo.Where(x => !string.IsNullOrWhiteSpace(x.CompetencyIds)))
                    {
                        inc.Competencies = new List<APICompetency>();
                        inc.Competencies.AddRange(await _competencyRepository.GetCompetenciesAssignedToIncedent(loggedInUserOrganizationCode, inc.IncidentId));
                    }
                    return apiOpenClosedIncidentInfo;
                }
            }
            catch (System.Exception ex)
            {
                throw ex;
            }
        }
        public async Task<List<APIIncidentReport>> GetIncidentReportsList(string loggedInUserOrganizationCode, int page, int pageSize, string filter = null, string search = null)
        {
            IQueryable<APIIncidentReport> Query = (from i in _db.IncidentReport
                                                   join c in _db.IncidentCategory on i.IncidentCategoryId equals c.Id
                                                   join d in _db.Department on i.LinkedToDepartmentId equals d.Id
                                                   join u in _db.UserMaster on i.CreatedBy equals u.Id
                                                   where (i.IsDeleted == false && i.OrganizationCode == loggedInUserOrganizationCode && i.Status==Helper.IncidentReportingStatus.Reported
                                                    && !(from a in _db.IncidentAssignment select a.ReferenceIncidentId).Contains(i.Id))
                                                   select new APIIncidentReport
                                                   {
                                                       Id = i.Id,
                                                       IncidentCategory = c.Category,
                                                       IncidentLocation = i.IncidentLocation,
                                                       LinkedToDepartment = d.Name,
                                                       Description = GetTrimDescription(i.Description),
                                                       Photo = i.Photo,
                                                       AdditionalDescription = i.AdditionalDescription,
                                                       Status = i.Status,
                                                       ReportedDate = i.CreatedDate,
                                                       ReportedUserName = u.Name,
                                                       CompetencyIds = i.CompetencyIds,
                                                       ClosureDate = i.ClosureDate
                                                   });

            if (page != -1)
                Query = Query.Skip((page - 1) * pageSize);
            if (pageSize != -1)
                Query = Query.Take(pageSize);

            List<APIIncidentReport> incidents = await Query.ToListAsync();
            foreach (APIIncidentReport inc in incidents.Where(x => !string.IsNullOrWhiteSpace(x.CompetencyIds)))
            {
                inc.Competencies = new List<APICompetency>();
                inc.Competencies.AddRange(await _competencyRepository.GetCompetenciesAssignedToIncedent(loggedInUserOrganizationCode, inc.Id));
            }
            return incidents;
        }
        public static string GetTrimDescription(string description)
        {
            int length = 60;
            // Return if the string is less than or equal to the truncation length
            if (description == null || description.Length <= length)
                return description;

            // Do a simple tuncation at the desired length
            string result = description.Substring(0, length);

            // Truncate the string at the word
            // List of characters that denote the start or a new word (add to or remove more as necessary)
            //List<char> alternativeCutOffs = new List<char>() { ' ', ',', '.', '?', '/', ':', ';', '\'', '\"', '\'', '-' };
            List<char> alternativeCutOffs = new List<char>() { ' ' };

            // Get the index of the last space in the truncated string
            int lastSpace = result.LastIndexOf(' ');

            // If the last space index isn't -1 and also the next character in the original
            // string isn't contained in the alternativeCutOffs List (which means the previous
            // truncation actually truncated at the end of a word),then shorten string to the last space
            if (lastSpace != -1 && (description.Length >= length + 1 && !alternativeCutOffs.Contains(description.ToCharArray()[length])))
                result = result.Remove(lastSpace);

            result += " ...";

            return result;
        }

        public async Task<List<APIIncidentReport>> GetIncidentReportsForManagers(int loggedInUserDBId, string loggedInUserOrganizationCode, string status, int page, int pageSize, string filter = null, string search = null)
        {
            List<APIIncidentReport> incidentReports = new List<APIIncidentReport>();
            IQueryable<APIIncidentReport> Query = incidentReports.AsQueryable();

            if (status.Equals("Open"))
            {
                Query = (from i in _db.IncidentReport
                         join c in _db.IncidentCategory on i.IncidentCategoryId equals c.Id
                         join d in _db.Department on i.LinkedToDepartmentId equals d.Id
                         join u in _db.UserMaster on i.CreatedBy equals u.Id
                         where (i.IsDeleted == false && i.Status == Helper.IncidentReportingStatus.Reported || i.Status == Helper.IncidentReportingStatus.WorkInProgress && i.OrganizationCode == loggedInUserOrganizationCode && i.CreatedBy == loggedInUserDBId)
                         select new APIIncidentReport
                         {
                             Id = i.Id,
                             IncidentCategory = c.Category,
                             IncidentLocation = i.IncidentLocation,
                             LinkedToDepartment = d.Name,
                             Description = i.Description,
                             Photo = i.Photo,
                             AdditionalDescription = i.AdditionalDescription,
                             Status = i.Status,
                             ReportStatus = "Created",
                             ReportedDate = i.CreatedDate,
                             ReportedUserName = u.Name,
                             CompetencyIds = i.CompetencyIds
                         }).OrderByDescending(s => s.Id);

                IQueryable<APIIncidentReport> QueryAssigned = (from i in _db.IncidentAssignment
                                                               join r in _db.IncidentReport on i.ReferenceIncidentId equals r.Id
                                                               join c in _db.IncidentCategory on r.IncidentCategoryId equals c.Id
                                                               join d in _db.Department on r.LinkedToDepartmentId equals d.Id
                                                               join u in _db.UserMaster on r.CreatedBy equals u.Id
                                                               where (i.IsDeleted == false && i.OrganizationCode == loggedInUserOrganizationCode && r.Status == Helper.IncidentReportingStatus.Reported || r.Status == Helper.IncidentReportingStatus.WorkInProgress && (i.PrimaryAssignToId == loggedInUserDBId || i.SecondaryAssignToId == loggedInUserDBId))
                                                               select new APIIncidentReport
                                                               {
                                                                   Id = r.Id,
                                                                   IncidentCategory = c.Category,
                                                                   IncidentLocation = r.IncidentLocation,
                                                                   LinkedToDepartment = d.Name,
                                                                   Description = r.Description,
                                                                   Photo = r.Photo,
                                                                   AdditionalDescription = r.AdditionalDescription,
                                                                   Status = r.Status,
                                                                   ReportStatus = "Assigned",
                                                                   ReportedDate = r.CreatedDate,
                                                                   ReportedUserName = u.Name,
                                                               }).OrderByDescending(s => s.Id);

                List<APIIncidentReport> reports = await Query.ToListAsync();
                reports.AddRange(QueryAssigned);
                IQueryable<APIIncidentReport> report = reports.AsQueryable();

                if (page != -1)
                    report = report.Skip((page - 1) * pageSize);
                if (pageSize != -1)
                    report = report.Take(pageSize);

                return report.ToList();
            }
            else
            {
                Query = (from i in _db.IncidentReport
                         join c in _db.IncidentCategory on i.IncidentCategoryId equals c.Id
                         join d in _db.Department on i.LinkedToDepartmentId equals d.Id
                         join u in _db.UserMaster on i.CreatedBy equals u.Id
                         where (i.IsDeleted == false && i.Status == status && i.OrganizationCode == loggedInUserOrganizationCode && i.CreatedBy == loggedInUserDBId)
                         select new APIIncidentReport
                         {
                             Id = i.Id,
                             IncidentCategory = c.Category,
                             IncidentLocation = i.IncidentLocation,
                             LinkedToDepartment = d.Name,
                             Description = i.Description,
                             Photo = i.Photo,
                             AdditionalDescription = i.AdditionalDescription,
                             Status = i.Status,
                             ReportStatus = "Created",
                             ReportedDate = i.CreatedDate,
                             ReportedUserName = u.Name,
                         });

                IQueryable<APIIncidentReport> QueryAssigned = (from i in _db.IncidentAssignment
                                                               join r in _db.IncidentReport on i.ReferenceIncidentId equals r.Id
                                                               join c in _db.IncidentCategory on r.IncidentCategoryId equals c.Id
                                                               join d in _db.Department on r.LinkedToDepartmentId equals d.Id
                                                               join u in _db.UserMaster on r.CreatedBy equals u.Id
                                                               where (i.IsDeleted == false && i.OrganizationCode == loggedInUserOrganizationCode && r.Status == status && (i.PrimaryAssignToId == loggedInUserDBId || i.SecondaryAssignToId == loggedInUserDBId))
                                                               select new APIIncidentReport
                                                               {
                                                                   Id = r.Id,
                                                                   IncidentCategory = c.Category,
                                                                   IncidentLocation = r.IncidentLocation,
                                                                   LinkedToDepartment = d.Name,
                                                                   Description = r.Description,
                                                                   Photo = r.Photo,
                                                                   AdditionalDescription = r.AdditionalDescription,
                                                                   Status = r.Status,
                                                                   ReportStatus = "Assigned",
                                                                   ReportedDate = r.CreatedDate,
                                                                   ReportedUserName = u.Name,
                                                               }).OrderByDescending(s => s.Id);

                List<APIIncidentReport> reports = await Query.ToListAsync();
                reports.AddRange(QueryAssigned);
                var report = reports.AsQueryable();

                if (page != -1)
                    report = report.Skip((page - 1) * pageSize);
                if (pageSize != -1)
                    report = report.Take(pageSize);

                return report.ToList();
            }

        }
        public async Task<int> GetIncidentReportsForManagersCount(int loggedInUserDBId, string loggedInUserOrganizationCode, string status, string filter = null, string search = null)
        {
            List<APIIncidentReport> incidentReports = new List<APIIncidentReport>();
            int Query;

            if (status.Equals("Open"))
            {
                Query = await (from i in _db.IncidentReport
                               join c in _db.IncidentCategory on i.IncidentCategoryId equals c.Id
                               join d in _db.Department on i.LinkedToDepartmentId equals d.Id
                               join u in _db.UserMaster on i.CreatedBy equals u.Id
                               where (i.IsDeleted == false && i.Status == Helper.IncidentReportingStatus.Reported || i.Status == Helper.IncidentReportingStatus.WorkInProgress && i.OrganizationCode == loggedInUserOrganizationCode && i.CreatedBy == loggedInUserDBId)
                               select i.Id).CountAsync();

                int QueryAssigned = await (from i in _db.IncidentAssignment
                                           join r in _db.IncidentReport on i.ReferenceIncidentId equals r.Id
                                           join c in _db.IncidentCategory on r.IncidentCategoryId equals c.Id
                                           join d in _db.Department on r.LinkedToDepartmentId equals d.Id
                                           join u in _db.UserMaster on r.CreatedBy equals u.Id
                                           where (i.IsDeleted == false && i.OrganizationCode == loggedInUserOrganizationCode && r.Status == Helper.IncidentReportingStatus.Reported || r.Status == Helper.IncidentReportingStatus.WorkInProgress && (i.PrimaryAssignToId == loggedInUserDBId || i.SecondaryAssignToId == loggedInUserDBId))
                                           select i.Id).CountAsync();
                int report = Query + QueryAssigned;
                return report;
            }
            else
            {
                Query = await (from i in _db.IncidentReport
                               join c in _db.IncidentCategory on i.IncidentCategoryId equals c.Id
                               join d in _db.Department on i.LinkedToDepartmentId equals d.Id
                               join u in _db.UserMaster on i.CreatedBy equals u.Id
                               where (i.IsDeleted == false && i.Status == status && i.OrganizationCode == loggedInUserOrganizationCode && i.CreatedBy == loggedInUserDBId)
                               select i.Id).CountAsync();

                int QueryAssigned = await (from i in _db.IncidentAssignment
                                           join r in _db.IncidentReport on i.ReferenceIncidentId equals r.Id
                                           join c in _db.IncidentCategory on r.IncidentCategoryId equals c.Id
                                           join d in _db.Department on r.LinkedToDepartmentId equals d.Id
                                           join u in _db.UserMaster on r.CreatedBy equals u.Id
                                           where (i.IsDeleted == false && i.OrganizationCode == loggedInUserOrganizationCode && r.Status == status && (i.PrimaryAssignToId == loggedInUserDBId || i.SecondaryAssignToId == loggedInUserDBId))
                                           select i.Id).CountAsync();
                int report = Query + QueryAssigned;
                return report;
            }
        }

        public async Task<List<APIIncidentReport>> GetSingleIncidentReportsList(string loggedInUserOrganizationCode, int id)
        {
            IQueryable<APIIncidentReport> Query = (from i in _db.IncidentReport
                                                   join c in _db.IncidentCategory on i.IncidentCategoryId equals c.Id
                                                   join d in _db.Department on i.LinkedToDepartmentId equals d.Id
                                                   join u in _db.UserMaster on i.CreatedBy equals u.Id
                                                   where (i.IsDeleted == false && i.OrganizationCode == loggedInUserOrganizationCode && i.Id == id)
                                                   select new APIIncidentReport
                                                   {
                                                       Id = i.Id,
                                                       IncidentCategory = c.Category,
                                                       IncidentLocation = i.IncidentLocation,
                                                       LinkedToDepartment = d.Name,
                                                       Description = GetTrimDescription(i.Description),
                                                       Photo = i.Photo,
                                                       AdditionalDescription = i.AdditionalDescription,
                                                       Status = i.Status,
                                                       ReportedDate = i.CreatedDate,
                                                       ReportedUserName = u.Name
                                                   });

            return await Query.ToListAsync();
        }

        public async Task<List<APIIncidentReport>> GetAllIncidents(string loggedInUserOrganizationCode, int page, int pageSize, string filter = null, string search = null)
        {
            IQueryable<APIIncidentReport> Query = (from i in _db.IncidentReport
                                                   join c in _db.IncidentCategory on i.IncidentCategoryId equals c.Id
                                                   join d in _db.Department on i.LinkedToDepartmentId equals d.Id
                                                   join u in _db.UserMaster on i.CreatedBy equals u.Id
                                                   where (i.IsDeleted == false && i.OrganizationCode == loggedInUserOrganizationCode)
                                                   select new APIIncidentReport
                                                   {
                                                       Id = i.Id,
                                                       IncidentCategory = c.Category,
                                                       IncidentLocation = i.IncidentLocation,
                                                       LinkedToDepartment = d.Name,
                                                       Description = i.Description,
                                                       Photo = i.Photo,
                                                       AdditionalDescription = i.AdditionalDescription,
                                                       Status = i.Status,
                                                       ReportedDate = i.CreatedDate,
                                                       ReportedUserName = u.Name,
                                                       CompetencyIds = i.CompetencyIds,
                                                       ClosureDate = i.ClosureDate
                                                   }).OrderByDescending(a => a.Id);

            if (page != -1)
                Query = Query.Skip((page - 1) * pageSize);
            if (pageSize != -1)
                Query = Query.Take(pageSize);

            List<APIIncidentReport> incidents = await Query.ToListAsync();
            foreach (APIIncidentReport inc in incidents.Where(x => !string.IsNullOrWhiteSpace(x.CompetencyIds)))
            {
                inc.Competencies = new List<APICompetency>();
                inc.Competencies.AddRange(await _competencyRepository.GetCompetenciesAssignedToIncedent(loggedInUserOrganizationCode, inc.Id));
            }
            return incidents;
        }

        public async Task<int> GetAllIncidentsCount(string loggedInUserOrganizationCode, string filter = null, string search = null)
        {
            return await(from i in _db.IncidentReport
                         join c in _db.IncidentCategory on i.IncidentCategoryId equals c.Id
                         join d in _db.Department on i.LinkedToDepartmentId equals d.Id
                         join u in _db.UserMaster on i.CreatedBy equals u.Id
                         where (i.IsDeleted == false && i.OrganizationCode == loggedInUserOrganizationCode)
                         select i.Id).CountAsync();
        }

        public async Task<int> GetStatusCount(string loggedInUserOrganizationCode, string status)
        {
            switch (status)
            {
                case Helper.IncidentReportingStatus.Reported:
                    return await (from i in _db.IncidentReport
                                  where (i.IsDeleted == false && i.Status == Helper.IncidentReportingStatus.Reported && i.OrganizationCode == loggedInUserOrganizationCode)
                                  select i.Id).CountAsync();

                case Helper.IncidentReportingStatus.Assigned:
                    return await (from i in _db.IncidentReport
                                  where (i.IsDeleted == false && i.IsAssigned == true && i.OrganizationCode == loggedInUserOrganizationCode)
                                  select i.Id).CountAsync();

                case Helper.IncidentReportingStatus.Closed:
                    return await (from i in _db.IncidentReport
                                  where (i.IsDeleted == false && i.Status == Helper.IncidentReportingStatus.Closed && i.OrganizationCode == loggedInUserOrganizationCode)
                                  select i.Id).CountAsync();
                case Helper.IncidentReportingStatus.WorkInProgress:
                    return await (from i in _db.IncidentReport
                                  where (i.IsDeleted == false && i.Status == Helper.IncidentReportingStatus.WorkInProgress && i.OrganizationCode == loggedInUserOrganizationCode)
                                  select i.Id).CountAsync();

            }
            return 0;
        }

        public async Task<double> GetAverageClosuerPeriod(string loggedInUserOrganizationCode)
        {
            try
            {
                var Query = (from i in _db.IncidentReport.Where(x => x.IsDeleted == false && x.Status == Helper.IncidentReportingStatus.Closed && x.OrganizationCode == loggedInUserOrganizationCode)
                                         join a in _db.ActionTakenReport.Where(x => x.IsDeleted == false && x.IncidentStatus == Helper.IncidentReportingStatus.Closed )
                                                        on i.Id equals a.ReferenceIncidentId into action
                                         from a in action
                                         select a.ModifiedDate - i.CreatedDate);
                if (Query.Count() > 0)
                {
                    List<double> list = await Query.Select(x=>x.TotalDays).ToListAsync();
                    return list.Average();
                }
            }
            catch (Exception e)
            {
                return 0;
            }
            //int closedCount = await (from i in _db.IncidentReport
            //                         where (i.IsDeleted == false && i.Status == Helper.IncidentReportingStatus.Closed && i.OrganizationCode == loggedInUserOrganizationCode)
            //                         select i.Id).CountAsync();

            //double closedCountSum = (from i in _db.IncidentReport
            //                            where (i.IsDeleted == false && i.Status == Helper.IncidentReportingStatus.Closed && i.OrganizationCode == loggedInUserOrganizationCode)
            //                            select i.ClosurePeriod).Sum();

          return 0;
        }

        public async Task<int> GetDaysSinceLastIncident(string loggedInUserOrganizationCode)
        {
            APIDate apiDate = await GetLastReportedDate(loggedInUserOrganizationCode);

            if (apiDate != null)
            {
                DateTime lastReportedDate = apiDate.Date;
                TimeSpan span = DateTime.Now.Date.Subtract(lastReportedDate.Date);
                //if the incident logged today then send 1
                //if (span.Days == 0)
                //    return 1;
                return span.Days;
            }
            return 0;
        }

        private async Task<APIDate> GetLastReportedDate(string loggedInUserOrganizationCode)
        {
            IQueryable<APIDate> Query = (from i in _db.IncidentReport
                                          where (i.IsDeleted == false && i.Status != Helper.IncidentReportingStatus.Draft 
                                          && i.Status != Helper.IncidentReportingStatus.Cancelled
                                          && i.OrganizationCode == loggedInUserOrganizationCode)
                                          select new APIDate { Date = i.CreatedDate }).OrderByDescending(s => s.Date).Take(1);

            return await Query.FirstOrDefaultAsync();
        }
    }
}
