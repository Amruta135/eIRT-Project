﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using User.API.APIModel;
using User.API.Data;
using User.API.Helper;
using User.API.Models;
using User.API.Repositories.Interface;

namespace User.API.Repositories
{
    public class IncidentCategoryRepository : Repository<IncidentCategory>, IIncidentCategoryRepository
    {
        private UserDbContext _db;

        public IncidentCategoryRepository(UserDbContext context) : base(context)
        {
            _db = context;
        }

        public async Task<List<APIIncidentCategory>> GetIncidentCategories(string loggedInUserOrganizationCode, int page, int pageSize, string filter = null, string search = null)
        {
            IQueryable<APIIncidentCategory> Query = (from i in _db.IncidentCategory
                                                     where (i.IsDeleted == false && i.OrganizationCode == loggedInUserOrganizationCode)
                                                     select new APIIncidentCategory
                                                     {
                                                         Id = i.Id,
                                                         Category = i.Category
                                                     });

            if (page != -1)
                Query = Query.Skip((page - 1) * pageSize);
            if (pageSize != -1)
                Query = Query.Take(pageSize);

            return await Query.ToListAsync();

        }

        public async Task<int> GetIncidentCategoriesCount(string loggedInUserOrganizationCode, string filter = null, string search = null)
        {
            return await (from i in _db.IncidentCategory
                          where (i.IsDeleted == false && i.OrganizationCode == loggedInUserOrganizationCode)
                          select i.Id).CountAsync();
        }

        public async Task<int> AddDefaultIncidentCategory(string organizationCode, int loggedInUserDBId)
        {
            try
            {

                if (string.IsNullOrEmpty(organizationCode))
                    return 0;

                if (!await this.FindAsync(s => s.OrganizationCode == organizationCode && s.Category == IncidentCategoryCode.High))
                {
                    IncidentCategory incidentCategory = new IncidentCategory();
                    incidentCategory.OrganizationCode = organizationCode;
                    incidentCategory.Category = IncidentCategoryCode.High;
                    incidentCategory.CreatedDate = DateTime.Now;
                    incidentCategory.ModifiedDate = DateTime.Now;
                    incidentCategory.CreatedBy = loggedInUserDBId;
                    incidentCategory.ModifiedBy = loggedInUserDBId;
                    await AddAndReturnEntityAsync(incidentCategory);
                }

                if (!await this.FindAsync(s => s.OrganizationCode == organizationCode && s.Category == IncidentCategoryCode.Medium))
                {
                    IncidentCategory incidentCategory = new IncidentCategory();
                    incidentCategory.OrganizationCode = organizationCode;
                    incidentCategory.Category = IncidentCategoryCode.Medium;
                    incidentCategory.CreatedDate = DateTime.Now;
                    incidentCategory.ModifiedDate = DateTime.Now;
                    incidentCategory.CreatedBy = loggedInUserDBId;
                    incidentCategory.ModifiedBy = loggedInUserDBId;
                    await AddAndReturnEntityAsync(incidentCategory);
                }

                if (!await this.FindAsync(s => s.OrganizationCode == organizationCode && s.Category == IncidentCategoryCode.Low))
                {
                    IncidentCategory incidentCategory = new IncidentCategory();
                    incidentCategory.OrganizationCode = organizationCode;
                    incidentCategory.Category = IncidentCategoryCode.Low;
                    incidentCategory.CreatedDate = DateTime.Now;
                    incidentCategory.ModifiedDate = DateTime.Now;
                    incidentCategory.CreatedBy = loggedInUserDBId;
                    incidentCategory.ModifiedBy = loggedInUserDBId;
                    await AddAndReturnEntityAsync(incidentCategory);
                }

                return 1;
            }
            catch (System.Exception)
            {
                return 0;
            }
        }
    }
}
