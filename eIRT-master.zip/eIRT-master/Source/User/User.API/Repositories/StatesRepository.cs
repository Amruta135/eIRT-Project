﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Caching.Memory;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using User.API.APIModel;
using User.API.Data;
using User.API.Helper;
using User.API.Repositories.Interface;

namespace User.API.Repositories
{
    public class StatesRepository : Repository<Models.States>, IStatesRepository
    {
        private UserDbContext _db;
        private IMemoryCache _cacheStates;
        public StatesRepository(UserDbContext context, IMemoryCache cacheStates) : base(context)
        {
            _db = context;
            _cacheStates = cacheStates;
        }

        public async Task<List<APIStates>> GetStates()
        {
            return await GetCacheStates();
        }

        private async Task<List<APIStates>> GetCacheStates()
        {
            List<APIStates> cacheEntryStates = new List<APIStates>();
            // Look for cache key.
            if (!_cacheStates.TryGetValue(CacheKeys.States, out cacheEntryStates))
            {
                // Key not in cache, so get data.
                cacheEntryStates = await this.GetStatesInfo();

                // Set cache options.
                var cacheEntryOptions = new MemoryCacheEntryOptions()
                    // Keep in cache for this time, reset time if accessed.
                    .SetSlidingExpiration(TimeSpan.FromHours(8));

                // Save data in cache.
                _cacheStates.Set(CacheKeys.States, cacheEntryStates, cacheEntryOptions);
            }
            return cacheEntryStates.ToList();
        }

        private async Task<List<APIStates>> GetStatesInfo()
        {
            IQueryable<APIStates> Query = (from states in _db.States
                                           where (states.IsDeleted == false)
                                           select new APIStates
                                           {
                                               Code = states.Code,
                                               Name = states.Name,
                                               DisplayOrder = states.DisplayOrder
                                           }).OrderBy(s => s.DisplayOrder).ThenBy(s => s.Code);
            return await Query.ToListAsync();
        }



    }
}
