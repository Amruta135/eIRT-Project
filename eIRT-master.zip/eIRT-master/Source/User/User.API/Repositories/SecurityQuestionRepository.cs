﻿using User.API.Data;
using User.API.Models;
using User.API.Repositories.Interface;

namespace User.API.Repositories
{
    public class SecurityQuestionRepository : Repository<SecurityQuestion>, ISecurityQuestionRepository
    {
        private UserDbContext _db;

        public SecurityQuestionRepository(UserDbContext context) : base(context)
        {
            _db = context;
        }
    }
}
