﻿using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using User.API.APIModel;
using User.API.Data;
using User.API.Models;
using User.API.Repositories.Interface;

namespace User.API.Repositories
{
    public class ActionTakenReportRepository : Repository<ActionTakenReport>, IActionTakenReportRepository
    {
        private UserDbContext _db;

        public ActionTakenReportRepository(UserDbContext context) : base(context)
        {
            _db = context;
        }

        public async Task<List<APIActionTakenReport>> GetActionTakenReports(int loggedInUserDBId, string loggedInUserOrganizationCode, int incidentId, string userRole, int page, int pageSize, string filter = null, string search = null)
        {
            IQueryable<APIActionTakenReport> Query = (from i in _db.ActionTakenReport.Where(x=>x.IsDeleted == false
                                                                                            && x.OrganizationCode == loggedInUserOrganizationCode
                                                                                            && x.ReferenceIncidentId == (incidentId == 0 ? x.ReferenceIncidentId : incidentId))
                                                      join r in _db.IncidentReport.Where(x=>x.IsDeleted == false) on i.ReferenceIncidentId equals r.Id
                                                      join c in _db.IncidentCategory.Where(x=>x.IsDeleted == false) on r.IncidentCategoryId equals c.Id
                                                      join ia in _db.IncidentAssignment.Where(x=>x.IsDeleted == false && (x.PrimaryAssignToId == loggedInUserDBId || x.SecondaryAssignToId == loggedInUserDBId || userRole == Helper.RoleCode.IRT_Client_Admin || userRole == Helper.RoleCode.EHS_Monitor))
                                                                                        on r.Id equals ia.ReferenceIncidentId
                                                      join u in _db.UserMaster on i.ModifiedBy equals u.Id
                                                      //where ()
                                                      select new APIActionTakenReport
                                                      {
                                                          Id = i.Id,
                                                          Category = c.Category,
                                                          ReferenceIncident = r.Description,
                                                          InvestigationFindings = i.InvestigationFindings,
                                                          RootCauseAnalysis = i.RootCauseAnalysis,
                                                          ImmediateActionTaken = i.ImmediateActionTaken,
                                                          IncidentStatus = i.IncidentStatus,
                                                          TargetClosureDate = i.TargetClosureDate,
                                                          CorrectiveActionsImplemented = i.CorrectiveActionsImplemented,
                                                          //ReportedUserName = u.Name,
                                                          //DateReported = r.CreatedDate,
                                                          ReferenceIncidentId = r.Id,
                                                          ActionTekenBy = u.Name,
                                                          ActionTekenOn = i.ModifiedDate
                                                      }).OrderByDescending(x=>x.Id);

            if (page != -1)
                Query = Query.Skip((page - 1) * pageSize);
            if (pageSize != -1)
                Query = Query.Take(pageSize);

            return await Query.ToListAsync();

        }
        public async Task<int> GetActionTakenReportsCount(int loggedInUserDBId, string loggedInUserOrganizationCode, int incidentId, string userRole, string filter = null, string search = null)
        {
            return await (from i in _db.ActionTakenReport.Where(x => x.IsDeleted == false 
                                                                && x.ReferenceIncidentId == (incidentId == 0 ? x.ReferenceIncidentId : incidentId)
                                                                && x.OrganizationCode == loggedInUserOrganizationCode)
                          join r in _db.IncidentReport.Where(x => x.IsDeleted == false) on i.ReferenceIncidentId equals r.Id
                          join c in _db.IncidentCategory.Where(x => x.IsDeleted == false) on r.IncidentCategoryId equals c.Id
                          join ia in _db.IncidentAssignment.Where(x => x.IsDeleted == false && (x.PrimaryAssignToId == loggedInUserDBId || x.SecondaryAssignToId == loggedInUserDBId || userRole == Helper.RoleCode.IRT_Client_Admin || userRole == Helper.RoleCode.EHS_Monitor))
                                                                                        on r.Id equals ia.ReferenceIncidentId
                          join u in _db.UserMaster on r.CreatedBy equals u.Id
                          //where (i.IsDeleted == false && i.OrganizationCode == loggedInUserOrganizationCode)
                          select i.Id).CountAsync();
        }
    }
}

