﻿using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Linq;
using System.Threading.Tasks;
using User.API.APIModel;
using User.API.Data;
using User.API.Helper;
using User.API.Models;
using User.API.Repositories.Interface;

namespace User.API.Repositories
{
    public class UserMasterRepository : Repository<UserMaster>, IUserMasterRepository
    {
        private readonly string _notificationBaseUrl;
        private readonly IOptions<AppSetting> _settings;
        private UserDbContext _db;
        private readonly ICompetencyRepository _competencyRepository;
        public UserMasterRepository(UserDbContext context, IOptions<AppSetting> settings, ICompetencyRepository competencyRepository) : base(context)
        {
            this._db = context;
            _settings = settings;
            _notificationBaseUrl = $"{settings.Value.NotificationUrl}";
            _competencyRepository = competencyRepository;
        }

        public async Task<APIUserDetails> GetUserDetails(int userMasterId, string token)
        {
            try
            {
                string tokenLastTwentychars = token.TokenLastNumberOfChars(20);

                using (DbConnection connection = this._db.Database.GetDbConnection())
                {
                    if (connection.State == ConnectionState.Broken || connection.State == ConnectionState.Closed)
                        connection.Open();

                    APIUserDetails user = null;
                    using (var cmd = connection.CreateCommand())
                    {
                        cmd.CommandText = "GetUserDetails";
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.Add(new SqlParameter("@UserMasterId", SqlDbType.Int) { Value = userMasterId });
                        cmd.Parameters.Add(new SqlParameter("@Token", SqlDbType.VarChar) { Value = tokenLastTwentychars });

                        DbDataReader reader = await cmd.ExecuteReaderAsync();
                        DataTable dt = new DataTable();
                        dt.Load(reader);

                        if (dt.Rows.Count > 0)
                        {
                            foreach (DataRow row in dt.Rows)
                            {
                                user = new APIUserDetails
                                {
                                    GuId = Guid.Parse(row["GuId"].ToString()),
                                    Name = row["Name"].ToString(),
                                    MobileNumber = row["MobileNumber"].ToString(),
                                    EmployeeCode = row["EmployeeCode"].ToString(),
                                    Role = row["Role"].ToString(),
                                    Status = row["Status"].ToString(),
                                    //FirstLoginDate = string.IsNullOrEmpty(row["FirstLoginDate"].ToString()) ? (DateTime?)null : Convert.ToDateTime(row["FirstLoginDate"].ToString()),
                                    LastLoggedInTime = string.IsNullOrEmpty(row["LastLoggedInTime"].ToString()) ? null : row["LastLoggedInTime"].ToString(),
                                    UserProfilePic = string.IsNullOrEmpty(row["UserProfilePic"].ToString()) ? null : row["UserProfilePic"].ToString(),
                                    AllowToLogin = CheckAccountValidityDate(row["AccountValidityDate"].ToString()),
                                    IsFirstLogin = (bool)row["IsFirstLogin"],
                                    DomainName = GetDecryptedDomainName(row["DomainName"].ToString()),
                                    DeliveryModel = row["DeliveryModel"].ToString(),
                                    Organization = row["Organization"].ToString(),
                                    OrganizationCode = row["OrganizationCode"].ToString(),
                                    AppName = row["AppName"] == null ? "" : row["AppName"].ToString(),
                                    RGBCode = row["RGBCode"] == null ? "#213958" : row["RGBCode"].ToString(),
                                    BaseLocation = row["BaseLocation"] == null ? "" : row["BaseLocation"].ToString(),
                                    GeoFencingDistance = row["GeoFencingDistance"] == null ? 0 : int.Parse(row["GeoFencingDistance"].ToString())
                                };
                            }
                        }
                        reader.Dispose();
                    }
                    connection.Close();
                    return user;
                }
            }
            catch (System.Exception ex)
            {
                throw ex;
            }
        }

        private string GetDecryptedDomainName(string val)
        {
            try
            {
                string domainName = val;

                if (!String.IsNullOrEmpty(val))
                {
                    domainName = Security.Decrypt(val);
                    if (String.IsNullOrEmpty(domainName))
                        return string.Empty;
                    domainName = domainName.Substring(0, (domainName.Length) - 5);
                    domainName = domainName.ToLower();
                    //if (domainName.Contains(".com"))
                    //    return domainName.Replace(".com", "");
                    //else
                    return domainName;
                }
                return domainName;
            }
            catch(Exception)
            {
            }
            return string.Empty;
        }

        private bool CheckAccountValidityDate(string accountValidityDate)
        {
            if (!string.IsNullOrEmpty(accountValidityDate))
            {
                try
                {
                    var AccountValidityDate = Security.Decrypt(accountValidityDate);
                    DateTime validityDate = Convert.ToDateTime(AccountValidityDate.Substring(0, (AccountValidityDate.Length) - 5));

                    if (validityDate.Date < DateTime.Today.Date)
                        return false;
                    else
                        return true;
                }
                catch(Exception)
                {
                    return false;
                }
            }
            return false;
        }

        public async Task<UserMaster> GetUserData(Guid guid)
        {
            return await _db.UserMaster.Where(am => am.GuId == guid).FirstOrDefaultAsync();
        }

        public async Task<List<APIUserDetails>> GetUsersForPA(int page, int pageSize, string filter = null, string search = null)
        {
            IQueryable<APIUserDetails> Query = (from userMaster in _db.UserMaster
                                                join org in this._db.OrganizationInfo on userMaster.OrganizationCode equals org.OrganizationCode
                                                join configValues in _db.ConfigurableValues on userMaster.Role equals configValues.ValueCode
                                                where (userMaster.IsDeleted != true && userMaster.Role == "CA")
                                                select new APIUserDetails
                                                {
                                                    Id = userMaster.Id,
                                                    GuId = userMaster.GuId,
                                                    Name = userMaster.Name,
                                                    MobileNumber = userMaster.MobileNumber,
                                                    Role = configValues.ValueName,
                                                    Status = userMaster.Status,
                                                    EmployeeCode = userMaster.EmployeeCode,
                                                    Email = userMaster.Email,
                                                    LastLoggedInTime = (_db.LoggedInHistory.Where(x=> x.UserMasterId == userMaster.Id).OrderByDescending(x=>x.Id).Take(1).Select(x=>x.LoggedInTime).LastOrDefault()).ToString("dd-MMM-yyyy"),
                                                    CreatedBy = userMaster.CreatedBy,
                                                    Organization = org.OrganizationName,
                                                    Designation = userMaster.Designation,
                                                }).OrderByDescending(a => a.Id);

            if (!string.IsNullOrEmpty(search) && !string.IsNullOrEmpty(filter))
            {
                switch (filter.ToLower())
                {
                    case "name":
                        Query = Query.Where(r => r.Name.Contains(search)).OrderByDescending(r => r.Name);
                        break;
                    case "mobilenumber":
                        Query = Query.Where(r => r.MobileNumber.StartsWith(search)).OrderByDescending(r => r.MobileNumber);
                        break;
                }
            }

            if (page != -1)
                Query = Query.Skip((page - 1) * pageSize);
            if (pageSize != -1)
                Query = Query.Take(pageSize);

            return await Query.ToListAsync();
        }

        public async Task<int> GetUsersCount(string filter = null, string search = null)
        {
            if (!string.IsNullOrEmpty(search) && !string.IsNullOrEmpty(filter))
            {
                switch (filter.ToLower())
                {
                    case "name":
                        return await this._db.UserMaster.Where(s => s.IsDeleted != true && s.Name.Contains(search)).CountAsync();
                    //case "userid":
                    //    return await this._db.UserMaster.Where(s => s.IsDeleted != true && s.UserId.StartsWith(search)).CountAsync();
                    case "mobilenumber":
                        return await this._db.UserMaster.Where(s => s.IsDeleted != true && s.MobileNumber.StartsWith(search)).CountAsync();
                }

                return await this._db.UserMaster.Where(s => s.IsDeleted != true).CountAsync();
            }
            else
                return await this._db.UserMaster.Where(s => s.IsDeleted != true).CountAsync();
        }

        public async Task<int> GetUsersForPACount(string filter = null, string search = null)
        {
            return await (from userMaster in _db.UserMaster
                          join org in this._db.OrganizationInfo on userMaster.OrganizationCode equals org.OrganizationCode
                          join configValues in _db.ConfigurableValues on userMaster.Role equals configValues.ValueCode
                          where (userMaster.IsDeleted != true && userMaster.Role == "CA")
                          select (userMaster.Id)).CountAsync();
        }

        public async Task<List<APIUserDetails>> GetUsersForCA(string loggedInUserOrganizationCode, int page, int pageSize, string filter = null, string search = null)
        {
            IQueryable<APIUserDetails> Query = (from userMaster in _db.UserMaster
                                                join org in this._db.OrganizationInfo on userMaster.OrganizationCode equals org.OrganizationCode
                                                join roles in _db.RolesConfiguration.Where(x=>x.OrganizationCode == loggedInUserOrganizationCode) on userMaster.Role equals roles.OriginalRoleCode
                                                join d in _db.Department on userMaster.DepartmentId equals d.Id.ToString()
                                                into dTbl
                                                from d in dTbl.DefaultIfEmpty()
                                                where (userMaster.IsDeleted != true && userMaster.Role != "PA" && userMaster.OrganizationCode == loggedInUserOrganizationCode)
                                                select new APIUserDetails
                                                {
                                                    Id = userMaster.Id,
                                                    GuId = userMaster.GuId,
                                                    Name = userMaster.Name,
                                                    MobileNumber = userMaster.MobileNumber,
                                                    Role = roles.ChangedRoleDescription,
                                                    RoleCode = roles.OriginalRoleCode,
                                                    Status = userMaster.Status,
                                                    EmployeeCode = userMaster.EmployeeCode,
                                                    CreatedBy = userMaster.CreatedBy,
                                                    Organization = org.OrganizationName,
                                                    Department=d.Name,
                                                    Email = userMaster.Email,
                                                    LastLoggedInTime = (_db.LoggedInHistory.Where(x => x.UserMasterId == userMaster.Id).OrderByDescending(x => x.Id).Take(1).Select(x => x.LoggedInTime).LastOrDefault()).ToString("dd-MMM-yyyy"),
                                                    Designation = userMaster.Designation,
                                                    CompetencyIds = userMaster.CompetencyIds
                                                }).OrderByDescending(a => a.Id);

            if (!string.IsNullOrEmpty(search) && !string.IsNullOrEmpty(filter))
            {
                switch (filter.ToLower())
                {
                    case "name":
                        Query = Query.Where(r => r.Name.Contains(search)).OrderByDescending(r => r.Name);
                        break;
                    case "mobilenumber":
                        Query = Query.Where(r => r.MobileNumber.StartsWith(search)).OrderByDescending(r => r.MobileNumber);
                        break;
                    case "status":
                        Query = Query.Where(r => r.Status.ToLower() == search.ToLower()).OrderByDescending(r => r.Name);
                        break;
                    case "department":
                        Query = Query.Where(r => r.Department.Contains(search)).OrderByDescending(r => r.Name);
                        break;
                }
            }

            if (page != -1)
                Query = Query.Skip((page - 1) * pageSize);
            if (pageSize != -1)
                Query = Query.Take(pageSize);

            List<APIUserDetails> Users = await Query.ToListAsync();
            foreach (APIUserDetails inc in Users.Where(x => !string.IsNullOrWhiteSpace(x.CompetencyIds)))
            {
                inc.Competencies = new List<APICompetency>();
                inc.Competencies.AddRange(await _competencyRepository.GetCompetenciesAssignedToUser(loggedInUserOrganizationCode, inc.Id));
            }
            return Users;
        }

        public async Task<int> GetUsersForCACount(string loggedInUserOrganizationCode, string filter = null, string search = null)
        {
            IQueryable<APIUserDetails> Query = (from userMaster in _db.UserMaster
                                                join org in this._db.OrganizationInfo on userMaster.OrganizationCode equals org.OrganizationCode
                                                join roles in _db.RolesConfiguration.Where(x => x.OrganizationCode == loggedInUserOrganizationCode) on userMaster.Role equals roles.OriginalRoleCode
                                                join d in _db.Department on userMaster.DepartmentId equals d.Id.ToString()
                                                into dTbl
                                                from d in dTbl.DefaultIfEmpty()
                                                where (userMaster.IsDeleted != true && userMaster.Role != "PA" && userMaster.OrganizationCode == loggedInUserOrganizationCode)
                                                select new APIUserDetails
                                                {
                                                    Id = userMaster.Id,
                                                    GuId = userMaster.GuId,
                                                    Name = userMaster.Name,
                                                    MobileNumber = userMaster.MobileNumber,
                                                    Role = roles.ChangedRoleDescription,
                                                    RoleCode = roles.OriginalRoleCode,
                                                    Status = userMaster.Status,
                                                    EmployeeCode = userMaster.EmployeeCode,
                                                    CreatedBy = userMaster.CreatedBy,
                                                    Organization = org.OrganizationName,
                                                    Department = d.Name
                                                }).OrderByDescending(a => a.Id);

            if (!string.IsNullOrEmpty(search) && !string.IsNullOrEmpty(filter))
            {
                switch (filter.ToLower())
                {
                    case "name":
                        Query = Query.Where(r => r.Name.Contains(search)).OrderByDescending(r => r.Name);
                        break;
                    case "mobilenumber":
                        Query = Query.Where(r => r.MobileNumber.StartsWith(search)).OrderByDescending(r => r.MobileNumber);
                        break;
                    case "status":
                        Query = Query.Where(r => r.Status.ToLower() == search.ToLower()).OrderByDescending(r => r.Name);
                        break;
                    case "department":
                        Query = Query.Where(r => r.Department.Contains(search)).OrderByDescending(r => r.Name);
                        break;
                }
            }
            return await Query.CountAsync();
        }

        public async Task<int> GetActiveUsersCount(string loggedInUserOrganizationCode)
        {
            return await (from userMaster in _db.UserMaster
                          where (userMaster.IsDeleted != true && userMaster.Role != "PA" && userMaster.OrganizationCode == loggedInUserOrganizationCode && userMaster.Status == Status.Active)
                          select (userMaster.Id)).CountAsync();
        }

        public async Task<int> GetUserId(Guid guid)
        {
            return await _db.UserMaster.Where(am => am.GuId == guid).Select(am=>am.Id).FirstOrDefaultAsync();
        }

        public async Task<APIUserProfile> GetDetailsById(string loggedInUserOrganizationCode, string userRole, int id)
        {
            APIUserProfile profile = new APIUserProfile();
            if (userRole.Equals(Helper.RoleCode.IRT_Client_Admin))
            {
                profile = await (from u in _db.UserMaster
                              join d in _db.Department on u.OrganizationCode equals d.OrganizationCode
                              into dTbl
                              from d in dTbl.DefaultIfEmpty()
                              where (u.IsDeleted == false && u.Id == id && u.OrganizationCode == loggedInUserOrganizationCode)
                              select new APIUserProfile
                              {
                                  Id = u.Id,
                                  GuId = u.GuId,
                                  OrganizationCode = u.OrganizationCode,
                                  EmployeeCode = u.EmployeeCode,
                                  Name = u.Name,
                                  DepartmentId = Convert.ToInt32(u.DepartmentId),
                                  Department = d.Name,
                                  Designation = u.Designation,
                                  MobileNumber = u.MobileNumber,
                                  Email = u.Email,
                                  Role = "IRT Client Admin",
                                  ProfilePicUrl = u.ProfilePicUrl,
                                  CompetencyIds = u.CompetencyIds
                              }).FirstOrDefaultAsync();
                
                if (!string.IsNullOrWhiteSpace(profile.CompetencyIds))
                {
                    profile.Competencies = new List<APICompetency>();
                    profile.Competencies.AddRange(await _competencyRepository.GetCompetenciesAssignedToUser(loggedInUserOrganizationCode, profile.Id));
                }
                return profile;
                //return await result.FirstOrDefaultAsync();
            }
            else
            {
                profile = await (from u in _db.UserMaster
                              join r in _db.RolesConfiguration on u.OrganizationCode equals r.OrganizationCode
                              join d in _db.Department on u.OrganizationCode equals d.OrganizationCode
                              into dTbl
                              from d in dTbl.DefaultIfEmpty()
                              where (u.IsDeleted == false && u.Id == id && u.OrganizationCode == loggedInUserOrganizationCode && u.Role == r.OriginalRoleCode)
                              select new APIUserProfile
                              {
                                  Id = u.Id,
                                  GuId = u.GuId,
                                  OrganizationCode = u.OrganizationCode,
                                  EmployeeCode = u.EmployeeCode,
                                  Name = u.Name,
                                  DepartmentId = Convert.ToInt32(u.DepartmentId),
                                  Department = d.Name,
                                  Designation = u.Designation,
                                  MobileNumber = u.MobileNumber,
                                  Email = u.Email,
                                  Role = r.ChangedRoleDescription,
                                  ProfilePicUrl = u.ProfilePicUrl,
                                  CompetencyIds = u.CompetencyIds
                              }).FirstOrDefaultAsync();

                if (!string.IsNullOrWhiteSpace(profile.CompetencyIds))
                {
                    profile.Competencies = new List<APICompetency>();
                    profile.Competencies.AddRange(await _competencyRepository.GetCompetenciesAssignedToUser(loggedInUserOrganizationCode, profile.Id));
                }
                return profile;
            }            
        }

        public async Task<APIUserProfile> GetUser(string loggedInUserOrganizationCode, int id)
        {
            var userProfile = await (from u in _db.UserMaster
                               where (u.OrganizationCode == loggedInUserOrganizationCode && u.Id == id)
                               select new APIUserProfile
                               {
                                   Id = u.Id,
                                   GuId = u.GuId,
                                   OrganizationCode = u.OrganizationCode,
                                   EmployeeCode = u.EmployeeCode,
                                   Name = u.Name,
                                   DepartmentId = Convert.ToInt32(u.DepartmentId),
                                   Designation = u.Designation,
                                   MobileNumber = u.MobileNumber,
                                   Email = u.Email,
                                   ProfilePicUrl = u.ProfilePicUrl,
                                   CompetencyIds = u.CompetencyIds
                               }).FirstOrDefaultAsync();

            if (!string.IsNullOrWhiteSpace(userProfile.CompetencyIds))
            {
                userProfile.Competencies = new List<APICompetency>();
                userProfile.Competencies.AddRange(await _competencyRepository.GetCompetenciesAssignedToUser(loggedInUserOrganizationCode, userProfile.Id));
            }
            return userProfile;
        }

        public async Task<APIUser> GetUserDetails(string loggedInUserOrganizationCode)
        {
            var userProfile = (from u in _db.UserMaster
                               where (u.OrganizationCode == loggedInUserOrganizationCode && u.Role==RoleCode.IRT_Client_Admin)
                               select new APIUser
                               {
                                   UserId = u.Id,
                                   OrganizationCode = u.OrganizationCode,
                                   Name = u.Name,
                                   Mobile=u.MobileNumber,
                               });

            return await userProfile.FirstOrDefaultAsync();
        }

        public async Task<APIUserSecurityQuestion> GetUserSecurityQuestion(string loggedInUserOrganizationCode, int loggedInUserDbId)
        {
            var question = await (from u in _db.UserMaster.Where(x=>x.IsDeleted == false && x.OrganizationCode == loggedInUserOrganizationCode && x.Id == loggedInUserDbId)
                               join SQ in _db.SecurityQuestion on u.SecurityQuestionId equals SQ.Id
                               select new APIUserSecurityQuestion
                               {
                                   SecurityQuestionId = u.SecurityQuestionId,
                                   SecurityQuestion = SQ.Question,
                                   SecurityAnswer = u.SecurityAnswer,
                               }).FirstOrDefaultAsync();

            return question;
        }
    }
}
