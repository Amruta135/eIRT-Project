﻿using ImageMagick;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using System;
using System.IO;
using System.Threading.Tasks;
using User.API.Helper;
using User.API.Repositories.Interface;

namespace User.API.Repositories
{
    public class FileUploaderRepository : IFileUploaderRepository
    {
        private static IConfiguration _AppConfig { get; set; }
        private IWebHostEnvironment _env;

        public FileUploaderRepository(IConfiguration AppConfig, IWebHostEnvironment env)
        {
            _AppConfig = AppConfig;
            _env = env;

        }
        public async Task<string> Upload(EnumFileUploadFor uploadFor, EnumFileType fileType, IFormFile file, bool Compress)
        {
            string SavedFileName = "";
            if (fileType == EnumFileType.Image)
            {
                if (FileHelper.CheckIfImageFile(file))
                {
                    if (Compress)
                    {
                        string tempImgPath = FileHelper.GetSaveFilePath(EnumFileUploadFor.Temp);
                        string saveFilePath = FileHelper.GetSaveFilePath(uploadFor);
                        SavedFileName = await CompressAndSaveFile(tempImgPath, saveFilePath, file);
                        if (!string.IsNullOrEmpty(SavedFileName) && SaveThumb(saveFilePath, SavedFileName))
                        {
                            return SavedFileName;
                        }
                        return "";
                    }
                    else
                    {
                        string saveFilePath = FileHelper.GetSaveFilePath(uploadFor);
                        SavedFileName = await SaveFile(saveFilePath, file);
                        if (!string.IsNullOrEmpty(SavedFileName) && SaveThumb(saveFilePath, SavedFileName))
                        {
                            return SavedFileName;
                        }
                        return "";
                    }
                }
                return "";
            }
            if (fileType == EnumFileType.Document)
            {
                string saveFilePath = FileHelper.GetSaveFilePath(uploadFor);
                return await SaveFile(saveFilePath, file);
            }
            return "Invalid Operation";
        }

        public bool DeleteFile(EnumFileUploadFor uploadFor, string fileName)
        {
            bool deleted = false;
            if (fileName == null || fileName.Trim().Length == 0)
                return deleted;
            deleted = FileHelper.DeleteFile(uploadFor, fileName);
            return deleted;
        }
        /// Method to write file onto the disk
        public async Task<string> SaveFile(string PicDirPath, IFormFile file)
        {
            string fileName;
            string webRootPath = _env.WebRootPath;
            string contentRootPath = _env.ContentRootPath;
            try
            {
                var extension = "." + file.FileName.Split('.')[file.FileName.Split('.').Length - 1];
                fileName = DateTime.Now.Ticks.ToString() + extension;   //Create a new Name 
                                                                        //for the file due to security reasons.
                var path = Path.Combine(contentRootPath + PicDirPath, fileName);

                using (var bits = new FileStream(path, FileMode.Create))
                {
                    await file.CopyToAsync(bits);
                }
            }
            catch (Exception e)
            {
                return "";
            }
            return fileName;
        }

        public bool SaveThumb(string FromFilePath, string fileName)
        {
            string webRootPath = _env.WebRootPath;
            string contentRootPath = _env.ContentRootPath;
            try
            {
                string ext = new FileInfo(fileName).Extension;
                var ImgPath = Path.Combine(contentRootPath + FromFilePath, fileName);
                var savePath = Path.Combine(contentRootPath + FromFilePath + "\\Thumbs", fileName);

                using (MagickImage image = new MagickImage(ImgPath))
                {
                    image.Format = image.Format;
                    image.Quality = 85;
                    MagickGeometry size = new MagickGeometry(350, 200);
                    image.BackgroundColor = MagickColors.None; //MagickColor.FromRgb(151, 170, 170);
                    image.Resize(size);
                    image.Extent(size, Gravity.Center);
                    image.Crop(350, 200, Gravity.Center);
                    image.Trim();
                    image.RePage();
                    image.Write(Path.Combine(savePath));
                }
                if (File.Exists(ImgPath))
                {
                    return true;
                }
                return false;
            }
            catch (Exception e)
            {
                return false;
            }
        }

        public async Task<string> CompressAndSaveFile(string tempImgPath, string SaveImgPath, IFormFile file)
        {
            string fileName;
            try
            {
                var extension = "." + file.FileName.Split('.')[file.FileName.Split('.').Length - 1];
                fileName = DateTime.Now.Ticks.ToString() + extension;   //Create a new Name 
                                                                        //for the file due to security reasons.
                string contentRootPath = _env.ContentRootPath;
                var ImgPath = Path.Combine(contentRootPath + tempImgPath, fileName);
                var CompressImgPath = Path.Combine(contentRootPath + SaveImgPath, fileName);

                using (var bits = new FileStream(ImgPath, FileMode.Create))
                {
                    await file.CopyToAsync(bits);

                    if (!ImageCompress(ImgPath, CompressImgPath))
                        return "";
                }
                if (File.Exists(ImgPath))
                {
                    File.Delete(ImgPath);
                    //return true;
                }
            }
            catch (Exception e)
            {
                return "";
            }
            return fileName;
        }

        public static bool ImageCompress(string ImgPath, string CompressedImgPath)
        {
            try
            {
                using (MagickImage image = new MagickImage(ImgPath))
                {
                    image.Format = image.Format;
                    image.Quality = 75;
                    //image.Resize(image.Width, image.Height);
                    MagickGeometry size = new MagickGeometry(1024, 768);
                    image.BackgroundColor = MagickColors.None; //MagickColor.FromRgb(151, 170, 170);
                    image.Resize(size);
                    image.Extent(size, Gravity.Center);
                    image.Crop(1024, 768, Gravity.Center);
                    image.Trim();
                    image.RePage();
                    image.Write(Path.Combine(CompressedImgPath));
                }
                return true;
            }
            catch (Exception e)
            {
                if (File.Exists(ImgPath))
                {
                    File.Delete(ImgPath);
                }
                return false;
            }
            return false;
        }
        public static bool ImageResize(int Width, int Height, string ImgPath, string ResizeImgPath)
        {
            try
            {
                using (MagickImage image = new MagickImage(ImgPath))
                {
                    MagickGeometry size = new MagickGeometry(Width, Height);
                    if (Width == 0 || Height == 0)
                        size.IgnoreAspectRatio = true;

                    image.Resize(size);
                    image.Format = image.Format;
                    image.Quality = 75;
                    image.Write(Path.Combine(ResizeImgPath));
                    return true;
                }
            }
            catch (Exception e)
            {
                if (File.Exists(ImgPath))
                {
                    File.Delete(ImgPath);
                }
                return false;
            }
        }
    }
}

