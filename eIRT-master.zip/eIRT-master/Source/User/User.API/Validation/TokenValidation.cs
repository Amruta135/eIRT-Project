﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using System;
using System.Threading.Tasks;
using User.API.Repositories.Interface;

namespace User.API.Validation
{
    public class TokenValidation
    {
        public class TokenValidAttribute : TypeFilterAttribute
        {
            public TokenValidAttribute() : base(typeof(TokenValidFilter))
            {
            }
        }

        public class TokenValidFilter : IAsyncActionFilter
        {
            readonly ITokenExpiredRepository _tokenExpiredRepository;

            public TokenValidFilter(ITokenExpiredRepository tokenExpiredRepository)
            {
                this._tokenExpiredRepository = tokenExpiredRepository;
            }

            public async Task OnActionExecutionAsync(ActionExecutingContext context, ActionExecutionDelegate next)
            {
                string userToken = context.HttpContext.Request.Headers["Authorization"].ToString() == null ? null : context.HttpContext.Request.Headers["Authorization"].ToString();
                bool expiredToken = false;
                if (!string.IsNullOrEmpty(userToken))
                {
                    string tokenLastTwentychars = userToken.TokenLastNumberOfChars(20);

                    if (await this._tokenExpiredRepository.TokenExists(tokenLastTwentychars))
                        expiredToken = true;
                }

                if (expiredToken)
                {
                    context.Result = new CustomUnauthorizedResult("Invalid Token!");
                }
                else
                {
                    await next();
                }
            }

            public class CustomUnauthorizedResult : JsonResult
            {
                public CustomUnauthorizedResult(string message)
                    : base(new CustomError(message))
                {
                    StatusCode = StatusCodes.Status401Unauthorized;
                }
            }
            public class CustomError
            {
                public string Error { get; }
                public CustomError(string message)
                {
                    Error = message;
                }
            }
        }
    }
}

