﻿using System;
using System.ComponentModel.DataAnnotations;

namespace User.API.Models
{
    public class ActionTakenReport : BaseEntity
    {
        public int Id { get; set; }
        [MaxLength(7)]
        [Required]
        public string OrganizationCode { get; set; }
        public int ReferenceIncidentId { get; set; }
        public string InvestigationFindings { get; set; }
        public string RootCauseAnalysis { get; set; }
        public string ImmediateActionTaken { get; set; }
        public string IncidentStatus { get; set; }
        public DateTime TargetClosureDate { get; set; }
        public string CorrectiveActionsImplemented { get; set; }
    }
}
