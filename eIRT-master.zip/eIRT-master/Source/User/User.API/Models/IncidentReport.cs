﻿using System;
using System.ComponentModel.DataAnnotations;

namespace User.API.Models
{
    public class IncidentReport : BaseEntity
    {
        public int Id { get; set; }
        [MaxLength(7)]
        [Required]
        public string OrganizationCode { get; set; }
        public int IncidentCategoryId { get; set; }
        [MaxLength(100)]
        public string IncidentLocation { get; set; }
        public int LinkedToDepartmentId { get; set; }
        [MaxLength(500)]
        public string Description { get; set; }
        [MaxLength(100)]
        public string Photo { get; set; }
        [MaxLength(500)]
        public string AdditionalDescription { get; set; }
        public string Status { get; set; }
        public bool IsAssigned { get; set; } = false;
        public int ClosurePeriod { get; set; } = 0;
        public string CompetencyIds { get; set; }

        public DateTime ClosureDate { get; set; }
    }
}
