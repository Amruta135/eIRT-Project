﻿using System.ComponentModel.DataAnnotations;

namespace User.API.Models
{
    public class States
    {
        public int Id { get; set; }
        [MaxLength(10)]
        public string Code { get; set; }
        [MaxLength(100)]
        public string Name { get; set; }
        public bool IsDeleted { get; set; }

        public int DisplayOrder { get; set; }
    }
}
