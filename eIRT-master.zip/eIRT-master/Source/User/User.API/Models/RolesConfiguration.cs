﻿using System.ComponentModel.DataAnnotations;

namespace User.API.Models
{
    namespace User.API.Models
    {
        public class RolesConfiguration : BaseEntity
        {
            public int Id { get; set; }
            [MaxLength(7)]
            [Required]
            public string OrganizationCode { get; set; }
            public string OriginalRoleCode { get; set; }
            public string OriginalRoleDescription { get; set; }
            public string ChangedRoleDescription { get; set; }

        }
    }
}
