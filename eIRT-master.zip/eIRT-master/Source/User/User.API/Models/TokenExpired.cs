﻿using System;

namespace User.API.Models
{
    public class TokenExpired
    {
        public int Id { get; set; }
        public DateTime CreatedDate { get; set; }
        public string Token { get; set; }
        public int UserId { get; set; }
        public bool IsDeleted { get; set; }
    }
}
