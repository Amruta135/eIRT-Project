﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace User.API.Models
{
    public class OrganizationInfo : BaseEntity
    {
        public int Id { get; set; }
        [MaxLength(7)]
        public string OrganizationCode { get; set; }
        [Required]
        public string OrganizationName { get; set; }
        [Required]
        [MaxLength(200)]
        public string Address { get; set; }
        [Required]
        [MaxLength(6)]
        public string Pincode { get; set; }
        [MaxLength(100)]
        public string City { get; set; }
        [MaxLength(100)]
        public string State { get; set; }
        [Required]
        [MaxLength(10)]
        public string MobileNumber { get; set; }
        [Url]
        [MaxLength(100)]
        public string Website { get; set; }
        [MaxLength(100)]
        public string DeliveryModel { get; set; }
        [Required]
        [MaxLength(100)]
        public string DomainName { get; set; }
        [Required]
        [MaxLength(100)]
        public string WorkflowOption { get; set; }
        [Required]
        public string NoofUsers { get; set; }
        [Required]
        public string AccountValidityDate { get; set; }
        [MaxLength(200)]
        public string Logo { get; set; }
        [MaxLength(50)]
        public string RGBCode { get; set; }

        [MaxLength(100)]
        public string AppName { get; set; }
        public string BaseLocation { get; set; }
        public int GeoFencingDistance { get; set; }
    }
}
