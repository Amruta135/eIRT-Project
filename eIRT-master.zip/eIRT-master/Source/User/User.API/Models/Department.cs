﻿using System.ComponentModel.DataAnnotations;

namespace User.API.Models
{
    public class Department : BaseEntity
    {
        public int Id { get; set; }
        [MaxLength(7)]
        [Required]
        public string OrganizationCode { get; set; }
        [MaxLength(100)]
        public string Name { get; set; }

        [MaxLength(50)]
        public string Code { get; set; }
    }
}
