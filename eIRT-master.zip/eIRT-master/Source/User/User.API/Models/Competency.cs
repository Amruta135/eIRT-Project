﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace User.API.Models
{
    public class Competency : BaseEntity
    {
        public int Id { get; set; }
        
        [MaxLength(7)]
        [Required]
        public string OrganizationCode { get; set; }

        [MaxLength(100)]
        [Required]
        public string CompetencyDescription { get; set; }
    }
}
