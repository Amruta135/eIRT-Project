﻿using System.ComponentModel.DataAnnotations;

namespace User.API.Models
{
    public class IncidentCategory : BaseEntity
    {
        public int Id { get; set; }
        [MaxLength(7)]
        [Required]
        public string OrganizationCode { get; set; }
        [MaxLength(100)]
        public string Category { get; set; }
    }
}
