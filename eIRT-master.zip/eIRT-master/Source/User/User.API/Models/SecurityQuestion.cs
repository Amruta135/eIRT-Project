﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace User.API.Models
{
    public class SecurityQuestion
    {
        public int Id { get; set; }
        [Required]
        [MaxLength(200)]
        public string Question { get; set; }
        public string Status { get; set; }
        public DateTime CreatedDate { get; set; }
    }
}
