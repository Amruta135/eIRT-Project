﻿using System.ComponentModel.DataAnnotations;

namespace User.API.Models
{
    public class PinCodes
    {
        public int Id { get; set; }
        [Required]
        [MaxLength(200)]
        public string PostOfficeName { get; set; }

        [Required]
        public int Pincode { get; set; }
        [Required]
        [MaxLength(100)]
        public string City { get; set; }

        [Required]
        [MaxLength(100)]
        public string District { get; set; }

        [Required]
        [MaxLength(100)]
        public string State { get; set; }

        [Required]
        [MaxLength(100)]
        public string StateCode { get; set; }

        public bool IsDeleted { get; set; }
    }
}
