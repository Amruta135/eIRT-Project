﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace User.API.Models
{
    public class IncidentAssignment : BaseEntity
    {
        public int Id { get; set; }
        [MaxLength(7)]
        [Required]
        public string OrganizationCode { get; set; }
        public int ReferenceIncidentId { get; set; }
        public int PrimaryAssignToId { get; set; }
        public int SecondaryAssignToId { get; set; }
        public DateTime AssignedDate { get; set; }
        [MaxLength(200)]
        public string Remarks { get; set; }
    }
}
