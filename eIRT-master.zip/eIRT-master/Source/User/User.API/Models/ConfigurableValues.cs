﻿using System.ComponentModel.DataAnnotations;

namespace User.API.Models
{
    public class ConfigurableValues : BaseEntity
    {
        public int Id { get; set; }
        [MaxLength(50)]
        public string TypeCode { get; set; }
        [MaxLength(200)]
        public string TypeName { get; set; }
        [MaxLength(50)]
        public string ValueCode { get; set; }
        [MaxLength(200)]
        public string ValueName { get; set; }
        public int Sequence { get; set; }
    }
}
