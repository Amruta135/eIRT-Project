﻿using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using User.API.Helper;
using User.API.MediatR.Command;
using User.API.MediatR.SMSSender;

namespace User.API.MediatR.Handler
{
    public class SendNewIncidentReportedHandler : IRequestHandler<SendNewIncidentReportedCommand, bool>
    {
        private readonly INotificationSender _smsSender;
        public SendNewIncidentReportedHandler(INotificationSender smsSender)
        {
            _smsSender = smsSender;
        }

        public async Task<bool> Handle(SendNewIncidentReportedCommand request, CancellationToken cancellationToken)
        {
            return await _smsSender.SendSMSAsync(Template.NewIncidentReported, request.JObject);
        }
    }
}
