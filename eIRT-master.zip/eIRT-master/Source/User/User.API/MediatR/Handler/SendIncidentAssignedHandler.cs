﻿using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using User.API.Helper;
using User.API.MediatR.Command;
using User.API.MediatR.SMSSender;

namespace User.API.MediatR.Handler
{
    public class SendIncidentAssignedHandler : IRequestHandler<SendIncidentAssignedCommand, bool>
    {
        private readonly INotificationSender _smsSender;
        public SendIncidentAssignedHandler(INotificationSender smsSender)
        {
            _smsSender = smsSender;
        }

        public async Task<bool> Handle(SendIncidentAssignedCommand request, CancellationToken cancellationToken)
        {
            return await _smsSender.SendSMSAsync(Template.IncidentAssigned, request.JObject);
        }
    }
}
