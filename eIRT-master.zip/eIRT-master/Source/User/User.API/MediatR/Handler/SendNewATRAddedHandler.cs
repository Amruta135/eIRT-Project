﻿using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using User.API.Helper;
using User.API.MediatR.Command;
using User.API.MediatR.SMSSender;

namespace User.API.MediatR.Handler
{
    public class SendNewATRAddedHandler : IRequestHandler<SendNewATRAddedCommand, bool>
    {
        private readonly INotificationSender _smsSender;
        public SendNewATRAddedHandler(INotificationSender smsSender)
        {
            _smsSender = smsSender;
        }

        public async Task<bool> Handle(SendNewATRAddedCommand request, CancellationToken cancellationToken)
        {
            return await _smsSender.SendSMSAsync(Template.NewATRAdded, request.JObject);
        }
    }
}
