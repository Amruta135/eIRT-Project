﻿using MediatR;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace User.API.MediatR.Command
{
    public class SendIRTAdminCreatesNewAccountCommand : IRequest<bool>
    {
        public SendIRTAdminCreatesNewAccountCommand()
        {
        }

        public JObject JObject { get; }

        public SendIRTAdminCreatesNewAccountCommand(JObject jObject)
        {
            JObject = jObject;
        }
    }
}
