﻿using MediatR;
using Newtonsoft.Json.Linq;

namespace User.API.MediatR.Command
{
    public class SendOTPCommand : IRequest<bool>
    {
        public SendOTPCommand()
        {
        }

        public JObject JObject { get; }

        public SendOTPCommand(JObject jObject)
        {
            JObject = jObject;
        }
    }
}
