﻿using MediatR;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace User.API.MediatR.Command
{
    public class SendNewATRAddedCommand : IRequest<bool>
    {
        public SendNewATRAddedCommand()
        {
        }

        public JObject JObject { get; }

        public SendNewATRAddedCommand(JObject jObject)
        {
            JObject = jObject;
        }
    }
}
