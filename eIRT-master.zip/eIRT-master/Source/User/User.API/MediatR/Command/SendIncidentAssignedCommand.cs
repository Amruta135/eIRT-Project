﻿using MediatR;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace User.API.MediatR.Command
{
    public class SendIncidentAssignedCommand : IRequest<bool>
    {
        public SendIncidentAssignedCommand()
        {
        }

        public JObject JObject { get; }

        public SendIncidentAssignedCommand(JObject jObject)
        {
            JObject = jObject;
        }
    }
}
