﻿using MediatR;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace User.API.MediatR.Command
{
    public class SendNewIncidentReportedCommand : IRequest<bool>
    {
        public SendNewIncidentReportedCommand()
        {
        }

        public JObject JObject { get; }

        public SendNewIncidentReportedCommand(JObject jObject)
        {
            JObject = jObject;
        }
    }
}
