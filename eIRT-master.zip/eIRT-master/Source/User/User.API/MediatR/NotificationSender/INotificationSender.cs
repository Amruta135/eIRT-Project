﻿using Newtonsoft.Json.Linq;
using System.Threading.Tasks;

namespace User.API.MediatR.SMSSender
{
    public interface INotificationSender
    {
        Task<bool> SendSMSAsync(string template, JObject jObject);
    }
}
