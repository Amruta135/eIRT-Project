﻿using Microsoft.Extensions.Options;
using Newtonsoft.Json.Linq;
using System;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using User.API.Helper;

namespace User.API.MediatR.SMSSender
{
    public class NotificationHandler : INotificationSender
    {
        private readonly IOptions<AppSetting> _settings;
        private readonly string _notificationBaseUrl;

        public NotificationHandler(IOptions<AppSetting> settings)
        {
            _settings = settings;
            _notificationBaseUrl = $"{settings.Value.NotificationUrl}";
        }
        public async Task<bool> SendSMSAsync(string template, JObject jObject)
        {
            bool result = false;
            string uri = null;
            switch (template)
            {
                case Template.OTP:
                    uri = _notificationBaseUrl + "/Notification/SendOTP";
                    result = await Send(uri, jObject);
                    break;
                case Template.IRTAdminCreatesNewAccount:
                    uri = _notificationBaseUrl + "/Notification/SendIRTAdminCreatesNewAccount";
                    result = await Send(uri, jObject);
                    break; 
                case Template.NewIncidentReported:
                    uri = _notificationBaseUrl + "/Notification/SendNewIncidentReported";
                    result = await Send(uri, jObject);
                    break;
                case Template.IncidentAssigned:
                    uri = _notificationBaseUrl + "/Notification/SendIncidentAssigned";
                    result = await Send(uri, jObject);
                    break;
                case Template.NewATRAdded:
                    uri = _notificationBaseUrl + "/Notification/SendNewATRAdded";
                    result = await Send(uri, jObject);
                    break;
            }
            return result;
        }

        private async Task<bool> Send(string uri, JObject jObject)
        {
            bool sent = false;
            try
            {
                var response = await CallAPI(uri, jObject);
                return response;
            }
            catch (Exception e)
            {
            }
            return sent;
        }

        private async Task<bool> CallAPI(string url, JObject oJsonObject, string token = null)
        {
            using (HttpClient client = new HttpClient())
            {
                //if (token != null)
                //{
                //    token = token.Replace("Bearer ", "");
                //    client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
                //}
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                string apiUrl = url;
                HttpResponseMessage response = await client.PostAsync(url, new StringContent(oJsonObject.ToString(), Encoding.UTF8, "application/json"));
                return response.IsSuccessStatusCode;
            }

        }
    }
}
