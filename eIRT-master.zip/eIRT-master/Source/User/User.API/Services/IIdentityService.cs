﻿namespace User.API.Services
{
    public interface IIdentityService
    {
        string GetUserIdentity();
        string GetUserId();
        string GetUserRole();
        string GetUserName();
        string GetToken();
        string GetName();
        string GetOrganizationCode();

    }
}
