﻿using Microsoft.AspNetCore.Http;
using System;

namespace User.API.Services
{
    public class IdentityService : IIdentityService
    {
        private IHttpContextAccessor _context;

        public IdentityService(IHttpContextAccessor context)
        {
            _context = context ?? throw new ArgumentNullException(nameof(context));
        }

        public string GetUserIdentity()
        {
            if (_context.HttpContext != null)
                return _context.HttpContext.User.FindFirst("sub").Value;
            else
                return null;
        }

        public string GetUserId()
        {
            if (_context.HttpContext != null)
                return _context.HttpContext.User.FindFirst("userId").Value;
            else
                return null;
        }

        public string GetUserName()
        {
            if (_context.HttpContext != null)
                return _context.HttpContext.User.FindFirst("username").Value;
            else
                return null;
        }

        public string GetName()
        {
            if (_context.HttpContext != null)
                return _context.HttpContext.User.FindFirst("name").Value;
            else
                return null;
        }
        public string GetUserRole()
        {
            if (_context.HttpContext != null)
                return _context.HttpContext.User.FindFirst("role").Value;
            else
                return null;
        }

        public string GetToken()
        {
            if (_context.HttpContext != null)
                return _context.HttpContext.Request.Headers["Authorization"].ToString();
            else
                return null;
        }
        public string GetOrganizationCode()
        {
            if (_context.HttpContext != null)
                return _context.HttpContext.User.FindFirst("kid").Value;
            else
                return null;
        }
    }
}
