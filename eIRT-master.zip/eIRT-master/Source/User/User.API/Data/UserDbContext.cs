﻿using Microsoft.EntityFrameworkCore;
using User.API.Models;
using User.API.Models.User.API.Models;

namespace User.API.Data
{
    public class UserDbContext : DbContext
    {
        public UserDbContext(DbContextOptions<UserDbContext> options) : base(options)
        {
        }
        public DbSet<UserMaster> UserMaster { get; set; }
        public DbSet<LoggedInHistory> LoggedInHistory { get; set; }
        public DbSet<Tokens> Tokens { get; set; }
        public DbSet<TokenExpired> TokenExpired { get; set; }
        public DbSet<PinCodes> PinCodes { get; set; }
        public DbSet<States> States { get; set; }
        public DbSet<OrganizationInfo> OrganizationInfo { get; set; }
        public DbSet<RolesConfiguration> RolesConfiguration { get; set; }
        public DbSet<Department> Department { get; set; }
        public DbSet<IncidentCategory> IncidentCategory { get; set; }
        public DbSet<IncidentReport> IncidentReport { get; set; }
        public DbSet<IncidentAssignment> IncidentAssignment { get; set; }
        public DbSet<ConfigurableValues> ConfigurableValues { get; set; }
        public DbSet<ActionTakenReport> ActionTakenReport { get; set; }
        public DbSet<SecurityQuestion> SecurityQuestion { get; set; }
        public DbSet<Competency> Competency { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
            modelBuilder.HasDefaultSchema("User");

            modelBuilder.Entity<UserMaster>().Property(x => x.GuId).HasDefaultValueSql("NEWID()");
        }
    }
}
