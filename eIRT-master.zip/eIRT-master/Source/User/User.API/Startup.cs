using AspNet.Security.OAuth.Introspection;
using AutoMapper;
using MediatR;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.FileProviders;
using Microsoft.OpenApi.Models;
using System;
using System.IO;
using User.API.Common;
using User.API.Data;
using User.API.Mapping;
using User.API.MediatR.SMSSender;
using User.API.Repositories;
using User.API.Repositories.Interface;
using User.API.Services;

namespace User.API
{
    public class Startup
    {
        public IConfiguration Configuration { get; }
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddMediatR(typeof(Startup));
            services.AddTransient<IUserMasterRepository, UserMasterRepository>();
            services.AddTransient(typeof(IExportManager<>), typeof(ExportManager<>));
            services.AddTransient<IIdentityService, IdentityService>();
            services.AddTransient<ITokensRepository, TokensRepository>();
            services.AddTransient<ITokenExpiredRepository, TokenExpiredRepository>();
            services.AddTransient<INotificationSender, NotificationHandler>();
            services.AddTransient<IOrganizationInfoRepository, OrganizationInfoRepository>();
            services.AddTransient<IStatesRepository, StatesRepository>();
            services.AddTransient<IPinCodesRepository, PinCodesRepository>();
            services.AddTransient<IFileUploaderRepository, FileUploaderRepository>();
            services.AddTransient<IRolesConfigurationRepository, RolesConfigurationRepository>();
            services.AddTransient<IDepartmentRepository, DepartmentRepository>();
            services.AddTransient<IIncidentCategoryRepository, IncidentCategoryRepository>();
            services.AddTransient<IIncidentReportRepository, IncidentReportRepository>();
            services.AddTransient<IIncidentAssignmentRepository, IncidentAssignmentRepository>();
            services.AddTransient<IActionTakenReportRepository, ActionTakenReportRepository>();
            services.AddTransient<ISecurityQuestionRepository, SecurityQuestionRepository>();
            services.AddTransient<ICompetencyRepository, CompetencyRepository>();

            services.AddOptions();
            services.Configure<AppSetting>(Configuration);

            ConfigureAuthService(services);
            services.AddDistributedMemoryCache();

            services.AddMvc();
            services.AddApiVersioning();
            services.AddCors(options =>
            {
                options.AddPolicy("AllowAllOrigins",
                builder =>
                {
                    builder.AllowAnyOrigin();
                });
            });

            var mappingConfig = new MapperConfiguration(mc =>
            {
                mc.AddProfile(new ModelToResourceProfile());
            });
            IMapper mapper = mappingConfig.CreateMapper();
            services.AddSingleton(mapper);
            //services.AddAutoMapper(typeof(Startup));

            services.AddDbContext<UserDbContext>(options =>
            {
                options.UseSqlServer(this.Configuration.GetConnectionString("DefaultConnection"));
                // opt => opt.EnableRetryOnFailure())
                // .UseQueryTrackingBehavior(QueryTrackingBehavior.NoTracking);
            });
            services.AddControllers();

            // Register the Swagger generator, defining 1 or more Swagger documents
            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v1", new OpenApiInfo { Title = "User", Version = "v1" });
            });
        }

        private void ConfigureAuthService(IServiceCollection services)
        {
            try
            {
                services.AddAuthentication(options =>
                {
                    options.DefaultScheme = OAuthIntrospectionDefaults.AuthenticationScheme;
                })
                .AddOAuthIntrospection(options =>
                {
                    options.Authority = new Uri(Configuration.GetValue<string>("IdentityUrl"));
                    options.Audiences.Add("user_api");
                    options.ClientId = "user_api";
                    options.ClientSecret = "ClientSecret";
                    options.RequireHttpsMetadata = false;
                });
            }
            catch (Exception)
            {

            }
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            //if (env.IsDevelopment())
            //{
            //    app.UseDeveloperExceptionPage();
            //}
            //else
            //{
            app.UseHttpStatusCodeExceptionMiddleware();
            //app.UseExceptionHandler();
            //}
            app.UseStaticFiles();
            app.UseSwagger();

            app.UseSwaggerUI(c =>
            {
                c.SwaggerEndpoint("/swagger/v1/swagger.json", "User V1");
            });

            app.UseStaticFiles(new StaticFileOptions
            {

                OnPrepareResponse = (context) =>
                {
                    if (!context.Context.User.Identity.IsAuthenticated)
                    {
                        //context.Context.Response.StatusCode = (int)HttpStatusCode.Unauthorized;
                        //throw new HttpStatusCodeException(statusCode.GetHashCode, "Please check username or password");
                        //throw new UnauthorizedAccessException("Access Restricted");
                        //throw new Exception("Access Restricted");
                        ////throw new HttpStatusCodeException(HttpStatusCode.Unauthorized, @"Access Restricted");
                    }
                },

                FileProvider = new PhysicalFileProvider(Path.Combine(Directory.GetCurrentDirectory(), "Uploded")),
                RequestPath = "/Uploded",
            });

            app.UseRouting();

            app.UseAuthorization();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });
        }
    }
}
