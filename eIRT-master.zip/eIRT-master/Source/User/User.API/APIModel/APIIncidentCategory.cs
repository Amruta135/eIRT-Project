﻿using System.ComponentModel.DataAnnotations;

namespace User.API.APIModel
{
    public class APIIncidentCategory
    {
        public int Id { get; set; }
        [MaxLength(100)]
        [Required]
        public string Category { get; set; }
    }
}
