﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace User.API.APIModel
{
    public class APIFileBase64Model
    {
        public int Id { get; set; }
        public Guid GuId { get; set; }
        public string FileName { get; set; }
        public string FileBase64 { get; set; }
        public string Caption { get; set; }
    }
}
