﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace User.API.APIModel
{
    public class APIHeaderForExport
    {
        public APIHeaderForExport(string name, string value, string newValue)
        {
            this.Name = name;
            this.Value = value;
            this.NewValue = newValue;
        }

        public string Name { get; set; }
        public string Value { get; set; }
        public string NewValue { get; set; }
    }
}
