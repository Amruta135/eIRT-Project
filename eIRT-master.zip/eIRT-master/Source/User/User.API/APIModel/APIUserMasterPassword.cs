﻿using System;
using System.ComponentModel.DataAnnotations;

namespace User.API.APIModel
{
    public class APIUserMasterPassword
    {
        [Required]
        public Guid GuId { get; set; }

        [Required]
        [StringLength(16, ErrorMessage = "The {0} must be at least {2} and maximum {1} characters long.", MinimumLength = 8)]
        [RegularExpression(@"^[a-zA-Z0-9_-]+$", ErrorMessage = "Use letters, numbers and special charecters like '_' and '-' only ")]
        public string UserId { get; set; }

        //[Required]
        //[MaxLength(10)]
        //public string OTP { get; set; }

        [Required]
        [RegularExpression(@"^([a-zA-Z0-9@*#]{8,16})$", ErrorMessage = "Password length should be min 8 characters long which contains alfanumeric and special character!")]
        public string Password { get; set; }

        //[Required]
        [MaxLength(10)]
        public string MPin { get; set; }
    }
}
