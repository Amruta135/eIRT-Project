﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace User.API.APIModel
{
    public class APICompetency
    {
        public int Id { get; set; }

        public string OrganizationCode { get; set; }

        [MaxLength(100)]
        [Required]
        public string CompetencyDescription { get; set; }

        public string ModifiedBy { get; set; }
        public DateTime ModifiedDate { get; set; }
    }
}
