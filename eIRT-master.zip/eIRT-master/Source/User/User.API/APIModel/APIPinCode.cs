﻿using System.Collections.Generic;

namespace User.API.APIModel
{
    public class APIPinCode
    {
        public int Pincode { get; set; }
        public string PostOfficeName { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public string StateCode { get; set; }
    }
    public class APICities
    {
        public string CityCode { get; set; }
        public string City { get; set; }
    }

    public class APIPostalPinCode
    {
        public int Pincode { get; set; }
        public string PostOfficeName { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public string District { get; set; }
    }

    public class PostOfficeResult
    {
        public string Message { get; set; }
        public string Status { get; set; }
        public List<PostOffice> PostOffice { get; set; }
    }
    public class PostOffice
    {
        public string Name { get; set; }
        public string Description { get; set; }
        public string BranchType { get; set; }
        public string DeliveryStatus { get; set; }
        public string Taluk { get; set; }
        public string Circle { get; set; }
        public string District { get; set; }
        public string Division { get; set; }
        public string Region { get; set; }
        public string State { get; set; }
        public string Country { get; set; }
    }
}
