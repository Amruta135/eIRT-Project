﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace User.API.APIModel
{
    public class APIOrganizationInfo
    {
        public int Id { get; set; }
        [MaxLength(7)]
        public string OrganizationCode { get; set; }
        [Required]
        public string OrganizationName { get; set; }
        [Required]
        [MaxLength(200)]
        public string Address { get; set; }
        [Required]
        [MaxLength(6)]
        public string Pincode { get; set; }
        [MaxLength(100)]
        public string City { get; set; }
        [MaxLength(100)]
        public string State { get; set; }
        [Required]
        [MaxLength(10)]
        public string MobileNumber { get; set; }
        //[Url]
        [MaxLength(100)]
        [RegularExpression(@"(http://)?(www\.)?\w+\.(com|net|edu|org)", ErrorMessage = "Please add correct Website!")]
        public string Website { get; set; }
        [MaxLength(100)]
        public string DeliveryModel { get; set; }
        //[Required]
        [MaxLength(100)]
        public string DomainName { get; set; }
        [Required]
        [MaxLength(100)]
        public string WorkflowOption { get; set; }
        [Required]
        [Range(5, 9999)]
        public int NoofUsers { get; set; }
        [Required]
        public DateTime AccountValidityDate { get; set; }
        [MaxLength(200)]
        public string Logo { get; set; }
        public string LogoBase64 { get; set; }
        [MaxLength(50)]
        public string RGBCode { get; set; }
        public int CreatedBy { get; set; }

        [MaxLength(100)]
        public string AppName { get; set; }
        public bool HasAdmin { get; set; }

        public string BaseLocation { get; set; }
        [Range(0,4000)]
        public int GeoFencingDistance { get; set; }
    }

    public class APIOrganizationInfo_Internal
    {
        public int Id { get; set; }
        [MaxLength(7)]
        public string OrganizationCode { get; set; }
        [Required]
        public string OrganizationName { get; set; }
        [Required]
        [MaxLength(200)]
        public string Address { get; set; }
        [Required]
        [MaxLength(6)]
        public string Pincode { get; set; }
        [MaxLength(100)]
        public string City { get; set; }
        [MaxLength(100)]
        public string State { get; set; }
        [Required]
        [MaxLength(10)]
        public string MobileNumber { get; set; }
        //[Url]
        [MaxLength(100)]
        [RegularExpression(@"(http://)?(www\.)?\w+\.(com|net|edu|org)", ErrorMessage = "Please add correct Website!")]
        public string Website { get; set; }
        [MaxLength(100)]
        public string DeliveryModel { get; set; }
        //[Required]
        [MaxLength(100)]
        public string DomainName { get; set; }
        [Required]
        [MaxLength(100)]
        public string WorkflowOption { get; set; }
        [Required]
        public string NoofUsers { get; set; }
        [Required]
        public string AccountValidityDate { get; set; }
        [MaxLength(200)]
        public string Logo { get; set; }
        public string LogoBase64 { get; set; }
        [MaxLength(50)]
        public string RGBCode { get; set; }
        public int CreatedBy { get; set; }
        [MaxLength(100)]
        public string AppName { get; set; }
        public bool HasAdmin { get; set; }
    }

    public class APIId
    {
        public int Id { get; set; }
    }

    public class APIOrganizationLogo
    {
        [Required]
        public int Id { get; set; }

        [Required]
        public IFormFile LogoFile { get; set; }
    }
}
