﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace User.API.APIModel
{
    public class APIUserProfile
    {
        public int Id { get; set; }

        public Guid GuId { get; set; }

        public string OrganizationCode { get; set; }

        [Display(Name = "Employee Code")]
        [Required]
        [Remote("IsEmployeeCodeExist", "UserMaster", ErrorMessage = "Employee Code is already Exist!", AdditionalFields = "Id, OrganizationCode")]
        public string EmployeeCode { get; set; }

        [RegularExpression("^[a-zA-Z\\s]+$", ErrorMessage = "Accepts only Alphabets.")]
        [Required]
        public string Name { get; set; }

        [Display(Name = "Department")]
        [Range(0, int.MaxValue, ErrorMessage = "Please select!")]
        public int DepartmentId { get; set; }

        public string Department { get; set; }

        public string Designation { get; set; }

        [Display(Name = "Mobile Number")]
        [RegularExpression(@"^[0-9]{10}$", ErrorMessage = "Must have 10 digit long Number!")]
        [Remote("IsMobileNumberExist", "UserProfile", ErrorMessage = "Mobile Number is already exist!", AdditionalFields = "UserMasterGuId")]
        public string MobileNumber { get; set; }

        [EmailAddress]
        [Required]
        [Remote("IsEmailExist", "UserMaster", ErrorMessage = "Email is already Exist!", AdditionalFields = "Id, OrganizationCode")]
        public string Email { get; set; }

        [Required]
        public string Role { get; set; }

        [MaxLength(500)]
        [Display(Name = "Profile Picture")]
        public string ProfilePicUrl { get; set; }

        public string ProfilePicBase64 { get; set; }
        public string ProfilePicBase64WithoutMIMEType { get; set; }
        public string CompetencyIds { get; set; }
        public List<APICompetency> Competencies { get; set; }
    }
}
