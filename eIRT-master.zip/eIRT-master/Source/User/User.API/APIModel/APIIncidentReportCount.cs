﻿using System;

namespace User.API.APIModel
{
    public class APIIncidentReportCount
    {
        public int OpenIncidentCount { get; set; }
        public int AssignedIncidentCount { get; set; }
        public int WorkInProgressIncidentCount { get; set; }
        public int ClosedIncidentCount { get; set; }
        public double AverageClosuerPeriod { get; set; }
        public int DaysSinceLastIncident { get; set; }
    }

    public class APIDate
    {
        public DateTime Date { get; set; }
    }

}
