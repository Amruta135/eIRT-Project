﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace User.API.APIModel
{
    public class APIUserDetails
    {
        public int Id { get; set; }
        public Guid GuId { get; set; }
        [RegularExpression("^[a-zA-Z\\s]+$", ErrorMessage = "Accepts only Alphabets.")]
        [Required]
        public string Name { get; set; }
        [Required]
        public string MobileNumber { get; set; }
        [Required]
        public string EmployeeCode { get; set; }
        [Required]
        public string Role { get; set; }
        public string RoleCode { get; set; }
        public string Status { get; set; }
        public string LastLoggedInTime { get; set; }
        public string UserProfilePic { get; set; }
        public bool AllowToLogin { get; set; }
        [Required]
        public string OrganizationCode { get; set; }
        public string Organization { get; set; }
        public int DepartmentId { get; set; }
        public string Department { get; set; }
        public string Designation { get; set; }
        [Required]
        public string Email { get; set; }
        public string ProfilePicUrl { get; set; }

        public string ProfilePicBase64 { get; set; }
        public string OTP { get; set; }
        public int CreatedBy { get; set; }
        public bool IsFirstLogin { get; set; }
        public string DomainName { get; set; }
        public string DeliveryModel { get; set; }
        public string AppName { get; set; }
        public string RGBCode { get; set; }
        public string BaseLocation { get; set; }
        public int GeoFencingDistance { get; set; }
        public string CompetencyIds { get; set; }
        public List<APICompetency> Competencies { get; set; }
    }

    public class APIUserProfilePic
    {
        [Required]
        public int Id { get; set; }

        [Required]
        public Guid UserMasterGuId { get; set; }

        [Required]
        public IFormFile ProfilePic { get; set; }
    }

    public class APIUserProfilePicWithBase64
    {
        [Required]
        public Guid UserMasterGuId { get; set; }

        [Required]
        public string Base64String { get; set; }
    }

    public class APIUser
    {
        public string OrganizationCode { get; set; }
        public int UserId { get; set; }
        public string Name { get; set; }
        public string Mobile { get; set; }
    }
}
