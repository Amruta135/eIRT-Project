﻿using System.ComponentModel.DataAnnotations;

namespace User.API.APIModel
{
    public class APIDepartments
    {
        public int Id { get; set; }
        [MaxLength(100)]
        [Required]
        public string Name { get; set; }

        [MaxLength(50)]
        public string Code { get; set; }
    }

    public class APIDepartmentsWithOrganization
    {
        public string OrganizationCode { get; set; }
    }
}
