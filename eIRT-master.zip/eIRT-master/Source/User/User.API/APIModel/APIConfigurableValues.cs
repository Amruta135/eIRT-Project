﻿using System.ComponentModel.DataAnnotations;

namespace User.API.APIModel
{
    public class APIConfigurableValues
    {
        public int Id { get; set; }
        public string TypeCode { get; set; }
        [MaxLength(200)]
        public string TypeName { get; set; }
        public string Code { get; set; }
        public string Name { get; set; }
        public int Sequence { get; set; }
    }
}
