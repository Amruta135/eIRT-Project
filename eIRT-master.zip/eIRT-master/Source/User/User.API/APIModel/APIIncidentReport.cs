﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace User.API.APIModel
{
    public class APIIncidentReport
    {
        public int Id { get; set; }
        public int IncidentCategoryId { get; set; }
        [MaxLength(100, ErrorMessage = "Length should be less than 100 characters!")]
        public string IncidentCategory { get; set; }
        [MaxLength(100, ErrorMessage = "Length should be less than 100 characters!")]
        public string IncidentLocation { get; set; }
        public int LinkedToDepartmentId { get; set; }
        public string LinkedToDepartment { get; set; }
        [MaxLength(90)]
        public string Description { get; set; }
        [MaxLength(100)]
        public string Photo { get; set; }
        public string PhotoBase64 { get; set; }
        [MaxLength(500)]
        public string AdditionalDescription { get; set; }
        public string Status { get; set; }
        public string ReportStatus { get; set; }
        public DateTime ReportedDate { get; set; }
        public string ReportedUserName { get; set; }
        public bool IsAssigned { get; set; } = false;
        public int PrimaryAssignedToId { get; set; }
        public string PrimaryAssignedTo { get; set; }
        public int SecondaryAssignedToId { get; set; }
        public string SecondaryAssignedTo { get; set; }
        public DateTime AssignmentDate { get; set; }
        public string RemarkByAdmin { get; set; }
        public DateTime ModifiedDate { get; set; }
        public string CompetencyIds { get; set; }
        public DateTime ClosureDate { get; set; }
        public List<APICompetency> Competencies { get; set; }
    }

    public class APIIncidentReportPhoto
    {
        [Required]
        public int Id { get; set; }

        [Required]
        public IFormFile PhotoFile { get; set; }
    }

    public class APIIncidentReportPhotoWithBase64
    {
        [Required]
        public int Id { get; set; }

        [Required]
        public string Base64String { get; set; }
    }

    public class APIOpenClosedIncidentSearch
    {
        public DateTime startDate { get; set; }
        public DateTime endDate { get; set; }
        public string status { get; set; }
        public int category { get; set; }
        public int departmentId { get; set; }
        public int month { get; set; }
        public int year { get; set; }
        public string CompetencyIds { get; set; }
    }

    public class APIOpenClosedIncidentReport
    {
        public string organizationName { get; set; }
        public string address { get; set; }
        public string city { get; set; }
        public string pinCode { get; set; }
        public List<APIOpenClosedIncidentInfo> reportDate { get; set; }
    }

    public class APIOpenClosedIncidentInfo
    {
        public int IncidentId { get; set; }
        public DateTime DateReported { get; set; }
        public string ReportedBy { get; set; }
        public string Designation { get; set; }
        public string BriefDescription { get; set; }
        public string IncidentCategory { get; set; }
        public string Status { get; set; }
        public DateTime? LastActionTaken { get; set; }
        public string CorrectiveActions { get; set; }
        public string ATRReportedBy { get; set; }
        public string Department { get; set; }
        public string CompetencyIds { get; set; }
        public DateTime ClosureDate { get; set; }
        public List<APICompetency> Competencies{ get; set; }
    }
}
