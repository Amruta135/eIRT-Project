﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace User.API.APIModel
{
    public class APIIncidentAssignment
    {
        public int Id { get; set; }
        [Required]
        public int ReferenceIncidentId { get; set; }
        public string ReferenceIncident { get; set; }
        public string Category { get; set; }
        public int PrimaryAssignToId { get; set; }
        public string PrimaryAssignToName { get; set; }
        public int SecondaryAssignToId { get; set; }
        public string SecondaryAssignToName { get; set; }
        public DateTime AssignedDate { get; set; }
        [MaxLength(200)]
        public string Remarks { get; set; }
        public string CompetencyIds { get; set; }
        public List<APICompetency> Competencies { get; set; }
        [Required]
        public DateTime ClosureDate { get; set; }
    }

    public class APIIsIncidentCreated
    {
        public int userId { get; set; }
        public int incidentId { get; set; }
    }
}

