﻿using System.ComponentModel.DataAnnotations;
using User.API.Helper;

namespace User.API.APIModel
{
    public class APIRolesConfigurations
    {
        public int Id { get; set; }
        [Validation.CustomValidation(AllowValue = new string[] { Role.Posiview_Admin, Role.IRT_Client_Admin, Role.EHS_Monitor, Role.EHS_Manager, Role.EHS_Inspector })]
        public string OriginalRoleDescription { get; set; }
        [Required]
        public string ChangedRoleDescription { get; set; }
        public string OriginalRoleCode { get; set; }
    }

    public class APIOrganizationCode
    {
        public string OrganizationCode { get; set; }
    }
}
