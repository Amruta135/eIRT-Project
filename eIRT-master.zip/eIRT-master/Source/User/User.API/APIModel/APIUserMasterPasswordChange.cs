﻿using System;
using System.ComponentModel.DataAnnotations;

namespace User.API.APIModel
{
    public class APIUserMasterPasswordChange
    {
        public Guid GuId { get; set; }

        [Required]
        //[RegularExpression(@"^([a-zA-Z0-9@*#]{8,16})$", ErrorMessage = "Password length should be min 8 characters long which contains alfanumeric and special character!")]
        [RegularExpression(@"^(?=.*[0-9]+.*)(?=.*[a-zA-Z]+.*)[0-9a-zA-Z*@_-]{8,12}$", ErrorMessage = "Password length should be 8 to 12 and it should have minimum 1 character and 1 number!")]
        public string OldPassword { get; set; }

        [Required]
        //[RegularExpression(@"^([a-zA-Z0-9@*#]{8,16})$", ErrorMessage = "Password length should be min 8 characters long which contains alfanumeric and special character!")]
        [RegularExpression(@"^(?=.*[0-9]+.*)(?=.*[a-zA-Z]+.*)[0-9a-zA-Z*@_-]{8,12}$", ErrorMessage = "Password length should be 8 to 12 and it should have minimum 1 character and 1 number!")]
        public string Password { get; set; }

        [Required]
        [Range(1, int.MaxValue, ErrorMessage = "Please Select!")]
        public int SecurityQuestionID { get; set; }

        [Required(AllowEmptyStrings = false, ErrorMessage = "Please Enter!")]
        [StringLength(100, MinimumLength = 3, ErrorMessage = "Answer should be minimum 3 & maximum 100 chars long!")]
        public string Answer { get; set; }
    }

    public class APIUserSecurityQuestion
    {
        public int SecurityQuestionId { get; set; }
        public string SecurityQuestion { get; set; }
        public string SecurityAnswer { get; set; }
    }
}
