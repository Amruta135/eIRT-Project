﻿using System;
using System.ComponentModel.DataAnnotations;

namespace User.API.APIModel
{
    public class APIActionTakenReport
    {
        public int Id { get; set; }
        public int ReferenceIncidentId { get; set; }
        public string ReferenceIncident { get; set; }
        public string Category { get; set; }
        public string InvestigationFindings { get; set; }
        public string RootCauseAnalysis { get; set; }
        public string ImmediateActionTaken { get; set; }
        [Required]
        public string IncidentStatus { get; set; }
        [Required]
        public DateTime TargetClosureDate { get; set; }
        [Required(ErrorMessage = "The Corrective Actions Implemented field is required.")]
        public string CorrectiveActionsImplemented { get; set; }
        public DateTime DateReported { get; set; }
        public string ReportedUserName { get; set; }
        public string ActionTekenBy { get; set; }
        public DateTime ActionTekenOn { get; set; }
    }
}
